package Akar::Javascript::YUICode;
{
  $Akar::Javascript::YUICode::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor::Fast);

use Scalar::Util;
use Interpolation 'E' => 'eval';

use Carp qw(carp croak);

use Akar::Javascript::Code qw(jsexp jsliteral);

# returns the function
sub on_dom_ready {
    my ($this, $code) = @_;

    return <<"END_JS";
YAHOO.util.Event.onDOMReady(function(){
$E{ jsexp($code) }
});
END_JS
}

# installs the event listener
sub add_listener {
    my ( $this, $element_id, $event, $code ) = @_;

    return $this->on_dom_ready(<<"END_JS");
YAHOO.util.Event.addListener(
    $E{ jsliteral($element_id) }
    , $E{ jsliteral($event) }
    , $E{ jsexp($code) }
);
END_JS
}

# returns the function  
sub call_remote_javascript {
    my ($this, $ajax_url) = @_;

    # 2008-11-21 danielr
    # returned code is executed by eval
    # there used to be check for Content-Type
    # if (o.getResponseHeader['Content-Type'] == 'application/javascript')
    # but I removed it because
    # - I don't know what to do if Content-Type is different
    # - Content-type changed (charset was appended), should I check RE
    #
    # responseText contains code of anonymous function to be executed
    # 2008-07-01 danielr
    # the evaluation of anonymous function
    # var codeToRun = eval('function(){...}');
    # ends up with syntactic error in FF 3
    # so I changed it to 
    # var codeToRun = eval(o.responseText);

    return <<"END_JS";
function(){
    var ajax_uri = $E{ jsliteral($ajax_url) };
    YAHOO.util.Connect.asyncRequest('GET', ajax_uri, {
    success: function(o){
        var codeToRun;
        eval('codeToRun = ' + o.responseText);
        codeToRun();
        return;
    }
    });
}
END_JS
}

1;

__END__

=head1 NAME

Akar::Javascript::YUICode - fragments of frequently used Javascript code using YUI 

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
