package Akar::Log::Message::Structured::StringifyAsJSON;
{
  $Akar::Log::Message::Structured::StringifyAsJSON::VERSION = '1.994';
}
use strict;
use warnings;

use MooseX::Role::Parameterized;

use namespace::autoclean;
use JSON;

# how the keys are ordered
# for example ['date', qr{.*}, 'class']
parameter keys_order => ( isa => 'ArrayRef', default => sub { [] } );

parameter json => ( default => sub { return JSON->new->allow_nonref->ascii; } );

# serializes Message into JSON with keys in certain order
role {
    my $p = shift;

    # the prescription
    my $keys_order = $p->keys_order;
    my $json       = $p->json;

    my $order_keys = sub {
        my %keys_order_idx = map {
            my $k = $_;
            my $max_re;    # longest re
            my $idx;
            for my $i ( 0 .. $#$keys_order ) {
                my $p = $keys_order->[$i];
                if ( ref $p ) {
                    if ( $k =~ $p
                        && ( !$max_re || length($p) > length($max_re) ) )
                    {
                        $idx    = $i;
                        $max_re = $p;
                    }
                }
                elsif ( $k eq $p ) {
                    $idx = $i;
                    last;
                }
            }
            $k => ( $idx // scalar(@$keys_order) );
        } @_;

        return [
            sort { $keys_order_idx{$a} <=> $keys_order_idx{$b} || $a cmp $b }
                @_ ];
    };

    my %keys_for;

    requires 'as_hash';

    around as_string => sub {
        my $orig = shift;
        my $this = shift;
        my $hr   = $this->as_hash;

        # the ordering of a set of keys is preserved
        my $ordered = $keys_for{ join '|', keys %$hr }
            ||= $keys_for{ join '|', sort keys %$hr }
            ||= $order_keys->( keys %$hr );

        return "{"
            . join( ',',
            map { $json->encode($_) . ':' . $json->encode( $hr->{$_} ) }
                @$ordered )
            . "}";
    };
};


1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
