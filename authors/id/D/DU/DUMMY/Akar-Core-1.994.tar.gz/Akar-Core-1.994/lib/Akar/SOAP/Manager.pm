package Akar::SOAP::Manager;
{
  $Akar::SOAP::Manager::VERSION = '1.994';
}
use strict;
use warnings;

# SOAP::Transport::HTTP::Apache 
use base qw(Class::Accessor);

use Class::Trait qw(Akar::Trait::PackageConfig);

use Encode;
use FileHandle;
use File::Path qw(mkpath);
use File::Basename qw(dirname basename);
use File::Spec;
use File::Slurp qw(write_file slurp);
use Carp qw(croak carp);
use Sys::Hostname qw(hostname);
use List::MoreUtils qw(uniq);

use Akar::Base;
use Interpolation 'E' => 'eval';
use HTTP::Status qw(RC_FORBIDDEN RC_OK RC_NOT_FOUND RC_INTERNAL_SERVER_ERROR);
use Akar::Text::Mason;
use Akar::CLI;
#use Apache2::Const -compile => qw(FORBIDDEN OK);

# maximum waiting period until Apache dies
use constant 'APACHE_DEATH_TIMEOUT' => 20;

# initial period of waiting for apache death (very unimportant constant)
use constant 'APACHE_DEATH_START_WAIT' => 0.1,    # 0.1 second

__PACKAGE__->add_config_param('port');
__PACKAGE__->add_config_param( 'ssl_port'    => -1 );
__PACKAGE__->add_config_param( 'dispatch_to' => [] );
__PACKAGE__->add_config_mapping('dispatch_with');
__PACKAGE__->add_config_param( 'authorized_by' => [] );
__PACKAGE__->add_config_param( 'basic_auth'    => 0 );
__PACKAGE__->add_config_param( 'raw_logging'   => 0 );

# if single_request is set then only one request is served by child
__PACKAGE__->add_config_param( 'single_request' => 0 );

# mason template with the configuration
__PACKAGE__->add_config_param( 'httpd_conf_template' =>
        '/usr/local/etc/Akar-SOAP-Manager/httpd.conf.mc' );

# which apache should I run
__PACKAGE__->add_config_param('apache_binary' => '/usr/sbin/httpd');

sub build_cli {
    my ($this) = @_;

    my $cli = Akar::CLI->new( { 'title' => 'SOAP (Apache) server control' } );

    # Command line interface
    $cli->add_action(
        'start - Starts the apache',
        sub {
            $this->start_apache;
        }
    );
    $cli->add_action(
        'stop - Stops the apache',
        sub {
            $this->stop_apache;
        }
    );
    $cli->add_action(
        'restart - Stops the apache, wait until its PID disappear and start it again',
        sub {
            $this->restart_apache;
        }
    );
    $cli->add_action(
        'show - displays the current configuration (port, dispatched modules, ...)',
        sub {
            $this->show_config();
        }
    );

    return $cli;
}

sub run {
    my ($this) = shift;
    return $this->build_cli->run(@_);
}


# returns app_data root
sub app_data_root {
    return Akar::Base->app_data( join '-', split /::/, __PACKAGE__ );
}

# filename relative to instance_root
sub app_data_path {
    my ( $this, $filename ) = @_;
    return File::Spec->rel2abs( $filename, $this->app_data_root );
}

sub logpath {
    my ( $this, $log_filename ) = @_;

    my $log_subdir = 'logs';
    return $this->app_data_path( @_ == 1
        ? $log_subdir
        : File::Spec->catfile( $log_subdir, $log_filename ) );
}

# configuration file
sub apache_config_file { return shift()->app_data_path('httpd.conf'); }

sub raw_logging_file { return shift()->logpath('SOAP_raw_data.log'); }

# Apache basic authorization file
sub basic_auth_file { return shift()->app_data_path('htusers.pwd'); }

# returns file where PID is stored
sub pid_file { return shift()->logpath('httpd.pid'); }

sub install_apache_config {
    my ($this) = @_;

    mkpath( $this->logpath );
    warn "... installing ". $this->apache_config_file. "\n";
    write_file( $this->apache_config_file, $this->httpd_conf);
    return;
}

# returns URI of SOAP server 
sub soap_proxy_url {
    my ($this) = @_;

    return sprintf('http://%s:%s/soap/', hostname(), $this->port);
}

sub ssl_soap_proxy_url {
    my ($this) = @_;

    return if ! $this->uses_ssl;
    return sprintf('https://%s:%s/soap/', hostname(), $this->ssl_port);
}

sub wsdl_url {
    my ( $this, $package ) = @_;

    grep { $_ eq $package } @{$this->dispatch_to} 
        or croak "Package $package is not dispatched to\n";

    return sprintf( 'http://%s:%s/wsdl/%s',
        hostname(), $this->port, join( '/', split '::', $package ) );
}

sub httpd_conf {
    my ($this) = @_;

    # processes the template by the Mason
    my $httpd_conf;
    warn sprintf "Processing template %s\n", $this->httpd_conf_template;
    eval {
        $httpd_conf = Akar::Text::Mason->process_file($this->httpd_conf_template, $this);
    };
    die sprintf "Processing of the Mason httpd template '%s' failed: %s\n",
        $this->httpd_conf_template, $@
        if $@;
    return $httpd_conf;
} 

# returns the body of the apache config file
sub start_apache {
    my ($this) = @_;

    $this->install_apache_config;

    my $apache_pid = $this->apache_pid;
    !$apache_pid
        or croak "$0 start: httpd (pid $apache_pid) already running\n";

    my $httpd = join ' ', $this->apache_binary, '-f', $this->apache_config_file;
    system($httpd ) == 0
        or croak "$0 start: httpd ($httpd) could not be started: $!\n";

    warn "$0 start: httpd started\n";
}

sub stop_apache {
    my ($this) = @_;

    my $apache_pid = $this->apache_pid
        or croak "$0 stop: httpd not running\n";

    kill 'TERM', $apache_pid
        or croak "$0 stop: httpd could not be stopped\n";

    warn "$0 stop: httpd stopped\n";
}

sub apache_pid {
    my ($this) = @_;

    return if !-f $this->pid_file;

    my $apache_pid = 0 + FileHandle->new( $this->pid_file )->getline();

    # Process with the PID exists?
    return $apache_pid if kill 0, $apache_pid;
    return;
}

sub restart_apache {
    my ($this) = @_;

    if ( my $apache_pid = $this->apache_pid ) {
        $this->stop_apache;
        $this->wait_until_apache_dies($apache_pid);
    }
    $this->start_apache;
}

sub wait_until_apache_dies {
    require Time::HiRes;

    my ( $this, $apache_pid ) = @_;

    # waiting for until process really dies
    my $total_sleep     = 0;
    my $max_total_sleep = int( APACHE_DEATH_TIMEOUT * 1e6 ); # in microseconds
         # starts the wait with
    my $sleep      = int( APACHE_DEATH_START_WAIT * 1e6 );
    my $last_sleep = 0;
    while ( my $process_exists = kill 0, $apache_pid ) {
        croak
            "Even after $max_total_sleep microseconds the Apache hasn't stopped\n "
            if $total_sleep > $max_total_sleep;
        Time::HiRes::usleep($sleep);
        $total_sleep += $sleep;

        # fibonacci number - I heard that they are good for repetitive tries
        my $new_sleep = $sleep + ( $last_sleep || $sleep );
        $last_sleep = $sleep;
        $sleep      = $new_sleep;
    }
}

# checks whether the configuration is OK
sub check_config {
    my ($this) = @_;

    for my $dispatched ( @{ $this->dispatch_to } ) {
        eval qq{ require $dispatched };
        die "Require of dispatched module '$dispatched' failed: $@" if $@;
    }

    for my $auth_module ( @{ $this->authorized_by } ) {
        eval qq{ require $auth_module };
        die $@ if $@;
        die "Require of authorized_by module '$auth_module' failed: $@" if $@;
        $auth_module->can('authorize_soap_call')
            or die
            "Authorization module doesn't have authorize_soap_call method\n";
    }
}

sub show_config {
    my ($this) = @_;

    print <<"END_CONFIG";
Akar::SOAP::Manager

http port:  $E{ $this->port }    
https port: $E{ $this->ssl_port > 0 ? $this->ssl_port: 'NONE'}

dispatched modules:
  $E{ join("\n  ", @{$this->dispatch_to}) }

dispatched mapping:
$E{ 
    join( "\n",
        map { "  $_ => " . $this->dispatch_with->{$_} }
            keys %{ $this->dispatch_with } )
}

authentication:     $E{ $this->basic_auth? 'Basic': '-' }
authentication file: $E{ $this->basic_auth_file }
authenticated users: $E{
    do {
            my $baf = $this->basic_auth_file;
            -e $baf
                ? join(', ', map { /^(.*?):/ } slurp($baf))
                : "NONE - authorization file doesn't exist"
       }
    }

raw_logging:    $E{ $this->raw_logging? 'yes': 'no' }

END_CONFIG
}

sub uses_ssl {
    my ($this) = @_;

    return $this->ssl_port >= 0;
}

{
    my $server;

    sub soap_handler {
        my $this = __PACKAGE__;

        if ( !$server ) {

            # following code is copied from Apache::SOAP
            #   ($server has to be of Akar::SOAP::Apache class)
            $server = Akar::SOAP::Manager::SOAPHandler->new;
            $server->dispatch_to( @{ $this->dispatch_to } );
            $server->dispatch_with( $this->dispatch_with );
            $server->raw_logging_file( $this->raw_logging_file );
            $server->raw_logging( $this->raw_logging );
            $server->authorized_by( $this->authorized_by );

            # 2007-09-27 danielr, the response element may not use default_namespce
            $server->serializer->use_default_ns(0);
        }

        return $server->handle(@_);
    }
}

sub wsdl_handler {
    my $r    = shift;
    my $this = __PACKAGE__;

    # anonymous subroutine
    # wrapper recognizing between Apache1 - has send_http_header
    # and Apache2 which doesn't have it
    my $send_http_header_sub
        = Akar::SOAP::Manager::SOAPHandler::mod_perl_version() == 1
        ? sub {
        my $r = shift;
        $r->send_http_header(@_);
        }
        : sub { };

    # splice removes wsdl prefix from uri
    my $soap_package = join '::',
        splice @{ [ grep {$_} split m{/}, $r->uri ] }, 1;
    if ( grep { $soap_package eq $_ } @{ $this->dispatch_to } ) {
        eval {

            # wsdl handler uses https or http according to port it got
            my $location =
                  $r->get_server_port == $this->ssl_port
                ? $this->ssl_soap_proxy_url
                : $this->soap_proxy_url;

            # stupid determination of the service
            # Akar::SOAP::Service is used only for old packages
            # they come with Akar::SOAP::Service preloaded
            # so I don't require it here
            my $service
                = UNIVERSAL::can( 'Akar::SOAP::Service', 'get_by_package' )
                && Akar::SOAP::Service->get_by_package(
                $soap_package)    #old ones
                || $soap_package;    # new packages
            if ( $service->can('create_wsdl') ) {
                my $wsdl_content = $service->create_wsdl($location);
                $send_http_header_sub->($r);
                $r->print($wsdl_content);
            }
            else {

                # package doesn't produce WSDL
                $r->status(HTTP::Status::RC_NOT_FOUND);
                $send_http_header_sub->($r);
                $r->print(
                    "Service $soap_package doesn't produce WSDL description\n"
                );
            }
        };
        if ($@) {
            warn $@;
            $r->status(HTTP::Status::RC_INTERNAL_SERVER_ERROR);
            $send_http_header_sub->($r);
        }
    }
    else {

        # package is not dispatched
        $r->status(HTTP::Status::RC_NOT_FOUND);
        $send_http_header_sub->($r);
        $r->print("Service $soap_package is not provided by this server\n");
    }
}


{

    package Akar::SOAP::Manager::SOAPHandler;
{
  $Akar::SOAP::Manager::SOAPHandler::VERSION = '1.994';
}

    # using SOAP::Transport::HTTP must precede use base
    # since SOAP::Transport::HTTP::Apache has not its own module
    use SOAP::Transport::HTTP;
    use base qw(SOAP::Transport::HTTP::Apache Class::Accessor::Fast);

    # 2008-07-08 danielr
    # ze zoufalstvi kvuli Anoa SOAP serveru
    use SOAP::Lite; 
    $SOAP::Constants::DO_NOT_CHECK_MUSTUNDERSTAND = 1;

    use URI;

    # I copy some properties from Akar::SOAP::Manager to make the 
    # soap handler easier to test
    __PACKAGE__->mk_accessors(
        qw(current_user raw_logging raw_logging_file authorized_by));

    # hook for make fault
    sub unathorized_fault_code {
        return 'Client.UnauthorizedAccessToSOAPMethod';
    }

    {
        # mod perl version is computed just once
        my $mod_perl_version;

        sub mod_perl_version {
            return $mod_perl_version ||= _find_mod_perl_version();
        }
    }

    sub _find_mod_perl_version {
        # 2008-04-08 danielr
        # this code was shamelesly copied from SOAP::Lite 0.701
        # from SOAP/Transport/HTTP.pm

        # Added this code thanks to JT Justman
        # This code improves and provides more robust support for
        # multiple versions of Apache and mod_perl

        # mod_perl 2.0
        if ( defined $ENV{MOD_PERL_API_VERSION}
            && $ENV{MOD_PERL_API_VERSION} >= 2 )
        {
            require Apache2::RequestRec;
            require Apache2::RequestIO;
            require Apache2::Const;
            require Apache2::RequestUtil;
            require APR::Table;
            Apache2::Const->import( -compile => 'OK', 'FORBIDDEN' );
            return 2;
        }
        else {    # mod_perl 1.xx
            die "Could not find or load mod_perl"
                unless ( eval "require mod_perl" );
            die "Could not detect your version of mod_perl"
                if ( !defined($mod_perl::VERSION) );
            if ( $mod_perl::VERSION < 1.99 ) {
                require Apache;
                require Apache::Constants;
                Apache::Constants->import('OK');
                return 1;

                #$self->{'MOD_PERL_VERSION'} = 1;
                #$self->{OK} = Apache::Constants::OK();
            }
            else {
                require Apache::RequestRec;
                require Apache::RequestIO;
                require Apache::Const;
                Apache::Const->import( -compile => 'OK' );

                #$self->{'MOD_PERL_VERSION'} = 1.99;
                #$self->{OK} = Apache::OK();
                return 1.99;
            }
        }
    }

    # authorization is
    sub find_target {
        my $this = shift();

        my ( $class, $method_uri, $method_name )
            = $this->SUPER::find_target(@_);
        die SOAP::Fault->new( 'faultcode' => $this->unathorized_fault_code )
            if !$this->authorize_soap_call( $class, $method_name,
            $this->current_user );
        return ( $class, $method_uri, $method_name );
    }

    sub authorize_soap_call {
        my ( $this, $class, $method_name, $user ) = @_;

        for my $auth_module ( @{ $this->authorized_by } ) {
            my $is_authorized
                = $auth_module->authorize_soap_call( $class, $method_name,
                $user );
            return $is_authorized if defined $is_authorized;
        }
        return 1;
    }

    sub make_fault {
        my ( $this, $code, @other_args ) = @_;
        if ( $code eq $this->unathorized_fault_code ) {
            $this->make_response(
                HTTP::Status::RC_FORBIDDEN() => 'You are forbidden to use this service' );
        }
        else {
            $this->SUPER::make_fault( $code, @other_args );
        }
        return;
    }

    # 2004-07-30 danielr - temporary redefinition logging SOAP
    # 2008-04-08 danielr
    # zrusil jsem prime volani SUPER::handle pokud neni definovane
    # raw_logging,
    # stejne by to se starou verzi (0.69) a novym Apachem nemohl jet
    my $Id;

    sub handle {
        my $self = shift->new;
        my $r    = shift;

        my $mod_perl_version = mod_perl_version();

        # 2008-04-08 danielr, opraveno
        my $content_len =
              $mod_perl_version < 2
            ? $r->header_in('Content-length')
            : $r->headers_in->get('Content-length');

        # End patch from JT Justman
        
        # throw appropriate error for mod_perl 2
        $content_len > 0
            or return $mod_perl_version >= 2
            ? Apache2::Const::HTTP_BAD_REQUEST()
            : Apache::Constants::BAD_REQUEST();

        my $content = '';
        my $buf;
        # attempt to slurp in the content at once...
        while ( $r->read( $buf, $content_len ) > 0 ){
            $content .= $buf;
        }

        $self->request(
            HTTP::Request->new(
                $r->method() => $r->uri,
# 2012-11-28 danielr
# $r->headers_in is not hashref - but APR::Table object (with tied hash interface)
# which doesnot go along well with HTTP::Headers->new (it used to work well)
# the { %{ $r->headers_in } } construction copies the object into ordinary hash
#
                HTTP::Headers->new({ %{$r->headers_in} }),
                $content
            )
        );

        # danielr - radek pridany do puvodniho kodu
        my $logging_id;
        if ( $self->raw_logging ) {
            $logging_id = $$ . '-' . ++$Id;
            $self->log_raw_data( 'Request', $logging_id, $self->request->content );
        }

        # danielr - I need SUPER:: to be relative to SOAP::Transport::HTTP::Apache
        $self->current_user( $r->user );
        $self->SOAP::Transport::HTTP::Apache::SUPER::handle;

        # we will specify status manually for Apache, because
        # if we do it as it has to be done, returning SERVER_ERROR,
        # Apache will modify our content_type to 'text/html; ....'
        # which is not what we want.
        # will emulate normal response, but with custom status code
        # which could also be 500.
        $r->status( $self->response->code );

        if ( $self->raw_logging ) {

            # danielr - radek pridany do puvodniho kodu
            $self->log_raw_data( 'Response', $logging_id, $self->response->content );
        }

        # hokus pokus ISim
        # $r->content_type("text/xml");

        # Begin JT Justman patch
        if ( $mod_perl_version > 1 ) {
            $self->response->headers->scan( sub { $r->headers_out->set(@_) }
            );
            $r->content_type( join '; ', $self->response->content_type );
        }
        else {
            $self->response->headers->scan( sub { $r->header_out(@_) } );
            $r->send_http_header( join '; ', $self->response->content_type );
        }

        $r->print( $self->response->content );

        # End JT Justman patch

        return $mod_perl_version == 2 ? Apache2::Const::OK()
            : $mod_perl_version == 1  ? Apache::Constants::OK()
            : Apache::OK();    # 1.99
    }

    sub log_raw_data {
        my ( $this, $request_response, $id, $data ) = @_;

        my $fh = FileHandle->new( '>> ' . $this->raw_logging_file )
            or die $!;
        if ( Encode::is_utf8($data) ) {
            binmode( $fh, ':utf8' );
        }

        $fh->printf( "%s - SOAP %s %s\n---------------\n%s\n\n",
            Akar::Time->new->text, $request_response, $id, $data );
        $fh->close;
    }
}

1;


# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
