package Akar::DBIC::AutoResultSetClass;
{
  $Akar::DBIC::AutoResultSetClass::VERSION = '1.994';
}
use strict;
use warnings;

use base qw/DBIx::Class::Schema/;

use Carp qw(carp croak);

__PACKAGE__->mk_classdata('resultset_class_base' => 'DBIx::Class::ResultSet');

sub build_resultset_class {
    my $class = shift;

    my $resultset_class = $class;
    $resultset_class =~ s/(?<=::)Schema\w*(?=::)/ResultSet/;

    my $base_class = 
          $class->class_is_inflated
        ? $class->inflated_info->{base_class}->resultset_class
        : 'CSR::DBIC::ResultSet';
#    warn "Building $resultset_class from $base_class\n";

    no strict 'refs';
    @{ $resultset_class . '::ISA' } = ($class->resultset_class_base);
#    $resultset_class->class_is_inflated( $class->class_is_inflated );
    return $resultset_class;
}

my %resultset_class_for;

sub resultset_class {
    my $class = shift;
    die "Don't set resultset_class it is set automatically\n " if @_;

    return $resultset_class_for{$class} ||= $class->build_resultset_class;
}

1;

__END__

=head1 NAME

Akar::DBIC::InplaceResultSet - each result class having its own resultset

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
