package Akar::SOAP::Apache;
{
  $Akar::SOAP::Apache::VERSION = '1.994';
}
use strict;
use warnings;

# using SOAP::Transport::HTTP must precede use base
# since SOAP::Transport::HTTP::Apache has not its own module
use SOAP::Transport::HTTP;
use base qw(SOAP::Transport::HTTP::Apache);

use Apache;
use URI;
use FileHandle;
use Encode;
use Apache::Constants qw(:http);
use Data::Dumper;
use Akar::SOAP::Service;
use Akar::Script;
use Akar::SOAP::Lite;
use Akar::Time;

# Akar::SOAP::Headers checks mustUnderstand attribute - not SOAP::Lite
# 2007-04-23 danielr, this is obsolete and not used AFAIK
# use Akar::SOAP::Headers 'checkMustUnderstand' => 1;

# 2007-09-07 danielr
# mustUnderstand may not be checked by SOAP::Lite
$SOAP::Constants::DO_NOT_CHECK_MUSTUNDERSTAND = 1;

# accessors
for my $method (qw(raw_logging raw_logging_file)) {
    no strict 'refs';
    *$method = sub {
        my ( $this, $new_value ) = @_;
        return @_ == 1
            ? $this->{$method}
            : do { $this->{$method} = $new_value };
    };
}

# each location (/soap, /wsdl) has own handler
sub handler {
    my $r = shift;

    if ( $r->uri =~ m{^/soap/?$} ) {

        # handling soap
        handler_soap($r);
    }
    elsif ( $r->uri =~ m{^/wsdl/} ) {

        # handling wsdl
        handler_wsdl($r);
    }
    else {

        # everything other is an error
        $r->status(HTTP_NOT_FOUND);
        $r->send_http_header();
    }
}

sub handler_wsdl {
    my $r = shift;

    my $package = $r->uri;
    $package =~ s{^/wsdl/}{};
    $package =~ s{/$}{};
    $package =~ s{/}{::}g;
    my @dispatch_to = split( /\s+/, $r->dir_config('dispatch_to'), -1 );
    if ( grep { $package eq $_ } @dispatch_to ) {

        # Is it a SOAP modul ?
        eval {
            eval "require $package;";
            die $@ if $@;
            my $location = sprintf(
                '%s://%s:%s/soap/',
                ( $ENV{'HTTPS'} ? 'https' : 'http' ),
                $r->hostname, $r->get_server_port
            );

            # stupid determination of the service
            my $service
                = Akar::SOAP::Service->get_by_package($package) #old ones
                || $package;                                    # new packages
            my $wsdl_content = $service->create_wsdl($location);
            $r->send_http_header();
            $r->print($wsdl_content);
        };
        if ($@){
            warn $@;
            $r->status(HTTP_INTERNAL_SERVER_ERROR);
            $r->send_http_header();
        }
    }
    else {

        # package is not dispatched
        $r->status(HTTP_NOT_FOUND);
        $r->send_http_header();
        $r->print("Service $package is not provided by this server\n" );
    }
}

# following code is copied from Apache::SOAP ($server has to be of Akar::SOAP::Apache class)
{
    my $server = __PACKAGE__->new;
    # 2007-09-27 danielr, the response element may not use default_namespce
    $server->serializer->use_default_ns(0);

    sub handler_soap {
        $server->configure(@_);
       
        # 2007-10-12 to prevent warnings in error_log 
        no warnings 'redefine';
        local *SOAP::Transport::HTTP::Apache::handler
            = \&SOAP::Transport::HTTP::Apache::handler;
        if ( $server->raw_logging ) {
            *SOAP::Transport::HTTP::Apache::handler
                = \&apache_handler_with_logging;
        }
        $server->SUPER::handler(@_);
    }
}

sub log_raw_data {
    my ( $this, $request_response, $id, $data ) = @_;

    my $fh = FileHandle->new( '>> ' . $this->raw_logging_file )
        or die $!;
    if ( Encode::is_utf8($data) ) {
        binmode( $fh, ':utf8' );
    }

    $fh->printf( "%s - SOAP %s %s\n---------------\n%s\n\n",
        Akar::Time->new->text, $request_response, $id, $data );
    $fh->close;
}

# 2004-07-30 danielr - temporary redefinition logging SOAP
my $Id;
sub apache_handler_with_logging
{
  # danielr - I need SUPER:: to be relative to SOAP::Transport::HTTP::Apache
  package SOAP::Transport::HTTP::Apache;
{
  $SOAP::Transport::HTTP::Apache::VERSION = '1.994';
}

  my $self = shift->new;
  my $r = shift || Apache->request;

  $self->request(HTTP::Request->new(
    $r->method => $r->uri,
    HTTP::Headers->new($r->headers_in),
    do { my $buf; $r->read($buf, $r->header_in('Content-length')); $buf; }
  ));

  # danielr - radek pridany do puvodniho kodu
  my $id = $$. '-'. ++$Id;
  $self->log_raw_data('Request', $id, $self->request->content);

  $self->SUPER::handle;

  # we will specify status manually for Apache, because
  # if we do it as it has to be done, returning SERVER_ERROR,
  # Apache will modify our content_type to 'text/html; ....'
  # which is not what we want.
  # will emulate normal response, but with custom status code 
  # which could also be 500.
  $r->status($self->response->code);
  $self->response->headers->scan(sub { $r->header_out(@_) });
  $r->send_http_header(join '; ', $self->response->content_type);

  # danielr - radek pridany do puvodniho kodu
  $self->log_raw_data('Response', $id, $self->response->content);

  $r->print($self->response->content);
  &Apache::Constants::OK;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
