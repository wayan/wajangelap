package Akar::DBI::Statement::Select;
{
  $Akar::DBI::Statement::Select::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Akar::DBI::Statement::Object);

use Carp qw(croak);
use Scalar::Util q(blessed);
use Akar::DBI::Statement::Join;

__PACKAGE__->mk_accessors(
    qw(select_clause from_clause where_clause group_by_clause
        order_by_clause)
);

sub layout {
    my ($this) = @_;

    return [
        $this->select_clause, $this->from_clause,
        grep { defined($_) } $this->where_clause, $this->group_by_clause,
        $this->order_by_clause
    ];
}

sub _indented {
    my ($text) = @_;

    $text =~ s/^/    /gm;
    return $text;
}

sub text {
    my ($this) = @_;

    my @texts = (
        'SELECT', _indented( $this->select_clause->text ),
        'FROM',   _indented( $this->from_clause->text )
    );
    if ( my $the_where = $this->where_clause->text ) {
        push @texts, 'WHERE', _indented($the_where);
    }
    if ( my $the_group_by = $this->group_by_clause->text ) {
        push @texts, 'GROUP BY', _indented($the_group_by);
    }
    if ( my $the_order_by = $this->order_by_clause->text ) {
        push @texts, 'ORDER BY', _indented($the_order_by);
    }

    return join "\n", @texts;
}

sub _normalize_ary_as_join {
    my ( $arg, $separator ) = @_;

    if ( !defined($arg) ) {
        $arg = [];
    }

    my $is_ary = UNIVERSAL::isa( $arg, 'ARRAY' ) && !blessed($arg);

    return $is_ary ? Akar::DBI::Statement::Join->new(
        {   'layout'    => $arg,
            'separator' => $separator,
        }
        )
        : __PACKAGE__->is_sql($arg) ? $arg
        : die "Invalid part of SQL $arg\n ";
}

sub new {
    my ( $package, $fields ) = @_;

    # Normalizing clauses
    
    # SELECT
    for my $select_clause ( $fields->{'select_clause'} ) {
        croak "Select clause not supplied\n " if !$select_clause;

        $select_clause = _normalize_ary_as_join($select_clause, "\n, ");
    }

    # Normalizing FROM
    for my $from_clause ( $fields->{'from_clause'} ) {
        croak "from clause not supplied\n " if !$from_clause;

        $from_clause = _normalize_ary_as_join($from_clause, "\n, ");
    }

    # Normalizing WHERE
    for my $where_clause ( $fields->{'where_clause'} ) {
        $where_clause = _normalize_ary_as_join($where_clause, "\nAND ");
    }

    # Normalizing GROUP BY
    for my $group_by_clause ( $fields->{'group_by_clause'}) {
        $group_by_clause = _normalize_ary_as_join($group_by_clause, "\n, ");
    }

    # Normalizing ORDER BY
    for my $order_by_clause ( $fields->{'order_by_clause'} ) {
        $order_by_clause = _normalize_ary_as_join( $order_by_clause, "\n, " );
    }

    return $package->SUPER::new($fields);
}

1;

__END__

=head1 NAME

Akar::DBI::Statement::Select - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
