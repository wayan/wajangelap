package Akar::Counter;
{
  $Akar::Counter::VERSION = '1.994';
}

=head1 NAME

Medea::Deposit - Jednoduch� modulu counter, kter� vrac� TRUE

=head1 SYNOPSIS

  use Akar::Counter;

  my $cnt = Akar::Counter->new(1 => 5, 10 => 50, 100 => 1000, 1E3 => 10000);
  for (my $i=0; $i<$x; $i++){
	...
	print "Processed $i records" if &$cnt($i);
  }

  # Vytiskne zpr�vu pro $i = 1, 2, 3 a� do 5; 10, 20, 30 a� do 50;
  # 100, 200, 300, ... 1000; a 1000, 2000, 3000, .... a� do nekone�na

=head1 DESCRIPTION

=cut

use strict;

sub new {
	my $class = shift;
	my @ary   = @_;

	my($mod, $max) = (1E10, -1);
	bless sub {
		my $cnt = shift or return 0;
		($mod,$max) = splice @ary, 0, 2 if @ary && $cnt > $max;
		!($cnt % $mod);
	}, ref($class) || $class;
}

1;
