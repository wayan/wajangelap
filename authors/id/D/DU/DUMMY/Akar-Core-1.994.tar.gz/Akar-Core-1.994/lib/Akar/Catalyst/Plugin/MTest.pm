package Akar::Catalyst::Plugin::MTest;
{
  $Akar::Catalyst::Plugin::MTest::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);
use Module::Find;
use Cwd qw(abs_path);

# loads MTest controllers for from test_lib
sub setup_components {
    my $this = shift;
   
    $this->next::method(@_);

    # setups all Controller::MTest modules from t dir
    # the test_lib has to be set in config :-(
    my $test_lib = $this->config->{MTest}{test_lib}
        or return;
    -d $test_lib 
        or die "Test directory $test_lib (for MTest) doesnot exist\n ";

    my @modules = do {
        local @INC = ($test_lib);
        Module::Find::findallmod 'Controller::MTest';
    };

    # to make Catalyst::Utils::class2appclass work
    # I have to create Controller under the app namespace
    for my $module (@modules) {
        # loads module
        local @INC = ($test_lib, @INC);
        eval "require $module;";
        die $@ if $@;

        my $controller_class = $this . '::' . $module;
        {
            no strict 'refs';
            @{$controller_class . '::ISA'} = ($module);
        }
        $controller_class->default_template_name('') if $controller_class->can('default_template_name');
        $this->log->debug("Setups $module as $controller_class")
            if $this->debug;
        $this->components->{$controller_class}
            = $this->setup_component($controller_class);
    }
}

1;

__END__

=head1 NAME

Akar::Catalyst::Plugin::MTest - deployment of Test controllers

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
