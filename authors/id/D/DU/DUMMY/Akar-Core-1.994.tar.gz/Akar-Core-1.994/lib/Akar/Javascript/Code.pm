package Akar::Javascript::Code;
{
  $Akar::Javascript::Code::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Exporter);

use Carp qw(carp croak);
our @EXPORT_OK = qw(jsquote literal jsexp jsblock jsliteral);
use Scalar::Util qw(blessed);

# object is implemented as [str, is_block]
use overload '""' => 'as_string',
    '.' => '_concatenate',
   'fallback' => 1;

#-------------------------------------------------------------------------------
#   Exported functions
#-------------------------------------------------------------------------------

# returns js_code which shouldnot be escaped when passed somewhere
sub jsexp {
    return _new( join( '', map { _is_javascript($_) ? $_->[0] : $_ } @_ ) );
}

# javascript literal
sub jsquote {
    my ($str) = @_;

    return _is_javascript($str)
        ? $str
        : _new( _js_quote($str) );
}

*jsliteral = *jsquote;

# JS block returns
sub jsblock {
    my $str = join( '', map { _is_javascript($_) ? $_->[0] : $_ } @_ );
    $str =~ s/\s+$//s;
    $str .= "\n" if $str !~ /\n$/;
    return _new($str, 1);
}

#-------------------------------------------------------------------------------

sub _new {
    my ($str, $is_block) = @_;
    return bless [$str, $is_block] => __PACKAGE__;
}

sub _is_javascript {
    return blessed($_[0]) && $_[0]->isa(__PACKAGE__);
}

# concatenation
sub _concatenate {
    my $reversed = $_[2];
    my ( $left, $right )
        = map { _is_javascript($_) ? $_ : [$_]; }
        @_[ $reversed ? ( 1, 0 ) : ( 0, 1 ) ];

    my $str = $left->[0] . $right->[0];
    my $is_block = $left->[1] || $right->[1];
    if ( !defined $reversed ) {

        # $exp .= $other_exp
        @{$left} = ( $str, $is_block );
        return $left;
    }
    return _new( $str, $is_block );
}

sub as_string {
    my ($str, $is_block) = @{shift()};

    return $is_block? _js_block($str): $str;

}

#  given Javascript script quote it
sub _js_quote {
    my ($str) = @_;

    # escaping and quoting
    $str =~ s/\n/\\n/g;
    $str =~ s/"/\\"/g;
    return '"' . $str . '"';
}

sub _js_block {
    my ($str) = @_;

    # dumping javascript block - zatim odflaknuto, chybi CDATA, ...
    $str =~ s/\n$//;
return <<"END_BLOCK";
<script type="text/javascript">
//<![CDATA[
$str
//]]>
</script>
END_BLOCK
}

1;

__END__

=head1 NAME

Akar::Javascript::Code - support for emiting javascript code

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
