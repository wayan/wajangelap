package Akar::XML::Compile::Schema;
{
  $Akar::XML::Compile::Schema::VERSION = '1.994';
}
use Moose;

# XML::Compile::Schema wrapper with readers and writers cached

use XML::Compile::Util qw(unpack_type);
use XML::Compile::Schema;
use XML::Compile::Cache;
use Data::Dump qw(pp);

has xml_compile_schema => (
    is         => 'rw',
    lazy_build => 1,
    handles    => {
        compile           => 'compile',
        elements          => 'elements',
        types             => 'types',
        importDefinitions => 'importDefinitions',
        findName => 'findName',
        prefixes => 'prefixes',
        addSchemaDirs => 'addSchemaDirs',
    }
);

# compilers cached
has compiler_for => (
    is      => 'ro',
    isa     => 'HashRef',
    default => sub { return {} },
    traits  => ['Hash'],
    handles => {}
);

with 'Akar::XML::Compile::Schema::XsiType',
    'Akar::XML::Compile::Schema::FindElement';

around importDefinitions => sub {
    my ( $orig, $this, $xml, %opts ) = @_;

    my $prefix = delete $opts{PREFIX};
    my @ret    = $orig->($this, $xml, %opts);
    if ($prefix) {
        $this->prefixes( { $prefix => $ret[0]->targetNamespace } );
    }

    return @ret;
};

sub _build_xml_compile_schema {
    return XML::Compile::Cache->new;
}

sub get_reader_for {
    my $this = shift;
    return $this->get_compiler_for( READER => @_ );
}

sub get_writer_for {
    my $this = shift;
    return $this->get_compiler_for( WRITER => @_ );
}

sub get_compiler_for {
    my $this = shift;
    my ( $direction, $element ) = @_;

    return $this->compiler_for->{$direction}{$element}
        ||= $this->_build_compiler_for(@_);
}

sub _build_compiler_for {
    my $this = shift;
    my ( $direction, $element ) = @_;

    return $this->compile(
        $direction => $element,
        xsi_type   => $this->xsi_type,
    );
}

__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

