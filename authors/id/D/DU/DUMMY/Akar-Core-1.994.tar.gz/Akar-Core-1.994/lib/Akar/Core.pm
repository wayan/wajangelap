package Akar::Core;
{
  $Akar::Core::VERSION = '1.994';
}
use strict;
use warnings;

# ABSTRACT: Utility libraries enhancing CPAN
#
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

