package Akar::AQ::Manager;
{
  $Akar::AQ::Manager::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Akar::Class::Accessor Akar::AQ::DaemonControl Akar::AQ::Dbize);

use Carp qw(carp croak);
use List::MoreUtils qw(uniq last_value);
use Akar::DBI::Statement qw(sql_param sql sql_param_inout sql_and sql_join);
use Akar::Time;
use Interpolation 'E' => 'eval', 'sqlp' => sub { return sql_param(@_) };
use File::Basename qw(dirname);
use File::Path qw(mkpath);
use File::Spec;
use List::Util qw(sum);
use Data::Dump qw(pp);
use Sys::Hostname;

use Akar::Class::Utils qw(require_package);

# helping classes
use Akar::AQ::_Queue;
use Akar::AQ::_Listener;

use Akar::AQ::Controller;
use Akar::AQ::Constants qw(LISTEN_TIMEOUT_ERRNO);
use Akar::AQ::WaitUntil;

__PACKAGE__->mk_ro_accessors('queue_table');

__PACKAGE__->mk_ro_accessors(
    'listen_timeout',
    'exit_when_timeout', 'message_class',
    'controller_options',
);

# logging
__PACKAGE__->mk_accessors('logdir', 'logpath');

# list of controllers
__PACKAGE__->mk_accessors( 'controllers');

sub listener_class { shift()->dbize('Akar::AQ::_Listener'); }

sub queue_class { shift()->dbize('Akar::AQ::_Queue'); }

sub controller_class { shift()->dbize('Akar::AQ::Controller') }

sub controllers {
    my $controllers = shift()->_controllers_accessor;
    return wantarray ? @{$controllers} : $controllers;
}

sub new {
    my ( $package, $queue_table, $message_class, $options ) = @_;

    $options ||= {};
    my $logdir = $options->{'logdir'}
        or die "No logdir supplied\n";

    # requiring message class
    my @message_classes = uniq(
        !ref($message_class)
        ? $message_class
        : map { $_->[1] } @{$message_class}
    );
    for my $class (@message_classes){
        require_package($class);
    }

    my $this = $package->SUPER::new(
        {   'listen_timeout' => 60,
            %{$options},
            'message_class' => $message_class,
            'queue_table'   => $queue_table,
            'logpath'       => File::Spec->rel2abs(
                'listener-' . $queue_table . '.log', $logdir
            ),
        }
    );
    $this->initialize;
    return $this;
}

# returns 1 if the queue table is multi consumer queue
sub multi_consumer {
    my $this = shift;

    my $qt = $this->queue_table;
    my ( $owner, $name ) = split /\./, $qt;
    my $sth
        = $this->db_Main->prepare(
        "SELECT recipients FROM sys.all_queue_tables WHERE owner = ? AND queue_table = ?"
        );
    $sth->execute( $owner, $name );
    my ($recipients) = $sth->fetchrow_array
        or die "No record for queue table $qt in system catalog";
    return
          $recipients eq 'SINGLE'   ? 0 
        : $recipients eq 'MULTIPLE' ? 1
        : die
        "Unexpected value of recipients ('$recipients') for queue table $qt";
}

sub initialize {
    my ($this) = @_;
    $this->_clean_dead_listener;
    $this->refresh_controllers;
}

sub refresh_controllers {
    my ($this) = @_;

    my @controllers = map {
        my $queue = $_;

        my $controller_logpath = File::Spec->rel2abs(
            join( '.', 'daemon', $queue->name, 'log' ),
            $this->logdir );
        $this->controller_class->new(
            $queue->qname,
            $this->message_class_for($queue->name),
            {   
                'logpath'       => $controller_logpath,
                %{ $this->controller_options_for($queue->name) },
                'multi_consumer' => $this->multi_consumer,
            }
        );
    } $this->queue_class->table_queues( $this->queue_table );
    $this->set_controllers( \@controllers );
}

sub message_class_for {
    my ( $this, $queue_name ) = @_;

    # message class is same for all queues - usual case
    my $mc = $this->message_class;
    return $mc if !ref($mc);

    # different message class - message class is
    # [ [queue_re => class], [  queue_re => class] ]
    my ($message_class) = map { $_->[1] } last_value {
        my $queue_re = $_->[0];
        $queue_name =~ /^(?:$queue_re)$/;
        }
        @{$mc}
        or die "No message class found for queue $queue_name\n ";
    return $message_class;
}

sub controller_options_for {
    my ( $this, $queue_name ) = @_;

    # message class is same for all queues - usual case
    my $co = $this->controller_options;
    return {} if !$co;

    # one controller options for all
    return $co if UNIVERSAL::isa( $co, 'HASH' );

    # combination of all controller options conforming the re
    my %controller_options = map {
        my ( $queue_re, $options ) = @{$_};

        $queue_name =~ /^(?:$queue_re)$/ ? %{$options} : ();
    } @{$co};

    return \%controller_options;
}

# returns queue with the message 
sub listen {
    my ( $this, $daemon ) = @_;

    my $dc_queue  = $this->DC_QUEUE;
    my @to_listen = grep { $_->can_be_listened } $this->controllers;

    warn
        "Listening on data queues $E{ join(', ', map {$_->queue} @to_listen) }\n";
    my @agents_psql = do {
        my $idx = 0;
        map {
            ++$idx;
            <<"END_PSQL"
            l_agent_list($idx) := sys.aq\$_agent(
                null, 
                $sqlp{ $_->queue },
                null);
END_PSQL
        } @to_listen;
    };

    my $queue_selected;
    my $agent_name  = $daemon->agent_name;
    my $listen_psql = sql(<<"END_PSQL");
        DECLARE 
            l_agent_list sys.dbms_aq.aq\$_agent_list_t;
            l_agent_selected sys.aq\$_agent;
        BEGIN 
            -- daemon control queue
            l_agent_list(0) := sys.aq\$_agent( 
                $E{ $agent_name ? sql_param($agent_name): 'null'},
                $sqlp{ $dc_queue }, 
                null);
            $E{ sql_join '', @agents_psql}
            sys.dbms_aq.listen(
                agent_list => l_agent_list,
                wait       => $sqlp{ $this->listen_timeout },
                agent      => l_agent_selected); 
            -- data queue
            $E{ sql_param_inout(\$queue_selected, 128) } := l_agent_selected.address;
        END;
END_PSQL

    my $sth = $this->db_Main->prepare($listen_psql);

# 2004-08-16 daniel - locally disabled PrintError causes empty sth->err in case of error
# bug? misunderstanding?
# local $$sth{'PrintError'} = 0;
    local $SIG{__WARN__} = sub { };
    $sth->execute;

    $queue_selected =~ s/"//g;
    return if uc($queue_selected) eq uc($dc_queue);    # control queue
    return $queue_selected;                            #data queue
}

# refresh
sub listener_loop {
    my ( $this, $daemon ) = @_;

    my $exit_reason;
LISTENER_LOOP: while ( !$exit_reason ) {
        $this->refresh_controllers;

        my $queue_selected = eval { $this->listen($daemon); };
        if ( my $error = $@ ) {
            if ( $this->dbh_err($error) == LISTEN_TIMEOUT_ERRNO ) {
                warn "listen timout\n";
                $exit_reason = 'Exit when timeout'
                    if $this->exit_when_timeout;
            }
            else {

                # Internal error
                die $error;
            }
        }
        elsif ( !$queue_selected ) {

            # dequeueing daemon control data
            my $dc_message;
            $this->txn_do(
                sub {
                    $dc_message = $this->dequeue_dc($daemon);
                }
            );

            #handling dc
            $exit_reason = $this->handle_dc_message($dc_message);
        }
        else {
            # data queue
            $this->start_controller( $this->controller($queue_selected) );
        }
    }    # LISTENER_LOOP
    return $exit_reason;
}

sub handle_dc_message {
    my ( $this, $dc_payload ) = @_;

    warn 'Dequeued DC message: ' . $this->list_dc_payload($dc_payload) . "\n";
    my $action = $dc_payload->action;
    if ( $action eq 'stop' ) {
        # stop waits until daemons are finished
        return $this->handle_dc_stop();
    }
    elsif ( $action eq 'restart' ) {
        return $this->handle_dc_restart();

    }
    elsif ( $action eq 'stopped' ) {
        # this action is only to woke the listener
        # so it rearranges the queues
        warn "Wow a daemon on $E{$dc_payload->sender } stopped\n";
        # daemon stopped we continue
        return;
    }
}

sub handle_dc_stop {
    my ($this) = @_;

    # stop waits until daemons are finished
    my $waiter = Akar::AQ::WaitUntil->new;
    for my $controller ( $this->controllers ) {
        $controller->stop_daemon($waiter);
    }
    return 'stop from queue';
}

sub handle_dc_restart {
    my ($this) = @_;

    my $waiter = Akar::AQ::WaitUntil->new;
    for my $controller ( $this->controllers ) {
        $controller->stop_daemon($waiter);
    }

    # restart doesn't wait until daemons are finished
    $waiter->cancel;
    return 'restart from queue';
}

# return controller for given queue
sub controller {
    my ( $this, $queue ) = @_;

    # the queue may be unqualified, supplied with lowercase ...
    my ($controller) = grep {
        lc( $_->queue )             eq lc($queue)     # qualified name
            || lc( $_->queue_name ) eq lc($queue);    # unqualified name
        } $this->controllers
        or die "Listener $E{ $this->queue_table } doesn't contain queue $queue\n ";

    return $controller;
}

sub _control_listener {
    my ( $this, $action ) = @_;

    my $listener = $this->retrieve_listener
        or return;

    # enqueues stop into control queue
    $this->txn_do(
        sub {
            $this->enqueue_dc_action_for( $listener, $action );
        }
    );
    return $listener->id;
}

# stops the listener
sub stop_listener {
    my ($this, $waiter) = @_;

    # listener object probably should not be remembered
    # so it could be found disappear when deleted by running listener
    my $listener_id = $this->_control_listener('stop');
    if ( !$listener_id ) {
        warn "There is no $E{$this->queue_table} listener running\n";
        return;
    }

    $waiter ||= Akar::AQ::WaitUntil->new;
    $waiter->add(
        'check' => sub {
            !$this->retrieve_listener( 'id' => $listener_id );
        },
        'on_failure' => sub {
            "Listener $E{ $this->queue_table} was sent signal but didn't stopped\n";
        }
    );
}

sub restart_listener {
    my ( $this, $waiter ) = @_;

    # sends message to listener
    my $listener_id = $this->_control_listener('restart');

    $waiter ||= Akar::AQ::WaitUntil->new;
    $waiter->add(
        'check' => sub {
            !$listener_id
                || !$this->retrieve_listener( 'id' => $listener_id );
        },
        'on_success' => sub {
            $this->start_listener;
        },
        'on_failure' => sub {
            "Listener $E{ $this->queue_table} was sent signal but didn't stopped\n";
        }
    );
}

sub wakeup_listener {
    my ($this) = @_;

    $this->_control_listener('wakeup');
}

# start_queues for dequeue
sub start_queues {
    my ( $this, @controllers ) = @_;

    for my $controller (@controllers) {
        if ( $controller->dequeue_enabled ) {
            warn
                "Queue $E{$controller->queue} already enabled for dequeue.\n";
        }
        else {
            $controller->start_queue( 0, 1 );
            warn "Queue $E{$controller->queue} started for dequeue.\n";

            # current listener is woken up to realize queue changes
            $this->_control_listener(
                $this->new_dc_payload( 'qstart', $controller->queue ) );
        }
    }
}

# stops queue for dequeue
sub stop_queues {
    my ( $this, @controllers ) = @_;

    my $waiter = Akar::AQ::WaitUntil->new;
    for my $controller ( grep { $_->dequeue_enabled } @controllers ) {
        my $cwaiter = Akar::AQ::WaitUntil->new;
        $controller->stop_queue($cwaiter);
        $waiter->add(
            'check'      => $cwaiter,
            'on_success' => sub {
                $controller->stop_queue( 0, 1 );
                warn "Queue " . $controller->queue . " stopped\n";

                # current listener is woken up to realize queue changes
                $this->_control_listener(
                    $this->new_dc_payload( 'qstop', $controller->queue ) );
            },
        );
    }
}

# start all queues for enqueue and dequeue
# to be used on fresh mirror when all queues are stopped
sub start_all_queues {
    my ($this) = @_;

    for my $controller ( $this->controllers ) {
        warn "Starting queue $E{$controller->queue}.\n";
        $controller->start_queue( $controller->is_exception_queue ? 0 : 1,
            1 );
    }
}

# starts the listener
sub start_listener {
    my ( $this, $waiter ) = @_;

    if ( my $listener = $this->retrieve_listener ) {
        die "There is already $E{$this->queue_table} listener running";
    }

    mkpath( $this->logdir );
    my $listener;
    $this->txn_do(
        sub {
            $listener = $this->listener_class->create(
                {   'queue_table' => $this->queue_table,
                    'pid'         => -1,
                    'hostname'    => Sys::Hostname::hostname(),
                    'usessionid'  => undef,
                }
            );
        }
    );

    # disconnect before fork
    $this->db_Main->disconnect;

    # copied from net::server::daemonize
    # i don't use net::server::daemonize directly
    # because there are no pid files and set_user needed.
    my $child_pid = fork();
    if ( $child_pid == 0 ) {
        ### child process will continue on
        ### close all input/output and separate
        ### from the parent process group

        # demonizuji se a presmeruji svuj vystup do logu
        $this->redirect_daemon_output( $this->logpath );
        local $SIG{__WARN__} = sub {
            warn sprintf( '%s [%s] - ', Akar::Time->new->text, $$ ), @_;
        };

        # creates the daemon - must be done AFTER fork
        my $usessionid = $this->db_Main->selectrow_array(<<"END_SELECT");
            SELECT DBMS_SESSION.UNIQUE_SESSION_ID
            FROM dual
END_SELECT

        $this->txn_do(
            sub {
                $listener->usessionid($usessionid);
                $listener->started( Akar::Time->new->text );
                $listener->pid($$);
                $listener->update;
            }
        );

        ### change to root dir to avoid locking a mounted file system
        ### does this mean to be chroot ?
        chdir '/' or die "can't chdir to \"/\": $!\n ";

        ### turn process into session leader, and ensure no controlling terminal
        POSIX::setsid();
        warn "START\n";
        my $exit_reason = eval { $this->listener_loop($listener); };
        if ($@) {
            $exit_reason = 'ERROR: ' . $@;
        }
        warn "END ($exit_reason)\n";

        # current listener is deleted
        $this->txn_do(
            sub {
                $listener->delete;
            }
        );
        exit(0);
    }
    else {
        my $listener_id = $listener->id;

        $waiter ||= Akar::AQ::WaitUntil->new;
        $waiter->add(
            'check' => sub {

                # listener either disappear or seizes the pid
                my $listener
                    = $this->retrieve_listener( 'id' => $listener_id );
                return !$listener || $listener->pid == $child_pid;
            },
            'on_failure' => sub {
                die "It seem that child process haven't started\n ";
            }
        );
    }

    return;
}

# stops the controller, runs an action after a controller is stopped
sub _stop_controllers {
    my ( $this, $when_stopped, @controllers ) = @_;

    my @stopped_subs; 
    my %unstopped;
    CONTROLLER: for my $controller ( @controllers ){
        $controller->retrieve_daemon or next CONTROLLER;

        my $checker_sub = $controller->stop_daemon;
        my $queue = $controller->queue;
        my $ok;
        $unstopped{$queue} = $controller;
        push @stopped_subs, sub {
            if (!$ok && $checker_sub->()){  
                delete $unstopped{$queue};
                if ($when_stopped) {
                    $when_stopped->($controller);
                }
                $ok = 1;
            }
            return $ok;
        };
    }

    wait_until(@stopped_subs);

    # timeout occured and there are still unstopped daemons
    if ( my @unstopped = values %unstopped ) {
        warn
            'Timeout occured and there are still unstopped daemon(s) on queues: '
            . join( ', ', map { $_->queue . "\n"; } @unstopped ), "\n";
        return @unstopped;
    }

    # everything is finished
    return;
}

sub list_queues {
    my ($this, $hide_legend) = @_;

    my $listener = $this->retrieve_listener;
    print $listener
        ? "Listener running on $E{ $this->queue_table } "
        . "(hostname $E{$listener->hostname}, pid $E{ $listener->pid })\n"
        : "No listener running on $E{ $this->queue_table}\n";

    print "\n";
    printf "%-30s %-10s %-3s %-3s %20s %23s\n", 'Queue', 'Type', 'Enq', 'Deq',
        'Daemon', 'Messages(Active)';
    for my $controller ( $this->controllers ) {

# if there are no messages or queue is exception queue only total number is reported
# otherwise TOTAL/ACTIVE
        my $messages_str = do {
            my $message_count    = $controller->message_count;
            my $total_messages   = sum( values %{$message_count} ) || 0;
            my $active_messsages = $message_count->{0} || 0;
            ( !$total_messages || $controller->is_exception_queue )
                ? $total_messages
                : "$total_messages ($active_messsages)";
        };

        my $pid_str = do {

            # 2008-03-20
            # daemon is so far only one, but later ...
            my @daemons = $controller->retrieve_daemon;
            @daemons ? join( ', ', map { $_->pid } @daemons )
                : !$controller->dequeue_enabled   ? 'S'    # queue is stopped
                : $controller->is_exception_queue ? 'E'
                : !$controller->auto_start          ? 'O'    # auto_start is reset
                : $listener                       ? 'L'    # queue is listened
                : '-';
        };
        printf "%-30s %-10s %-3s %-3s %20s %23s\n", $controller->queue_name,
            ( $controller->is_exception_queue ? 'exception' : 'normal' ),
            ( $controller->is_exception_queue ? '-'
            : $controller->enqueue_enabled ? 'yes'
            : 'no' ), ( $controller->dequeue_enabled ? 'yes' : 'no' ), $pid_str,
            $messages_str;
    }
    if (!$hide_legend){
        print $this->list_queues_legend;
    }
}

sub list_queues_legend {
    my ($this) = @_;
   
    return <<"END_LEGEND";

Columns legend:

Queue   - queue name
Type    - either normal or exception queue
Enq     - can the messages be enqueued?
Deq     - can the messages be dequeued?
Daemon  - "state" of the queue
        S   - stopped for dequeue (physically), no daemon can be run, no messages moved from
        E   - exception queue, no daemon can be run
        0   - auto_start is reset, no daemon will be run, but messages can be dequeued from 
        L   - listener is listening on queue
        <number> - pid of the currently running daemon
Messages (Active) - number of messages in queue. Inactive messages 
    are those to be run at particular time or failed ones waiting for next retry. 
END_LEGEND
}

sub start_controller {
    my ( $this, $controller ) = @_;

    warn "Starting daemon on queue $E{ $controller->queue }\n";

    # when daemons end the listener (it may be different instance is notified)
    my $on_end = sub {
        $this->_control_listener(
            $this->new_dc_payload( 'stopped', $controller->queue ) );
    };
    $controller->start_daemon( { 'on_end' => $on_end, } );
}

sub _clean_dead_listener {
    my ($this) = @_;

    my $listener = $this->retrieve_listener;
    return if !$listener || $listener->is_alive;

    warn("Listener $E{ $listener->queue_table } seems dead\n ");
    $this->txn_do(
        sub {
            $listener->delete;
        }
    );
}

sub retrieve_listener {
    my ($this, @condition) = @_;

    my ($listener) = $this->listener_class->search(
        @condition ? @condition : ('queue_table' => $this->queue_table ));

    return $listener;
}

sub move_messages {
    my ($this, @condition) = @_;
}

sub list_messages {
    my ( $this, $selection, $options, @controllers ) = @_;

    for my $controller (@controllers) {
        $controller->list_messages( $selection, $options );
    }
}

1;

__END__

=head1 NAME

Akar::AQ::Manager - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
