package Akar::SOAP::Exception;
{
  $Akar::SOAP::Exception::VERSION = '1.994';
}
use strict;
use warnings;


use base qw(Class::Accessor::Fast Exporter);
use overload 
	'""' => 'as_string',
	'fallback' => 1;

# methods exported on demand (preferred)
our @EXPORT_OK = qw(is_soap_exception);

use Carp qw(carp croak);
use Scalar::Util qw(blessed);
use Data::Dump qw(pp);

__PACKAGE__->mk_ro_accessors(qw(soap_fault transport_error any_som));

sub is_soap_exception {
    my ($exc) = @_;

    return blessed($exc) && $exc->isa(__PACKAGE__);
}

# only for compatibility
sub is_soap_fault { shift()->soap_fault }

sub new {
    my ( $class, $soap, $som ) = @_;

    return $class->SUPER::new(
        {   (   $som && blessed($som)
                ? ( 'soap_fault' => $som )
                : ( 'transport_error' =>
                        eval { scalar $soap->transport->status } )
            )
        }
    );
}

# most frequently used
sub as_string {
    my $this = shift;

    if ( my $soap_fault = $this->soap_fault ) {
        my $msg = sprintf "SOAP fault: %s %s", $soap_fault->faultcode,
            $soap_fault->faultstring;
        if ( my $detail = $soap_fault->faultdetail ) {
            $msg .= "\n    detail " . pp($detail);
        }
        $msg .= "\n";
        return $msg;
    }

    if ( my $transport_error = $this->transport_error ) {
        return "SOAP transport error: $transport_error\n";
    }

    # text error
    return sprintf "SOAP unspecified error: SOM follows\n%s\n", $this->any_som;
}

1;

__END__

=head1 NAME

Akar::SOAP::Exception - clent SOAP exception class

=head1 SYNOPSIS

  use Akar::SOAP::Exception qw(is_soap_exception);

  my $info = eval {
	$service->any_call($x); #... soap call
  };

  my $exc = $@;
  if ($exc && is_soap_exception($exc)){
	# action
	if ($exc->is_soap_fault){
		...
		print $exc->som->faultstring;
	}
  }

=head1 DESCRIPTION

Akar::SOAP::Exception is an exception thrown by default on_fault handler
of Akar::SOAP::Lite in case of error (SOAP or transport).

Stringification od Akar::SOAP::Exception is overloaded so the exception behaves 
also as ordinary string.

=head1 Methods

=over 4

=item is_soap_fault

Returns true if the exception is SOAP Fault (it is not a transport error).

=item soap_fault

  warn $exc->soap_fault->faultstring if $exc->soap_fault;

Returns SOAP::SOM object associated with the exception (See SOAP::Lite) if any.

=item transport_error

Returns transport error if it was triggered.

=back

=head1 Exported functions 

=over 4

=item is_soap_exception

  if (is_soap_exception($@)){
	...
  }

Returns true if argument is defined and of class inherited from Akar::SOAP::Exception.
Exported on demand.

=back

=head1 AUTHOR 

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
