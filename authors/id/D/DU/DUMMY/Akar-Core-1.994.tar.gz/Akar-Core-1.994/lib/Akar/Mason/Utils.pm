package Akar::Mason::Utils;
{
  $Akar::Mason::Utils::VERSION = '1.994';
}
use strict;
use warnings;

use Exporter 'import';

use Carp qw(carp croak);
use HTML::Mason::Escapes;

our @EXPORT_OK = qw(element_tag);

# returns opening and closing tag
sub element_tag {
    my $element = shift or return;

    # we preserve the order of attributes
    # processing them in reverse order
    # the latter keys overrides the prior ones
    @_ % 2 == 0
        or die "Odd number of elements in attribute key => value list\n";

    my $attrs = '';
    my %processed;
ATTR: while (@_) {
        my $value = pop();
        my $name  = pop();

        if ( ref $value && ref $value eq 'ARRAY' ) {

            # most likely class attribute
            $value = join( ' ', grep { defined($_) && $_ ne '' } @$value );
        }

 # _ underscore attributes, undef attributes and empty attributes are  skipped
        next ATTR
            if $processed{$name}++
            || !defined($value)
            || $name =~ /^_/
            || ($value eq '' && $name ne 'value');

        HTML::Mason::Escapes::basic_html_escape( \$value );
        $attrs = " $name=\"$value\"" . $attrs;
    }
    return
        wantarray
        ? ( "<$element$attrs>", "</$element>" )
        : "<$element$attrs />";
}

1;

__END__

=head1 NAME

Akar::Mason::Utils - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
