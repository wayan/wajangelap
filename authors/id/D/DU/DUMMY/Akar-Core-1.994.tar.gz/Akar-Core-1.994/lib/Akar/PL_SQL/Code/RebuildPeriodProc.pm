package Akar::PL_SQL::Code::BulkBindFragment::Cumulative;
{
  $Akar::PL_SQL::Code::BulkBindFragment::Cumulative::VERSION = '1.994';
}
use strict;

# adds dump_rebuild_day proc into bulk_bind_fragment

use Akar::PL_SQL::Code::Functions qw(ilist);

sub dump_rebuild_period_proc {
    my ( $this, $name ) = @_;

    $name ||= 'rebuild_period';

    return (
        'procedure ' . $name . '(',
        ilist( 'in_from in date', 'in_to in date default null' ),
        ')',
        'is', 
        'l_from date;', 'l_to date;',
        'begin',
        'l_from := trunc(in_from);',
        'if in_to is not null then', 
            iblock('l_to := trunc(in_to);'), 
        'else',
            iblock('l_to := l_from;'),
        'end if;',
        '-- clearing the report',
        'update ' . $this->table,
        'set',
        ilist(
            map {
                my $column = $_;
                ( $_->style eq 'sum' || $_->style eq 'count' )
                    ? $column->name . '= 0'
                    : ();
            } $this->columns
        ),
        'where day >= l_from and day < l_to + 1;',
        $this->proc_name('init'). ';',
        '-- adding all rows from the period',
        'for l_primary in (',
        iblock(
            'select',
            ilist( map { $_->name } $this->input_params ),
            'from ' . $this->primary_table,
            'where end_date_time >= l_from and end_date_time < l_to + 1'
        ),
        ')', 'loop',
        iblock( $this->proc_name('add') . '(', 
            ilist( (map {'l_primary.'. $_->name} $this->input_params), 1 ), 
        ');', ),
        'end loop;',
        $this->proc_name('flush'). ';',
        "end $name;"
        );
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96: 
