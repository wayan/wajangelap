package Akar::TemporalDFA;
{
  $Akar::TemporalDFA::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Akar::PrefixFinder);

use Carp qw(carp croak);
use Akar::RangeFinder;

sub add_value {
    my ($this, $prefix, $value, $valid_from, $valid_to) = @_; 

    my $range_finder = $this->match_exact($prefix);
    if (!$range_finder){
        $range_finder = Akar::RangeFinder->new;
        $this->add_string( $prefix, $range_finder );
    }
    $range_finder->add_value( $value, $valid_from, $valid_to );
}

sub get_value {
    my ( $this, $str, $date ) = @_;

    my $maxlen;
    while ( my ( $prefix, $range_finder )
        = $this->match_long( $str, $maxlen ) )
    {
        my $value = $range_finder->get_value($date);
        return $value if defined $value;

        # I found proper prefix, but no range for the day exists,
        # so I try shorter prefix
        $maxlen = length($prefix) - 1;
    }
    return;
}

1;

__END__

=head1 NAME

Akar::TemporalDFA - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
