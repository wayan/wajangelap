package Akar::Mason::PComponent::XHTML;
{
  $Akar::Mason::PComponent::XHTML::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Akar::Mason::PComponent);

use Class::C3;
use Scalar::Util qw(weaken);
use HTML::Mason::Escapes;
use JSON;
use File::Find;
use File::Basename qw(basename);
use File::Slurp qw(slurp);
use File::Spec;
#use Akar::Javascript::JSON;
use Image::Size qw(imgsize);
use Data::Uniqid qw(uniqid);

use Akar::Mason::Utils qw(element_tag);

use Carp qw(carp croak);

sub c { return $HTML::Mason::Commands::c; }

# kod, ktery vyrenderuje Javascript
sub javascript : Global {
    my ($this, $m, %args) = @_;

    if (my $content_sub = $m->pcomp_csub) {

        # P .. arguments passed to javascript from Perl
        if ( exists $args{P} ) {
            my $P    = $args{P};
            my $orig = $content_sub;
            $content_sub = sub {

                # zbavime se jednoho uzaveru
                $m->print( "var P=" . json_encode($P) . ";\n" );
                $orig->();
                return;
            };
        }

        # almost all code has jQuery wrapper running the code via onDomReady
        if ( !$args{immed} ) {
            my $unwrapped = $content_sub;
            $content_sub = sub {
                $m->print("\$(function(\$){\n");
                $unwrapped->();
                $m->print("});\n");
            };
        }
        my ( $open, $close ) = element_tag( 'script', type => 'text/javascript' );
        $m->print( $open . '// <![CDATA[' . "\n" );
        $content_sub->();
        $m->print( '// ]]>' . $close );
    }
}

sub elem : Auto {
    my ($this, $m, $elem, %args) = @_;

    if ( my $content_sub = $m->pcomp_csub ) {
        if ( my $jquery_data = delete $args{jquery_data} ) {
            my $id = $args{id} ||= 'X'. uniqid();
            $m->pcomp(
                [ $this, 'javascript' ],
                [ P => $jquery_data ],
                sub {
                    $m->print("\$('#$id').data(P)");
                }
            );
        }
        my ( $open, $close ) = element_tag( $elem, %args );
        $m->print($open);
        $content_sub->();
        $m->print($close);
    }
    else {
        $m->print( scalar element_tag($elem, %args) );
    }
}

sub img : Global : Local {
    my ($this, $m, %args) = @_;

    die "img cannot be called with content\n " if $m->pcomp_has_content;

    # I want args in same order
    my $img = delete $args{img};
    if ( !$img ) {
        my $src = $args{src}
            or die "Image has no source\n";
        if ( !ref $src ) {

            # we compute the width and height only for static
            # images (src is string not uri)
            $img = _img( $args{src} );
        }
    }


    # element_tag MUST be called in scalar context => <img ... />
    my $tag = element_tag(
        'img',
        alt => '',
        %args,
        (   $img
            ? ( src    => $this->c->uri_for( $img->{path} ),
                width  => $img->{width},
                height => $img->{height}
                )
            : ()
        ),
    );
    $m->print($tag);
}

sub json_encode {   
    # docasne reseni
    no warnings 'redefine';
    local *URI::TO_JSON = sub { return "$_[0]"; };
    return JSON->new->allow_nonref->convert_blessed->encode(shift());
}

sub _file {
    my $path     = shift();
    my $abs_path = Akar::Base->app_home( 'lib/www/' . $path );
    -f $abs_path or die "Can't find file $path, file doesnot exist\n";
    return {
        path     => $path,
        abs_path => $abs_path,
    };
}

my %Images;
sub _img {
    my $path = shift;

    return $Images{$path} ||= do {
        my $img = _file($path);
        @$img{qw(width height)} = imgsize( $img->{abs_path} );
        $img;
    };
}

1;

__END__

=head1 NAME

Akar::Mason::PComponent::XHTML - support for xhtml rendering for mason request

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

