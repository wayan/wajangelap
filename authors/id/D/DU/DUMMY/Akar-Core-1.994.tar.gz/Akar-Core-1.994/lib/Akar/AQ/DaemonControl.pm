package Akar::AQ::DaemonControl;
{
  $Akar::AQ::DaemonControl::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);
use Akar::DBI::Statement qw(sql_param sql sql_param_inout sql_and sql_join);
use Interpolation 'E' => 'eval', 'sqlp' => sub { return sql_param(@_) };
use FileHandle;

sub dc_payload_fields { return qw(action sender); }

sub dc_payload_type { return 'akar.aq_controller_dc_t'; }

{
    my $package = __PACKAGE__;

    package Akar::AQ::DaemonControl::DCPayload;
{
  $Akar::AQ::DaemonControl::DCPayload::VERSION = '1.994';
}
    use base qw(Class::Accessor::Fast);

    __PACKAGE__->mk_accessors( $package->dc_payload_fields );
}

sub new_dc_payload {
    my ( $this, $action, $sender ) = @_;

    return Akar::AQ::DaemonControl::DCPayload->new(
        {   'action' => $action,
            'sender' => $sender,
        }
    );
}

sub list_dc_payload {
    my ( $this, $payload ) = @_;

    return $payload->action
        . ( $payload->sender ? ' from ' . $payload->sender : '' );
}

# enqueue the message into daemon control queue, returns the message id
sub enqueue_dc_action_for {
    my ( $this, $daemon, $dc_payload ) = @_;

    if ( !ref $dc_payload ) {
        $dc_payload = $this->new_dc_payload($dc_payload);
    }
    my $compose_psql = sql_join ', ',
        map { sql_param( $dc_payload->$_ ) } $this->dc_payload_fields;

    my $msgid;
    my $dc_payload_type   = $this->dc_payload_type;
    my $dc_queue          = $this->DC_QUEUE;
    $this->db_Main->do(<<"END_PSQL");
        DECLARE
            l_message_properties    sys.dbms_aq.message_properties_t;
            l_enqueue_options       sys.dbms_aq.enqueue_options_t;
            l_msgid raw(128); 
            l_payload $dc_payload_type := $dc_payload_type($compose_psql);
        BEGIN   
            -- only multiple consumer has to set rcpt 
            l_message_properties.recipient_list(0) := sys.aq\$_agent(
                $sqlp{ $daemon->agent_name },
                $sqlp{ $dc_queue }, 
                0);
            sys.dbms_aq.enqueue(
                queue_name  => $sqlp{ $dc_queue },
                enqueue_options => l_enqueue_options,
                message_properties => l_message_properties,
                payload            => l_payload,
                msgid              => l_msgid); 
            $E{ sql_param_inout(\$msgid, 128) } := l_msgid;
        END;
END_PSQL
    return $msgid;
}

sub dequeue_dc {
    my ( $this, $daemon ) = @_;

    # decomposing the variable into params
    my %dc_payload;

    my $consumer_name = $daemon->agent_name;
    my $dc_queue      = $this->DC_QUEUE;
    my $sql           = sql(<<"END_PSQL");
        DECLARE
            l_message_properties    sys.dbms_aq.message_properties_t;
            l_dequeue_options       sys.dbms_aq.dequeue_options_t;
            l_payload               $E{ $this->dc_payload_type };
            l_target_queue varchar2(256);
            l_msgid raw(128); 
        BEGIN
            l_dequeue_options.navigation    := sys.dbms_aq.FIRST_MESSAGE;
            l_dequeue_options.wait          := 1;
            l_dequeue_options.dequeue_mode  := sys.dbms_aq.REMOVE;
            l_dequeue_options.consumer_name := $E{ $consumer_name ?  sql_param($consumer_name): 'null' };
            sys.dbms_aq.dequeue(
                queue_name  => $sqlp{ $dc_queue },
                payload     => l_payload,
                message_properties => l_message_properties,
                dequeue_options    => l_dequeue_options,
                msgid              => l_msgid); 
            $E{ 
                sql_join "\n", map {
                    my $param = sql_param_inout( \$dc_payload{$_}, 48 );
                    sql("$param := l_payload.$_;");
                } $this->dc_payload_fields
            }
        END;
END_PSQL
    my $sth = $this->db_Main->prepare($sql);
    $sth->execute;
    return $this->new_dc_payload( @dc_payload{qw(action sender)} );
}

sub redirect_daemon_output {
    my ($this, $logfile) = @_;

    my $logfh = FileHandle->new( $logfile, '>>' )
        or die "Can't open '$logfile' for writing: $! \n ";

    warn "Output will be redirected to '$logfile'\n";

    open STDIN, '</dev/null' or die "Can't open STDIN from /dev/null: $!\n ";
    open STDOUT, '>&' . $logfh->fileno()
        or die "Can't reopen STDOUT into log '$logfile': $!\n ";
    STDOUT->autoflush(1);
    open STDERR, '>&STDOUT' or die "Can't reopen STDERR into STDOUT: $!\n ";
}

# daemon control 
sub DC_QUEUE { return 'AKAR.AQ_CONTROLLER_DC_Q'; }

# 2009-07-02 danielr
# since I have sudden problem with $this->db_Main->err returning undef (caused
# by AutoCommit=1?) I add the detection of error
sub dbh_err {
    my ( $this, $error ) = @_;

    my $err = $this->db_Main->err;
    return $err if $err;

    # it is a bit evil and works for oracle only
    my ($code) = $error =~ /\bORA-(\d+):/
        or die "Can't determine the error code number\n";
    return $code;
}

1;

__END__

=head1 NAME

Akar::AQ::DaemonControl - common properties of Manager and Controller regarding dc_queue

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
