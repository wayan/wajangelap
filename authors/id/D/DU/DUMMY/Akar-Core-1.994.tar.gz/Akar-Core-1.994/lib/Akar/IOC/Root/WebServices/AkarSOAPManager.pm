package Akar::IOC::Root::WebServices::AkarSOAPManager;
{
  $Akar::IOC::Root::WebServices::AkarSOAPManager::VERSION = '1.994';
}
use MooseX::Role::Parameterized;

use strict;
use warnings;

use namespace::autoclean;

# the role adding services emulating the behaviour of Akar-SOAP-Manager
# (SOAP::Lite + Apache)
#
use Class::Load;
use File::Slurp qw(slurp);
use Carp qw(confess);
use Plack::Request;
use Plack::Builder;

use Akar::BreadBoard;

# use the soap basic auth
parameter basic_auth => ( default => 1 );

role {
    my $P = shift;

    before build_content => sub {

        # list of service modules
        config_service dispatch_to => ();
        config_service dispatch_with => ( default => sub { return {} } );
        config_service raw_logging => ( default => 0 );
        config_service basic_auth  => ( default => 1 );

        # must be supplied from outside
        #
        # Assumimng we have runner in WebServices (..)
        alias runner         => '../runner';
        service htusers_file => (
            block => sub {
                my $s = shift;
                return $s->param('runner')->data_root . '/' . 'htusers.pwd';
            },
            dependencies => [qw(runner)],
        );

        service raw_logging_file => (
            block => sub {
                my $s = shift;
                return $s->param('runner')->log_dir . '/'
                    . 'SOAP_raw_data.log';
            },
            dependencies => [qw(runner)],
        );

        # complete psgi_app with wsdl and soap
        service psgi_app => (
            dependencies => [qw(soap_psgi_app wsdl_psgi_app)],
            block        => sub {
                my $s = shift;
                my $p = $s->params;

                return builder {
                    mount '/wsdl' => $p->{wsdl_psgi_app};
                    mount '/soap' => $p->{soap_psgi_app};
                };
            },
        );

    # returns filtering psgi_app
    # to be used when the url (for example /soap) is shared with other
    # application
    # this middleware chooses which application to use according to SOAPAction
    # it is used in Durian maybe
        service soap_middleware => (
            block => sub {
                my $s = shift;
                my $p = $s->params;

                my $psgi_app = $p->{soap_psgi_app};

                # quite approximate
                my $re = join '|', map {
                    my $path = join '/', split /::/, $_;
                    "^\Q$path";
                } @{ $p->{dispatch_to} }, values %{ $p->{dispatch_with} };
                $re = qr{$re};

                return sub {
                    my $app = shift;
                    sub {
                        my ($env) = @_;

                        my $SOAPAction = $env->{HTTP_SOAPACTION} || '';
                        $SOAPAction =~ s/^"//;
                        $SOAPAction =~ s/"$//;

                        return (
                            (   $SOAPAction =~ $re

                              # 2013-05-13 danielr
                              # unfortunately some of the old services
                              # (call statement) use the empty '""' SOAPAction
                                    || $SOAPAction eq ''

                                ? $psgi_app
                                : $app
                            )->($env)
                        );
                    };
                };
            },
            dependencies =>
                [ 'soap_psgi_app', 'dispatch_to', 'dispatch_with' ],
        );

        # SOAP service with the middleware
        service soap_psgi_app => (
            block => sub {
                my $s = shift;
                my $p = $s->params;

                return builder {
                    enable $p->{basic_auth_middleware}  if $p->{basic_auth};
                    enable $p->{raw_logging_middleware} if $p->{raw_logging};
                    $p->{raw_soap_psgi_app};
                };
            },
            dependencies => [
                qw(basic_auth_middleware
                    raw_logging_middleware
                    raw_logging
                    basic_auth
                    raw_soap_psgi_app
                    )
            ],
        );

        # the bare psgi app without any middleware
        service raw_soap_psgi_app => (
            block => sub {
                my $transport = shift()->param('soap_transport');
                return sub {
                    return $transport->handle( Plack::Request->new(@_) );
                };
            },
            dependencies => [qw(soap_transport)],
        );

        # old style wsdl mapping wsdl/My/Module
        service wsdl_psgi_app => (
            block => sub {
                my $s = shift;
        
                return $s->params->{wsdl_middleware}->(sub {});
            },
            dependencies => [qw(wsdl_middleware)],
        );

        service wsdl_middleware => (
            block => sub {
                my $s = shift;

                return sub {
                    my $app = shift;

                    return builder {
                        my $ret;
                        for my $module ( @{ $s->param('dispatch_to') } ) {
                            my $path = join '/', '', split( /::/, $module );
                            mount $path => $s->parent->module_wsdl_psgi($module);
                        }

                        # if we don't find the wsdl we fallback to application 
                        mount '/' => $app;
                    };
                };
            },
            dependencies => [qw(dispatch_to load_modules)],
        );

        # returns nothing only loads dispatch_to modules
        service load_modules => (
            block => sub {
                my $s = shift;
                for my $class ( @{ $s->param('dispatch_to') } ) {
                    Class::Load::load_class($class);
                }
                return 1;
            },
            lifecycle    => 'Singleton',
            dependencies => [qw(dispatch_to)],
        );

        service soap_transport => (
            class        => 'SOAP::Transport::HTTP::Plack',
            dependencies => [qw(dispatch_with dispatch_to)],
        );

        # service htusers_file - this service has to be supplied
        # from the role used
        # service htusers_file => ();

        service basic_auth_middleware => (
            class => 'Plack::Middleware::Auth::Basic',
            block => sub {
                my $s = shift();

                # params must be evaluated here, not inside sub
                my %p = %{ $s->params };
                return sub {
                    return $s->class->wrap( shift(), %p );
                };
            },
            dependencies => { authenticator => 'htusers_authenticator' },
        );

        service raw_logging_middleware => (
            constructor_name => 'wrapper',
            class            => 'Akar::Plack::Middleware::SOAPRawData',
            dependencies     => { file => 'raw_logging_file' },
        );

        # the subroutine checking against htusers pwd
        service htusers_authenticator => (
            class            => 'Akar::Plack::Util::HtusersAuthenticator',
            constructor_name => 'authenticator',
            dependencies     => { file => 'htusers_file' },
        );
    };

    # PSGI for one module
    method module_wsdl_psgi => sub {
        my ( $this, $module ) = @_;
        return sub {
            my $req = Plack::Request->new( shift() );

            # soap usually resides on /soap
            # while wsdl on /wsdl
            my $uri  = $req->uri;
            my $path = $uri->path;
            $path =~ s/\bwsdl\b.*/soap/;
            $uri->path($path);
            return [
                200,
                [ 'Content-type' => 'text/xml' ],
                [ $module->create_wsdl($uri) ]
            ];
        };
    };
};

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
