package Akar::WebServices::XSD;
{
  $Akar::WebServices::XSD::VERSION = '1.994';
}
use strict;
use warnings;

use Path::Class;

sub base_dir {
    return dir(file(__FILE__)->parent, 'xsd');
}

# paths for XSD files stored together in perl dirs
sub xsd_path {
    my ($class, $path) = @_;

    return file($class->base_dir, $path);
}

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
