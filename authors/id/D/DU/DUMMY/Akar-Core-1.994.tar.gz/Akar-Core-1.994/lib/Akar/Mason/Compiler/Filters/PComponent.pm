package Akar::Mason::Compiler::Filters::PComponent;
{
  $Akar::Mason::Compiler::Filters::PComponent::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);

# enables calling PComponents (components in Perl modules) from mason
# <& namespace:method, ... &>
# <&| namespace:method, ...&>...</&>

sub new {
    my $class = shift;
    my $this  = $class->next::method(@_);

    $this->add_filter(
        {   component_content_call => _component_call(1),
            component_call         => _component_call(0),
        },
        30      # lower priority, if someone wants to redefine SOME:SOME
                # it overruns PComponent
    );
    return $this;
}

sub _component_call {
    my ($has_content) = @_;

    return sub {
        my ( $this, %args ) = @_;

        my $pcomp_args = _pcomp_args($args{call}) or return;
        $pcomp_args .= ', sub {___}' if $has_content;

        # callbacks are stopped before output perl is called
        $this->stop_callbacks;
        # content subroutine (if exists) is passed as last parameter
        # output_perl with one or 2 args
        $this->output_perl( split /___/, "\$m->pcomp($pcomp_args);");
    };
}

sub _pcomp_args {
    my $call = shift;

    $call =~ s/^\s*//;

    # as pcomponents are recognized all calls
    # WORD
    # WORD:SOMETHING
    if ( my $name = $call =~ s/^(\w+(?::\w+)?)\s*(?:,\s*|$)// && $1 ) {

        # WORD:WORD or WORD
        return if $name =~ /^(PARENT|SELF):/;    # solved by mason
        return " '$name', [$call] ";
    }
    elsif ( my $ns = $call =~ s/^(\w+):\s*// && $1 ) {

       # WORD:SOMETHING (xhtml: @args)
        return
            "do { my \@args = ($call); my \$first; \$first = shift \@args if \@args; ('$ns\:'. (defined \$first?\$first:''), \\ \@args) }";
    }
    return;
}

1;

__END__

=head1 NAME

Akar::Mason::Compiler::PComponent - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
