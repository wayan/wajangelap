package Akar::Log::Any::WithLogging;
{
  $Akar::Log::Any::WithLogging::VERSION = '1.994';
}
use MooseX::Role::Parameterized;

# logging with Akar::Log::Message::Structured and Any::Log
#
#

{

   # this is the only way how to put insert StrictConstructor
   # into parameters object
   # I create the own parameters class and let the MooseX::Role::Parameterized
   # to work with it
    my $meta = __PACKAGE__->meta;
    $meta->parameters_metaclass(
        do {

            package Akar::Log::WithStructured::Parameters;
{
  $Akar::Log::WithStructured::Parameters::VERSION = '1.994';
}
            use Moose;
            use MooseX::StrictConstructor;

            extends $meta->parameters_class;
            __PACKAGE__->meta;
            }
    );
}

use Log::Any;
use Akar::Log::Message::Structured;

parameter category => ();

parameter levels => (
    isa        => 'ArrayRef',
    auto_deref => 1,
    default    => sub {
        return [
            qw(trace
                debug
                info inform
                notice
                warning warn
                error err
                critical crit fatal
                alert
                emergency)
        ];
    },
);

# whether the arguments of logging functions are turned to structured message
parameter structured => ( default => 1 );

parameter delegation => ( default => 1 );

# the class for structured message
parameter message_class => ( default => 'Akar::Log::Message::Structured' );

# only to calm down strict constructor when consuming -extra and -alias 
parameter _FAKE_excludes => ( is => 'bare', init_arg => '-excludes' );
parameter _FAKE_alias    => ( is => 'bare', init_arg => '-alias' );

role {
    my $p = shift();

    my $message_class = $p->message_class;

    my $logger = Log::Any->get_logger(
        $p->category ? ( category => $p->category ) : () );

    method logger => sub { return $logger; };

    my $structured = $p->structured;
    if ($structured) {
        method new_log_message => sub {
            my $this = shift;
            return $message_class->new(@_);
        };
    }

    if ( $p->delegation ) {
        for my $level ( $p->levels ) {

            # delegation
            method "log_$level" => sub {
                my $this = shift;

                # 2012-12-05 danielr
                # passing log levels into message also
                $this->logger->$level(
                      $structured
                    ? $this->new_log_message( level => $level, @_ )
                    : @_
                );
            };
        }
    }
};

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
