package Akar::PrefixFinder;
{
  $Akar::PrefixFinder::VERSION = '1.994';
}
use strict;
use warnings;

# stores prefixes and values
# for a string given can find longest prefix and associated value


use Carp qw(carp croak);
use List::Util qw(min);

use constant 'MINLEN_IDX' => 0;
use constant 'MAXLEN_IDX' => 1;
use constant 'COUNT_IDX'  => 2;
use constant 'LOOKUP_IDX' => 3;

sub new {
    my ($package) = @_;

    return bless( [ 0, 0, 0 ] => $package );
}

sub count  { return ${ shift() }[COUNT_IDX] }
sub minlen { return ${ shift() }[MINLEN_IDX] }
sub maxlen { return ${ shift() }[MAXLEN_IDX] }

sub add_string {
    my ( $this, $prefix, $value ) = @_;

    defined($value) or croak "No undefined value can be added\n ";

    my $length = length($prefix)
        or croak "Prefix long 0 chars can't be added\n ";

    $this->[ LOOKUP_IDX + $length ]{$prefix} = $value;

    if ( ++$this->[COUNT_IDX] == 1 ) {

        # first prefix
        $this->[MAXLEN_IDX] = $this->[MINLEN_IDX] = $length;
    }
    else {
        # ranges are shifted if necessary
        if ( $length > $this->[MAXLEN_IDX] ) {
            $this->[MAXLEN_IDX] = $length;
        }

        if ( $length < $this->[MINLEN_IDX] ) {
            $this->[MINLEN_IDX] = $length
        }
    }
}

sub add_prefix {
    my ($this, $prefix, $value) = @_;

    return $this->add_string($prefix => $value);
}

# removes the prefix (only existing)
sub remove_prefix {
    my ( $this, $prefix, $value ) = @_;

    my $prefix_map = $this->[ LOOKUP_IDX + length($prefix) ]
        or return;
    delete $prefix_map->{$prefix};
    return;
}

sub match_long {
    my ( $this, $str, $maxlen ) = @_;

    # looking for prefix of length $length
LENGTH: for (
        my $length = min(
            length($str), $this->[MAXLEN_IDX],
            defined($maxlen) ? $maxlen : ()
        );
        $length >= $this->[MINLEN_IDX];
        $length--
        )
    {
        my $lookup = $this->[ LOOKUP_IDX + $length ] or next LENGTH;
        my $prefix = substr( $str, 0, $length );
        my $value  = $lookup->{$prefix};

        return wantarray ? ( $prefix, $value ) : $value
            if defined($value);
    }

    # nothing found
    return;
}

sub match_exact {
    my ( $this, $str ) = @_;

    my $lookup = $this->[ LOOKUP_IDX + length($str) ]
        or return;

    return $lookup->{$str};
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96:

1;

__END__

=head1 NAME

Akar::PrefixFinder - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
