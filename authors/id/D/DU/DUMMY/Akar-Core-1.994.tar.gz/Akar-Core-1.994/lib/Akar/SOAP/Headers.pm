package Akar::SOAP::Headers;
{
  $Akar::SOAP::Headers::VERSION = '1.994';
}

=head1 NAME

Akar::SOAP::Headers - processing of headers

=head1 DESCRIPTION

Akar::SOAP::Headers->process is called in the prologue of every Akar::SOAP::Method method. 
to create a Perl objects for each header. This objects are then accessible from methods.

=cut

use strict;
use URI;

sub import {
	my $this = shift;
	while(my($k, $v) = splice(@_,0,2)){
		my $method = 'import_'.$k;
		$this->$method($v);
	}
}

sub import_checkMustUnderstand {
	$SOAP::Constants::DO_NOT_CHECK_MUSTUNDERSTAND = $_[0];
}

# Objects originated from current headers
our @Objects;

sub process_som {
	my $this = shift;
	my($som) = @_;

	my(@headers) = $som->headerof(ref($som)->headers);

	# header modification - I try to prevent SOAP encoding
	for(my $i=1; $i <= @headers; $i++){
		(my $path = ref($som)->headers) =~ s,/[^/]*$,/[$i]/[>0],;
		if($som->match($path)){	
			$headers[$i - 1]->type('');
			$headers[$i - 1]->value(join('', map {
# TFUUUUJ
				my $xml = Akar::SOAP::Lite->serializer->serialize($_);
				$xml =~ s/<\?xml.*?>//si;
				$xml;
			} $som->dataof));
		}
	}
	@Objects = map($this->process_header($_), @headers);
}

sub process_header {
	my $this = shift;
	my($header) = @_;

	if(my $package = $this->uri_to_package($header->uri)){
		eval qq{require $package;};
		die($@) if $@;
		return($package->header($header));
	}
	else {
    		die SOAP::Fault
      			->faultcode($SOAP::Constants::FAULT_MUST_UNDERSTAND)
			->faultstring("Unrecognized header has mustUnderstand attribute set to 'true'")
  			if $header->mustUnderstand;
		return();
	}
} 

sub uri_to_package {
	my $this = shift;
	my($uri) = @_;

	(my $package = URI->new($uri)->path) =~ s,/,::,g;
	$package =~ s/^:://;
	return($package);
}

=item get_by_package

  Akar::SOAP::Headers->get_by_package(PACKAGE,...)

Returns all header objects which are descendants of any package supplied.
To get all callbacks, you need to write:

  my @callbacks = Akar::SOAP::Headers->get_by_package('Akar::SOAP::Extension::Callback');

Or just

  my @callbacks = Akar::SOAP::Extension::Callback->get_current;

=cut

sub get_by_package {
	my $this = shift;
	return(grep {my $obj = $_; grep {$obj->UNIVERSAL::isa($_)} @_} @Objects);
}

=back

=head1 AUTHOR 

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

1;
