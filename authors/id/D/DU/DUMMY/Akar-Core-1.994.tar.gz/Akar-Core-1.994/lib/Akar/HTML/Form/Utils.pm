package Akar::HTML::Form::Utils;
{
  $Akar::HTML::Form::Utils::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Exporter);

use Carp qw(carp croak);
our @EXPORT_OK = qw(is_array auto_expand);

use Scalar::Util qw(blessed);

sub is_array {
    my $ref = ref( shift() );
    return $ref && $ref eq 'ARRAY';
}

# interpolates arrayref
sub auto_expand {
    my @args = grep { defined $_ } @_;

    if ( @args == 1 ) {
        my ($arg) = @args;
        return wantarray && is_array($arg) ? @{$arg} : $arg;
    }
    elsif ( @args > 1 ) {

        # if more than one value supplied it must be returned as array ref
        # in scalar context
        die "Array reference in the middle of list\n "
            if grep { is_array($_) } @args;
        return wantarray ? @args : \@args;
    }
    else {
        return;
    }
}


1;

__END__

=head1 NAME

Akar::HTML::Form::Utils - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
