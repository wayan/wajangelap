package Akar::Filter::MasonPL::Base;
{
  $Akar::Filter::MasonPL::Base::VERSION = '1.994';
}

=head1 NAME

Akar::Filter::MasonPL::Base

=head1 SYNOPSIS

=head1 DESCRIPTION

=cut

use strict;


use File::Path qw(mkpath);
use File::Basename qw(dirname);
use File::Spec;

use HTML::Mason;

use constant 'COMPONENT_SOURCE_FILE_FIELD' => '_akar_source_file';

{

    my $interp;

    # current Mason interpreter - singleton
    sub interp {
        my ($this) = @_;

        unless ($interp) {
            eval { require Akar::Base; };
            unless ($@) {

                # application hierarchy exists
                my $data_dir  = Akar::Base->app_data('mason');
                my $comp_root = Akar::Base->app_home('lib/mason');
                mkpath($data_dir);
                $interp = HTML::Mason::Interp->new(
                    'comp_root' => $comp_root,
                    'data_dir'  => $data_dir
                );
            }
            else {

                # No Akar::Base available
                $interp = HTML::Mason::Interp->new;
            }
        }
        $interp;
    }
}


# if comp is created from file, associates the file with it
sub get_component_source_file {
    my ($this, $component) = @_;

    $$component{COMPONENT_SOURCE_FILE_FIELD};
}

sub set_component_source_file {
    my ($this, $component, $source_file) = @_;

    $$component{COMPONENT_SOURCE_FILE_FIELD} = $source_file;
}

sub make_component {
    my $this = shift;
    my ($key, $value) = @_;

    my $comp = $this->interp->make_component(@_);
    $this->set_component_source_file($comp, $value) if $key eq 'comp_file';
    $comp;
}

sub process_buffer {
    my($this, $buffer, @params) = @_;
    $this->process_comp($this->make_component('comp_source' => $buffer), @params);
}

sub process_file {
    my($this, $file, @params) = @_;
    $this->process_comp($this->make_component('comp_file' => $file), @params);
}

sub process_comp {
    my ($this, @params) = @_;

    my $buffer;
    $this->interp->out_method(\$buffer);
    $this->interp->exec(@params);
    $buffer;
}

# returns absolute path relative to current component
sub rel2abs {
    my ($this, $file) = @_;

    my $base_file = $this->get_component_source_file(HTML::Mason::Request->instance->current_comp)
      or die "Can't find base file for relative component path $file\n";
    File::Spec->rel2abs($file, dirname($base_file));
}

sub relative_comp {
    my ($this, $file) = @_;

    $this->make_component('comp_file' => $this->rel2abs($file));
}

# enables to call component with path relative to current working directory
sub HTML::Mason::Commands::akar_relative_comp {
    __PACKAGE__->relative_comp(@_);
}

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

1;

