package Akar::SOAPClient;
{
  $Akar::SOAPClient::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor::Grouped);

use Carp qw(carp croak);
use Class::Trait qw(Akar::Trait::PackageConfig);
use Class::C3;
use LWP::UserAgent;
use Akar::XML::DOMBuilder;
use Akar::SOAP::Utils qw(soap_xml_data);
use Akar::Iconv qw(utf8_il2);

__PACKAGE__->mk_group_accessors( 'inherited', 'soap_proxy_path',
    'namespace_url' );

__PACKAGE__->soap_proxy_path('');

sub new {
    my $class      = shift;
    my $fields_ref = shift || {};

    return bless( {%$fields_ref} => $class );
}

# adds the parameters
sub setup_class {
    my ($class) = @_;
    $class->add_config_param('soap_proxy_host');
    $class->add_config_param('soap_user');
    $class->add_config_param('soap_password');
}


# compose the URI of the service
sub soap_proxy {
    my ($this) = @_;

    my $soap_proxy = URI->new( $this->soap_proxy_host );
    my $soap_user = $this->soap_user;
    if ( defined($soap_user) && $soap_user ne '-' ) {
        $soap_proxy->userinfo( $soap_user . ':' . $this->soap_password );
    }
    if ( my $soap_proxy_path = $this->soap_proxy_path ) {
        my $path = $soap_proxy->path || '';
        $path .= '/' if $path !~ m{/$};
        $path .= $soap_proxy_path;
        $soap_proxy->path($path);
    }
    return $soap_proxy;
}

# on fault handler
sub on_fault {
    my ( $this, $soap, $som ) = @_;

    if ( ref $som ) {

        # SOAP Fault
        my $msg = sprintf "SOAP fault: %s %s", $som->faultcode,
            $som->faultstring;
        if ( my $detail = $som->faultdetail ) {
            $msg .= "\n    detail "
                . Data::Dumper->new( [$detail] )->Terse(1)->Dump;
        }
        $msg .= "\n ";
        die utf8_il2($msg);
    }
    elsif ( $soap->transport->status ) {

        # transport error
        die sprintf( "SOAP transport error: %s\n", $soap->transport->status );
    }
    else {
        die "SOAP unspecified error: $som\n";
    }
}

sub soap_client {
    my $this = shift;

    return SOAP::Lite->new(

        # serializing URI object
        'proxy'     => $this->soap_proxy . '',
        'on_action' => sub {
            my ( $ns, $action ) = @_;

            return $ns . ( $ns =~ m{/$} ? '' : '/' ) . $action;
        },
        'on_fault' => sub { $this->on_fault(@_) },
    );
}

sub xml_builder {
    my ($this) = @_;

    return Akar::XML::DOMBuilder->new(
        { 'default_namespace' => $this->namespace_url } );
}

sub call_soap {
    my ( $this, $doc ) = @_;

    return $this->soap_client->call( soap_xml_data($doc) );
}

sub ping_doc { return '<ping/>'; }

# tries if the service is available
sub ping {
    my ($this) = shift;

    my $ua   = LWP::UserAgent->new;
    my $doc  = $this->ping_doc;

    my $soap_proxy = $this->soap_proxy;
    my $resp = $ua->post( $soap_proxy,
        'Content' => ( ref $doc ? $doc->toString : $doc ) );
    $this->analyze_ping_response($resp)
        or die "Unexpected response for ". (ref $this || $this). "->ping\n";
}


1;

__END__

=head1 NAME

Akar::SOAPClient - ancestor of SOAP clients used by Cow and others

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
