package Akar::DBI;
{
  $Akar::DBI::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(DBI);

use Class::Trait 'Akar::Trait::PackageConfig';
use Scalar::Util qw(reftype blessed);
use Carp qw(croak carp);
use YAML;
use File::Spec;
use Akar::Base;
use FileHandle;
use File::Basename qw(basename fileparse dirname);
use File::Spec;
use Interpolation 'E' => 'eval';

use Akar::Class::Utils qw(require_package);
use Akar::List::Utils qw(pop_options);

# the global config file is nested '/usr/local/etc/Akar-DBI/Akar-DBI.yml'
# instead of '/usr/local/etc/Akar-DBI.yml

{
    my $global_config_file = __PACKAGE__->package_config->global_config_file;
    __PACKAGE__->package_config->global_config_file(
        File::Spec->catfile(
            dirname($global_config_file),    # /usr/local/etc/
            scalar( fileparse( $global_config_file, qr{\.yml} ) ),  # Akar-DBI
            basename($global_config_file),    # Akar-DBI.yml
        )
    );
}

__PACKAGE__->add_config_mapping( 'datasource_for' );

sub find_datasource_for_or_die {
    my ( $this, $dsn_abstract ) = @_;

    # looking for in local, then global configuration file
    my $dsn = $this->datasource_for->{$dsn_abstract}

        # Error should be verbose enough so I don't have to explain anything
        # no configuration found => error
        or croak <<"END_ERROR";
Akar::DBI Error: No datasource mapping found for key '$dsn_abstract'.
Curently there are mappings for these keys: $E{ 
    join(', ', keys %{$this->datasource_for}) }.
The mapping is looked for in global configuration file '$E{
    $this->package_config->global_config_file }'. 
Mapping can also be overwritten in local configuration file '$E{ 
    $this->package_config->local_config_file }. 
This should be done with a sound reason (testing on specific database) only.
END_ERROR

    return $dsn;
}

# complete arguments for DBI->connect
sub normalize_connect_args {
    my $package = shift();

    my $input_data_source = shift();

    # if last arg is a hash reference it is the attributes
    my $input_attr = pop_options(\@_) || {};

    my ($data_source, $username);
    if ( $input_data_source =~ /^(\w+)\.(\w+)/ ) {
        # obsolete way .. input_data_source is NAME.USER
        $username    = $2;
        $data_source = $package->find_datasource_for_or_die($1);
    }
    else {
        # NAME, USER
        # if datasource is a symbolic name (one word)
        # real datasource is looked in configuration
        $data_source =
              $input_data_source =~ /^([\w_]+)$/
            ? $package->find_datasource_for_or_die($input_data_source)
            : $input_data_source;

        # first argument is user
        $username = shift()
            or croak "Akar::DBI->connect: missing username\n ";
    }

    # next arg is password, if not supplied it is looked for
    my $auth = @_
        ? shift()
        : $package->get_auth( $data_source, $username );

    # 2007-05-14 danielr, ugly hack - password can also modify the user
    # very temporary to allow c_moai in mysql connect as ptest
    if ($auth =~ s/{username=\s*(.*?)}//){
        $username = $1;
    }

    # attributes are normalized
    my $attr = $package->normalize_attr($input_attr, $data_source);

    return ( $data_source, $username, $auth, $attr );
}

sub connect {
    my ($package, @args) = @_;

    my ( $data_source, $username, $auth, $attr )
        = $package->normalize_connect_args(@args);

    $package->set_env_vars($attr);
    return DBI->connect( $data_source, $username, $auth, $attr );
}

sub connect_cached {
    my ($package, @args) = @_;

    my ( $data_source, $username, $auth, $attr )
        = $package->normalize_connect_args(@args);

    $package->set_env_vars($attr);
    return DBI->connect_cached( $data_source, $username, $auth, $attr );
}

# sets the environment variables needed for connection
# currently used for Oracle only (NLS_DATE_FORMAT, ...)
# variables are keys in attr with ENV: prefix
sub set_env_vars {
    my ( $package, $attr ) = @_;

    my $env_prefix = qr(^ENV:);
    for my $env_attr ( grep {/$env_prefix/} keys %{$attr} ) {
        my $env_var = $env_attr;
        $env_var =~ s/$env_prefix//;

        # key must deleted, not propagated to DBI->connect
        $ENV{$env_var} = delete( $attr->{$env_attr} );
    }
}

# mixing attribute with default ones
sub normalize_attr {
    my ( $package, $attr_ref, $data_source ) = @_;

    return {
        'RaiseError' => 1,
        'AutoCommit' => 0,
        'PrintError' => 0,
        'RootClass'  => 'DBI',

        # XML may be large (1M should be enough)
        'LongReadLen' => 1000000,

        # Oracle
        (   $data_source && $data_source =~ /^dbi:Oracle:/i
            ? (

                # DBIx::ContextualFetch because of Class::DBI
                'RootClass'           => 'DBIx::ContextualFetch',
                'ENV:NLS_DATE_FORMAT' => 'YYYY-MM-DD HH24:MI:SS',
                'ENV:NLS_LANG'        => 'CZECH_CZECH REPUBLIC.EE8ISO8859P2',
                'ENV:NLS_NUMERIC_CHARACTERS' => '. '
                )
            : ()
        ),

        # attributes passed overwrites default
        %{ $attr_ref || {} },
    };
}

# methods are ineffective now
# 2007-09-26 danielr hlasky jsem odstranil, stejne jim nikdo nerozumi
{
    my $warned;

    sub set_datasource {
        return;
        return if $warned++;

        carp "Method set_datasource is ineffective now,\n"
            . "datasources are configured in file(s) "
            . join( ', ', map {"'$_'"} __PACKAGE__->all_config_files )
            . "\n ";
    }
}

# method is ineffective now
{
    my $warned;

    sub set_auth {
        return;
        return if $warned++;

        carp "Method set_auth is ineffective now,\n"
            . "authorizations are configured in dir(s) "
            . join( ', ', map {"'$_'"} __PACKAGE__->auth_dirs ) . "\n ";
    }
}

# returns the authorization for datasource and user
sub get_auth {
    my ( $package, $data_source, $user ) = @_;

    for my $config_file ( $package->auth_files($data_source) ) {
        my $auth = $package->package_config->load_config_file($config_file);
        return $auth->{$user} if defined( $auth->{$user} );
    }
    # no authorization found
    croak
        "No authorization found for datasource '$data_source' and user '$user'.\n"
        . "Supply this authorization into the file(s) "
        . join( ', ', $package->auth_files($data_source) ) . "\n";

    return;
}

sub auth_dirs {
    my ($this) = @_;

    return map { File::Spec->catfile( $_, 'Akar-DBI/auth' ) }

        # 2007-05-11 danielr I allow only "global" auth file
        # to make things simpler
        # Akar::Base->app_config,
        $this->package_config->GLOBAL_CONFIG_ROOT;
}

sub auth_files {
    my ( $package, $datasource ) = @_;

    my ( undef, $driver, $dsn ) = split ':', $datasource, 3;

# works for oracle and mysql
# basename for dbi:Oracle:gtsnet is oracle-gtsnet.yml
# basename for dbi:mysql:database=devel;host=oliver;mysql_client_found_rows=true
#   is mysql-oliver-devel.yml
    my $basename;
    if ( $dsn =~ /^\w+$/ ) {

        # dsn is one word (Oracle, dbi:Oracle:gtsnet)
        $basename = $dsn;
    }
    else {

        # dsn is more complicated
        my %parts = map {
            my ( $key, $value ) = split '=', $_, 2;
            ( $key => $value );
        } split ';', $dsn;
        # 2013-04-18 danielr
        # i Oracle muze mit dsn jako
        # dbi:Oracle:host=kahan.gtsgroup.cz;sid=supp
        $basename = join( '-', grep {$_} @parts{qw(host sid database)} );
    }
    $basename = lc( join '-', $driver, $basename ) . '.yml';

    # the password is first searched for in global config
    return
        map { File::Spec->catfile( $_, $basename ); } $package->auth_dirs;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

