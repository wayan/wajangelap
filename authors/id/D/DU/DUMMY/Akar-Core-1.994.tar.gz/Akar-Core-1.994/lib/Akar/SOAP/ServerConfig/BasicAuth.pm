package Akar::SOAP::ServerConfig::BasicAuth;
{
  $Akar::SOAP::ServerConfig::BasicAuth::VERSION = '1.994';
}
use strict;

use base qw(Class::Accessor);
use File::Path qw(mkpath);
use File::Basename qw(dirname);
use File::Slurp qw(read_file write_file);

__PACKAGE__->mk_accessors(qw(enabled filename users));

sub new {
    my $proto   = shift;
    my $fields  = shift || {};
    $proto->SUPER::new({'enabled' => 0, %$fields});
}

sub check_filename {
    my $this = shift;

    my $filename = $this->filename;
    unless(-f($filename)){
        mkpath(dirname($filename));
        write_file($filename, '');
    }
}

# merges current file with the new one
sub add_file {
    my $this = shift;
    my($filename) = @_;

    $this->check_filename;
    my $new     = $this->read_auth_file($filename);
    my $current = $this->read_auth_file($this->filename);
    @$current{keys(%$new)} = values(%$new);
    write_file($this->filename, 
        join('', map {"$_:$$current{$_}\n"} keys(%$current)));
}

# returns key - value pairs
sub read_auth_file {
    my $this = shift;
    my($filename) = @_;

    my %auth = map {
        chomp;
        (!/\S/ || /^#/ || !/:/)
          ? ()
          : (split(/:/, $_, 2))[0,1];
    } read_file($filename);
    \%auth;
}

sub refresh_users {
    my $this = shift;

    $this->check_filename;
    my $hr = $this->read_auth_file($this->filename);
    $this->users([keys %$hr]);
}

1;
