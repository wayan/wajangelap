use strict;
use DBIx::Class::Storage::DBI;
use DBD::Oracle qw(ORA_BLOB ORA_CLOB);

# 2008-05-28 danielr
# ugly hack to force {'ora_type' => ORA_BLOB} into bind_param
# to work blob columns must have 'data_type' => 'ora_blob' set
no strict 'refs';
no warnings 'redefine';
my $orig_sub = DBIx::Class::Storage::DBI->can('bind_attribute_by_data_type');

# 2009-07-20 danielr
# DBIx::Class in version 0.08102 calls this method in scalar context
# (expect hashref)
# while version 0.08108 in list context (expecting list - hash)
*DBIx::Class::Storage::DBI::bind_attribute_by_data_type = sub {
    my ( undef, $data_type ) = @_;

    my %attr =
          $data_type eq 'ora_blob' ? ( 'ora_type' => ORA_BLOB )
        : $data_type eq 'ora_clob' ? ( 'ora_type' => ORA_CLOB )
        : $orig_sub->(@_);
    return wantarray ? %attr : \%attr;
};

1;
