package Akar::IOC::Root::WebServices;
{
  $Akar::IOC::Root::WebServices::VERSION = '1.994';
}
use Moose::Role;

use Akar::BreadBoard;

# role with commonly used services in  WebServices container (OCP, CSR, ...)
#
# mostly for basic_auth
before build_content => sub {

    # basic authorization
    service basic_auth_middleware => (
        block => sub {
            my $s = shift;
            my $authenticator = $s->param('authenticator');
            return sub {
                my $app = shift;
                $s->class->wrap( $app, authenticator => $authenticator );
            };
        },
        dependencies => ['authenticator'],
        class        => 'Plack::Middleware::Auth::Basic',
    );

    # basic auth authenticator
    service authenticator => (
        block => sub {
            my $s = shift;
            my $users = $s->param('users');
            return sub {
                my ( $login, $password ) = @_;
                return $users->{$login}
                    && $users->{$login}{password} eq $password;
            };
        },
        dependencies => ['users'],
    );

    # checked users
    my $users_service = config_service 'users';
    service users => (
        block => sub {

            # normalizing users hash
            return
                shift()
                ->parent->normalize_basic_auth_users( $users_service->get );
        },
        lifecycle => 'Singleton',
    );

};

# normalizes the hash into form
# $user => {
#   password => $password,
#   roles => [ ... ],
# }
#
sub normalize_basic_auth_users {
    my ( $this, $users ) = @_;

    return {
        map {
            my $login = $_;
            my $info  = $users->{$login};
            if ( !ref $info ) {
                $info = { password => $info };
            }
            $info->{password} or die "No password for user $login\n ";

            my $roles = $info->{roles} ||= [];
            if ( !ref $roles ) {
                $info->{roles} = [ grep {$_} split /[,\s+]/, $roles ];
            }
            ( $login => $info );
            } keys %$users
    };
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
