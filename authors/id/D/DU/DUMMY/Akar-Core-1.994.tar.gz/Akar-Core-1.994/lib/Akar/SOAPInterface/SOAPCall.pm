package Akar::SOAPInterface::SOAPCall;
{
  $Akar::SOAPInterface::SOAPCall::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor);
use XML::LibXML::XPathContext;

use Carp qw(carp croak);

__PACKAGE__->mk_ro_accessors(qw(document soap_interface soap_context));

sub xpc {
    my ($this) = @_;

    my $xpc        = XML::LibXML::XPathContext->new( $this->document );
    my $namespaces = $this->soap_interface->namespaces;
    while ( my ( $prefix, $namespace ) = each %{$namespaces} ) {
        $xpc->registerNs( $prefix => $namespace );
    }
    return $xpc;
}

sub xml_builder {
    my ($this) = @_;
    return $this->soap_interface->xml_builder;
}

sub build_doc {
    my $this = shift;

    return $this->soap_interface->xml_builder->create_doc(@_);
}

sub args {
    my ($this) = @_;

    my %args = map { ( $_->localName => $_->findvalue('.') ) }
        $this->document->findnodes('/*/*');
    return \%args;
}

1;

__END__

=head1 NAME

Akar::SOAPInterface::SOAPCall - SOAP call context 

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
