package Akar::Async::Pattern::Process;
{
  $Akar::Async::Pattern::Process::VERSION = '1.994';
}
use Moose;
# must not be used here
#use namespace::autoclean;

use Scalar::Util qw(weaken);
use overload '&{}' => sub {
        my $this = shift;
        return sub { $this->start(@_) };
    },
    fallback => 1;

# subs to be called on end
has on_finish => (
    is      => 'ro',
    isa     => 'ArrayRef',
    default => sub { return []; },
);

has on_start => (
    is       => 'rw',
    required => 1,
    default  => sub {
        sub { }
    }
);

has task_id => (
    is      => 'rw',
    default => 0,
    isa     => 'Int',
);

has tasks => (
    is       => 'ro',
    isa      => 'HashRef|ArrayRef',
    required => 1,
);

sub get_task_ids {
    my $this = shift;
    return ( 0 .. ( @{ $this->tasks } - 1 ) );
}

around on_finish => sub {
    my $orig = shift;
    my $this = shift;
    my $ar   = $this->$orig();
    if (@_) {
        push @$ar, @_;    # set is push
    }
    else {
        my @ret = @$ar;
        undef @$ar;
        return @ret;
    }
};

sub next_task {
    my $this = shift;

    my $task = shift @{ $this->tasks } or return;
    my $id = $this->task_id;
    $this->task_id( $id + 1 );
    return ( $id, $task );
}

sub start_task {
    my $this = shift;
    my $task = shift;

    eval {

        if ( blessed($task) && $task->can('cancel') ) {

            # if task can be cancelled it is cancelled after
            # its parent finish
            my $wtask = $task;
            weaken $wtask;
            $this->on_finish( sub { $wtask->cancel if $wtask; } );
        }
        $task->(@_);
    };
    $this->finish($@) if $@;
}

sub start {
    my $this = shift;

    my $on_start = $this->on_start or return;
    $this->on_start('');
    $this->on_finish( pop() ) if ref $_[-1] eq 'CODE';
    $this->$on_start(@_);
}

#  this is an utility
sub _once {
    my $f = shift;
    return sub {
        my $ff = $f or return;
        undef $f;
        $ff->(@_);
    };
}

sub finish {
    my $this = shift;

    undef @{ $this->tasks };
    for my $on_finish ( $this->on_finish ) {
        $on_finish->(@_);
    }
}

sub cancel {
    my $this = shift;

    $this->finish('CANCELLED');
}



# the value returned by function are passed further
sub _any {
    my $self = shift;
    while ( my ( $id, $task ) = $self->next_task() ) {
        $self->start_task( $task, sub { $self->finish(@_); } );
    }
}

sub _parallel {
    my $self = shift;
    my %left = map { ( $_ => 1 ) } $self->get_task_ids;
    my @ret;
    while ( my ( $id, $task ) = $self->next_task() ) {
        $self->start_task(
            $task,
            sub {
                delete $left{$id}
                    or return;    # each task can be called once only
                if ( my $err = shift ) {
                    undef %left;
                    $self->finish($err);
                }
                else {
                    $ret[$id] = [@_];
                    %left
                        or $self->finish( undef, [ map { $_ && @$_ } @ret ] );
                }
            }
        );
    }
}

sub _series {
    my $self = shift;

    my @ret;
    my $f;
    $f = sub {
        my ( $id, $task ) = $self->next_task()
            or return $self->finish( undef, \@ret );
        $self->start_task(
            $task,
            _once sub {
                if ( my $err = shift ) {
                    $self->finish($err);
                }
                else {
                    push @ret, @_;
                    $f->();
                }
            }
        );
    };
    $f->();
}

sub _waterfall {
    my $self = shift;

    my $f;
    $f = sub {
        my ( $id, $task ) = $self->next_task()
            or return $self->finish( undef, @_ );
        $self->start_task(
            $task, @_,
            _once sub {
                if ( my $err = shift ) {
                    $self->finish($err);
                }
                else {
                    $f->(@_);
                }
            }
        );
    };
    $f->(@_);
}

__PACKAGE__->meta->make_immutable;
no Moose;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
