package Akar::UTest::XML::DOMBuilder;
{
  $Akar::UTest::XML::DOMBuilder::VERSION = '1.994';
}
use strict;
use warnings;


use base qw(Test::Class);

# Test::More imports: 
#   ok use_ok require_ok is isnt like unlike is_deeply
#   cmp_ok skip todo todo_skip pass fail eq_array
#   eq_hash eq_set $TODO plan can_ok isa_ok diag BAIL_OUT
use Test::More;
use XML::LibXML::XPathContext;

# Test::Exception imports:
#   dies_ok lives_ok throws_ok lives_and
use Test::Exception;

use Akar::XML::DOMBuilder qw(xml_builder);
use Carp qw(carp croak);

use constant 'NS_FROG' => 'http://frog.cz';
use constant 'NS_NEWT' => 'http://newt.cz';
use constant 'NS_EFT' => 'http://eft.cz';
use constant 'NS_TOAD' => 'http://toad.cz';

sub tested_module { return 'Akar::XML::DOMBuilder' }

# returns XML::LibXML::XPathContext for $xml_dom_builder
sub xpc_for {
    my ($this, $xb, $doc) = @_;

    my $xpc = XML::LibXML::XPathContext->new;
    for my $prefix ( keys %{$xb->namespaces}){
        $xpc->registerNs($prefix, $xb->namespaces->{$prefix});
    }
    if (my $default_namespace = $xb->default_namespace){
        $xpc->registerNs('DEFAULT', $default_namespace);
    }
    if ($doc){
        $xpc->setContextNode($doc);
    }
    return $xpc;
}

sub sample_namespaces {
    my %namespaces = (
        'frog' => NS_FROG,
        'newt' => NS_NEWT,
        'eft'  => NS_EFT,
    );
    return { %namespaces };
}

# returns Akar::XML::DOMBuilder with default fields
sub xb {
    my ( $this, $fields_ref ) = @_;

    $fields_ref ||= {};
    my %namespaces = (
        %{$this->sample_namespaces},
        %{ delete $fields_ref->{'namespaces'} || {} }
    );

    my %fields = (
        'namespaces'        => \%namespaces,
        'default_namespace' => NS_TOAD,
        %{$fields_ref},
    );
    for my $hr ( \%fields, \%namespaces ) {
        delete @{$hr}{ grep { !defined $hr->{$_} } keys %{$hr} };
    }
    return Akar::XML::DOMBuilder->new( \%fields );
}

sub basic: Test(1) {
    my ($this) = @_;

    my $xb = Akar::XML::DOMBuilder->new;

    # simple test - no namespaces
    my $doc = $xb->create_doc('vasil' => ['jarmil']);
    is($doc->findvalue('local-name(/vasil/*)'), 'jarmil');

    # nested elements
}

sub nested : Test(4) {
    my ($this) = @_;

    my $xb = $this->xb;
    {
        my $doc = $xb->create_doc( 'newt:flute',
            [ 'eft:theft/frog:rogue' => { 'tree' => 'frog' }, 'yaba' ] );
        my $xpc = $this->xpc_for( $xb, $doc );
        is( $xpc->findvalue('/newt:flute/eft:theft/frog:rogue'),
            'yaba', 'all hierarchy is created' );
        is( $xpc->findvalue('/newt:flute/eft:theft/frog:rogue/@tree'),
            'frog', 'attributes are set for innermost element' );
    }

    # 2008-10-02 danielr
    # tento test testuje chybu, na ktere vyhorela odpoved ze SetBoxu
    # hierarchicky element totiz vrazil obsah do prvniho elementu
    {
        my $doc = $xb->create_doc(
            'eft:left/frog:rogue' => { 'tree' => 'frog' },
            'yaba'
        );
        my $xpc = $this->xpc_for( $xb, $doc );
        is( $xpc->findvalue('/eft:left/frog:rogue'),
            'yaba', 'all hierarchy is created' );
        is( $xpc->findvalue('/eft:left/frog:rogue/@tree'),
            'frog', 'attributes are set for innermost element' );
    }
}

sub include_all_namespaces : Test(5) {
    my ($this) = @_;
    {
        my $xb = $this->xb;
        is( $xb->include_all_namespaces, 1,
            'All namespaces are included by default' );
        my $doc = $xb->create_doc( 'newt:emil' => 'lupin' );

        is( $doc->documentElement->lookupNamespaceURI('newt'),
            NS_NEWT, 'namespace is included implicitly' );
        is( $doc->documentElement->lookupNamespaceURI('frog'),
            NS_FROG, 'even namespace which is not used is included' );
    }

    {
        my $xb = $this->xb( { 'include_all_namespaces' => 0 } );

        my $doc = $xb->create_doc( 'newt:emil' => 'lupin' );
        is( $doc->documentElement->lookupNamespaceURI('newt'),
            NS_NEWT, 'namespace is included implicitly' );
        ok( !defined $doc->documentElement->lookupNamespaceURI('frog'),
            'namespace not used is not included' );
    }
}

sub test_import: Test(4) {
    my ($this) = @_;

    my $xb1 = xml_builder(NS_NEWT);
    is($xb1->default_namespace, NS_NEWT, 'scalar argument becomes a default namespace');

    my $xb2 = xml_builder({}, NS_NEWT);
    is( $xb2->default_namespace, NS_NEWT,
        'scalar argument becomes a default namespace even when passed as second argument'
    );

    my $xb3 = xml_builder($this->sample_namespaces);
    is_deeply($xb3->namespaces, $this->sample_namespaces, 'hashref argument becomes the namespaces');

    my $xb4 = xml_builder( NS_EFT, $this->sample_namespaces );
    is_deeply( $xb4->namespaces, $this->sample_namespaces,
        'hashref argument becomes the namespaces even when passed as second argument'
    );
}

# the namespace declaration should appear only once
# older versions of XML::LibXML dont' pass this test
sub single_ns_declaration: Test(1) {
    my ($this) = @_;

    my $xb = $this->xb;
    my $doc = $xb->create_doc('eft:theft' => ['newt:flute'], ['newt:dispute']);
    my $ns_newt = NS_NEWT;
    my $occurences = grep {1} $doc->toString =~ /(\Q$ns_newt\E)/;
    is ($occurences, 1, 'just one namespace declaration');
}

sub create_doc_from_elem : Test(3) {
    my $xml = <<"END_XML";
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/"
xmlns:xsd="http://www.w3.org/2001/XMLSchema"
xmlns:ve_vsech_trech="http://deda.cz"
xmlns:ve_dvou="http://dedecek.cz"
>
  <env:Body env:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"
    xmlns:ve_vsech_trech="http://tata.cz"
    xmlns:ve_dvou="http://tatinek.cz"
>
    <m:sendNotification xmlns:m="http://www.openuri.org/" 
    xmlns:ve_vsech_trech="http://syn.cz">
    >
      <type xsi:type="xsd:string">ORDER_STATUS</type>
      <notificationMessage xsi:type="xsd:string">&lt;WsAdslEmail/&gt;</notificationMessage>
    </m:sendNotification>
  </env:Body>
</env:Envelope>
END_XML

    my ($content_elem) = do {
        my $doc = XML::LibXML->new->parse_string($xml);
        $doc->findnodes("/*/*[local-name() = 'Body']/*");
    };
    my $xb  = Akar::XML::DOMBuilder->new;
    my $doc = $xb->create_doc($content_elem);
    is( $doc->documentElement->lookupNamespaceURI('xsd'),
        'http://www.w3.org/2001/XMLSchema',
        'namespace present in ancestor is present');

    is( $doc->documentElement->lookupNamespaceURI('ve_dvou'),
        'http://tatinek.cz',
        'parent namespace is preferred over grandparent one');
    is( $doc->documentElement->lookupNamespaceURI('ve_vsech_trech'),
        'http://syn.cz',
        'own namespace is preferred over parent one');

}

1;

__END__

=head1 NAME

Akar::UTest::XML::DOMBuilder - Unit testing class for Akar::XML::DOMBuilder

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
