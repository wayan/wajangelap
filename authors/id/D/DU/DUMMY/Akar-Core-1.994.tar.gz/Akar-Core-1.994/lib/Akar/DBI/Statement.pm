package Akar::DBI::Statement;
{
  $Akar::DBI::Statement::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Exporter);
our @EXPORT_OK = qw(sql sql_join
    sql_param sqlp
    sql_param_inout sqlp_io
    is_sql sql_select sql_in
    sql_and sql_with_param
);

use Carp qw(croak);
use Scalar::Util q(blessed);

require Akar::DBI::Statement::Object;
require Akar::DBI::Statement::Interpolated;
require Akar::DBI::Statement::ModifyDBI;

sub is_sql {
    my ($arg) = @_;

    return Akar::DBI::Statement::Object->is_sql($arg);
}

sub sql_param {
    my ( $value, $attr_or_type ) = @_;

    return is_sql($value)
        ? $value
        : Akar::DBI::Statement::Object->new_param( undef, $value,
        $attr_or_type );
}

sub sql_param_inout {
    my ( $value_ref, $size, $attr_or_type ) = @_;

    return is_sql($value_ref)
        ? $value_ref
        : Akar::DBI::Statement::Object->new_param_inout( undef, $value_ref,
        $size, $attr_or_type );
}

sub sql_with_param {
    my ( $str, $param_value ) = @_;

    @_ == 2 && !ref($str) && !ref($param_value)
        or croak "sql_with_param(TEXT, PARAM_VALUE)\n ";

    return sql( $str, sql_param($param_value) );
}

sub sql {

    # if first and only argument is sql it is returned untouched
    return @_ == 1 && is_sql( $_[0] )
        ? $_[0]
        : Akar::DBI::Statement::Interpolated->new( { 'layout' => [@_] } );
}

sub sql_join {
    require Akar::DBI::Statement::Join;

    my $separator = shift();

    # if last arg is unblessed hash then it is considered options
    my $opt_ref = pop_options( \@_ ) || {};
    return Akar::DBI::Statement::Join->new(
        {   'separator' => $separator,
            'elements'    => [@_],
            %{$opt_ref}
        }
    );
}

sub sql_and { return sql_join( ' and ', @_ ); }

sub sql_select {
    require Akar::DBI::Statement::Select;

    # if last arg is unblessed hash then it is considered options
    my $opt_ref = pop_options( \@_ ) || {};
    my ($select_clause,   $from_clause, $where_clause,
        $group_by_clause, $order_by_clause
        )
        = @_;

    return Akar::DBI::Statement::Select->new(
        {   'select_clause'   => $select_clause,
            'from_clause'     => $from_clause,
            'where_clause'    => $where_clause,
            'group_by_clause' => $group_by_clause,
            'order_by_clause' => $order_by_clause,
            %{$opt_ref},
        }
    );
}

# in list
sub sql_in {
    require Akar::DBI::Statement::InList;

    my $opt_ref = pop_options( \@_ ) || {};

    # if the first value from list is an anonymous array
    # then it is passed directly
    my $values_ref = @_ == 1
        && UNIVERSAL::isa( $_[0], 'ARRAY' )
        && !blessed( $_[0] ) ? $_[0] : [@_];
    return Akar::DBI::Statement::InList->new(
        {   'values' => $values_ref,
            %{$opt_ref}
        }
    );
}

# if the last member of the array is unblessed hash reference
# (hash with the options passed as last argument)
# it is popped out and returnded
sub pop_options {
    my ($args_ref) = @_;
    
    return pop @{$args_ref} if @{$args_ref}
            && UNIVERSAL::isa($args_ref->[-1], 'HASH')
            && !blessed($args_ref->[-1]);
    return;
}

1;

__END__

=head1 NAME

Akar::DBI::Statement - SQL text kept together with params before prepare

=head1 SYNOPSIS

    use Akar::DBI::Statement qw(sql sql_param sql_join sql_in)

    # Building sql 

    # 1 - mixing parameters (and other sql) with text
    my $sql = sql(
        'SELECT max(id) FROM runable WHERE package = ',
        sql_param('Anoa::Runables::GP::OCP::ADSL')
        );

    # 2 - interpolation works
    my $sql_package = sql_param('Anoa::Runables::GP::OCP::ADSL'),
    my $sql = sql("SELECT max(id) FROM runable WHERE package = $sql_package");

    # it even works like this
    my $sql = "SELECT max(id) FROM runable WHERE package = $sql_package";

    # 3 - old fashioned 
    my $sql = sql('SELECT max(id) FROM runable WHERE package = :package');
    $sql->bind_param(':package' => 'Anoa::Runables::GP::OCP::ADSL');

    # Passing sql to database, same as with text
    my $sth = $dbh->prepare($sql);
    my($row) = $dbh->selectrow_array($sql);
    ...

    # using interpolation 
    use Akar::DBI::Statement qw(sql_param);
    use Interpolation 'sqlp' => sub { sql_param(@_) }, 'E' => 'eval';
    ....

    my $service_item_id;
    $dbh->do(<<"END_PL_SQL");
        BEGIN
            $E{ sql_param_inout(\$service_item_id) } := cstmr.pkg_service.f_item_insert(
                in_service_id           => $sqlp{$service_id},
                in_product2item_type_id => $sqlp{$PRODUCT2PLIST_ID},
                in_quantity             => 1,
                in_dt_start   => to_date( $sqlp{ $START_DATE }, 'YYYY-MM-DD' ),
                in_dt_expires => null,
                in_created_by => $sqlp{ $CREATED_BY }
                );
        END;
    END_PL_SQL


    # Composition of SQL, any of method 1, 2, 3 works
    my $sql_from = sql('to_date(', sql_param($to), ", 'YYYY-MM-DD')");
    my $sql_to   = sql('sysdate');
    my $sql_runable = sql(<<"END_SQL");
    SELECT * 
    FROM runable 
    WHERE date between $sql_from AND $sql_to
    ORDER BY id DESC
    END_SQL

    my $sql_final = sql( "SELECT created FROM ($sql_runable) WHERE package = ",
        sql_param($desired_package) );

    # in list
    my $sql_packages = sql_in(qw(Anoa::Runables::GP::OCP::ADSL
        Anoa::Runables::GP::ADSL));
    my $sql
        = sql("SELECT max(id) FROM runable WHERE package IN $sql_packages");

    # sql join (AND condition, list, ...)
    my $sql_where = sql_join(' AND ', 
        "created > to_date(", sql_param('2006-12-01'), '", 'YYYY-MM-DD')"),
        "package = ", sql_param('Anoa::XYZ'

    # the join is live you can add sqls and texts 
    push @{$sql_where}, sql(
        'runable_group_id IN (SELECT id FROM runable_group WHERE name = ', sql_param('SALWIN'), ')'), 
        'created < sysdate - 10';

    my $in_list = sql_in('Anoa::Runables::GP::ADSL', 'Anoa::Runables::GP::OCP::ADSL');
    my $sql = sql("SELECT max(id) FROM runable WHERE package IN $in_list");

    # the list is alive
    push @{$in_list}, 'Anoa::Runables::GP::XYZ';

=head1 DESCRIPTION

=head1 FUNCTIONS

All functions are imported on demand.

=over 4

=item sql

=item is_sql

=item sql_param

=item sql_param_inout

=item sql_join

=item sql_and

=item sql_in

List of values.

=back

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz>

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
