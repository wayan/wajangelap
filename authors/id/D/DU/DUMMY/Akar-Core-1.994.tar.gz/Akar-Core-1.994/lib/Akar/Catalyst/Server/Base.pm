package Akar::Catalyst::Server::Base;
{
  $Akar::Catalyst::Server::Base::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);
use base qw(Class::Accessor Class::Accessor::Grouped);
use YAML;

__PACKAGE__->mk_classdata('application');
__PACKAGE__->mk_classdata('port');

# instance root (for Apache)
__PACKAGE__->mk_classdata('app_data_root');

sub mk_classdata {
    my $this = shift;
    my $name = shift;

    $this->mk_group_accessors('inherited', $name);
    $this->set_inherited($name => shift()) if @_;
}

sub load_config {
    my ($this) = @_;

    my $class = ref $this || $this;
    my $file
        = Akar::Base->app_config( join( '-', split /::/, $class ) . '.yml' );
    return if !-r $file;

    my $config = YAML::LoadFile($file);
    for my $property ( keys %$config ) {
        $this->set_inherited( $property => $config->{$property} );
    }
}

# loads *.yml for the application  
sub load_application_config {
    my ( $this, $application ) = @_;

    my $file = Akar::Base->app_config(
        join( '-', split /::/, $application ) . '.yml' );
    return if !-r $file;
    return YAML::LoadFile($file);
}

# filename relative to instance_root
sub app_data_path {
    my ( $this, $filename ) = @_;
    return File::Spec->rel2abs( $filename, $this->app_data_root );
}


sub new {
    my $class      = shift;
    my $fields_ref = shift || {};

    my $application = $fields_ref->{'application'} || $class->application
        or die "No application supplied\n";
    my $application_config = $class->load_application_config($application);

    # specific part of the configuration
    my $config_part = $application_config
        && $application_config->{ $class->application_subname }
        || {};
    my $app_data_root = Akar::Base->app_data(
        join( '-', split /::/, $application ) . '/'
            . $class->application_subname );
    return bless {
        'app_data_root' => $app_data_root,
        %$config_part, %$fields_ref, 'application' => $application
    }, $class;
}

1;

__END__

=head1 NAME

Akar::Catalyst::Server::Base - common ancestor of Akar::Catalyst::Apache and Akar::Catalyst::Server

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
