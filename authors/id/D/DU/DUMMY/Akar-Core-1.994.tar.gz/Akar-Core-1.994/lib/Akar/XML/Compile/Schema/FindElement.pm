package Akar::XML::Compile::Schema::FindElement;
{
  $Akar::XML::Compile::Schema::FindElement::VERSION = '1.994';
}
use Moose::Role;

# role for Akar::XML::Compile::Schema
# finds fullname for element or type 
# from either localname
# or any_suffix_of_namespace:localname

use XML::Compile::Util qw(unpack_type);

sub find_element {
    my ( $this, $element ) = @_;

    my @found;
    if ($element =~ /^\{/ ){
        # the qualified name "{NS}localname"
        @found = grep { $_ eq $element; } $this->elements;
    } 
    else {

        # piece_of_path:localname
        my ( $localname_searched, $ns_suffix ) = reverse split /:/, $element, 2;
        @found = grep {
            my ( $ns, $localname ) = unpack_type($_);
            $localname eq $localname_searched
                && ( !$ns_suffix || $ns =~ /\Q$ns_suffix\E$/ );
        } $this->elements;
    }

    die "No element found for '$element'\n " if !@found;
    die "Element search '$element' is ambiguous, matches: "
        . join( ', ', sort @found ) . "\n "
        if @found > 1;
    return shift @found;
}

sub find_type {
    my ( $this, $type ) = @_;

    my @found;
    if ($type =~ /^\{/ ){
        # the qualified name "{NS}localname"
        @found = grep { $_ eq $type; } $this->types;
    } 
    else {

        # piece_of_path:localname
        my ( $localname_searched, $ns_suffix ) = reverse split /:/, $type, 2;
        @found = grep {
            my ( $ns, $localname ) = unpack_type($_);
            $localname eq $localname_searched
                && ( !$ns_suffix || $ns =~ /\Q$ns_suffix\E$/ );
        } $this->types;
    }

    die "No type found for '$type'\n " if !@found;
    die "Type search '$type' is ambiguous, matches: "
        . join( ', ', sort @found ) . "\n "
        if @found > 1;
    return shift @found;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
