package Akar::Async::Queue;
{
  $Akar::Async::Queue::VERSION = '1.994';
}
use Moose;

# processes waiting to be dequeued
has waiting => (
    is      => 'ro',
    isa     => 'ArrayRef',
    default => sub { return [] },
    traits  => ['Array'],
    handles => {
        num_waiting    => 'count',
        add_to_waiting => 'push',
        shift_waiting  => 'shift',
    }
);

# what to call when the pending requests hits the max_pending level
has on_saturated => (
    is  => 'rw',
    isa => 'CodeRef',
);

has worker => (is => 'ro', isa => 'CodeRef', required => 1);

has max_pending => ( is => 'rw', isa => 'Int', required => 1, );

# counter of pending processes 
has num_pending => (
    is      => 'rw',
    isa     => 'Int',
    default => 0,
);

sub add {
    my ( $this, $task, $cb ) = @_;

    if ( $this->num_waiting ) {
        $this->add_to_waiting([$task, $cb]);
    }
    elsif ( $this->num_pending < $this->max_pending ) {
        $this->start_task($task, $cb);
    }
    else {
        # first message aded to queue
        $this->add_to_waiting([$task, $cb]);
        if ( $this->num_pending >= $this->max_pending && $this->on_saturated )
        {
            $this->on_saturated->();
        }
    }
}

# releases the first waiting process into pending
sub start_task {
    my ( $this, $task, $cb ) = @_;

    $this->num_pending($this->num_pending + 1);
    $this->start_worker( $task, sub { $cb->(@_) if $cb; $this->finish_worker(@_); } );
}

sub start_worker {
    my ( $this, $task ) = @_;

    my $cb = pop();
    $this->worker->( $task, $cb );
}

sub finish_worker {
    my $this = shift;

    $this->num_pending( $this->num_pending - 1 );
    if ( my $next = $this->shift_waiting ) {
        $this->start_task(@$next);
    }
}

__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
