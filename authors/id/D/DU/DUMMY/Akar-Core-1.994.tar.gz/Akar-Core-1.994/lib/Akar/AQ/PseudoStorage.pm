package Akar::AQ::PseudoStorage;
{
  $Akar::AQ::PseudoStorage::VERSION = '1.994';
}
use strict;
use warnings;

# pseudo storage for Class::DBI classes of AQ

use base qw(Class::Accessor::Fast);

use Carp qw(carp croak);

__PACKAGE__->mk_accessors('connection_sub');

sub dbh {
    my $this = shift;
    return $this->connection_sub->();
}

sub txn_do {
    my ( $this, $code ) = @_;

    eval { $code->(); };
    if ( my $err = $@ ) {
        $this->dbh->rollback;
        die $err;
    }
    $this->dbh->commit;
}

1;

__END__

=head1 NAME

Akar::AQ::PseudoStorage - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
