package Akar::PL_SQL::Type::Base;
{
  $Akar::PL_SQL::Type::Base::VERSION = '1.994';
}
use strict;

use base qw(Class::Accessor);

use Akar::PL_SQL::Value;

__PACKAGE__->mk_ro_accessors(qw(name));

sub new_type { shift()->SUPER::new(@_) }

sub new {
    my ($this, $value) = @_;

    Akar::PL_SQL::Value->new({'type' => $this, 'value' => $value});
}

# creates method which called without params return the type
# with params return the value
sub create_method {
    my $this = shift;
    sub { @_ ? $this->new(@_) : $this }
}

sub is_output_value {
    my ($this, $value) = @_;

    ref($value) && (UNIVERSAL::isa($value, 'SCALAR') || UNIVERSAL::isa($value, 'REF'));
}

sub dump_value {
    my ($this, $value) = @_;

    $this->is_output_value($value)
      ? $this->dump_output_value($value)
      : $this->dump_input_value($value);
}

sub dump_output_value { '*OUTPUT*' }

1;

