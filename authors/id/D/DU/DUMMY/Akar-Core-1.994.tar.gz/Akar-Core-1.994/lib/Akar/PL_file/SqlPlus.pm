package Akar::PL_file::SqlPlus;
{
  $Akar::PL_file::SqlPlus::VERSION = '1.994';
}
use strict;

=head1 NAME

Akar::PL_file::SqlPlus - SQL files preprocessed by Perl (Mason) 

=head1 SYNOPSIS

    use Akar::PL_file::SqlPlus;
    -- This is a Mason, baby 
    connect mdevice@durian
   
    % for my $table ( qw(files virtual_files) ){ 
    create table mdevice.<% $table %> (
        ...
    )
    %}

    @@utils/grants.sql.PL

=head1 DESCRIPTION

Akar::PL_file::SqlPlus is a simple module which enables you to use
Mason markup in command files for sqlplus. It can be usefull for

=over 4

=item

Connection handling. It can map abstract connection parameters (mdevice@durian)
to the real ones (mdevice/THE_PWD@gtsnet) according to Akar configuration.

=item

DML commands, which must be extracted from database first.
(DISABLE CONSTRAINTS ...)

=back

=head1 Invocation

PL file can be run 

    perl file.sql.PL
    perl file.sql.PL output_file.sql

If output file is not specified (first form), output is placed into C<file.sql>.

The second form also enables you to pipe the preprocessed file to standard output

    perl file.sql.PL - | sqlplus /nologin

The perl which invokes PL file must know about the Akar environment. 
It can be achieved in two ways 

    . PATH_TO_APP/bin/akar_setenv
    perl file.sql.PL 

    PATH_TO_APP/bin/akar_perl file.sql.PL

=head1 Processing

The rest of Perl script after C<use Akar::PL_file::SqlPlus> is considered Mason, not Perl.
So you can use all (or none) Mason markups. 

=head2 Functions usable from templates

Within templates you can use:

=over 4

=item PL_ifile()

Current input file (probably F<*.sql.PL>). Because you are in template, 
you cannot use C<__FILE__>.

=item PL_ofile()

Current output file (probably F<*.sql>).

=item PL_dir()

=item PL_dir(rel_path)

Returns input file directory or absolutized path according to this directory

=back

=head2 Postprocessing

After the source file is processed by Mason, some of the C<sqlplus> commands are modified.

=over 4

=item connect USER@SUBS

    connect mdevice@durian
    ...
    connect anoanya@anoa

Abstract connection parameters are replaced by the real ones according to Akar configuration.

=item start command_file.sql

=item start command_file.sql.PL

=item @command_file.sql

=item @command_file.sql.PL

=item @@command_file.sql

=item @@command_file.sql.PL

File argument of start command is absolutized, which enables to use C<@@path/file.sql>
(it didn't work for me in sqlplus).

If file to be started has f<.sql.PL> suffix, it is preprocessed (Perl with Akar settings 
is run on it), and the result (F<.sql>) is used as start argument.

=back

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz>

=cut


use Akar::Base;
use File::Basename qw(dirname);
use File::Spec;
use HTML::Mason;
use FileHandle;
use Akar::DBI::Oracle;
use File::Basename qw(dirname);
use File::Spec;

my($PL_ifile, $PL_outfile, %PL_params);

# the command line arguments are [OUTPUT_FILE] [KEY=VALUE], [KEY2=VALUE2], ...
sub import {
    (undef, $PL_ifile, my $caller_line) = caller();

    # parsing input file, output file, params
    $0 eq $PL_ifile or die 'use '. __PACKAGE__ . " can be called only from the script\n";
    my $PL_ofile = ( @ARGV && $ARGV[0] !~ /=/)
        ? shift(@ARGV)
        : do {
            $PL_ifile =~ /(.*)\.PL$/ or die "Input file must have .PL suffix\n";
            $1;
        };
    my %params = map { split(/=/, $_, 2) } @ARGV;
    warn "Processing $PL_ifile => $PL_ofile\n";

    # Processing the input file via mason
    my $buffer;
    my $interp = HTML::Mason::Interp->new(
        'comp_root'  => Akar::Base->app_home('lib/mason'),
        'out_method' => \$buffer);
    *HTML::Mason::Commands::PL_ifile        = sub { $PL_ifile };
    *HTML::Mason::Commands::PL_ofile        = sub { $PL_ofile };
    *HTML::Mason::Commands::PL_params       = sub { \%params };
    *HTML::Mason::Commands::PL_dir          = sub { 
        my($subdir) = @_;

        my $basedir = dirname($PL_ifile);
        @_? File::Spec->rel2abs($subdir, $basedir): $basedir;
    };

    my $comp = $interp->make_component('comp_source' => get_source($PL_ifile, $caller_line));
    $interp->exec($comp);

    # Postprocessing lines (@, @@, connect)
    my $postprocessed = join("\n", map(postprocess_line($_), split(/\n/, $buffer, -1)));

    my $fh = FileHandle->new('>'. $PL_ofile) or die "Can't open $PL_ofile for write: $!\n ";
    $fh->print("-- This file was generated automatically.\n",
        "-- Don't modify it or your changes will be lost.\n",
        "-- To make a change, modify the source '$PL_ifile' and run:\n", 
        "-- \n",
        "-- perl $PL_ifile\n");
    $fh->print($postprocessed);

    # exit - no line after use is executed as Perl
    exit(0);
}

sub get_source {
    my ($caller_file, $caller_line) = @_;

    # I don't use filtering, instead read the caller's file after use line
    my $fh_caller = FileHandle->new($caller_file) or die $!;
    my @source    = $fh_caller->getlines;
    splice(@source, 0, $caller_line);
    join('', @source);
}

sub sqlplus_connect {
    my ($connect_str) = @_;

    # connect str is either SUBS.NAME or NAME@SUBS
    my ($subs, $username);
    if ($connect_str =~ m{^(\w+)(?:/(\w+))?\@(\w+)$}x) {
        $subs     = $3;
        $username = $1;
    }
    elsif ($connect_str =~ /(.*?)\.(.*)/) {
        $subs     = $1;
        $username = $2;
    }
    else {
        die "Invalid connect string ($connect_str)\n";
    }

    my $datasource = Akar::Config->get_param_or_die("$subs/dbi/magic/$username/datasource")
      or die "No datasource found to $connect_str\n ";
    my ($two_task) = $datasource =~ /dbi:Oracle:(\w+)/
      or die "No two task separated\n ";
    my $auth = Akar::DBI::Oracle->get_auth($username, $two_task)
      or die "No auth found for $username\@$two_task\n ";
    "connect $username/$auth\@$two_task";
}

sub sqlplus_start {
    my ($file, $relative_to_current, @args) = @_;

    my $abs_path = File::Spec->rel2abs($file, $relative_to_current? dirname($PL_ifile): ());
    my $start_path = $abs_path;
    # if file ends up with PL it is processed
    if ($abs_path =~ /(.*)\.PL$/){
        $start_path = $1;
        process_file($abs_path);
    }
    # start command
    '@'. $start_path;
}

sub process_file {
    my ($file) = @_;

    system('perl', '-I', Akar::Base->perl5lib, '-MAkar::Base::Profile', $file);
}

sub postprocess_line {
    my ($line) = @_;

    if ($line =~ /^connect\s+(\S+)/i){
        return sqlplus_connect($1);
    }
    elsif ($line =~ /^(\@\@|\@|start\s+)(\S+)/i){
        return sqlplus_start($2, $1 eq '@@');
    }
    else {
        return $line;
    }
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96: 
