package Akar::SOAPInterface;
{
  $Akar::SOAPInterface::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor);

use Carp qw(carp croak);
use Scalar::Util qw(blessed);
use File::Temp ();
use Akar::XML::DOMBuilder;
use Akar::SOAP::Utils qw(soap_document_passed_as_doc soap_response_body soap_xml_data);
use Akar::Class::Utils qw(lexical_cleaner);
use Akar::SOAPInterface::SOAPCall;
use POSIX ();

use Akar::XML::CommonNamespaces qw(
    wsdl_http_namespace
    xml_schema_namespace
    xml_schema_instance_namespace
    wsdl_namespace
    wsdl_soap_namespace);

__PACKAGE__->mk_accessors(
    'service_package',    # the package defining the service
    'uri',               # SOAP service URI (targetNamespace)
    'methods',           # array of methods exported by the SOAP service
    'service_name',      # name of service
    'documentation',     # service description
    'soap_action_sep',

    'service_schema',           # the validation schema as XML::LibXML::Document
    'auxiliary_schemas',        # other schemas (if there is more than one targetNamespace)
    'service_schema_validator', # validating object 
    'schema_chunks',            # schema types, etc.

    'document_like',            # if set (and it is set by default), then 
        # - arguments to the method are passed as single XML document 
        # - return value is treated as complete response XML document
        # - input is validated by schema
        # - output is validated by schema
        #
    'namespaces',

    # if set schema is created with element_form_default = unqualified
    'schema_element_unqualified',
);

sub new {
    my ( $package, $service_package, $uri, $fields ) = @_;

    $fields ||= {};

    my $soap_interface = $package->SUPER::new(
        {   'soap_action_sep'   => '#',
            'documentation'     => '',
            'service_name'      => join( '_', split /::/, $service_package ),
            'document_like'     => 1,
            'auxiliary_schemas' => [],
            'namespaces'        => {},
            %{$fields},
            'service_package' => $service_package,
            'uri'             => $uri,
            'methods'         => [],
            'schema_chunks'   => [],
        }
    );

    return $soap_interface;
}

# methods returns the list of methods 
# to obtain the array reference you must use _methods_accessor
sub methods { return @{ shift()->_methods_accessor } }

sub schema_chunks { return @{ shift()->_schema_chunks_accessor } };

sub auxiliary_schemas { return @{ shift()->_auxiliary_schemas_accessor } }

sub add_method {
    my ( $this, $name, $code, $fields ) = @_;

    $fields ||= {};
    UNIVERSAL::isa($code, 'CODE')
    or die "Parameter 2 of add_method must be a code reference\n ";

    ! grep { $name eq $_->name } $this->methods
    or die "Method $name was already added\n ";

    my $method = Akar::SOAPInterface::Method->new(
        {   'soap_action' =>
                join( $this->soap_action_sep, $this->uri, $name ),
            'response_element' => 'tns:' . $name . 'Response',
            %{$fields},
            'code'    => $code,
            'name'    => $name,
            'element' => 'tns:' . $name,
        }
    );

    push @{ $this->_methods_accessor }, $method;
    return $method;
}

# adds new schema element
sub add_schema {
    my ($this, $schema) = @_;

    push @{$this->_auxiliary_schemas_accessor}, $schema;
}

sub add_schema_chunk {
    my $this = shift;

    push @{$this->_schema_chunks_accessor}, $_ for @_;
}

# adds new namespace
sub register_namespace {
    my $this = shift;

    if ( ref( $_[0] ) ) {
        # hash reference
        my ($namespaces) = @_;
        @{ $this->_namespaces_accessor }{ keys %{$namespaces} }
            = values %{$namespaces};
    }
    else {
        my ( $prefix, $namespace ) = @_;
        $this->_namespaces_accessor->{$prefix} = $namespace;
    }
}

# returns hash with all namespaces
sub namespaces {
    my ($this) = @_;

    return {
        'xs'   => xml_schema_namespace,
        'wsdl' => wsdl_namespace,
        'soap' => wsdl_soap_namespace,
        'xsi'  => xml_schema_instance_namespace,
        'tns'  => $this->uri,
        %{ $this->_namespaces_accessor },
    };
}

sub xml_builder {
    my ($this) = @_;
    return Akar::XML::DOMBuilder->new(
        { 'namespaces' => $this->namespaces, } );
}

# creates the WSDL document
sub build_wsdl {
    my ( $this, $location ) = @_;

    my ( @message_elems, @port_type_operation_elems,
        @binding_operation_elems );
    for my $method ( $this->methods ) {
        my $input_message_name  = $method->name . 'SoapIn';
        my $output_message_name = $method->name . 'SoapOut';

        push @message_elems,
            [
            'wsdl:message',
            { 'name' => $input_message_name },
            [   'wsdl:part',
                {   'name'    => 'parameters',
                    'element' => $method->element,
                }
            ],
            ];
        push @message_elems,
            [
            'wsdl:message',
            { 'name' => $output_message_name, },
            [   'wsdl:part',
                {   'name'    => 'parameters',
                    'element' => $method->response_element,
                }
            ],
            ];
        push @binding_operation_elems,
            [
            'wsdl:operation',
            { 'name' => $method->name },
            [ 'soap:operation', { 'soapAction' => $method->soap_action } ],
            [   'wsdl:input/soap:body',
                {   'use'       => 'literal',
                    'namespace' => $this->uri,
                }
            ],
            [   'wsdl:output/soap:body',
                { 'use' => 'literal', 'namespace' => $this->uri, }
            ]
            ];
        push @port_type_operation_elems,
            [
            'wsdl:operation',
            { 'name' => $method->name },
            [ 'wsdl:documentation', $method->documentation ],
            [ 'wsdl:input',  { 'message' => 'tns:' . $input_message_name, } ],
            [ 'wsdl:output', { 'message' => 'tns:' . $output_message_name, } ],
            ];
    }

    # service element
    return $this->xml_builder->create_doc(
        'wsdl:definitions',
        { 'targetNamespace' => $this->uri },
        [ 'wsdl:types'      => 
            $this->service_schema,
            $this->auxiliary_schemas
        ],
        @message_elems,
        [   'wsdl:portType',
            { 'name' => $this->service_name . 'PortType' },
            @port_type_operation_elems,
        ],
        [   'wsdl:binding',
            {   'name' => $this->service_name . 'Binding',
                'type' => 'tns:' . $this->service_name . 'PortType',
            },
            [   'soap:binding',
                {   'style'     => 'document',
                    'transport' => wsdl_http_namespace,
                }
            ],
            @binding_operation_elems
        ],
        [   'wsdl:service',
            { 'name'          => $this->service_name, },
            [ 'wsdl:documentation' => $this->documentation ],
            [   'wsdl:port',
                {   'name'    => $this->service_name . 'Port',
                    'binding' => "tns:" . $this->service_name . 'Binding',
                },
                [   'soap:address',
                    { 'location' => $location }
                ],
            ]
        ]
    );
}

{

    package Akar::SOAPInterface::Method;
{
  $Akar::SOAPInterface::Method::VERSION = '1.994';
}
    use base qw(Class::Accessor);

    __PACKAGE__->mk_ro_accessors(
        'name',      # name of the method
        'code',      # code reference
        'schema',    # schema for the method - list of XML::LibXML elements
                     # or arrays turned to elements
        'soap_action',
        'documentation',
        'element',             # qualified name of the method element
        'response_element',    # qualified name of the response element
    );
}

# install 
#   - closes the method - so no methods can be added
#   - installs the wrapper methods for soap methods
#   - installs the create_wsdl method
sub install {
    my ($this) = @_;

    no strict 'refs';

    # closes the object
    # service schema can be set from outside
    my $service_schema = $this->service_schema;
    if ( !$service_schema ) {
        $service_schema = $this->build_service_schema;
        $this->service_schema($service_schema);
    }

    # things are getting complicated when there is more schemas
    my @tmp_fhs;    # just to have proper scope
    if ( my @auxiliary_schemas = $this->auxiliary_schemas ) {

        # I store all schemas to temporary files
        my @tmp_files;
        for my $schema ( $service_schema, @auxiliary_schemas ) {
            my $fh = File::Temp->new(
                'TEMPLATE' => 'Akar-SOAPInterfaceXXXXX',
                'SUFFIX'   => '.xsd',
                'UNLINK'   => 1,
                'DIR'      => File::Temp::tempdir(CLEANUP => 1),
            );
            push @tmp_fhs, $fh;
            $fh->print( $schema->toString );
            $fh->close;
            push @tmp_files, $fh->filename;
        }

        # new schema importing the other ones
        $service_schema = $this->xml_builder->create_doc(
            'xs:schema',
            { 'targetNamespace' => 'http://none.org', },
            map { [ 'xs:import', { 'schemaLocation' => $_ } ] } @tmp_files
        );
    }

    # 2010-01-18 danielr
    # service_schema_validator can be supplied to constructor
    if ( !$this->service_schema_validator ) {
        my $schema_validator = XML::LibXML::Schema->new(
            'string' => $service_schema->toString );
        $this->service_schema_validator($schema_validator);
    }

    # installs the soap interface
    *{ $this->service_package . '::soap_interface' } = sub { return $this };

    if ( !$this->service_package->isa('SOAP::Server::Parameters') ) {
        push @{ $this->service_package . '::ISA' },
            'SOAP::Server::Parameters';
    }

    *{ $this->service_package . '::create_wsdl' } = sub {
        my ( undef, $location ) = @_;

        return $this->build_wsdl($location)->toString(1);
    };

    # creates the soap wrapper
    for my $method ( $this->methods ) {

        # zkontrolovat zda metoda neexistuje
        *{ $this->service_package . '::' . $method->name } = sub {
            return $this->call_method( $method, @_ );
            }
    }
}

# returns soap call object
sub build_soap_call {
    my ( $this, $som ) = @_;

    my $soap_input_document = soap_document_passed_as_doc($som);
    return Akar::SOAPInterface::SOAPCall->new(
        {   document       => $soap_input_document,
            soap_interface => $this,
            soap_context   => $som->context
        }
    );
}

sub call_method {
    my $this = shift;

    my $retval = eval { $this->_call_method(@_); };

    if ( my $error = $@ ) {

        # soap fault is propagated without change
        die $error if ref($error) && UNIVERSAL::isa( $error, 'SOAP::Fault' );

        # Other errors are NOT propagated to client but output to the log instead
        my $error_id = join('_', 'INTERNAL_ERROR', $$, POSIX::strftime('%Y-%m-%dT%H:%M:%S', localtime));
        warn "Internal error $error_id\n$error\n";
        die SOAP::Fault->faultcode('Server.InternalError')
            ->faultstring(
            "Internal error occured (id $error_id), contact the service vendor ");
    }

    return $retval;
}

sub _call_method {
    my ( $this, $method, $invocant, @args ) = @_;

    my $method_code = $method->code;

    # document_like - soap_call in, document out both validated
    if ( $this->document_like ) {
        my $soap_call = $this->build_soap_call( $args[-1] );
        eval {
            $this->service_schema_validator->validate( $soap_call->document );
        };
        if ( my $err = $@ ) {
            die SOAP::Fault->new(
                'faultcode'   => 'Client.InputValidationFailed',
                # 2009-08-17 danielr
                # validation error is an object I need it serialized here
                'faultstring' => "$err",
            );
        }

        # XML::LibXML::Document is expected
        my $soap_output = $invocant->$method_code($soap_call);

        # output validation
        eval { $this->service_schema_validator->validate($soap_output); };
        if ( my $err = $@ ) {
            my $soap_output_str = $soap_output->toString(1);
            die <<"END_FAILURE";
Output validation failed  
  output document: 
$soap_output_str
  error: 
$err
END_FAILURE
        }

        # return value must be prepared to penetrate through SOAP::Lite
        # unchanged
        return soap_response_body( soap_xml_data($soap_output) );
    }
    else {

        # SOAP::Lite like - no validation, no XML
        return $invocant->$method_code(@args);
    }
}

# returns XML::LibXML::Document containing the schema describing service
sub build_service_schema {
    my ($this) = @_;

    my @aux_namespaces = grep {$_}
        map { $_->documentElement->getAttribute('targetNamespace') }
        $this->auxiliary_schemas;
    return $this->xml_builder->create_doc(
        'xs:schema',
        {     'elementFormDefault' => $this->schema_element_unqualified
            ? 'unqualified'
            : 'qualified',
            'targetNamespace' => $this->uri,
        },

        # imports auxiliary_schema target namespaces
        ( map { [ 'xs:import', { 'namespace' => $_ } ] } @aux_namespaces ),
        $this->schema_chunks,
        map { @{ $_->schema } } $this->methods
    );
}

1;

__END__

=head1 NAME

Akar::SOAPInterface - SOAP interface for a Perl package 

=head1 SYNOPSIS

    package MySOAPPackage;
    
    use Akar::SOAPInterface;

    # defines 
    my $soap_interface = Akar::SOAPInterface->new( __PACKAGE__,
        'http://some.uri.cz/MySOAPPackage',
        { 'documentation' => 'A sample soap service' }
    );
    $soap_interface->add_method( 'create', \&_create, {
        'schema' => [ ...  ],
    } );
    $soap_interface->add_method( 'info',   \&info, {
        'schema' => [ ...  ],
    } );
    $soap_interface->install;

    # soap methods
    sub _create {
        my ($this, $soap_call) = @_;

        ....

        return $response_doc;
    }

    sub _info {
        my ($this, $soap_call) = @_;

        ...
        return $response_doc;
    }

    1;

=head1 DESCRIPTION

Akar::SOAPInterface is a simple interface for a Perl package 
implementing a service in SOAP::Lite based SOAP server 
environment.

It can:

=over 4

=item *

create WSDL

=item *

wrap soap methods so they work with XML documents 
    (XML::LibXML::Document) instead of SOAP data

=item *

validate soap input and output documents against XML Schema.

=item *

prevent an error thrown by soap method from being seen by SOAP client.

=back

=head1 METHODS

=over 4

=item new

my $soap_interface
    = Akar::SOAPInterface->new( $service_package, $uri, \%fields );

Constructor. The mandatory parameters are:

=over 4

=item $service_package

Package implementing the service.

=item $uri 

Namespace of the service.

=back

Other parameters may be supplied in C<\%fields> hash reference.  They are.

=over 4

=item documentation

The documentation for the service to be used in WSDL file. Plain text in UTF8.

=item document_like

When set (and set by default) the service does all the interesting things
described above (validation, passing documents, ...)

=item service_name

The name of service to be used in WSDL. By default generated from the service package.

=item soap_action_sep

The separator used to create method soapAction from soap service URI and method name. 
Hash ('#') by default.

=back

All parameters passed to constructor work also as getters and setters (be carefull
with setters). 

  $soap_interface->service_package;
  $soap_interface->uri;

=item add_method

  $soap_interface->add_method($name, $code, \%fields);

Adds new SOAP method to the interface. 

=over 4

=item  $name 

Name of the method.

=item $code 

The implementation of SOAP method. A code reference.

=back

=over 4

The C<\%fields> hash reference can contain folowing options:

=item documentation

Method documentation - UTF8 text.

=item schema 

XML schema describing the method request and response document elements. 

It is an array reference containing either XML::LibXML nodes (document,
element)  or array reference describing the elements as defined by
Akar::XML::DOMBuilder method.

Each element in the array is used as part of the XML Schema.
It can be XML Schema element definition for the soap method element,
soap response element, XML Schema type definition, ...

As you can see in the example, you can use several defined namespace prefixes:

    'xs'   => 'http://www.w3.org/2001/XMLSchema',
    'wsdl' => 'http://schemas.xmlsoap.org/wsdl/',
    'soap' => 'http://schemas.xmlsoap.org/wsdl/soap/',
    'tns'  => $service->uri,


    my @gpAuthorized_schema = (

        # request
        [   'xs:element',
            { 'name'                           => 'gpAuthorized', },
            [ 'xs:annotation/xs:documentation' => '' ],
            [   'xs:complexType',
                [   'xs:sequence',
                    [   'xs:element',
                        {   'name' => 'wsOperatorId',
                            'type' => 'xs:string'
                        },
                    ],
                    [   'xs:element',
                        {   'name' => 'login',
                            'type' => 'xs:string'
                        },
                    ],
                    [   'xs:element',
                        {   'name' => 'password',
                            'type' => 'xs:string'
                        },
                    ]
                ],
            ],
        ],

        # response
        [   'xs:element',
            { 'name'                           => 'gpAuthorizedResponse', },
            [ 'xs:annotation/xs:documentation' => '' ],
            [   'xs:simpleType/xs:restriction',
                { 'base' => 'xs:string', },
                [ 'xs:enumeration', { 'value' => 'OK' } ],
                [ 'xs:enumeration', { 'value' => 'Failure' } ],
            ]
        ]
    );

    $soap_interface->add_method(
        'gpAuthorized',
        $package->can('_gpAuthorized'),
        { 'schema' => \@gpAuthorized_schema, }
    );

=item soap_action

soapAction of the method to be used in wsdl.

=item response_element

Document element for the response document. By default C<tns:${name}Response>.

=back

=item methods

Returns the list of method objects.

=item build_wsdl 

    my $doc = $soap_interface->build_wsdl($soap_location);

Returns WSDL for the service as XML::LibXML::Document object.

=item install

Finishes the soap interface and binds it with the service package.  It means

=item * 

Wraps each soap method.

=item *

Compose the XML schema for the service from the method schemas.

=item * 

Import a few methods into service package:

=over 4

=item soap_interface

Returns the soap_interface object.

=item create_wsdl

  $soap_service->create_wsdl($location_url);

Returns the soap service WSDL (as text).

=back

After call of install the interface may not be changed nor installed again.

=back

=head1 SOAP METHOD IMPLEMENTATION 

    $soap_interface->add_method('getUserInfo', $this->can('_getUserInfo'));


    sub _getUserInfo {
        my ( $package, $soap_call ) = @_;

        my $user_id = $soap_call->args->{'userId'};

        my $user = $package->retrieve($user_id);
        return $soap_call->xml_builder->create_doc(
            'tns:userInfo',
            { 'id'            => $user_id },
            [ 'tns:firstName' => $user->first_name ],
            [ 'tns:lastName'  => $user->last_name ],
        );
    }

The implementation method C<_getUserInfo> is passed the SOAP call object.

The method is expected to return XML::LibXML::Document object.
To build the object method can use xml_builder method of soap_call. 

=head1 SOAP Call object

SOAP method implementation is given soap call object (Akar::SOAPInterface::SOAPCall)
as parameter. 

=over 4

=item document

Returns XML::LibXML::Document object - the content of SOAP:Body element.

=item xpc 

Returns XML::LibXML::XPathContext object bound to soap input document, with 
couple namespaces registered:

    'xs'   => 'http://www.w3.org/2001/XMLSchema',
    'wsdl' => 'http://schemas.xmlsoap.org/wsdl/',
    'soap' => 'http://schemas.xmlsoap.org/wsdl/soap/',
    'tns'  => $service->uri,

=item args

Returns hash with soap input parameters. Keys are localnames of child elements
of document element, values are their respective text values.

=item xml_builder

Returns Akar::XML::DOMBuilder object which can be used to build a response XML document.
When building one can use the predefined prefixes mentioned above.

=back

=head1 INHERITANCE OF SOAP SERVER PACKAGES

Sometimes it is desirable to inherit the whole soap interface.
Akar::SOAPInterface is simple and it is allways bind to
one package. But this functionality may be achieved by following
simple technique:

    package MySystem::SoapServiceBase;
    # this is the base class

    use Akar::SOAPInterface;

    sub build_soap_interface {
        my ($this) = @_;

        my $soap_interface = Akar::SOAPInterface->new($this, $this->uri, {
            'documentation' => ...
        });
        $soap_interface->add_method('m1', $this->can('_m1'), ...);
        return $soap_interface;
    }

    package MySystem::SoapService1;
    use base qw(MySystem::SoapServiceBase); 

    # this line must be used in any (even derived) module
    # accesible as soap service
    __PACKAGE__->build_soap_interface->install;

    sub build_soap_interface {
        my ($this) = @_;

        my $soap_interface = $this->SUPER::build_soap_interface;
        $soap_interface->documentation('Completely different service');
        $soap_interface->add_method(...);
        return $soap_interface;
    }

    ...

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz>

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
