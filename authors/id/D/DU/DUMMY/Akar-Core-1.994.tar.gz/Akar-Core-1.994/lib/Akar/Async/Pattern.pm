package Akar::Async::Pattern;
{
  $Akar::Async::Pattern::VERSION = '1.994';
}
use strict;

use Exporter 'import';

our @EXPORT = qw(
    async_waterfall
    async_any
    async_parallel
    async_series
    async_one
    push_callback
);

our @EXPORT_OK = qw(is_callback);

use Akar::Async::Pattern::Process;

sub _create {
    my $process_class = 'Akar::Async::Pattern::Process';

    my $on_start  = shift;
    my $tasks     = shift;
    my $on_finish = [ @_ && is_callback( $_[-1]) ? pop() : () ];
    my $process = $process_class->new(
        tasks => $tasks,
        on_finish => $on_finish,
    );
    if ( defined wantarray ) {
        # in scalar or list context we return the process
        $process->on_start($on_start);
        return $process;
    }
    else {

        # in void context we start the process
        $process->$on_start(@_);
        return;
    }
}

for my $pattern (qw(series any parallel waterfall)) {
    my $inner    = '_' . $pattern;
    my $exported = "async_" . $pattern;
    no strict 'refs';
    *$exported = sub {
            return _create( $inner, @_ );
        };
}

# so far async_one is only shortcut but later I will make it more effective
sub async_one {
    my $code = shift;
    return async_any([$code], @_);
}

# pushes the callback into the list of args
# if the last argument is already the callback
# the two callbacks together

sub push_callback {

    # callback we passed is the last argument
    # so the possible callback is before it
    @_ > 1 && is_callback( $_[-2] )
        or return @_;

    my $cb1 = pop();
    my $cb2 = pop();
    return @_, sub {
        $cb1->(@_);
        $cb2->(@_);
    };
}

sub pop_callback {
    my $args = $_[0];
    return @$args && is_callback( $_[-1] ) ? pop @$args : sub { };
}

sub is_callback {
    my $code = shift;
    return ref $code && ref $code eq 'CODE';
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
