package Akar::Catalyst::Plugin::Postsetup;
{
  $Akar::Catalyst::Plugin::Postsetup::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor::Grouped);

use Carp qw(carp croak);

__PACKAGE__->mk_group_accessors(inherited => 'postsetup_actions');
__PACKAGE__->postsetup_actions([]);

# enables components to add action into application which is run after setup
# APP->postsetup has to be run explicitly
sub postsetup {
    my $this = shift;

    if (@_){
        $this->postsetup_actions( [ @{ $this->postsetup_actions }, @_ ] );
        return;
    }
    
    # flush
    my @actions = @{$this->postsetup_actions};
    $this->postsetup_actions([]); # freeing
    for my $action (@actions){
        $action->($this);
    }
}

1;

__END__

=head1 NAME

Akar::Catalyst::Plugin::MTest - deployment of Test controllers

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

