package Akar::PL_SQL::Code::Proc;
{
  $Akar::PL_SQL::Code::Proc::VERSION = '1.994';
}
use strict;

# procedure or function 
use base qw(Akar::PL_SQL::Code);
use Akar::PL_SQL::Code::Functions qw(iblock);

__PACKAGE__->mk_accessors(qw(header decl body name));

sub dump {
    my ($this) = @_;

    return ( @{$this->header}, ';' ) if !$this->dumping_body;

    return (
        @{$this->header}, 'is', iblock( @{$this->decl || []} ),
        'begin',
        iblock( @{$this->body} ),
        'end ' . $this->name, ';'
    );
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96: 
