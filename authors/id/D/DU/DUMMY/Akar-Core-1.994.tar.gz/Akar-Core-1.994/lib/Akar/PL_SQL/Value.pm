package Akar::PL_SQL::Value;
{
  $Akar::PL_SQL::Value::VERSION = '1.994';
}
use strict;

use base qw(Class::Accessor);
__PACKAGE__->mk_ro_accessors(qw(type value));

sub new {
    my $proto   = shift;
    my($fields) = @_;

    my $value = $$fields{'value'};
    ref($value) && UNIVERSAL::isa($value, __PACKAGE__)
      ? $value # typed value is not retyped 
      : $proto->SUPER::new($fields);
}

for my $method (qw(is_output dump)){
    my $type_method = $method. '_value';
    no strict 'refs';
    *$method = sub { 
        my $this = shift;
        $this->type->$type_method($this->value, @_);
    };
}

1;

