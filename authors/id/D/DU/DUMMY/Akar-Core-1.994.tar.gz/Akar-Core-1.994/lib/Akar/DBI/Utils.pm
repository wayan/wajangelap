package Akar::DBI::Utils;
{
  $Akar::DBI::Utils::VERSION = '1.994';
}

=head1 NAME

Akar::DBI::Utils - some database related stuff

=head1 DESCRIPTION

Akar::DBI::Utils is a container for some database related functions,
I didn't find a better location for.

=head1 EXPORTABLE FUNCTIONS 

=over 4

=cut

use strict;

our @EXPORT_OK = qw(qname2name qname2owner);
our @ISA = qw(Exporter);

require Exporter;

=item qname2owner

returns the owner part of qualified name (OWNER.NAME).
Dies when the name doesn't consist of two parts separated by dot.

=cut

sub qname2owner {
	my($qname) = @_;
	my @qname = split(/\./, $qname);
	@qname  == 2 or die "qualified name expected, got $qname\n ";
	$qname[0];
}

=item qname2name

returns the name part of qualified name (OWNER.NAME).
Dies when the name doesn't consist of two parts separated by dot.

=cut

# returns the name part of qualified database object name
sub qname2name {
	my($qname) = @_;
	my @qname = split(/\./, $qname);
	@qname  == 2 or die "qualified name expected, got $qname\n ";
	$qname[1];
}

=back

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

1;
