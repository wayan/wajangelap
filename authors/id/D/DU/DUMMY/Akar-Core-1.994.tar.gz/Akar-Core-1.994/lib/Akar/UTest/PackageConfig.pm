package Akar::UTest::PackageConfig;
{
  $Akar::UTest::PackageConfig::VERSION = '1.994';
}
use strict;
use warnings;


use base qw(Test::Class);

# Test::More imports: 
#   ok use_ok require_ok is isnt like unlike is_deeply
#   cmp_ok skip todo todo_skip pass fail eq_array
#   eq_hash eq_set $TODO plan can_ok isa_ok diag BAIL_OUT
use Test::More;

# Test::Exception imports:
#   dies_ok lives_ok throws_ok lives_and
use Test::Exception;
use File::Spec;
use Data::Dumper;
use Class::Trait;

use Akar::Base;
use Akar::PackageConfig;
use File::Slurp;
use File::Temp;

# You can defined properties for your testing class
use base qw(Class::Accessor);
__PACKAGE__->mk_accessors(qw());

use Carp qw(carp croak);

sub tested_module { return 'Akar::PackageConfig' }

#-------------------------------------------------------------------------------
# different YAMLS
#-------------------------------------------------------------------------------

my $not_a_yaml = temp_yaml('NoYaml.yml', <<'END_INVALID_YAML');
this is not a yaml
END_INVALID_YAML

my $array_yaml = temp_yaml('ArryYaml.yml', <<'END_ARRAY_YAML');
---
- this
- yaml
- contains 
- array
END_ARRAY_YAML

my $multiple_yaml = temp_yaml('MultiYaml.yml', <<'END_MULTIPLE_YAML');
---
this: 'is a hash containing yaml'
---
but: 'with more than one hash'
END_MULTIPLE_YAML

my $global_yaml = temp_yaml('My-Module-global.yml', <<'END_GLOBAL_YAML');
---
pet: baboon
END_GLOBAL_YAML

my $local_yaml = temp_yaml('My-Module-local.yml', <<'END_LOCAL_YAML');
---
pet: gibbon
datasource: 'not a mapping'
datasource_for:
  manggis: dbi:Pg:manggis
  durian: dbi:Oracle:durian
soap_proxy: ~
END_LOCAL_YAML

my $inherited_yaml = temp_yaml('My-Module-Inh.yml', <<'END_INH_YAML');
---
pet: mongoose
datasource_for: 
  durian: dbi:Oracle:durianDevel
  rambutan: dbi:Oracle:rambutan
END_INH_YAML

{

    # the config files are kept until global cleanup
    my @temp_yamls;

    sub temp_yaml {
        my ( $file, $content ) = @_;

        my $template = $file . '-XXXX';
        my $temp = File::Temp->new( 'TEMPLATE' => $template );
        print $temp $content;
        close($temp);

        push @temp_yamls, $temp;
        return $temp->filename;
    }
}

# returns new traited package
my $pkg_no = 0; 
sub new_traited_class {
    my ( $this, $inherit_from ) = @_;

    $pkg_no++;
    my $package = "TestOf::Akar::PackageConfig::No$pkg_no";
    if ($inherit_from) {
        no strict 'refs';
        @{ $package . '::ISA' } = ($inherit_from);
    }
    else {
        Class::Trait->apply($package, 'Akar::Trait::PackageConfig');
    }
    return $package;
}

# test method with two tests
sub config_file : Test(2) {
    my $package_config = Akar::PackageConfig->new('My::Module');

    # test names
    is( $package_config->local_config_file,
        Akar::Base->app_config('My-Module.yml'),
        'local_config_file'
    );
    is( $package_config->global_config_file,
        File::Spec->catfile( '/usr/local/etc', 'My-Module.yml' ),
        'global_config_name'
    );
}


sub load_config_file: Test(5) {
    my $package_config = Akar::PackageConfig->new('No::Such::Module');
    throws_ok {
        $package_config->load_config_file( $not_a_yaml );
        }
        qr{Loading of.*failed:};

    throws_ok {
        $package_config->load_config_file( $array_yaml );
        }
        qr{Invalid conf.*};

    throws_ok {
        $package_config->load_config_file( $multiple_yaml );
        }
        qr{Invalid conf.*};

    {
        my $config;
        lives_ok {
            $config = $package_config->load_config_file( $global_yaml );
            }
            'reading regular config';
        is_deeply( $config, { 'pet' => 'baboon' } );
    }
} 

sub add_config_param : Test(7) {
    my $package_config = Akar::PackageConfig->new('My::Module');
    $package_config->global_config_file( $global_yaml );
    $package_config->local_config_file( $local_yaml );

    lives_ok {
        $package_config->add_param('pet');
        }
        'adding existing parameter';

    throws_ok {
        $package_config->add_param('flower');
        }
        qr{No value.*flower}, 'adding non existent parameter';
    diag $@;

    lives_ok {
        $package_config->add_param( 'flower' => 'carnation' );
        }
        'Adding non existent parameter with default value';

    # checking the values - local must superseded global
    {
        my $pet;
        lives_ok { $pet = $package_config->pet } 'checking value';
        is( $pet, 'gibbon' );
    }

    {
        my $flower;
        lives_ok { $flower = $package_config->flower } 'checking value';
        is( $flower, 'carnation' );
    }
}

# in
sub add_config_param_inherited : Test(3) {
    my ($this) = @_;

    my $traited_class = $this->new_traited_class;
    $traited_class->package_config->global_config_file($global_yaml);
    $traited_class->package_config->local_config_file($local_yaml);
    $traited_class->add_config_param('pet');
    $traited_class->add_config_mapping('datasource_for');

    my $inh_class = $this->new_traited_class($traited_class);

    $inh_class->package_config->global_config_file($inherited_yaml);
    $inh_class->package_config->local_config_file(undef);

    lives_and {
        my $inh_pet = $inh_class->pet;
        is( $inh_pet, 'gibbon' );
        }
        'Inherited value is not superseded until param is defined';

    $inh_class->add_config_param('pet');
    lives_and {
        my $inh_pet = $inh_class->pet;
        is( $inh_pet, 'mongoose' );
        }
        'Inherited value is superseded after param is defined';

    # 2008-11-19 there is no sense to test this
    # since there no merging
    if (0) {
        my $inh_datasource_for;
        lives_ok { $inh_datasource_for = $inh_class->datasource_for }
            'inherited mapping';
        diag Dumper($inh_datasource_for);
        is_deeply(
            [ sort { $a cmp $b } keys %{$inh_datasource_for} ],
            [ sort { $a cmp $b } qw(durian manggis rambutan) ]
            )
            or diag join( ', ', keys %{$inh_datasource_for} );
    }
}

sub reader : Test(2) {
    my ($this) = @_;

    my $traited_class = $this->new_traited_class; 
    $traited_class->package_config->global_config_file($global_yaml);
    $traited_class->package_config->local_config_file($local_yaml);
    $traited_class->add_config_param( 'pet', { 'reader' => 'cfg_pet' } );

    ok( !UNIVERSAL::can( $traited_class, 'pet' ),
        'No reader under original name' );
    can_ok( $traited_class, 'cfg_pet' );
}

sub add_mapping : Test(4) {
    my $package_config = Akar::PackageConfig->new(
        'My::NotUsedModule',
        {   'global_config_file' => $global_yaml,
            'local_config_file'  => $local_yaml,
        }
    );
    throws_ok {
        $package_config->add_mapping('datasource');
        }
        qr{\QCan't use string ("not a mapping") as a HASH ref while},
        'not a hash ref';

    $package_config->add_mapping( 'datasource_for');

    lives_and {
        my $datasource_for = $package_config->datasource_for;
        is_deeply(
            $datasource_for,
            {   'durian'  => 'dbi:Oracle:durian',
                'manggis' => 'dbi:Pg:manggis',
            }
        );
        }
        'getting mapping';


    lives_and { is $package_config->datasource_for('durian'), 'dbi:Oracle:durian' }
        'datasource for durian is ....';

    throws_ok { $package_config->datasource_for('sirsak') }
        qr{No value of configuration parameter 'datasource_for' found for key 'sirsak'},
        'No datasource for sirsak';
}

# using trait
sub use_trait: Test(6) {
    my ($this) = @_;
    my $traited_class = $this->new_traited_class;
    ok(!$@, 'using trait') or diag $@;

    lives_and {
        my $package_config = $traited_class->package_config;
        isa_ok($package_config, 'Akar::PackageConfig');
    } 'package_config';

    lives_and {
        $traited_class->package_config->global_config_file(
            $global_yaml);
        is( $traited_class->package_config->global_config_file,
            $global_yaml );
        }
        'setting the global file';

    lives_and {
        $traited_class->package_config->local_config_file(
            $local_yaml);
        is( $traited_class->package_config->local_config_file,
            $local_yaml );
        }
        'setting the local file';

    lives_ok {
        $traited_class->add_config_param('pet');
    } 'Adding param';

    lives_ok {
        $traited_class->add_config_mapping('datasource_for');
    } 'Adding mapping'
}

sub undefined_value: Test(1) { 
    eval qq{
        package My::Module::UnusedUndefined;
        use Class::Trait qw(Akar::Trait::PackageConfig);
    };

    My::Module::UnusedUndefined->package_config->local_config_file($local_yaml);
    dies_ok {
        My::Module::UnusedUndefined->add_config_param('soap_proxy'); 
    } 'pridani parametru s nedefinovanou hodnotou';
    diag $@;
}

1;

__END__

=head1 NAME

Akar::UTest::PackageConfig - Testing class for Akar::PackageConfig

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
