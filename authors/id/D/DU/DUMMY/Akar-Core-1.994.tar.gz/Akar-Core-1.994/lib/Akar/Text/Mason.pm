package Akar::Text::Mason;
{
  $Akar::Text::Mason::VERSION = '1.994';
}

=head1 NAME

Akar::Text::Mason - filtr volaj�c� html mason

=head1 SYNOPSIS


=head1 DESCRIPTION

=cut

use strict;

use base qw(Akar::Filter::MasonPL::Base Akar::Script);

use File::Path qw(mkpath);
use Data::Dumper;
use HTML::Mason;
use File::Spec::Functions qw(rel2abs abs2rel); 
use File::Basename qw(dirname);
use Akar::Script 'header_footer' => 0;

sub options {
	my $this = shift;
	return($this->SUPER::options, qw(root=s param=s%));
}

sub body {
	my $this = shift;
	print $this->process_file($_, %{$this->opt('param') || {}})
		for $this->argv;
}

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

1;


