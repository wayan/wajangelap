package Akar::Catalyst::View::Mason;
{
  $Akar::Catalyst::View::Mason::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Catalyst::View::Mason);

use Akar::Base;
use File::Path qw(mkpath);
use Interpolation 'E' => 'eval';
use JSON;

my $data_dir = Akar::Base->app_data('mason/data_dir');
mkpath($data_dir) if !-e $data_dir;


# allow_nonref means it can convert also strings and numbers
my $json = JSON->new->allow_nonref;

__PACKAGE__->config(
    {   'use_match' => 0,
        'data_dir'  => $data_dir,

        # 2008-10-29 danielr
        # by default all mason substitutions - <% $expression %>
        # are considered pure text in X(HT)ML environment
        # thus entity encoded
        # to insert a piece of html use <% $piece_of_html | n %>

        # 2008-11-04 danielr
        # we must use basic_html_escape function (from HTML::Mason::Escapes)
        # to prevent czech chars to encoded too
        'default_escape_flags' => ['bh'],
        'escape_flags'         => {
            'bh' => 'basic_html_escape',
            'js' => sub {
                my $txtref = shift;
                $$txtref = $json->encode($$txtref);
            },
        },

        # special compiler striping the leading whitespaces
        # from the beginning of text in templates and
        # their methods
        'compiler_class' =>
            'Akar::Catalyst::View::Mason::Compiler::StripLeadingWhitespace'
    }
);

sub HTML::Mason::Commands::encode_json {
    return $json->encode(shift());
}

sub process {
    my $self = shift();
    my $c    = shift();

  # 2008-05-14 danielr
  #   because the content_type was already set in Catalyst::Action::RenderView
  #   condition would be allways false
  #    if ( !$c->response->content_type ) {
    $c->response->content_type('text/html; charset=iso-8859-2');

    # 2008-11-09 danielr
    # context for a page rendering free for template use
    # (I introduce it to ensure uniqueness for required javascripts)
    $c->stash->{'rendering_context'} = {};

    #    }
    return $self->SUPER::process($c);
}

{

    package Akar::Catalyst::View::Mason::Compiler::StripLeadingWhitespace;
{
  $Akar::Catalyst::View::Mason::Compiler::StripLeadingWhitespace::VERSION = '1.994';
}

    # strips leading whitespace in methods and all templates
    use base qw(HTML::Mason::Compiler::ToObject);
    use Class::C3;

    # cow_text_started is a "stack" 
    # - index 0 for template text
    # - index 1 for method
    #
    # No whitespace is issued until appropriate text started
    use HTML::Mason::MethodMaker 'read_write' => ['cow_text_started'];

    sub compile {
        my $this = shift;

        $this->cow_text_started( [0] );
        return $this->next::method(@_);
    }

    # starts the method
    sub start_named_block {
        my $this = shift;

        push @{ $this->cow_text_started }, 0;
        return $this->next::method(@_);
    }

    sub end_named_block {
        my $this = shift;

        pop @{ $this->cow_text_started };
        return $this->next::method(@_);
    }

    sub text {
        my $this   = shift;
        my %params = @_;

        # text in the block is trimmed from left
        $this->cow_text_started->[-1] ||= do {
            $params{'text'} =~ s/^\s+//s;
            $params{'text'} =~ /\S/; 
        };
        return $this->next::method(%params);
    }

    Class::C3::initialize();

    # probably HTML::Mason tries to require this class
    # so I need to pretend it was required
    my $pm = __PACKAGE__ . '.pm';
    $pm =~ s{::}{/}g;
    $INC{$pm} = __FILE__;
}

1;

__END__

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 


