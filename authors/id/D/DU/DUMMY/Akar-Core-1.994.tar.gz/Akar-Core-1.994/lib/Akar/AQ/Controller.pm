package Akar::AQ::Controller;
{
  $Akar::AQ::Controller::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Akar::Class::Accessor Akar::AQ::DaemonControl Akar::AQ::Dbize);

use Carp qw(carp croak);
use List::MoreUtils qw(zip first_value);
use Time::HiRes qw(gettimeofday tv_interval);

use Akar::DBI::Statement qw(sql_param sql sql_param_inout sql_and sql_join);
use Interpolation 'E' => 'eval', 'sqlp' => sub { return sql_param(@_) };
use Akar::Class::Utils qw(require_package);
use Akar::AQ::WaitUntil;
use Akar::AQ::Constants qw(LISTEN_TIMEOUT_ERRNO DEQUEUE_TIMEOUT_ERRNO
    NO_MESSAGE_IN_QUEUE_ERRNO);
use File::Basename qw(basename);

use Akar::AQ::_Queue;
use Akar::AQ::_AqQueue;
use Akar::AQ::_Daemon;

# queue types
use constant 'NORMAL_QUEUE'    => 'NORMAL_QUEUE';
use constant 'EXCEPTION_QUEUE' => 'EXCEPTION_QUEUE';

# qualified!! name of the queue table
__PACKAGE__->mk_ro_accessors(qw(queue));

# those are read only, set when object is created
__PACKAGE__->mk_ro_accessors(
    qw(queue_owner queue_name qid queue_type payload_type queue_table
        queue_table_name sort_order
        multi_consumer
    )
);
__PACKAGE__->mk_ro_accessors(qw(message_class));
__PACKAGE__->mk_accessors(qw(dequeued errors));

# number of timeouts after which the controller stops 
# default is 1
__PACKAGE__->mk_accessors( 'exit_when_timeout');
__PACKAGE__->mk_accessors( 'listen_timeout', 'stop_after' );

__PACKAGE__->mk_accessors(qw(logpath));

# dequeue_options.navigation (values are NEXT_MESSAGE (default), # FIRST_MESSAGE)
__PACKAGE__->mk_accessors(qw(dequeue_navigation));

sub queue_class { shift()->dbize('Akar::AQ::_Queue'); }

sub daemon_class { shift()->dbize('Akar::AQ::_Daemon') }

# 2013-01-04 danielr - returns the "table" to read the messages from
# for single consumer queues is the queue table directly
# for multiconsumer it is the view AQ$<queue_table>
sub ext_queue_table {
    my $this = shift;

    if ( $this->multi_consumer ) {
        my $qv = my $qt = $this->queue_table;
        $qv =~ s/(?<=\.)/AQ\$/;

        return <<"END_SELECT";
(
select qt.*, qv.consumer_name
from $qt qt join $qv qv on qt.msgid = qv.msg_id
)
END_SELECT

    }
    return $this->queue_table;
}

sub new {
    my ( $package, $queue, $message_class, $fields ) = @_;

    $fields ||= {};
    $queue or die "No queue supplied\n ";

    require_package($message_class);

    my ( $owner, $queue_name ) = $queue =~ /(.*?)\.(.*)/
        or die "Queue name must be qualified, $queue isnot\n ";

    # queue object
    my ($queue_o) = $package->queue_class->retrieve_by_qname_or_die($queue)
        or die "No queue $queue found\n";

    # qualified name of the payload type, sort_order from queue_table 
    my ($payload_type, $sort_order) = $package->db_Main->selectrow_array(
        <<'END_SELECT', undef,
        SELECT object_type, sort_order
        FROM sys.all_queue_tables 
        WHERE owner = ? AND queue_table = ?
END_SELECT
        $owner, $queue_o->queue_table
    );

    # passing the connection method to message class
    my $controller = $package->SUPER::new(
        {   'listen_timeout'     => 2,
            'stop_timeout'       => 20,
            'exit_when_timeout'  => 1,
            'dequeue_navigation' => 'NEXT_MESSAGE',
            %{$fields},
            'message_class'    => $package->dbize($message_class),
            'queue_name'       => $queue_o->name,
            'queue_owner'      => $owner,
            'queue_type'       => $queue_o->queue_type,
            'queue_table_name' => $queue_o->queue_table,
            'queue_table'      => join( '.', $owner, $queue_o->queue_table ),
            'qid'              => $queue_o->qid,
            'queue'            => $queue,
            'payload_type'     => $payload_type,
            'sort_order'       => $sort_order,
        }
    );

    $controller->_clean_dead_daemon;    
    return $controller;
}

sub is_exception_queue {
    my ($this) = @_;

    return $this->queue_type eq 'EXCEPTION_QUEUE';
}

sub auto_start {
    return shift()->retrieve_aq_queue->auto_start;
}

sub set_auto_start {
    my ( $this, $new_value ) = @_;
    my $aq_queue = $this->retrieve_aq_queue;
    $aq_queue->auto_start($new_value);
    $aq_queue->update;
}

sub dequeue_enabled {
    return shift()->retrieve_queue->dequeue_enabled;
}

sub enqueue_enabled {
    return shift()->retrieve_queue->enqueue_enabled;
}

sub list_messages {
    my ( $this, $selection, $options ) = @_;

    $options ||= {};
    my ( $displays_empty_list, $extended_view ) = @{$options}{qw(displays_empty_list extended_view)};

    my $multi_consumer = $this->multi_consumer;
    my $message_class = $this->message_class;
    my $header = 
        sprintf( "Messages in queue %s (%s)\n\n",
            $this->queue, $this->queue_type )
            . sprintf(
            "%-32s"
                . ( $multi_consumer ? ' %-16s ' : ' ' )
                . "%2s %3s %20s %s\n",
            'Msgid', ( $multi_consumer ? 'Consumer' : () ),
            'St', 'Pri', 'Delay', $message_class->list_headers($extended_view)
            );
    my $header_displayed;

    # displays_empty_list - list messages even if there is no message
    if ($displays_empty_list) {
        print $header;
        $header_displayed = 1;
    }

    my @field_names = $message_class->payload_fields;
    my $payload_fields_sql = join(
        ', ',
        map {
            my $field_value;
            if ($this->message_class->payload_field_properties->{$_}{'type'}) {
                if ($this->message_class->payload_field_properties->{$_}{'type'} eq 'XML') {
                    $field_value = $_ . '.getClobVal() AS ' . $_;
                }
                else {
                    die "Not valid type '$_' for payload field!";
                }
            }
            else {
                $field_value = $_;
            }

            'qt.user_data. ' . $field_value;
        } @field_names
    );

    # sort order is ENQUEUE_TIME but there is enq_time in queue table
    my $order_by    = $this->sort_order;
    $order_by       =~ s/ENQUEUE_TIME/enq_time/g;

	my $consumer_sql = $multi_consumer? "qt.consumer_name": "null as consumer_name";
    my $sth         = $this->db_Main->prepare(<<"END_SELECT");
        SELECT 
            qt.msgid, 
            qt.state, 
            qt.priority,
            TO_CHAR(qt.delay, 'YYYY-MM-DD HH24:MI:SS') delay,
			$consumer_sql,
            $payload_fields_sql
        FROM 
            $E{ $this->ext_queue_table } qt 
        WHERE 
            q_name = $sqlp{$this->queue_name}
            AND $E{ $message_class->selection_sql($selection) }
        ORDER BY 
            $order_by
END_SELECT
    $sth->execute;

    my $listed = 0;
    while ( my ( $msgid, $state, $priority, $delay, $consumer_name, @fields ) = $sth->fetchrow_array ) {
        my $message = $message_class->new( { zip @field_names, @fields } );

        # header is displayed before first message
        if ( !$header_displayed ) {
            print $header;
            $header_displayed = 1;
        }
        printf "%-32s". ($multi_consumer? ' %-16s ': ' ') ."%2s %3s %20s %s\n", 
            defined($msgid) ? $msgid : '-',
            ($multi_consumer? 
                (defined($consumer_name) ? $consumer_name : '-'): ()),
            defined($state) ? $state : '-', 
            defined($priority) ? $priority : '-', 
            defined($delay) ? $delay : '-',
            $message->list_payload($extended_view)
        ;
        $listed++;
    }

    if ($header_displayed) {
        print "\n$listed message(s) listed\n";
    }
}

# starts the queue
sub start_queue {
    my ( $this, $enqueue, $dequeue ) = @_;

    $enqueue = $this->is_exception_queue ? 0 : 1 if !defined $enqueue;
    $dequeue = 1 if !defined $dequeue;
    $this->db_Main->do(<<"END_PSQL");
        BEGIN
            sys.dbms_aqadm.start_queue(
                $sqlp{$this->queue}, 
                $E{ $enqueue? 'true': 'false'}, 
                $E{ $dequeue? 'true': 'false'} 
            );
        END;
END_PSQL
}

sub stop_queue {
    my ($this, $enqueue, $dequeue) = @_;

    $enqueue = $this->is_exception_queue ? 0 : 1 if !defined $enqueue;
    $dequeue = 1 if !defined $dequeue;
    $this->db_Main->do(<<"END_PSQL");
        BEGIN
            sys.dbms_aqadm.stop_queue(
                $sqlp{$this->queue}, 
                $E{ $enqueue? 'true': 'false'}, 
                $E{ $dequeue? 'true': 'false'} 
            );
        END;
END_PSQL
}

# clones current queue (uses its parameters)
sub clone_queue {
    my ( $this, $new_queue, $queue_params ) = @_;

    my $current_queue = $this->retrieve_queue;
    my $max_retries
        = first_value { defined($_) } $queue_params->{'max_retries'},
        $current_queue->max_retries;
    my $retry_delay
        = first_value { defined($_) } $queue_params->{'retry_delay'},
        $current_queue->retry_delay;
    $this->db_Main->do(<<"END_PSQL");
        DECLARE
        BEGIN
            sys.dbms_aqadm.create_queue(
                queue_name  => $sqlp{ $new_queue },
                queue_table => $sqlp{ $this->queue_table },
                max_retries => $sqlp{ $max_retries },
                retry_delay => $sqlp{ $retry_delay }
            );
        END;
END_PSQL
}

sub drop_queue {
    my ($this) = @_;

    my $queue = $this->retrieve_queue;
    die "Queue has to be stopped first before drop\n "
        if $queue->dequeue_enabled;

    my $message_count = $this->message_count;
    die "Queue has to be emptied before drop\n "
        if $message_count && grep {$_} values %{$message_count};

    $this->db_Main->do(<<"END_PSQL");
        DECLARE
        BEGIN
            sys.dbms_aqadm.drop_queue(
                queue_name  => $sqlp{$this->queue}
            );
        END;
END_PSQL
}

sub move_messages {
    my ( $this, $selection, $target_queue, $options ) = @_;

    $this->retrieve_queue->dequeue_enabled
        or die <<"END_ERROR";
Queue $E{ $this->queue } is not started for dequeue, 
no messages can be moved from it.
END_ERROR

    my $target_queue_decl;
    my $target_queue_psql;
    if ($target_queue) {
        # target_queue must be qualified name
        if ( $target_queue !~ /\./ ) {
            $target_queue = $this->queue_owner . '.' . $target_queue;
        }
        $target_queue_psql = sql_param($target_queue);
    }
    else {

        # $this->message_class->target_queue_sql returns
        #   either (decl, expression)
        #   or    (expression)
        ( $target_queue_psql, $target_queue_decl )
            = reverse $this->message_class->target_queue_sql(
            $this,
            {   'payload'            => 'l_payload',
                'message_properties' => 'l_message_properties',
                'msgid'              => 'l_msgid',
            }
            );
    }
    
    # something can be done when the message is moved from queue to queue
    # EXPERIMENTAL
    my $on_move_psql = $this->message_class->on_move_psql(
        $this,
        {   'payload'            => 'l_payload',
            'message_properties' => 'l_message_properties',
            'msgid'              => 'l_msgid',
        }
    );
    if (!defined $on_move_psql){
        $on_move_psql = '';
    }

    my $mc_dequeue = '';
    my $mc_enqueue = '';
    if ( $this->multi_consumer ) {
        $mc_dequeue = <<'END_MC_DEQUEUE';
        l_dequeue_options.consumer_name := l_msgid_selection.consumer_name;
END_MC_DEQUEUE

        $mc_enqueue = <<'END_MC_ENQUEUE';
        l_message_properties.recipient_list(0) := sys.aq$_agent(l_msgid_selection.consumer_name, null, 0);
END_MC_ENQUEUE

    }

    my $body_psql = sql(<<"END_PSQL");
        -- dequeue part
        l_dequeue_options.msgid := l_msgid_selection.msgid;
        l_dequeue_options.wait  := sys.dbms_aq.NO_WAIT;
        $mc_dequeue

        sys.dbms_aq.dequeue(
            queue_name  => $sqlp{ $this->queue },
            payload     => l_payload,
            message_properties => l_message_properties,
            dequeue_options    => l_dequeue_options,
            msgid              => l_msgid); 

        -- modification_part
        l_target_queue := $target_queue_psql;
        if l_enqueued_into.EXISTS(l_target_queue) then  
            l_enqueued_into(l_target_queue) := l_enqueued_into(l_target_queue) + 1;
        else
            l_enqueued_into(l_target_queue) := 1;
        end if;

        -- 2008-03-25 danielr
        -- I cannot leave delay as it is or the messages would be shifted
        -- to future
        -- if delay is NOT dbms_aq.NO_WAIT then it is set
        -- to remaining number of seconds to the desired dequeue time
        -- If this time already expired then delay is set to dbms_aq.NO_WAIT
        l_delay  := l_message_properties.delay;
        if not((sys.dbms_aq.NO_WAIT is null and l_delay is null)
           or l_delay = sys.dbms_aq.NO_WAIT)
        then
            l_delay := l_delay - round(86400 * (sysdate - l_message_properties.enqueue_time));
            if l_delay <= 0 then
                l_delay := sys.dbms_aq.NO_WAIT;
            end if;
            l_message_properties.delay := l_delay;
        end if;

        -- something may be done when the message is moved from queue to queue
        $on_move_psql

        $mc_enqueue

        -- enqueue part
        sys.dbms_aq.enqueue(
            queue_name  => l_target_queue,
            enqueue_options => l_enqueue_options,
            message_properties => l_message_properties,
            payload            => l_payload,
            msgid              => l_msgid); 
END_PSQL

    my $where_psql = sql_and( "q_name = $sqlp{$this->queue_name}",
        $this->message_class->selection_sql($selection) );

    my $dequeued;
    my $enqueued_into_str;
    my $the_columns = join ', ', map {"qt.$_"} 'msgid',
        $this->multi_consumer ? 'consumer_name' : ();
    my $moving_psql = sql(<<"END_PSQL");
        DECLARE
            -- target distribution mapping queue => messages_moved
            TYPE enqueued_into_type IS TABLE OF NUMBER INDEX BY VARCHAR2(64);
            l_queue                 varchar2(64);
            l_enqueued_into         enqueued_into_type;
            l_enqueued_into_str     varchar2(2048);
            l_message_properties    sys.dbms_aq.message_properties_t;
            l_dequeue_options       sys.dbms_aq.dequeue_options_t;
            l_dequeued              number default 0;
            l_enqueue_options       sys.dbms_aq.enqueue_options_t;
            l_payload $E{ $this->payload_type };
            l_target_queue varchar2(256);
            l_msgid raw(128); 
            l_delay binary_integer; -- sys.dbms_aq.message_properties_t.delay%TYPE;
            $E{ $target_queue_decl || '-- no target_queue_psql declaration' }
        BEGIN
            for l_msgid_selection in (
                SELECT $the_columns
                FROM $E{ $this->ext_queue_table } qt 
                WHERE $where_psql
            )
            LOOP    
                $body_psql
                l_dequeued := l_dequeued + 1;
            END LOOP;
            $E{ sql_param_inout( \$dequeued, 20 ) } := l_dequeued;

            -- passing the distribution back to Perl
            l_queue := l_enqueued_into.FIRST;
            l_enqueued_into_str := '';
            loop 
                exit when l_queue is null;
                l_enqueued_into_str := l_queue || ':' || l_enqueued_into(l_queue) || ':';
                l_queue := l_enqueued_into.NEXT(l_queue);
            end loop;
            $E{ sql_param_inout(\$enqueued_into_str, 2050) } := l_enqueued_into_str; 
        END;
END_PSQL
    $this->txn_do(
        sub {
            $this->db_Main->do($moving_psql);
        }
    );

    warn "$dequeued message(s) moved from " . $this->queue . "\n";
    if ($enqueued_into_str) {
        my %enqueued_into = $enqueued_into_str =~ m{(.*?):}g;
        for my $queue ( keys %enqueued_into ) {
            warn sprintf "  %s enqueued into %s\n", $enqueued_into{$queue},
                $queue;
        }
    }
}

sub remove_messages {
    my ( $this, $selection, $options ) = @_;

    $this->retrieve_queue->dequeue_enabled
        or die <<"END_ERROR";
Queue $E{ $this->queue } is not started for dequeue, 
no messages can be removed from it.
END_ERROR

    my $mc_dequeue
        = $this->multi_consumer
        ? 'l_dequeue_options.consumer_name := l_msgid_selection.consumer_name;'
        : '';
    my $body_psql = sql(<<"END_PSQL");
        -- dequeue part
    	$mc_dequeue
        l_dequeue_options.msgid := l_msgid_selection.msgid;
        l_dequeue_options.wait  := sys.dbms_aq.NO_WAIT;
        $mc_dequeue
        sys.dbms_aq.dequeue(
            queue_name  => $sqlp{ $this->queue },
            payload     => l_payload,
            message_properties => l_message_properties,
            dequeue_options    => l_dequeue_options,
            msgid              => l_msgid); 
END_PSQL

    my $where_psql = sql_and( "q_name = $sqlp{$this->queue_name}",
        $this->message_class->selection_sql($selection) );

    my $dequeued;
    my $the_columns = join ', ', map {"qt.$_"} 'msgid',
        $this->multi_consumer ? "consumer_name" : ();
    my $moving_psql = sql(<<"END_PSQL");
        DECLARE
            l_queue                 varchar2(64);
            l_message_properties    sys.dbms_aq.message_properties_t;
            l_dequeue_options       sys.dbms_aq.dequeue_options_t;
            l_dequeued              number default 0;
            l_payload $E{ $this->payload_type };
            l_msgid raw(128); 
            l_delay binary_integer; -- sys.dbms_aq.message_properties_t.delay%TYPE;
        BEGIN
            for l_msgid_selection in (
                SELECT $the_columns
                FROM $E{ $this->ext_queue_table } qt 
                WHERE $where_psql
            )
            LOOP    
                $body_psql
                l_dequeued := l_dequeued + 1;
            END LOOP;
            $E{ sql_param_inout( \$dequeued, 20 ) } := l_dequeued;
        END;
END_PSQL
    $this->txn_do(
        sub {
            $this->db_Main->do($moving_psql);
        }
    );

    warn "$dequeued message(s) removed from " . $this->queue . "\n";
}

# enqueues stop message into control queue, 
# returns subroutine checking whether the daemon was stopped
sub stop_daemon {
    my ( $this, $waiter ) = @_;

    # enqueue stop into daemon queue
    my $daemon = $this->retrieve_daemon;
    if ( !$daemon ) {

        # no daemon
        #    warn "No daemon running on queue $E{ $this->queue }\n";
        return;
    }
    elsif ( $daemon->being_stopped ) {
        warn "Daemon on $E{$this->queue} is already being stopped\n";
        return;
    }

    warn "Stopping daemon on " . $this->queue . "\n";
    $this->txn_do(
        sub {
            $this->enqueue_dc_action_for( $daemon, 'stop' );
            $daemon->being_stopped( Akar::Time->new->text );
            $daemon->update;
        }
    );

    # daemon_id is remembered not the object
    my $daemon_id = $daemon && $daemon->id;
    $waiter ||= Akar::AQ::WaitUntil->new;
    $waiter->add(
        'check'      => sub { !$this->retrieve_daemon( 'id' => $daemon_id ) },
        'on_failure' => sub {
            die
                "Daemon on $E{ $this->queue } was sent stop but it is still running\n ";
        },
        'on_success' => sub {
            warn "Daemon on $E{ $this->queue } was stopped\n";
        }
    );
}

# starts daemon
sub start_daemon {
    my ( $this, $options ) = @_;

    $this->logpath or die "No logpath supplied\n";
    $options ||= {};

    # retrieves daemons already running on queue
    if ( my @daemons = $this->retrieve_daemon){
        die "There is already a daemon(s) (pid "
            . join( ', ', map { $_->pid } @daemons )
            . ') on queue '
            . $this->queue;
    }

    my $daemon;
    $this->txn_do(
        sub {
            $daemon = $this->daemon_class->create(
                {   'queue' => $this->queue,
                    'pid'   => -1,
                }
            );
        }
    );

    # disconnect before fork
    #$this->db_Main->disconnect;

    # copied from net::server::daemonize
    # i don't use net::server::daemonize directly
    # because there are no pid files and set_user needed.
    
    # parent doesn't reap the children
    $SIG{'CHLD'} = 'IGNORE';
    my $child_pid = fork();
    if ( $child_pid == 0 ) {
        # child should reap the children
        $SIG{'CHLD'} = '';
        # first of all I have to use another db_Main handle
        $this->db_Main->{'InactiveDestroy'} = 1;
       
        # this weird reconnect / disconnect 
        # old controller instances can reconnect
        # the new ones (based on DBIx::Class::Storage)
        # can disconnect only, but the reconnect is accomplished
        # by following txn_do
        #
        # 2009-07-09 danielr
        # bitter experience (2 hours burned)
        # I have to use UNIVERSAL::can because DBI::db can
        # is redefined and returns false even when dbh can reconnect
        my $method = $this->db_Main->UNIVERSAL::can('reconnect')? 'reconnect': 'disconnect';
        $this->db_Main->$method;

        # 2008-03-11 danielr I change my name so I will be easily identified
        $0 = basename($0) . ' on ' . $this->queue;

        
        ### child process will continue on
        ### close all input/output and separate
        ### from the parent process group

        # demonizuji se a presmeruji svuj vystup do logu
        $this->redirect_daemon_output($this->logpath);
        local $SIG{__WARN__} = sub {
            warn sprintf( '%s [%s] - ', Akar::Time->new->text, $$ ), @_;
        };

        $this->txn_do(
            sub {

                # creates the daemon - must be done AFTER fork
                my $usessionid
                    = $this->db_Main->selectrow_array(<<"END_SELECT");
            SELECT DBMS_SESSION.UNIQUE_SESSION_ID
            FROM dual
END_SELECT

                $daemon->usessionid($usessionid);
                $daemon->started( Akar::Time->new->text );
                $daemon->pid($$);
                $daemon->update;
            }
        );

        ### change to root dir to avoid locking a mounted file system
        ### does this mean to be chroot ?
        chdir '/' or die "can't chdir to \"/\": $!\n ";

        ### turn process into session leader, and ensure no controlling terminal
        POSIX::setsid();

        warn "START$E{ $options->{'testrun'}? ' (testrun)': ''}\n";
        my $exit_reason = eval { 
            $this->daemon_loop( $daemon );
        };
        if ($@){
            $exit_reason = 'ERROR: '. $@;
        }
        warn "END ($exit_reason)\n";

        $this->txn_do(
            sub {
                $daemon->delete;
                if ( my $on_end = $options->{'on_end'} ) {
                    $on_end->();
                }
            }
        );
        exit(0);
    }
    else {
        my $daemon_id = $daemon->id;

        # parent is waiting until daemon either disappear or its pid is son's pid
        my $waiter = Akar::AQ::WaitUntil->new;
        $waiter->add(
            'check' => sub {
                my $daemon = $this->daemon_class->retrieve($daemon_id);
                return !$daemon || $daemon->pid == $child_pid;
            },
        );
    }

    return;
}

# listen_sub returns subroutine because it has to store statement handle
sub prepare_listen {
    my ( $this, $daemon ) = @_;

    #my $listen_timeout =
    #    $this->exit_when_timeout
    #    ? sql('sys.dbms_aq.NO_WAIT')
    #    : sql_param( $this->listen_timeout );
    my $listen_timeout =
        defined( $this->listen_timeout )
        ? sql_param( $this->listen_timeout )
        : sql('sys.dbms_aq.NO_WAIT');

    my $agent_name = $daemon->agent_name;
    my $dc_queue = $this->DC_QUEUE;
    my $queue_selected;
    my $listen_psql = sql(<<"END_PSQL");
        DECLARE 
            l_agent_list sys.dbms_aq.aq\$_agent_list_t;
            l_agent_selected sys.aq\$_agent;
        BEGIN 
            -- daemon control queue
            l_agent_list(0) := sys.aq\$_agent( 
                $E{ $agent_name? sql_param($agent_name): 'null' },
                $sqlp{ $dc_queue }, 
                null);
            -- ordinary queue
            l_agent_list(1) := sys.aq\$_agent(
                null, 
                $sqlp{$this->queue}, 
                null);
            sys.dbms_aq.listen(
                agent_list => l_agent_list,
                wait       => $listen_timeout,
                agent      => l_agent_selected); 
            $E{ sql_param_inout(\$queue_selected, 128) } := l_agent_selected.address; 
        END;
END_PSQL

    my $sth = $this->db_Main->prepare($listen_psql);

    # this procedure calls listen and returns 1 if dc_queue was selected
    return sub {
        $sth->execute;

        # there is something strange with Oracle
        $queue_selected =~ s/"//g;
        return uc($queue_selected) eq uc( $dc_queue );
    };
}

# where all module outputs are stored
sub app_data_dir {
    my ($this) = @_;
    
    my $basename = join '-', split /::/, (ref($this) || $this);
    return Akar::Base->app_data($basename);
}

# where the log is stored
sub daemon_logfile {
    my ($this) = @_;

    my $basename = join '.', grep {$_} 'daemon', $this->queue_name, 'log';
    return File::Spec->catfile( $this->app_data_dir, $basename );
}

# returns hash STATE => COUNT
sub message_count {
    my ($this) = @_;

    my $sth = $this->db_Main->prepare(<<"END_SQL");
        SELECT state, count(*) 
        FROM $E{ $this->queue_table }
        WHERE q_name = ? 
        GROUP BY state
END_SQL
    my %msgs_dist;
    $sth->execute( $this->queue_name );
    while ( my ( $state, $msgs ) = $sth->fetchrow_array ) {
        $msgs_dist{$state} = $msgs;
    }
    return \%msgs_dist;
}

sub prepare_dequeue {
    my ( $this, $options ) = @_;

    $options ||= {};

    # decomposing object the variable into params
    my (%message, %message_properties, $msgid);
    my $decompose_psql = sql_join(
        '',
        map {
            my $size = $this->message_class->payload_field_properties->{$_}{'size'} || 128;

            my $field_value;
            if ($this->message_class->payload_field_properties->{$_}{'type'}) {
                if ($this->message_class->payload_field_properties->{$_}{'type'} eq 'XML') {
                    $field_value = $_ . '.getClobVal()';
                }
                else {
                    die "Not valid type '$_' for payload field!";
                }
            }
            else {
                $field_value = $_;
            }

            sql( sql_param_inout( \$message{$_}, $size ) . ":= l_payload.$field_value;\n" );
        } $this->message_class->payload_fields
    );

    # message properties are so far only attempts
    my $decompose_message_properties_psql = sql_join '', map {
        my $param = sql_param_inout( \$message_properties{$_}, 128 );
        sql("$param := l_message_properties.$_;\n");
    } qw(attempts);

    my $sql = sql(<<"END_PSQL");
        DECLARE
            l_message_properties    sys.dbms_aq.message_properties_t;
            l_dequeue_options       sys.dbms_aq.dequeue_options_t;
            l_payload               $E{ $this->payload_type };
            l_target_queue varchar2(256);
            l_msgid raw(128); 
            l_delay binary_integer; 
        BEGIN
            l_dequeue_options.wait          := $sqlp{ $options->{'dequeue_timeout'} || 1};
            l_dequeue_options.navigation    := sys.dbms_aq.$E{ $this->dequeue_navigation };
            l_dequeue_options.dequeue_mode  := sys.dbms_aq.REMOVE;
            sys.dbms_aq.dequeue(
                queue_name  => $sqlp{ $this->queue },
                payload     => l_payload,
                message_properties => l_message_properties,
                dequeue_options    => l_dequeue_options,
                msgid              => $E{ sql_param_inout(\$msgid, 128) }
            ); 
            $decompose_psql
            $decompose_message_properties_psql
        END;
END_PSQL
    my $sth = $this->db_Main->prepare($sql);
    return sub {
        $sth->execute;
        my $message_obj = $this->message_class->new( \%message );
        return wantarray
            ? ( $message_obj, \%message_properties, $msgid )
            : $message_obj;
    };
}

# daemon_loop - returns the string with the reason of exit
sub daemon_loop {
    my ($this, $daemon) = @_;

    # loop
    $this->set_dequeued(0);
    $this->set_errors(0);

    my $listen_sth     = $this->prepare_listen($daemon);
    my $dequeue_sth    = $this->prepare_dequeue;
    my $timeouts       = 0; # number of timeout in a row occured so far
DAEMON_LOOP:
    while (1) {
        my $dc_queue_selected = eval {

# 2004-08-16 daniel - locally disabled PrintError causes empty sth->err in case of error
# bug? misunderstanding?
# local $$sth{'PrintError'} = 0;
            local $SIG{__WARN__} = sub { };
            $listen_sth->();
        };
        if ( my $error = $@ ) {
            if ( $this->dbh_err($error) == LISTEN_TIMEOUT_ERRNO ) {
                $timeouts++;
                return "timeout no. $timeouts"
                    if $this->exit_when_timeout
                    && $timeouts >= $this->exit_when_timeout;
                next DAEMON_LOOP;
            }
            else {

                # Internal error
                die $error;
            }
        }

        # timeout counter can be reset
        $timeouts = 0;

        # dequeueing daemon control data
        if ($dc_queue_selected) {
            my $dc_message;
            $this->txn_do( sub { $dc_message = $this->dequeue_dc($daemon); }
            );

            # daemon control - the only reaction is stopped
            return $dc_message->action . ' from queue';
        }

        # dequeueing data
        my ($message, $message_properties, $msgid);
        eval {
            $this->txn_do(
                sub {
                    ( $message, $message_properties, $msgid ) = $dequeue_sth->(); 

                    my $attempts = $message_properties->{'attempts'};
                    my $msg = $message->list_payload
                        . ( $attempts ? ", retry " . $attempts : '' ) ;
                    warn "Dequeued $msg\n";

                    $this->set_dequeued($this->dequeued + 1);

                    # here is the message handling
                    my @started = gettimeofday;
                    $this->handle_message( $message, $message_properties, $msgid );
                    my $elapsed = tv_interval(\@started);
                    warn sprintf "finished %s, took %fs (%.3f/s)\n",
                        $msg, $elapsed, 1/$elapsed;
                }
            );
        };

        if ( my $error = $@ ) {
            # dequeue error
            if (!$message){
                # timeout is ignored, other error propagated
                next DAEMON_LOOP
                    if $this->dbh_err($error) == DEQUEUE_TIMEOUT_ERRNO;
                die $error;
            }
            # application error
            $this->handle_message_error($error, $message, $message_properties, $msgid);
        }
       
        if ( defined $this->stop_after && $this->dequeued >= $this->stop_after ) {
            return 'Stopped stop_after='. $this->stop_after;
        }
    }    # DAEMON_LOOP
}

sub handle_message {
    my ( $this, $message, $message_properties, $msgid ) = @_;

    $message->handle($message_properties, $msgid);
}

sub handle_message_error {
    my ( $this, $error, $message, $message_properties, $msgid ) = @_;
    warn "Error $error\n ";

    # the rollback here is necessary for AQ
    $message->handle_error( $error, $message_properties, $msgid );
}

sub _clean_dead_daemon {
    my ($this) = @_;

    my $daemon = $this->retrieve_daemon;
    return if !$daemon || $daemon->is_alive;

    warn "Daemon $E{ $daemon->queue } seems dead\n ";
    $this->txn_do(
        sub {
            $daemon->delete;
        }
    );
}

# 1 if there can be 
sub can_be_listened {
    my ($this) = @_;

    return !$this->is_exception_queue                # normal_queue
        && $this->retrieve_queue->dequeue_enabled    # started queue
        && !$this->retrieve_daemon                   # no daemon
        && $this->auto_start;                        # auto start must be set
}

# returns the queue object
sub retrieve_queue {
    my ($this) = @_;

    return $this->queue_class->retrieve_by_qname_or_die( $this->queue );
}

# returns the AqQueue object, if there is no record in aq_queue, the record is created
sub retrieve_aq_queue {
    my ($this) = @_;

    my $class = $this->dbize('Akar::AQ::_AqQueue');
    return $class->retrieve( $this->queue )
        || $class->create( { 'queue' => $this->queue } );
}

sub retrieve_daemon {
    my ( $this, @condition ) = @_;

    my @daemons = $this->daemon_class->search(
        @condition ? @condition : ('queue' => $this->queue) );

    return wantarray ? @daemons : $daemons[0];
}

# starts the queue, starts daemon, let him process some messages and again stop the queue
sub testrun {
    my ($this, $config) = @_;

    die "For testrun the queue $E{ $this->queue} must have auto_start reset.\n"
        if $this->auto_start;
    die "The queue $E{ $this->queue } is disabled from dequeue.\n"
        if !$this->dequeue_enabled;

    # when testrun - listener timeout is 1 sec only
    $this->set_listen_timeout(1);
    if ($config) {
        while ( my ( $param, $value ) = each %{$config} ) {
            my $method = 'set_' . $param;
            $this->$method($value);
        }
    }
    $this->start_daemon( { 'testrun' => 1 } );
}

1;

__END__

=head1 NAME

Akar::AQ::Controller - managing and running one queueu 

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: shiftwidth=4:tabstop=4:softtabstop=0:
