package Akar::Script;
{
  $Akar::Script::VERSION = '1.994';
}

# $Id: Script.pm,v 1.4 2006/05/16 09:44:02 danielr Exp $

=head1 NAME

Akar::Script - the ancestor of unified scripts

=head1 SYNOPSIS

  package MyScript;

  use base qw(Akar::Script);
  sub options {
    my $this = shift;
           return($this->SUPER::options, qw(id=s nocache|nc));
  }

  sub check_options {
    my $this = shift;
    $this->optref->{'id'}
    or die "--id is mandatory option\n ";
  }

  sub actions {
           return(qw(list show install));
  }

  sub do_list {
    my $this = shift;
    ....
  }

  sub do_show {
    my $this = shift;
    ...
  }

  sub do_install {
    my $this = shift;
    ...
  }

  sub body {
      my $this = shift;
      $this->do_actions();
  }

  # calling "script"
  use MyScript;
  MyScript->run(@ARGV);

=head1 DESCRIPTION

The idea behind Akar::Script is to put all our Perl code into modules 
and use only minimal, generated scripts with identical structure.

  PACKAGE->run(@ARGV);

The reasons are

=over 4

=item 

modules (packages) are inheritable

=item  

modules have "naturally" hierarchical names, 
so they are easy to organized

=item 

methods can be easily called within one invocation of Perl

=back

Akar::Script handles:

=over 4

=item options processing

Getopt::Long is used for options processing, option specifiers
are defined by options method.

=item command line scripts help 

It is supposed that each script has C<--help> option. If this option
is provided from command line, script writes to standart output
something like this

  Script OPTIONS
  Title

  Description

Script is the name of the script, title and description are 
by default extracted from module's POD.

=back

=head2 Scriptmodule

Scriptmodule is just a common name I will use for the modules inherited 
from Akar::Script.

=head1 METHODS

=head2 Method defining script

=over 4

=item run

  my $exit_code = Balik->run(@ARGV);
  Balik->run({opt},@ARGV);

  # or 
  my($exit_code, $message) = Balik->run(@ARGV);

Runs the scriptmodule. Its parameters are unparsed command line options.
As first parameter it accepts the hash with options already preparsed.

=back

=head2 Methods to be redefined in inherited modules

=over 4

=item body

The executive part of the script (module) called after the options and actions
 are parsed and checked. It is necessary to redefine (define) it.

With actions defined you can use:

  sub body {
    my $this = shift;
    $this->do_actions();
  }

In this case do_actions calls $this->do_$ACTION for every action supplied.

=item options

  $this->options

Returns the list of option specifiers for Getopt::Long::GetOptions.

  sub options {
    my $this = shift;
    return($this->SUPER::options, qw(action|a=s nocache|nc));
  } 

  # recognizes options 
  # --nocache -nc --action=start

=item actions

  sub actions {
      return(qw(list install));
  }

Returns the list of acceptable actions.
Actions are command line arguments which are neither options nor option arguments.

=item check_options 

  sub check_options {
    my $this = shift;
    $this->SUPER::check_options(@_); # handles --help

    $this->opt('id') 
    or die "--id is mandatory option\n ";
  }

Method checks parsed options. Should call $this->SUPER::check_options(@_)
at the beginning.

=item check_actions

  sub check_actions {
    my $this = shift;

    $this->SUPER::check_actions(@_);
    if (grep {$_ eq 'start'} $this->argv){
        for($this->argv){
            $_ eq 'start' 
            or die "Action start cannot be combined with $_\n ";
        }
    }
  }

Checks parsed actions. 

=back

=head2 Methods to be used inside body 

=over 4

=item app_home

  my $xsl = $this->app_home('lib/xslt/Akar/Base.xsl');

Without parameters returns the home directory of scriptmodule. 
Parameter is considered as relative path to the home directory 
and resulting absolute path is returned.

=item app_data

Similar for data directory of scriptmodule. 

=item app_config

Similar for configuration directory of scriptmodule. 

  my $log = $this->app_data('log/errors.log');
  my $cfg = $this->app_config('mainconfig.log');

=item opt 

 if ($this->opt('nocache')){
    ...
 }

Returns the value of option supplied.

=item is_permitted

  $this->is_permitted($opt)

Returns true if the option is one of those defined by PACKAGE->options, 
otherwise false.

=item argv

  local @ARGV = $this->argv();

In list context, returns the array of non-option arguments (actions) 
from command line. In scalar context returns the array reference of 
the same.

=back

=head2 Other methods

These methods are unlikely to be redefined or used in user's scriptmodules.

=over 4

=item instantiate

    my $x = Class->instantiate('--op','12','--phone','23393');

Creates an scriptmodule instance as run, but returns it instead of calling body method.
Rarely used.

=item script

=item title

=item desc

Defines name, title and description of the script. Scriptmodule commented 
in POD doesn't need to take care of these.

=item new

  my $script = MyScript->new;

Constructor.

=item parse_options

  $this->parse_options(@volby); 

Process options by specifiers returned by options method. 
The result is accessible via method optref.

=item parse_arguments

  $this->parse_arguments( @what_left_from_option_processing );

Parses what left after option processing. By default only saves
the arguments.

=item prolog

  $this->prolog

The prologue of processing. It also prints the header of script.

=item epilog

  $this->epilog

The epilogue of processing. Also prints the time of processing.

=back

=cut 

use strict;

use base qw(Akar::Base Class::Data::Inheritable Class::Accessor);

use Getopt::Long;
use File::Basename qw(basename dirname);
use File::Spec::Functions qw(catfile rel2abs);

use Akar::Time;
use Akar::Verbose qw(gverbose);

__PACKAGE__->mk_accessors(
    'start_time', 'end_time', 'duration',
    'preparsed',
    # (package properties) 
    #'properties' => [
        #'header_footer', # should header and footer to be displayed?
    #],
    # list of options permitted
    'permitted',
    # options supplied - save in field opt accessed as optref 
    # inconsistent because of legacy
    'optref',
    # actions supplied 
    'argv',
    # exception from call of body
    'died_with');

# whether header or footer should be displayed
__PACKAGE__->mk_classdata('header_footer'); 
# where to find POD documentation
# if undefined then the module is searched
__PACKAGE__->mk_classdata('pod_file');
__PACKAGE__->header_footer(1);

# both vars are package variables, so I can localize them
our $Level = 0;
our @Script; # stack of scripts

# identity if called as object method, otherwise returns a script with level 0
sub this_or_root {
    my $this = shift;

    ref($this) && $this
    or $Script[0] or die "No instance of Akar::Script available\n ";
}

sub options {
    qw(help verbose+ quiet+ akar-die-as-confess);
}

sub actions { () }

my $script;
sub script_pathname { $script ||= rel2abs($0) }

sub script { basename(shift(@_)->script_pathname) } 

sub title {
    my $this = shift; 

    my $str = $this->podsec_text('NAME');
    $str =~ s/^\s*NAME\s*\S+\s*(?:-\s*)?//si;
    $str =~ s/[\n\s]+/ /sgi;
    $str =~ s/\s*$//si;
    $str;
}

sub desc { shift(@_)->podsec_text('VOLBY') }

sub desc_en { shift(@_)->podsec_text('OPTIONS') }

sub run {
    local $Level = $Level + 1;

    # If have to create instance first
    my $this = ref($_[0])? shift : shift->new;
    local @Script = (@Script, $this);

    # first param could be preparsed options
    $this->preparsed(shift) if @_ and UNIVERSAL::isa($_[0], 'HASH');

    my @args = $this->parse_options(@_);
    eval {
        $this->parse_arguments(@args); 
        $this->check_options($this->optref);
        if ($this->actions){
            # 2004-12-08 danielr
            # if actions are permitted then check_options_$action 
            # is called for every action
            my @actions = @{$this->argv};
            push @actions, ($this->actions)[0] unless @actions;
            for my $action (@actions){
                my $check_sub = UNIVERSAL::can($this, "check_options_$action");
                $this->$check_sub($this->optref) if $check_sub;
            }
            $this->check_actions($this->optref, $this->argv());
        }
    };
    if($@){
        # OK is used by --help handling
        return(0) if $@ =~ /^OK\s/;
        die $@;
    }

    # setting of global verbosity if any of the options --verbose or --quiet
    # is used
    local $Akar::Verbose::Verbosity = $Akar::Verbose::Verbosity;
    my $optref    = $this->optref;
    my $verbosity = defined($$this{'verbose'})?  
            $$this{'verbose'}: # legacy
        ($$optref{'verbose'} || $$optref{'quiet'}) ? 
            1 + ($$optref{'verbose'} || 0) - ($$optref{'quiet'} || 0)
        : undef;
    $Akar::Verbose::Verbosity = $verbosity if defined($verbosity);

    # special Akar option
    local $SIG{'__DIE__'} = $SIG{'__DIE__'};
    if ($this->optref->{'akar-die-as-confess'}){
        require Carp;
        $SIG{'__DIE__'} = \&Carp::confess;
    } 
    $this->prolog;
    
    my @ret = eval { $this->body_dispatch(); };
    $this->died_with($@);
    $this->epilog;

    die $this->died_with if $this->died_with;
    
    # in list context run returns what body returned
    # in scalar context returns first element 
    # or 1 if body returned empty list
    wantarray? @ret: @ret? $ret[0]: 1;
}

sub new {
    my $class = shift;

    bless {
        'opt'  => {},
        'argv' => [],
        # permitted options
        'permitted' => {
            map  { (not(ref($_)) && /([-a-z0-9_]+)/i)
                ? ($1 => 1)
                : () 
            } $class->options
        },
    }, ref($class) || $class;
}

sub parse_options {
    my $this = shift;
    local @ARGV = @_;

    # 2004-07-28 as a legacy a duplicity is tolerated - for a while
    # used mainly when help is defined in derived class also
    my @_spec = $this->options;
    my(@spec, %spec);
    for(my $i=0; $i < @_spec; $i++){
        my $spec = $_spec[$i];

        # existing spec not followed by reference
        push @spec, $spec unless !ref($spec) and $spec{$spec} and !ref($_spec[$i+1]);
        $spec{$spec} = 1 unless ref($spec);
    }

    # Parsing 
    my %opt_parsed;
    my $script  = $this->script;
    Getopt::Long::Configure(qw(norequire_order auto_abbrev));
    GetOptions(\%opt_parsed, @spec)
    or die "Invalid options, try  $script --help\n ";

    my %opt = %{$this->preparsed || {}};
    # combining options with the preparsed ones (lower priority)
    while(my($k, $v) = each(%opt_parsed)){
        $opt{$k} = _combine_values($opt{$k}, $v);
    }
    $this->optref(\%opt);

    # returns rest of arguments
    return(@ARGV);
}

sub _combine_values {
    my($v1, $v2) = @_;
    if(!ref($v1) && !ref($v2)){
        return($v2);
    }
    elsif(UNIVERSAL::isa($v2, 'HASH')){
        return({%{$v1 || {}}, %$v2 });
    }
    elsif(UNIVERSAL::isa($v2, 'ARRAY')){
        return([@{$v1 || []}, @$v2 ]);
    }
    else {
        return($v2);
    }
}

sub parse_arguments {
    my $this = shift;
    $this->argv(\@_);
}

# handles the --help
sub check_options {
    my $this = shift;
    #my($optref) = @_;
    if ( $this->optref->{'help'} ){
        $this->print_help();
        die "OK HELP";
    }
}

# checks the action permitted
sub check_actions {
    my $this = shift;
    # my($optref, @actions_supplied) = @_;

    my @permitted = $this->actions();
    my %permitted = map {$_=>1} @permitted;
    my @unknown = grep {!$permitted{$_}} $this->argv;

    die sprintf("Unknown actions %s, permitted are %s\n ",
        join(', ', @unknown),
        join(', ', @permitted))
    if @unknown;
}

sub prolog {
    my $this = shift;
    # additional information about script, rarely used
    my($appendix) = @_;

    $this->start_time(Akar::Time->new);
    # with zero verbosity nothing is printed
    return unless gverbose(1) and $this->header_footer;

    my $script  = $this->script;
    my $title   = $this->title;
    my $package = ref($this) || $this;

    my $prolog  = _underline("$script ($package) - $title")."\n";
    if (gverbose(2)){
        # options print 
        $prolog .= "OPTIONS\n";
        $prolog .= "$_\n" for $this->reverse_options();
        $prolog .= "\n";
    }
    
    # start
    $prolog .= 'START: '. $this->start_time->text . "\n";
    $prolog .= 'PID: '. $$ . "\n\n";
    $prolog .= $appendix if $appendix;
    
    # indentation
    $prolog =~ s/^/[$Level]: /mg;
    print "\n", $prolog;
}

sub epilog {
    my $this      = shift;

    $this->end_time(Akar::Time->new);
    $this->duration($this->end_time->diff($this->start_time));
    return unless gverbose(1) and $this->header_footer;

    my $script  = $this->script;
    my $title   = $this->title;
    my $package = ref($this) || $this;

    # time processing
    my $d      = $this->duration;
    my $epilog = sprintf "END: %s (%02d:%02d:%02d)\n",
        $this->end_time->text,
        $d / 3600, ($d % 3600)/60, $d % 60;
    if (my $died_with = $this->died_with){
        $epilog  .= "ERROR: $died_with\n";
    }

    # indentation
    $epilog =~ s/^/[$Level]: /mg;
    print $epilog,"\n";
}

sub is_permitted {
    my $this = shift;
    my($opt) = @_;
    $this->permitted->{$opt};
}

sub opt {
    my $this    = shift;
    my($opt) = @_;

    my $value = $this->optref->{$opt};
    # if defined no check is performed
    if (!defined($value)){
        # kontroluje povolene volby
        $this->is_permitted($opt) 
        or die "No option '$opt' specified\n "; 
    }
    return($value);
}


sub argv {
    my $this = shift;
    not(@_) && wantarray
      ? @{$this->_argv_accessor}
      : $this->_argv_accessor(@_);
}

# returns the options supplied in printable form (can be used for recursive calling
# of other scriptmdules)
sub reverse_options {
    my $this = shift;

    my @ret;
    my @opt = @_? grep(exists( ${$this->optref}{$_}), @_): 
        keys(%{$this->optref}); 
    for my $opt ( @opt ){
        # k zadane existujici volbe hledam specifikator
        my @spec = grep( !(ref($_) || /<>/), $this->options );
        for my $spec ( @spec ){
            my $has_arg  = ($spec =~ s/[=:].*$//);
            my $has_plus = ($spec =~ s/\+$//);
            my $has_neg  = ($spec =~ s/^!//);
            $spec =~ /^$opt(?=[\|\+]|$)/ or next;

            my $val = $this->opt($opt);
            push @ret, 
                ($has_neg) ?  ($val? "--$opt":"--no$opt"):
                ($has_plus)?  map("--$opt", 1 .. $val):
                (!$has_arg)?   "--$opt":
                (!ref($val))?  "--$opt=$val":
                ("$val" =~ /ARRAY/)? map("--$opt=$_", @$val):
                ("$val" =~ /HASH/)?  
                    map("--$opt=$_=$$val{$_}", 
                    keys(%$val)):('NOT');
            last;
        }
    }
    @ret;
}

sub out {
    my $this = shift;
    my($min_level, @args) = @_;

    print @args, "\n" if gverbose($min_level);
}

sub outf {
    my $this = shift;
    my($min_level, $format, @args) = @_;

    printf($format. "\n", @args) if gverbose($min_level);
}


sub print_help {
    # texty voleb bere z PODu, 
    my $this   = shift;

    my $script = $this->script;
    my $title  = $this->title;

    my $options_text = 'VOLBY';
    my $desc   = $this->desc;
    if (!$desc){
        $desc = $this->desc_en;
        $options_text = 'OPTIONS';
    }

    my $package = ref($this) || $this;
    my $prolog  = _underline("$script ($package) - $title");

    print <<__HELP__;
$prolog 
$script $options_text

$title

$desc
__HELP__

}

sub podsec_text {
    my $this = shift;
    my($sec, $file) = @_;

    $file ||= $this->pod_file
      || do {
        my $class = ref($this) || $this;
        $class =~ s,::,/,g;
        $INC{"$class.pm"}; } 
      || $0 or die "podsec_text: Nelze najit soubor ";

    my $code = "/^=head1 ($sec)?.*/s; print if \$1...s///;";
    scalar(qx[perl -ne'$code' $file| perl -MPod::Text -e'pod2text("-")']);
}

sub _underline {
    my($str) = @_;

    "$str\n". ('-' x length($str)) . "\n";
}

sub body_dispatch {
    my $this = shift;
    return($this->body(@_));
}

sub do_actions {
    my $this = shift;
    
    my @supplied = @{$this->argv};
    # if no action is provided the first one 
    # specified by PACKAGE->actions is performed
    push @supplied, ($this->actions)[0] unless @supplied;
    
    # for every action $ACTION method $this->do_$ACTION is called
    for my $action (@supplied){
        my $method = "do_$action";
        $this->$method();
    }
}

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

1;

__END__

