package Akar::PL_SQL::Type::SQLObject;
{
  $Akar::PL_SQL::Type::SQLObject::VERSION = '1.994';
}
use strict;

use base qw(Akar::PL_SQL::Type::Base);
use Akar::PL_SQL::Caller::Functions qw(psql_record);

__PACKAGE__->mk_ro_accessors(qw(fields fields_order));

sub new_type {
    my ($proto, $params) = @_;

    my $fields = $$params{'fields'};

    # if fields is array then fields and fields_order are derived from it
    if (UNIVERSAL::isa($fields, 'ARRAY')) {
        $$params{'fields'} = {@$fields};
        $$params{'fields_order'} = [ @$fields[ grep(($_ % 2) == 0, 0 .. $#$fields) ] ];
    }
    $proto->SUPER::new_type($params);
}

sub dump_input_value {
    my ($this, $value) = @_;

    # dumps as record of same name and fields
    #$this->SUPER::dump_input_value($value);
    psql_record($this->name, $this->fields)->dump_value($value);
}

1;
