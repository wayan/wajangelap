package Akar::Catalyst::Controller::Dispatcher;
{
  $Akar::Catalyst::Controller::Dispatcher::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor::Grouped);

use Module::Find;
use List::MoreUtils qw(uniq);

# can keep controllers (for "subclasses" of model)
__PACKAGE__->mk_group_accessors(simple => 'dispatched_controller_for');

# the name of dispatched class
__PACKAGE__->mk_group_accessors(simple => 'dispatched_moniker');

__PACKAGE__->mk_group_accessors(inherited => '_dispatcher_options');

sub COMPONENT {
    my $class       = shift;
    my ($app_class) = @_;
    my $comp        = $class->next::method(@_);
    if ( my $options_ref = $class->_dispatcher_options ) {
        # _setup_dispatcher can be run after all other controllers are loaded
        $app_class->postsetup(
            sub { $comp->_setup_dispatcher( $app_class, $options_ref ) } );
    }
    return $comp;
}

sub _setup_dispatcher {
    my ($this, $c, $options_ref) = @_;

    # reading the all subclasses
    # they are already loaded by catalyst
    my %dispatched_controller_for;
    my $class = ref $this || $this;
    for my $dispatched_class ( uniq Module::Find::findsubmod($class) ) {
        my ($moniker) = $dispatched_class =~ /^\Q$class\E::(.*)/;

        my $dispatched_controller = $c->component($dispatched_class)
            or die "There is no controller for $dispatched_class, weird\n ";
        $dispatched_controller_for{$moniker} = $dispatched_controller;
        $dispatched_controller->dispatched_moniker($moniker);
    }

    # I need all dispatched_classes from model
    if (my $model_name = $options_ref->{model}){
        my $model = $c->model($model_name);

        # model is a resultset
        for my $moniker ($model->dispatched_resultsets){
            $dispatched_controller_for{$moniker} 
                or die "No controller for dispatched resultset $moniker in model $model_name\n ";
        }
    }
    $this->dispatched_controller_for(\%dispatched_controller_for);
}

# loads all subcontroller classes
sub setup_dispatcher_class {
    my ( $class, %options ) = @_;

    $class->_dispatcher_options(\%options);
}

# return the list of all monikers
sub dispatched_controllers {
    my $this = shift;
    my $dispatched_controller_for = $this->dispatched_controller_for or return;
    return keys %$dispatched_controller_for;
}

sub dispatched_controller {
    my $this    = shift;
    my $moniker = shift;
    return $this->dispatched_controller_for->{$moniker};
}

1;

__END__

=head1 NAME

Akar::Catalyst::Controller::Dispatcher - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
