package Akar::IOC::Root::Database;
{
  $Akar::IOC::Root::Database::VERSION = '1.994';
}
use MooseX::Role::Parameterized;

use namespace::autoclean;
use Akar::BreadBoard;

parameter schema_class => ();

role {
    my $p = shift;

    before build_content => sub {
        my $this = shift;

        # 2013-05-20 I add a new service storage_new
        # which returns the new storage everytime I
        # resolve it
        my @storage_args = (
            class        => 'DBIx::Class::Storage::DBI',
            dependencies => wire_names(qw(connect_info env)),
            block        => sub {
                my $s   = shift;
                my $p   = $s->params;
                my $env = $p->{env};
                @ENV{ keys %$env } = values %$env;
                my $storage = $s->class->new();
                $storage->connect_info( $p->{connect_info} );
                return $storage;
            },
        );

        service storage => ( @storage_args, lifecycle => 'Singleton', );
        service storage_new => @storage_args;
        service dbh         => (
            block => sub {
                my $s = shift;
                return $s->params->{storage}->dbh;
            },
            dependencies => [qw(storage)],
        );
        service dbh_new => (
            block => sub {
                my $s = shift;
                return $s->params->{storage_new}->dbh;
            },
            dependencies => [qw(storage_new)],
        );
        

        service env => {};
        config_service 'dsn';
        config_service 'username';
        config_service 'password';

        # connection attributes
        # this service is also to be rewritten in class using the role
        service attr => {
            RaiseError => 1,
            AutoCommit => 1,
        };

        # on_connect_do returns subroutine
        # to be rewritten in classes which uses this role
        service on_connect_do => sub { };

        # this service is connected from configuration
        service connect_info => (
            block => sub {
                my $s      = shift;
                my $params = $s->params;
                return [
                    $params->{dsn},
                    $params->{username},
                    $params->{password},
                    $params->{attr},
                    { on_connect_do => $params->{on_connect_do}, }
                ];
            },
            dependencies =>
                wire_names(qw(dsn username password on_connect_do attr)),
        );


        if ( $p->schema_class ) {
            service schema => (
                class => $p->schema_class,
                block => sub {
                    my $s      = shift;
                    my $schema = $s->class->clone;
                    $schema->storage( $s->param('storage') );
                    return $schema;
                },
                dependencies => wire_names(qw(storage)),
            );
        }
    };
};

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 



