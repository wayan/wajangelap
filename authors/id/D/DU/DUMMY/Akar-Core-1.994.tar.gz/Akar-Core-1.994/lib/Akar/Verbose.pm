package Akar::Verbose;
{
  $Akar::Verbose::VERSION = '1.994';
}
use strict;

=head1 NAME

Akar::Verbose - verbosity level for objects and packages

=head1 SYNOPSIS

 # inheritance
 package Foo;  

 use base qw(Akar::Verbose);
 sub bar {
 	my $this = shift;
 	warn 'Problem ...' if $this->verbose(2);
	
	# sets the verbosity for package locally
	local $Foo::Verbosity = 3;
	do_something();
 }

 # use
 package Foo;

 use Akar::Verbose;

 warn 'Problem ' if verbose(2);

 sub some {
 	# sets global verbose level
 	local $Akar::Verbose::Verbose = 2;
	do_something();
 }

=head1 DESCRIPTION

Simple module for sharing the verbosity level among packages.
The verbosity is stored as field with 'Verbosity' key for objects
(have to be hash references), $Verbosity variable for packages.

The verbosity value for Akar::Verbosity is the last resort,
the global verbosity.

This value could be accessed and set via verbosity method
(for package or object) or verbosity function (the global
one).


=head1 METHODS AND FUNCTIONS

=over 4

=cut

our @ISA = qw(Exporter);

# functions have prefix g(lobal) to be distinguished from methods
our @EXPORT_OK = qw(gverbose gverbosity);
require Exporter;

our $Verbosity = 1;

=item verbosity

  $obj->verbosity;
  $obj->verbosity($new_value);
  PACKAGE->verbosity;
  PACKAGE->verbosity($new_value);
  Akar::Verbose->verbosity();
  Akar::Verbose->verbosity($new_value);

Gets or sets the verbosity level for an object or a package (if inherited from Akar::Verbose)
or a global level of verbosity if used as a method of Akar::Verbose.

=item gverbosity

  gverbosity()
  gverbosity($new_value);

Gets or sets the global level of verbosity (equals Akar::Verbose->verbose).

=cut

sub verbosity {
	my $this = shift;
	if (my($value) = @_){
		# setter
		if (ref($this)){
			$$this{'verbosity'} = $value;  
		}
		else {
			no strict 'refs';
			${(ref($this) || $this) . '::Verbosity'} = $value;  
		}
		return($this);
	}
	else {	
		# getter
		my $verbosity;
		if (ref($this)){
			$verbosity = $$this{'verbosity'};  
		}
		if (!defined($verbosity)){
			no strict 'refs';
			$verbosity = ${(ref($this) || $this) . '::Verbosity'};  
		}
		return(defined($verbosity)? $verbosity: (defined($Verbosity)? $Verbosity: 1));
	}
}

sub gverbosity {
	__PACKAGE__->verbosity(@_);
}

=item verbose

  $obj->verbose($min_level);
  PACKAGE->verbose($min_level);
  Akar::Verbose->verbose($min_level);

Returns true if the corresponding verbosity is greater or equal the minimal level supplied.

=item gverbose

  gverbose($min_level);

Global verbosity checked.

=cut

sub verbose {
	my $this = shift;
	my($min_level) = @_;
	return($this->verbosity >= $min_level);
}

sub gverbose {
	__PACKAGE__->verbose(@_);
}

=back

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

1;
