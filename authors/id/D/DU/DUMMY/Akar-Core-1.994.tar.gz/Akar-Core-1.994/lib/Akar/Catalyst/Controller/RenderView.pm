package Akar::Catalyst::Controller::RenderView;
{
  $Akar::Catalyst::Controller::RenderView::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Catalyst::Controller);

use Carp qw(carp croak);
use XML::LibXML;

# Rendering Mason view + XHTML checks

sub _render_view : ActionClass('RenderView') {
    my ( $this, $c ) = @_;

    my $controller_class = $c->action->class;
    my $template         = $c->stash->{'template'}
        ||= $c->component($controller_class)->default_template
        or die "Can't find template to render\n";
        
    my $template_method = $c->stash->{'template_method'}
        ||= $controller_class->default_template_method($c);

    $c->log->debug("Rendering with $template : $template_method") if $c->debug;
}

sub render_view : Private {
    my ( $this, $c ) = @_;

    # calling private rendering
    $c->forward('_render_view');
    return if @{$c->error};    # error is solved differently

    # checking XHTML
    $this->_check_xhtml($c) if $c->stash->{xhtml_rendered} && $c->debug && 0;
}

sub _check_xhtml {
    my ( $this, $c ) = @_;

    my $rendered = $c->response->body;
    eval {
        my $doc = $this->_check_xhtml_validity( $c, $rendered );
        $this->_check_xhtml_tables( $c, $doc );
    };
    my $err = $@ or return;

    # errors from rendering are unblessed hashes other errors are ignored
    ref $err && ref $err eq 'HASH' or return;

    # xhtml_problem has to be rendered by base template
    $c->stash->{template_page_method} = 'page';

    # 2010-06-29 danielr
    # this is little bit hardcoded
    $c->stash->{template} = $this->default_template;
    $c->stash->{template_method} = 'xhtml_problem';
    $c->stash->{rendered}        = $rendered;
    $c->stash->{problem}         = $err->{problem};
    $c->stash->{error_message}   = $err->{error_message};
    $c->response->body(''); # without this the new rendering would be skipped
    $c->forward('_render_view');
}

# checks the response whether it is a well formed and valid XML
my $xml_parser = XML::LibXML->new;
sub _xml_parser { return $xml_parser; }

my $xhtml_schema_location = Akar::Base->app_home('lib/xsd/xhtml1-strict.xsd');
-f $xhtml_schema_location or die <<"END_DIE";
To check validity of rendered xhtml, 
we need the XHTML schema '$xhtml_schema_location'
to be present on disk.
END_DIE

my $xhtml_schema;
sub _xhtml_schema {
    return $xhtml_schema ||= XML::LibXML::Schema->new( location => $xhtml_schema_location);
}

sub _check_xhtml_validity {
    my ( $this, $c, $rendered ) = @_;


    my $response_doc;
    eval { $response_doc = $this->_xml_parser->parse_string( $rendered) };
    if ( my $error = $@ ) {
        die {
            problem        => 'Page is not well-formed XML',
            error_message  => $error,
        };
    }

    eval { $this->_xhtml_schema->validate($response_doc) };
    if ( my $error = $@ ) {
        die {
            problem       => 'Page is not XHTML strict valid',
            error_message => $error,
        };
    }
    return $response_doc;
}


# checks whether the nested tables has the same widths for all cols
sub _check_xhtml_tables { 
    my ($this, $c, $response_doc) = @_;
    my %widths_of;

    my @widths;    # lines ahead (because of rowspan)

    # inner table first
    for my $table (
        reverse $response_doc->findnodes('//*[local-name() = "table"]') )
    {
        my $rownum = 0;
        my @widths;
        for my $tr ( $table->findnodes('descendant::*[local-name() = "tr"]') )
        {
            for my $cell (
                $tr->findnodes(
                    '*[local-name() = "td" or local-name() = "th"]')
                )
            {
                my $colspan = $cell->getAttribute('colspan') || 1;
                my $rowspan = $cell->getAttribute('rowspan') || 1;
                for my $row ( 1 .. $rowspan ) {
                    ( $widths[ $rownum + $row - 1 ] ||= 0 ) += $colspan;
                }
            }
            $rownum++;
        }

        # table is removed from document thus I don't need to care about
        # nested tables
        my $table_path
            = $table->nodePath;   # path must be asked before table is removed
        $table->parentNode->removeChild($table);

        my %has_width = map { ( $_ => 1 ) } @widths;
        if ( keys %has_width > 1 ) {
            my $error = join(
                "\n",
                "Table $table_path has rows with different number of columns:",
                (   map {
                        "row "
                            . ( $_ + 1 ) . " has "
                            . $widths[$_]
                            . " columns";
                        } 0 .. $#widths
                ),
                "table starts with: ",
                substr( $table->toString , 0, 200 )
            );
            die {
                problem       => 'Tables of uneven widths',
                error_message => $error,
            };
        }

    }
}

1;

__END__

=head1 NAME

Akar::Catalyst::Controller::RenderView - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

