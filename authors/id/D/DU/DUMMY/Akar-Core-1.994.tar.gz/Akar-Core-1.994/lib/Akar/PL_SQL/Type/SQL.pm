package Akar::PL_SQL::Type::SQL;
{
  $Akar::PL_SQL::Type::SQL::VERSION = '1.994';
}
use strict;

use base qw(Akar::PL_SQL::Type::Base);

use Data::Dumper;

sub dump_input_value {
    my ($this, $value) = @_;

    my $dumped = Data::Dumper->new([$value])->Terse(1)->Dump;
    $dumped =~ s/\s*$//s;
    $dumped;
}

1;
