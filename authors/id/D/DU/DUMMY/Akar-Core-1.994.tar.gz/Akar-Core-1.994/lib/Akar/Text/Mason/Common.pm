package Akar::Text::Mason::Common;
{
  $Akar::Text::Mason::Common::VERSION = '1.994';
}

=head1 NAME

Akar::Text::Mason::Common - filtr volaj�c� html mason

=head1 SYNOPSIS

=head1 DESCRIPTION

=cut

use strict;

use File::Path qw(mkpath);
use Data::Dumper;
use HTML::Mason;
use File::Basename qw(dirname);
use File::Spec;


# current Mason interpreter - singleton
my $interp;
sub interp {
    my $this = shift;
    $interp ||= do {
        # The application hierarchy may not exist
        my($data_dir, $comp_root);
        eval { 
            require Akar::Base;
            $data_dir  = Akar::Base->app_data('mason');
            $comp_root = Akar::Base->app_home('lib/mason');
            mkpath($data_dir);
        };
        $interp = HTML::Mason::Interp->new(
        $@
          ? ()
          : ('comp_root' => $comp_root, 'data_dir' => $data_dir));
    };
}

# if comp is created from file, associates the file with it
sub _component_file {
    my $this = shift;
    my $component = shift;
    my $field = '_akar_text_mason_component_file';
    @_
        ? ($$component{$field} = $_[0], $component)
        : $$component{$field};
}

sub make_component {
    my $this = shift;
    my($key, $value) = @_;

    my $comp = $this->interp->make_component(@_);
    $this->_component_file($comp, $value) if $key eq 'comp_file';
    $comp;
}


sub process_buffer {
    my $this   = shift;
    my $buffer = shift;
    $this->process_comp($this->make_component('comp_source' => $buffer), @_);
}

sub process_file {
    my $this = shift;
    my $file = shift;
    $this->process_comp($this->make_component('comp_file' => $file), @_);
}

#our $Request;
sub process_comp {
    my $this      = shift;
    #my $component = shift;

    my $buffer;
    $this->interp->out_method(\$buffer);
    $this->interp->exec(@_);
    $buffer;
}

# returns absolute path relative to current component 
sub rel2abs {
    my $this  = shift;
    my($file) = @_;
    my $base_file = $this->_component_file(HTML::Mason::Request->instance->current_comp)
    or die "Can't find base file for relative component path $file\n";
    File::Spec->rel2abs($file, dirname($base_file));
}

sub relative_comp {
    my $this  = shift;
    my($file) = @_;
    $this->make_component('comp_file' => $this->rel2abs($file));
}

# enables to call component with path relative to current working directory
sub HTML::Mason::Commands::akar_relative_comp {
    __PACKAGE__->relative_comp(@_);
}


=head1 AUTHOR

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

1;


