package Akar::XML::DOMBuilder;
{
  $Akar::XML::DOMBuilder::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor::Fast);

use Carp qw(carp croak);
use Scalar::Util qw(blessed reftype);
use XML::LibXML;
use Akar::Class::Utils qw(lexical_cleaner);

# exports 
use Exporter qw(import);
our @EXPORT_OK = qw(xml_builder);

__PACKAGE__->mk_accessors(

    # mapping prefix => namespace
    'namespaces',

    # default namespace
    'default_namespace',

    # includes all namespaces into document element not only those used
    # default is 1
    'include_all_namespaces',

    # encoding to be set on processing document 
    # all input string should follow this encoding
    # default utf8
    'encoding',
);

sub new {
    my ( $package, $fields ) = @_;

    $fields ||= {};
    return $package->SUPER::new(
        {   'namespaces'             => {},
            'include_all_namespaces' => 1,
            %{$fields},
        }
    );
}

# constructor exported as function with positional parameters
sub xml_builder {
    my ($arg1, $arg2, $options) = @_;
    my ($namespaces) =        grep { UNIVERSAL::isa($_, 'HASH') } $arg1, $arg2;
    my ($default_namespace) = grep { $_ && !ref($_) } $arg1, $arg2;

    return __PACKAGE__->new(
        {   $default_namespace
            ? ( 'default_namespace' => $default_namespace )
            : (),
            $namespaces ? ( 'namespaces' => $namespaces ) : (),
            %{ $options || {} },
        }
    );
}

# tests 
sub _is_document {
    return blessed($_[0]) && $_[0]->isa('XML::LibXML::Document');
}

sub _is_element {
    return blessed($_[0]) && $_[0]->isa('XML::LibXML::Element');
}

sub _is_node {
    return blessed($_[0]) && $_[0]->isa('XML::LibXML::Node');
}

# Interface procedures create new document
for my $method (qw(create_elem create_doc create_fragment create_text)) {
    my $internal = '_' . $method;

    no strict 'refs';
    *{$method} = sub {
        my $this = shift;

        my $document = XML::LibXML::Document->new;
        if ($this->encoding){
            $document->setEncoding($this->encoding);
        }
        my $node = $this->$internal($document, @_);
        return $node;
    };
}

sub modify_elem {
    my $this = shift;
    my $elem = shift;

    if ( _is_document($elem) ) {
        $elem = $elem->documentElement;
    }
    _is_element($elem) or die "Invalid argument $elem to modify_elem\n";

    my $lc;
    my $doc = $elem->ownerDocument;
    if ($this->encoding && $this->encoding ne $doc->encoding){
        $lc = lexical_cleaner { $doc->setEncoding(shift()) } $doc->encoding;
        $doc->setEncoding($this->encoding);
    }
    $this->_modify_elem( $elem, @_ );
    return $elem;
}

# the name can be like this: xs:complexType/xs:sequence
# nested elements are then created with attributes belonging
# to the most inner one
# turns
# 'alfa/beta/gama', {'ric' => 'pic'}, 'bum'
# into 'alfa' => [ 'beta' => ['gama', {'ric' => 'pic'}, 'bum']]
# array is modified in place
sub _rearrange_nested_elems {
    my ($this, $args_ref) = @_;
  
    my $elem = $args_ref->[0]; 
    return if !$elem || ref $elem || $elem !~ m{/};

    # wow nested elems
    my @elems = split m{/}, $elem;
    
    # I can't do this, since it may result in modification of constant value
    #$args_ref->[0] = pop @elems;
    splice @{$args_ref}, 0, 1, pop(@elems);
    while (@elems) {
        @{$args_ref} = ( pop(@elems), [ @{$args_ref} ] );
    }
}

sub _create_elem {
    my $this     = shift;
    my $document = shift;

    $this->_rearrange_nested_elems(\@_);

    # first argument is either an element name or element or document
    my $qname = shift;
    my $elem;
    if ( _is_element($qname) ) {

        # Element - deep copy
        $elem = $qname->cloneNode(1);

        if ( $this->include_all_namespaces ) {
            # 2008-09-16 danielr
            # all namespaces above the copied node has to be added
            # because they can be used in context node as attribute
            # value ... xsi:type="xsd:string"
            #
            # reverse .. I start with the innermost one
            for my $ancestor_namespace ( map { $_->getNamespaces; }
                reverse $qname->findnodes('ancestor::*') )
            {
                my $prefix    = $ancestor_namespace->getLocalName;
                my $namespace = $ancestor_namespace->value;
                if ( !$elem->lookupNamespaceURI($prefix) ) {

                    # warn "Adding mapping $prefix => $namespace";
                    $elem->setNamespace( $namespace, $prefix, 0 );
                }
            }
        }
    }
    elsif ( _is_document($qname) ) {

        # Document - deep copy of document element
        $elem = $qname->documentElement->cloneNode(1);
    }
    elsif ( !ref($qname) && $qname ) {
        if ( my ($prefix) = $qname =~ /^(.*?):/ ) {
            my $namespace = $this->namespaces->{$prefix}
                or croak "No namespace found for prefix $qname\n ";
            $elem = $document->createElementNS( $namespace, $qname );
        }
        else {
            my $namespace = $this->default_namespace;
            $elem = $namespace
                ? $document->createElementNS( $namespace, $qname )
                : $document->createElement($qname);
        }
    }
    else {
        die "Unrecognized element argument $qname";
    }
    $this->_modify_elem( $elem, @_ );
    return $elem;
}

sub _modify_elem {
    my $this = shift;
    my $elem = shift;

    # second (if unblessed hash) are the attributes
    if ( @_ && UNIVERSAL::isa( $_[0] => 'HASH' ) && !blessed( $_[0] ) ) {
        my $attr_ref = shift();

        # attributes
        while ( my ( $name, $value ) = each %{$attr_ref} ) {
            my ($prefix) = $name =~ /^(.*?):/;
            if ( $prefix && $prefix ne 'xmlns' ) {
                my $namespace = $this->namespaces->{$prefix}
                    or croak "No namespace found for attribute name $name\n ";
                $elem->setAttributeNS( $namespace, $name, $value );
            }
            else {
                $elem->setAttribute( $name, $value );
            }
        }
    }

    # 2007-08-10 danielr - since now arguments left are content
    # Because the content used to be one array reference 
    # I have to distinguish between element and content 
    # This is the only case I recognize as content 
    # [
    #   [ ]
    # ]
    my $old_deprecated = @_ == 1
        && UNIVERSAL::isa( $_[0], 'ARRAY' )
        && !blessed( $_[0] )
        && @{ $_[0] } > 0
        && UNIVERSAL::isa( $_[0][0], 'ARRAY' )
        && !blessed( $_[0][0] );
    my @children =
        $old_deprecated
        ? @{ $_[0] }
        : @_;

    # children
CHILD: for my $child ( @children ) {
        my $childNode = $this->_normalize_node($elem->ownerDocument, $child)
            or next CHILD;
        $elem->appendChild($childNode);
    }
}

# creates node from misc argument
sub _normalize_node {
    my ( $this, $document, $child ) = @_;

    # undefined node => nothing
    return if !defined($child);

    # non reference  => text node
    return $this->_create_text($document, $child) if !ref $child;

    # document => clone of document element
    return $child->documentElement->cloneNode(1)
        if _is_document($child);

    # object (NODE) => object itself
    return $child->cloneNode(1)
        if _is_node($child);

    return $this->_create_elem($document, @{$child} )
        if UNIVERSAL::isa( $child, 'ARRAY' );

    croak "Unrecognized param $child\n ";
}

sub _create_text {   
    my ($this, $document, $text) = @_;

    return $document->createTextNode($text);
}

# 2007-08-10 danielr - again content is list, not reference
sub _create_fragment {
    my ( $this, $document, @content ) = @_;

    my $fragment = $document->createDocumentFragment;
CHILD: for my $child (@content) {
        my $childNode = $this->_normalize_node($document, $child)
            or next CHILD;
        $fragment->appendChild($childNode);
    }
    return $fragment;
}

sub _create_doc {
    my $this       = shift;
    my $document   = shift;

    $this->_rearrange_nested_elems(\@_);

    my $elem_proto = shift;

    my $doc_elem = $this->_create_elem( $document, $elem_proto );
    $document->setDocumentElement($doc_elem);
    if ( $this->include_all_namespaces ) {
        while ( my ( $prefix, $namespace ) = each %{ $this->namespaces } ) {
            if ( !$doc_elem->lookupNamespaceURI($prefix) ) {

                # warn "Adding mapping $prefix => $namespace";
                $doc_elem->setNamespace( $namespace, $prefix, 0 );
            }
        }
        if ( $this->default_namespace && !$doc_elem->lookupNamespaceURI('') )
        {

            # warn "Adding mapping '' => " . $this->default_namespace;
            $doc_elem->setNamespace( $this->default_namespace, '', 0 );
        }
    }
    if (@_) {
        $this->_modify_elem( $doc_elem, @_ );
    }
    return $document;
}

1;

__END__

=head1 NAME

Akar::XML::DOMBuilder - trivial XML DOM builder

=head1 SYNOPSIS

    #!/usr/bin/perl 
    use Akar::XML::DOMBuilder;

    my $target_namespace = 'http://akar.in.gtsgroup.cz/OC/SOAP/TT';

    my $xml_builder = Akar::XML::DOMBuilder->new(
        { 'namespaces' => { 'tns' => $target_namespace } },
    );

    # very simple document (element only)
    my $doc = $xml_builder->_create_doc( 'tns:ttId' => 200 );

    Yields:

    <?xml version="1.0"?>
    <tns:ttId xmlns:tns="http://akar.in.gtsgroup.cz/OC/SOAP/TT">200</tns:ttId>





    # element containing one other element
    my $doc = $xml_builder->_create_doc( 'tns:ttFeedback',
        $xml_builder->_create_elem( 'tns:ttId' => 100 ) );

    # the shortcut
    my $doc = $xml_builder->_create_doc( 'tns:ttFeedback',
        [ 'tns:ttId' => 100 ] );
    
    Yields:

    <?xml version="1.0"?>
    <tns:ttFeedback xmlns:tns="http://akar.in.gtsgroup.cz/OC/SOAP/TT">
      <tns:ttId>100</tns:ttId>
    </tns:ttFeedback>




    my $doc = $xml_builder->_create_doc(
        'tns:ttFeedback',
        {   'feedbackType' => 'immediate',
            'importance'   => 'high',
        },
        [ 'tns:ttId',          100 ],
        [ 'tns:state',         'finished' ],
        [ 'tns:feedbackEvent', '2007-04-12T11:17:28.680+02:00' ],
    );

    Yields:

    <?xml version="1.0"?>
    <tns:ttFeedback xmlns:tns="http://akar.in.gtsgroup.cz/OC/SOAP/TT" importance="high" feedbackType="immediate">
      <tns:ttId>100</tns:ttId>
      <tns:state>finished</tns:state>
      <tns:feedbackEvent>2007-04-12T11:17:28.680+02:00</tns:feedbackEvent>
    </tns:ttFeedback>




    # with default namespace
    my $xml_builder = Akar::XML::DOMBuilder->new(
        { 'default_namespace' => $target_namespace } );

    my $doc = $xml_builder->_create_doc(
        'ttFeedback',
        {   'feedbackType' => 'immediate',
            'importance'   => 'high',
        },
        [ 'ttId', 100 ],
        [ 'state', { 'terminal' => 'true' } 'finished' ],
        [ 'feedbackEvent', '2007-04-12T11:17:28.680+02:00' ],
    );

    Yields:

    <?xml version="1.0"?>
    <ttFeedback xmlns="http://akar.in.gtsgroup.cz/OC/SOAP/TT" 
        importance="high" feedbackType="immediate">
      <ttId>100</ttId>
      <state terminal="true">finished</state>
      <feedbackEvent>2007-04-12T11:17:28.680+02:00</feedbackEvent>
    </ttFeedback>


    my $xml_builder = Akar::XML::DOMBuilder->new(
        {   'namespaces' => {
                'tns' => $target_namespace,
                'xsi' => 'http://www.w3.org/1999/XMLSchema-instance',
                'xsd' => 'http://www.w3.org/1999/XMLSchema',
            }
        },
    );

    # attributes can have namespaces
    my $doc
        = $xml_builder->_create_doc( 'tns:ttId', { 'xsi:type' => 'xsd:int' },
        1234 );

     Yields:

    <?xml version="1.0"?>
    <tns:ttId xmlns:tns="http://akar.in.gtsgroup.cz/OC/SOAP/TT" 
        xmlns:xsi="http://www.w3.org/1999/XMLSchema-instance" 
        xmlns:xsd="http://www.w3.org/1999/XMLSchema" 
        xsi:type="xsd:int">1234</tns:ttId>
     


=head1 DESCRIPTION

Akar::XML::DOMBuilder is just simple way to create XML::LibXML nodes 
and documents, it's not a XML tree implementation.

=head1 PROPERTIES 

Following methods are setters/getters. They can be set in constructor.

=over 4

=item namespaces

Mapping from prefix => namespace.

=item default_namespace

Namespace to be used when element with unprefixed name is created. 

=back

=head1 METHODS

=over 4

=item new

    Akar::XML::DOMBuilder->new(\%fields)

Constructor.

=item create_elem

    my $node = $xb->create_elem($name, [\%attr], @content);

Creates new element node via C<$xb->document->createElement> 
or C<$xb->document->createElementNS>.

C<$name> is either qualified name of the created element or XML::LibXML
element or XML::LibXML::Document. 

C<\%attr> is a hash of attributes.

C<@content> is the content of the created (cloned) element, 
each member of from C<@content> is turned into XML::LibXML node 
and appended as child to created element.

Following rules are used:

=over 4

=item *

no node is created for undefined value 

=item *

text is turned to text node.

=item *

array reference C<$aref> is turned into new element 
using C<create_elem(@{$aref})>

=item *

when XML::LibXML::Document object is passed,
cloned document element is returned.

=item *

XML::LibXML::Node object is cloned (deeply)

=back 

        my $message_out = $xb->create_elem(
            'message',
            { 'name' => 'someMessage' },
            [   'part',
                {   'name'    => 'parameters',
                    'element' => 'tns:something'
                }
            ],
        );

        yields  

        <message name="someMessage">
            <part name="parameters" element="tns:something"/>
        </message>

=item create_doc

New element according to rules above is created
and made document element of new empty document.
The document is then returned.

=item create_fragment

    my $fragment = $xb->create_fragment(@content);

Creates new XML::LibXML::Fragment. Content has the same meaning as with create_elem.

=item create_text

    my $text_node = $xb->create_text($this_is_the_text);

=item modify_elem

    $xb->modify_elem($elem_or_doc, \%attr, @content);

Modify existing element XML::LibXML::Element node by setting attributes
and appending content. When XML::LibXML::Document is passed its document
element is used.

modify_elem returns the element (or document passed). 

=back

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz>

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
