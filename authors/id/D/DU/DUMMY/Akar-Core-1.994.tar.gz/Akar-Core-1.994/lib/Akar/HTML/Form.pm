package Akar::HTML::Form;
{
  $Akar::HTML::Form::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Akar::HTML::Form::Node Akar::HTML::Form::XHTML);

use Carp qw(carp croak);

# unique identifier generator
use Data::UUID;
use Scalar::Util qw(weaken);
use Akar::List::Utils qw(pop_options);
use Akar::HTML::Form::Field;
use Akar::HTML::Form::Exceptions;

# form properties
__PACKAGE__->mk_accessors(qw(action method enctype));

# input values
__PACKAGE__->mk_accessors(qw(params));

# default values for fields (inflated)
__PACKAGE__->mk_accessors(qw(def_values));

__PACKAGE__->mk_accessors(qw(form_uuid));

# fields
__PACKAGE__->mk_ro_accessors(qw(_fields _fields_order));

__PACKAGE__->mk_ro_accessors(qw(submitted_name));

# if set the value produced by the form is an array
__PACKAGE__->mk_ro_accessors(qw(produces_array));

# unique form id generator
my $ug = Data::UUID->new;

# we need the name for validations
sub name { return '/'; }

sub new {
    my ( $class, $fields_ref ) = @_;

    $fields_ref ||= {};

    my $submitted_name = $fields_ref->{'submitted_name'} ||= '_is_submitted';
    $fields_ref->{action} or die "No action supplied\n";
    $fields_ref->{_fields}      = {};
    $fields_ref->{_fields_order} = [];
    $fields_ref->{def_values} ||= {};

    my $form_uuid;
    my $params = $fields_ref->{'params'} ||= {};
    $form_uuid = $fields_ref->{'form_uuid'} ||= $params->{$submitted_name}
        || $ug->create_str;

    my $form = $class->next::method(
        {   method  => 'get',
            enctype => "multipart/form-data",
            %$fields_ref
        }
    );

    # hidden field indicating whether form was submitted
    $form->add_hidden_field(
        $submitted_name,
        value      => $form_uuid,
        omit_value => 1,
    );
    return $form;
}

#-------------------------------------------------------------------------------
#   Fields manipulations
#-------------------------------------------------------------------------------

# the names of all fields 
sub field_names {
    return map { $_->name } shift()->fields;
}

# return the list of the objects
sub fields {
    return @{ shift()->_fields_order }; 
}

sub submit_fields {
    return grep { ($_->type || '') eq 'submit' } shift()->fields;
}

sub hidden_fields {
    return grep { ($_->type || '') eq 'hidden'} shift()->fields;
}

# field under current form
sub field {
    my ( $this, $path ) = @_;

    return $this if $path eq '/' or $path eq '';
    return $this->_fields->{$path};
}

sub _add_field {
    my ($this, $name, $field) = @_;

    $this->_fields->{$name} = $field;
    push @{$this->_fields_order},  $field;
}

sub add_field {
    my $this           = shift;
    my $basename       = shift;
    my %params = @_;

    # 2009-01-19 danielr 
    # omit_value on file fields
    if (   !defined $params{omit_value}
        && defined $params{type}
        && $params{type} eq 'file' )
    {
        $params{'omit_value'} = 1;
    }
    my $name = $basename;
    $params{basename} = $basename;
    $params{parent_form} = $this;
    $params{name} = $name;

    # sets the default value
    # but the value set in def_values has priority
    if ( exists $params{value} ) {
        my $value      = delete $params{value};
        my $def_values = $this->def_values;
        exists $def_values->{$name}
            or $def_values->{$name} = $value;
    }

    my $field = Akar::HTML::Form::Field->new(
        {   validates => 1,
            trimmed   => 1,
            %params
        }
    );
    $this->_add_field($basename, $field);
    weaken $field->{parent_form};
    return $field;
}

sub remove_field {
    my ( $this, $name ) = @_;

    $name = $name->name if ref $name;    # field object
    my $field = delete $this->_fields->{$name}
        or die "No field $name found\n";
    @{ $this->_fields_order }
        = grep { $_ ne $name } @{ $this->_fields_order };
    return $field;
}

# shortcut
sub add_submit_field {
    my $this = shift;
    return $this->add_field( @_, type => 'submit' );
}

sub add_hidden_field {
    my $this = shift;
    return $this->add_field( @_, type => 'hidden' );
}

# a special field, which cannot be rendered but can carry value
sub add_static_field {
    my $this = shift;

    my $f = $this->add_field( @_ );
    $f->is_static(1);
    return $f;
}

# fields which creates the value of the form
sub value_fields {
    my ($this) = @_;

    return grep { !$_->omit_value } $this->fields;
}

sub _compose_value {
    my ( $this, $method ) = @_;

    my @value_fields = $this->value_fields;

    # 2009-02-13 danielr
    # empty hash {} is turned into undef
    # so it is not included into parents value
    if ( $this->produces_array ) {
        return [ map { $_->$method }
                sort { $a->basename <=> $b->basename } @value_fields ];
    }
    else {
        my %value = map {
            my $field = $_;
            my $value = $field->$method;
            defined $value
                || $field->force_value
                ? ( $field->basename => $value )
                : ()
        } @value_fields;

        return %value || $this->force_value
            ? \%value
            : undef;
    }
}

# value on form returns hashref 
# field_name => $value
#
# 2009-01-15 danielr 
# value not raw_value is intentional, since 
# raw_value of form is unprocessed result of processed field values
# inflated_value of form is processed result of processed field values
sub raw_value {
    my $this = shift;
    return $this->_compose_value('value');
}

sub elem_value {
    my $this = shift;

    return $this->_compose_value('elem_value');
}

# 2009-01-19 danielr
# inflate_value has to be redefined
# since the inflator is applied on raw_value at whole
# even it is an array (array form)
sub inflate_value {
    my ( $this, $raw_value ) = @_;

    my @inflators = @{ $this->inflators } or return $raw_value;

    # TO DO error on inflation
    my $inflated = $raw_value;
    for my $inflator (@inflators) {
        $inflated = $inflator->( $inflated, $this );
    }
    return $inflated;
}

#-------------------------------------------------------------------------------
#   Submitting
#-------------------------------------------------------------------------------

# test whether form was submitted
sub submitted {
    my ($this) = @_;

    return $this->params->{ $this->submitted_name };
}

# returns the field object which was pressed
sub submitted_field {
    my ($this) = @_;
    
    for my $field ($this->submit_fields){
        return $field if $field->value;
    }

    for my $form ($this->forms){
        my $submitted_field = $form->submitted_field;
        return $submitted_field if $submitted_field
    }

    # nothing was found
    return;
}

# returns 1 if form is valid, calls validate but once only
sub is_valid {
    my $this = shift;

    my $ok = $this->validation_context->{'ok'};
    return defined $ok
        ? $ok
        : $this->validate;
}

# returns 1 if the form was submitted and is valid
sub passed {
    my $this = shift;

    return $this->submitted && $this->is_valid;
}

#-------------------------------------------------------------------------------
#   Validation and values
#-------------------------------------------------------------------------------

sub set_defaults {

    # adds values before current ones
    my ( $this, $defaults ) = @_;

    # merging saved form data into current request->params
    # saved data have lower priority than $c->request->params
    %{ $this->params } = ( %$defaults, %{ $this->params } );
}

# validation context cannot be set only reset
sub validation_context {
    my $this = shift;

    return $this->{'validation_context'}
        || $this->reset_validation_context;
}

sub reset_validation_context {
    my $this = shift;

    return $this->{'validation_context'} = {

        # mapping field_path => 1
        is_missing          => {},
        validation_messages => {},
        inflated_values     => {},
    };
}

# validates the form possibly submitted in other form
# returns 1 if the form is valid
sub validate {
    my ($this) = @_;

    # cleaning context
    $this->reset_validation_context;

    # Unless any error appears the form is valid
    my $validation_context = $this->validation_context;
    $validation_context->{'ok'} = 1;

    $this->validate_fields;
    $this->process_validations;
    return $validation_context->{'ok'};
}

sub validate_fields {
    my $this = shift;

FIELD: for my $moniker ( $this->fields ) {
        my $field = $this->field($moniker);

        my $is_supplied = $field->is_supplied;
        if ($is_supplied) {
            $field->process_validations;
        }
        else {
            my $required = $field->required
                || ( $field->required_if
                && $field->required_if->($field) );
            $field->process_validation( sub { $field->throw_missing_field; } )
                if $required;
        }
    }
}

# searches the form params keys to find available subforms
sub available_subforms {
    my ( $this, $subform_re, $marker_re ) = @_;

    # by default subforms are numbered
    my $numeric;
    if ( !defined $subform_re ) {
        $subform_re = '\d+';
        $numeric    = 1;
    }

    my $re              = join(
        $this->input_name_separator,
        $this->input_name,
        '(' . $subform_re . ')',
        defined $marker_re ? $marker_re : ''
    );

    return
        sort { $numeric ? ($a <=> $b) : ($a cmp $b) }
        map { /^$re/ } keys %{ $this->params };
}


# 2009-02-17 danielr
# by default the form acts as being supplied
sub is_supplied {
    return 1;
}

# return field objects for missing fields 
sub missing_fields {
    my $this = shift;

    my $context = $this->validation_context;
    return map { $this->field($_); } keys %{$context->{'is_missing'} };
}

sub invalid_fields {
    my $this = shift;

    my $context = $this->validation_context;
    return map { $this->field($_); } keys %{$context->{'validation_messages'}};
}

#-------------------------------------------------------------------------------
#   Form unique id
#   the unique id is the value of of submitted name
#   has sense for only for forms of level 0
#-------------------------------------------------------------------------------


#-------------------------------------------------------------------------------
#   Rendering 
#-------------------------------------------------------------------------------



1;

__END__

=head1 NAME

Akar::HTML::Form - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
