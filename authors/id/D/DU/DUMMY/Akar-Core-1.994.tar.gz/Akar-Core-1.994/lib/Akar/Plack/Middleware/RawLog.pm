package Akar::Plack::Middleware::RawLog;
{
  $Akar::Plack::Middleware::RawLog::VERSION = '1.994';
}
use Moose;

# logging HTTP request and response in (headers, content)

use namespace::autoclean;

use Data::Uniqid qw/uniqid/;
use Plack::Request;
use Plack::Response;
use Plack::Util;
use HTTP::Headers;

has app => ( is => 'rw', required => 1 );

# the logger from role (...WithLogging) is the default value
# for logger attribute
has logger => ( is => 'rw', lazy_build => 1 );

# with has to be called after logger definition
with 'Akar::Log::Any::WithLogging' => {
    '-alias'    => { logger => '_build_logger', },
    '-excludes' => 'logger',
};

sub wrap {
    my $class = shift;
    return $class->new( app => @_ )->psgi_app;
}

# the "constructor" returning subroutine to be used in 
# Plack Builder enable
sub wrapper {
    my ( $class, @args ) = @_;
    return sub {
        my $app = shift;
        return $class->new( @args, app => $app )->psgi_app;
    };
}

my $cnt = 0;

sub psgi_app {
    my $this = shift;
    my $app  = $this->app;

    return sub {
        my $env = shift;

        my $request_id = "$$-" . ( ++$cnt );
        my $req = Plack::Request->new($env);
        $this->log_debug(
            message    => 'HTTP request',
            request_id => $request_id,
            body       => $req->raw_body,
            headers    => $req->headers->as_string,
            url => $req->uri,
        );

        return Plack::Util::response_cb(
            $app->($env),
            sub {
                my $ret = shift;
                $this->_log_response( $ret, $request_id );
            }
        );
    };
}

sub _log_response {
    my ( $this, $ret, $request_id ) = @_;

    my ( $status, $headers, $raw_content ) = @$ret;
    my $content;
    if ( Plack::Util::is_real_fh($raw_content) ) {

        # tohle je pofiderni
        my $cl = Plack::Util::content_length($raw_content);
        $raw_content->read( $content, $cl, 0 );
        $raw_content->seek( 0, 0 );
    }
    elsif ( ref $raw_content eq 'ARRAY' ) {
        $content = join '', @$raw_content;
    }
    else {
        $content = '';
    }

    $this->log_debug(
        message    => 'HTTP response',
        request_id => $request_id,
        status     => $status,
        headers    => HTTP::Headers->new(@$headers)->as_string,
        body       => $content,
    );

}

__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
