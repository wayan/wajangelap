package Akar::Mason::Compiler::Filters::LocalMethod;
{
  $Akar::Mason::Compiler::Filters::LocalMethod::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);

sub new {
    my $class = shift;
    my $this = $class->next::method(@_);

    $this->add_filter(
        {   component_content_call => _component_call(1),
            component_call => _component_call(0),
        }
    );
    return $this;
}

sub _component_call {
    my ($has_content) = @_;

    my $pkg = __PACKAGE__;
    sub {
        my ( $this, %args ) = @_;

        my ( $is_def, $args ) = $args{call} =~ /^\s*local(def)?:\s*(.*)?$/s
            or return;

        $this->stop_callbacks;

        # first arg can be unquoted - so we quote it
        $args =~ s/^(\w+)(?=\s*(,.*)?$)/'$1'/s;

        if ($is_def){
            if ($has_content){
                $this->output_perl("local \$$pkg\:\:LocalMethod{$args} = sub { my \$CONTENT = pop();", "};");
                # inside localdef I can use special component <& CONTENT &>
                my $content = sub {     
                    my ($has_content, $this, %args) = @_;
                    my $call = $args{call};
                    $call =~ /^\s*CONTENT\b/ or return;
                    die "CONTENT cannot be called with content\n" if $has_content;
                    $this->stop_callbacks;
                    $this->output_perl('$CONTENT->() if $CONTENT;');
                };
                $this->add_filter(
                    {
                        component_call => sub { $content->(0, @_) },
                        component_content_call => sub { $content->(1, @_) },
                    },
                    1000,
                );
            }
            else {
                # empty subroutine is defined
                $this->output_perl("local \$$pkg\:\:LocalMethod{$args} = sub {};");
            }
        }
        else {
            $this->output_perl(
                $has_content?
                    ("$pkg\:\:call_local($args, sub {", "});")
                    : "$pkg\:\:call_local($args, undef);");
        }
    };
}

our %LocalMethod;
sub call_local {
    my $method = shift;

    my $code = $LocalMethod{$method} or die "No local method $method found\n";
    $code->(@_);
}

1;

__END__

=head1 NAME

Akar::Mason::Compiler::Filters::LocalMethod - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
