package Akar::AQ::Functions;
{
  $Akar::AQ::Functions::VERSION = '1.994';
}
use strict;
use warnings;


use base qw(Exporter);

# methods exported on demand (preferred)
our @EXPORT_OK = qw(qname);

# methods exported automatically
our @EXPORT = qw();

use Carp qw(carp croak);

# returns qualified name object
sub qname {
    return Akar::AQ::_QName->new(@_);
}

{

    package Akar::AQ::_QName;
{
  $Akar::AQ::_QName::VERSION = '1.994';
}
    use base qw(Class::Accessor::Fast);
    use overload '""' => sub {
        my $this = shift;
        return $this->owner . '.' . $this->name;
        },
        'fallback' => 1;

    __PACKAGE__->mk_ro_accessors(qw(owner name));

    sub new {
        my $class = shift;
        my ($qname) = @_;

        my @qname = split /\./, $qname;
        @qname == 2 or die "Qualified name expected, not $qname\n ";

        return $class->SUPER::new(
            {   'owner' => $qname[0],
                'name'  => $qname[1],
            }
        );
    }

}

1;

__END__

=head1 NAME

Akar::AQ::Functions - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
