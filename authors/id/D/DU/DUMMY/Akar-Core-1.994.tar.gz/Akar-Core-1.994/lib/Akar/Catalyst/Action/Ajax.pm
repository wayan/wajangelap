package Akar::Catalyst::Action::Ajax;
{
  $Akar::Catalyst::Action::Ajax::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);
use base qw(Catalyst::Action);
use XML::LibXML qw(XML_ELEMENT_NODE XML_TEXT_NODE XML_DOCUMENT_NODE);
use Interpolation 'E' => 'eval';
use JSON;
use Akar::Iconv qw(il2_utf8 utf8_il2);

{
    my $json = JSON->new->allow_nonref;

    sub _encode_json {
        # 2008-11-28 danielr
        # I can't force json to accept anything else then utf8 string
        # so this double encode/decode
        return utf8_il2($json->encode( il2_utf8(shift())));
    }
}

sub execute {
    my $self = shift;
    my ( $controller, $c ) = @_;

    # !!! the action object is passed as last parameter
    # so the function body can call different methods
    # from this package
    $self->NEXT::execute(@_, $self);
}

# runs a javascript code
sub run_javascript {
    my ($self, $c, $js_code) = @_;

    $c->response->headers->header(
        'Content-type' => 'application/javascript; charset=iso-8859-2' );

    # 2008-11-21 danielr 
    # code returned is INTENTIONALLY wrapped in function
    # so the variables in the code don't mess with current context
    $c->response->body( join( "\n", 'function(){', $js_code, '}' ) );
    $c->stash->{'skip_rendering'} = 1;    # already rendered
}

# replaces target element
sub replace_element {
    my ( $self, $c, $element_id, $content ) = @_;

    # using DOM
    # is is the best way ???
    my $doc =
          !defined($content) ? $self->render_as_xml($c)
        : ref($content)      ? $content
        :    # XML document
        XML::LibXML->new->parse_string($content);

    my $javascript = $self->doc2jsdom($doc);
    return $self->run_javascript( $c, <<"END_JS");
        var replacedElem  = YAHOO.util.Dom.get('$element_id');    
        if (replacedElem){
            var fNewContent = $javascript;
            var newContent  = fNewContent(replacedElem.ownerDocument);
            replacedElem.parentNode.replaceChild(newContent, replacedElem);
        }
END_JS
}

sub replace_content {
    my ($self, $c, $element_id, $content) = @_;

    $content ||= $self->render($c);
    return $self->run_javascript( $c, <<"END_JS");
        var replacedElem  = YAHOO.util.Dom.get($E{ _encode_json($element_id) });    
        if (replacedElem){
            replacedElem.innerHTML = $E{ _encode_json($content) };
            var jsElements = replacedElem.getElementsByTagName('script');
            for (var i = 0; i < jsElements.length; i++) {
                eval(jsElements[i].innerHTML);
            }
        }
END_JS
}

sub render_as_xml {
    my ($self, $c ) = @_;

    my $body = $self->render($c);

    # if document starts with whitespaces is unparsable
    $body =~ s/^\s+//s;
    $body =~ s/\s+$//s;
    # hardcoded encoding - tfuj
    $body = '<?xml version="1.0" encoding="iso-8859-2" ?>' .  $body;
    return XML::LibXML->new->parse_string($body);
}

# returns rendered content
sub render {
    my ($self, $c) = @_;

    $c->stash->{'render_page_fragment'} = 1;

    # 2008-11-11 danielr
    # rendering via /render_view should set the template
    $c->forward( '/render_view' );
    die $c->error->[-1] if @{ $c->error };

    return $c->response->body;
}


# given XML document 
# returns Javascript function constructing the document 
# by DOM calls
sub doc2jsdom {
    my ( $self, $doc ) = @_;

    my $var_no = 0;
    my $new_var = sub { return 'c' . ( ++$var_no ); };
    my $node2jsdom;
    $node2jsdom = sub {
        my ( $node, $var ) = @_;

        return "$var = doc.createTextNode(" . _encode_json( $node->nodeValue ) . ');'
            if $node->nodeType == XML_TEXT_NODE;

        if ( $node->nodeType == XML_ELEMENT_NODE ) {
            my @c = "$var = doc.createElement("
                . _encode_json( $node->nodeName ) . ');';
            for my $attr ( $node->attributes ) {
                push @c,
                    'c.setAttribute('
                    . _encode_json( $attr->nodeName ) . ', '
                    . _encode_json( $attr->nodeValue ) . ');';
            }
            for my $child ( $node->childNodes ) {
                my $child_var = $new_var->();
                push @c, "var $child_var;",
                    $node2jsdom->( $child, $child_var ),
                    "$var.appendChild($child_var);";
            }
            return @c;
        }
        die 'Invalid node type ' . $node->nodeType;
    };
    return join( "\n",
        "function(doc){", 'var c;',
        $node2jsdom->( $doc->documentElement, 'c' ),
        'return c;', "}" );
}

1;

__END__

=head1 NAME

Akar::Catalyst::Action::Ajax - different reactions to ajax request

=head1 SYNOPSIS

=head1 DESCRIPTION

Akar::Catalyst::Action::Ajax can react to Ajax request.
It can 

=over 4

=item *

Replace an element by rendered content.

=item *

Runs a javascript code.

=back

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
