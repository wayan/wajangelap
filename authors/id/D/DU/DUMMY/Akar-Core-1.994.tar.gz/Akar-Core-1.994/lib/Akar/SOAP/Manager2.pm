package Akar::SOAP::Manager2;
{
  $Akar::SOAP::Manager2::VERSION = '1.994';
}
use strict;
use warnings;

# SOAP::Transport::HTTP::Apache 
use base qw(Class::Accessor);

use Class::Trait qw(Akar::Trait::Scriptmodule Akar::Trait::PackageConfig);

use FileHandle;
use File::Path qw(mkpath);
use File::Basename qw(dirname basename);
use File::Spec;
use File::Slurp qw(write_file);
use Carp qw(croak carp);
use Sys::Hostname qw(hostname);
use List::MoreUtils qw(uniq);

use Akar::Base;
use Interpolation 'E' => 'eval';
use Apache::Constants qw(:http);

# maximum waiting period until Apache dies
use constant 'APACHE_DEATH_TIMEOUT' => 20;

# initial period of waiting for apache death (very unimportant constant)
use constant 'APACHE_DEATH_START_WAIT' => 0.1,    # 0.1 second

__PACKAGE__->add_config_param('port');
__PACKAGE__->add_config_param( 'ssl_port'    => -1 );
__PACKAGE__->add_config_param( 'dispatch_to' => [] );
__PACKAGE__->add_config_mapping('dispatch_with');
__PACKAGE__->add_config_param( 'authorized_by' => [] );
__PACKAGE__->add_config_param( 'basic_auth'    => 0 );
__PACKAGE__->add_config_param( 'raw_logging'   => 0 );

# if single_request is set then only one request is served by child
__PACKAGE__->add_config_param( 'single_request' => 0 );
__PACKAGE__->add_config_param( 'server_root'    => '/usr/local/httpd-test' );

# Command line interface
__PACKAGE__->add_script_action(
    'start - Starts the apache',
    sub {
        my ($this) = @_;
        if ( !-e $this->apache_config_file ) {
            $this->install_config;
        }
        $this->start_apache;
    }
);
__PACKAGE__->add_script_action(
    'stop - Stops the apache',
    sub {
        shift()->stop_apache;
    }
);
__PACKAGE__->add_script_action(
    'restart - Stops the apache, wait until its PID disappear and start it again',
    sub {
        my ($this) = shift;
        $this->restart_apache;
    }
);

sub server_path {
    my ($this, $subpath) = @_;
    return File::Spec->catfile($this->server_root, $subpath);
}

# options directly converted to server_config properties
sub apache_binary {
    my ($this) = @_;

    return $this->server_path('bin/httpd');
}

# returns app_data root
sub app_data_root {
    return Akar::Base->app_data( join '-', split /::/, __PACKAGE__ );
}

# filename relative to instance_root
sub app_data_path {
    my ( $this, $filename ) = @_;
    return File::Spec->rel2abs( $filename, $this->app_data_root );
}

sub logpath {
    my ( $this, $log_filename ) = @_;

    my $log_subdir = 'logs';
    return $this->app_data_path( @_ == 1
        ? $log_subdir
        : File::Spec->catfile( $log_subdir, $log_filename ) );
}

# configuration file
sub apache_config_file { return shift()->app_data_path('httpd.conf'); }

sub raw_logging_file { return shift()->logpath('SOAP_raw_data.log'); }

# Apache basic authorization file
sub basic_auth_file { return shift()->app_data_path('htusers.pwd'); }

# returns file where PID is stored
sub pid_file { return shift()->logpath('httpd.pid'); }

sub install_config {
    my ($this) = @_;

    mkpath( $this->logpath );
    write_file( $this->apache_config_file, $this->apache_config);
    return;
}

sub apache_config {
    my ($this) = @_;

    my $this_package = ref($this) || $this;
    return <<"END_CONFIG";
<Perl>
use lib '$E{ Akar::Base->perl5lib }';
use Akar::Base;
use Akar::Base::Profile;
use $this_package;
$this_package->check_config;
Apache->httpd_conf($this_package->httpd_conf);
</perl>
END_CONFIG
}

# returns URI of SOAP server 
sub soap_proxy_url {
    my ($this) = @_;

    return sprintf('http://%s:%s/soap/', hostname(), $this->port);
}

sub ssl_soap_proxy_url {
    my ($this) = @_;

    return if ! $this->uses_ssl;
    return sprintf('https://%s:%s/soap/', hostname(), $this->ssl_port);
}

sub wsdl_uri {
    my ( $this, $package ) = @_;

    grep { $_ eq $package } @{$this->dispatch_to} 
        or croak "Package $package is not dispatched to\n";

    return sprintf( 'http://%s:%s/wsdl/%s',
        hostname(), $this->port, join( '/', split '::', $package ) );
}

# returns the content of httpd.conf
sub httpd_conf {
    my ($this) = @_;

    my $this_package = ref($this) || $this;
    my $httpd_conf   = <<"END_HTTPD_CONF";
ServerType standalone
ServerRoot $E{ $this->server_root }
PidFile $E{ $this->logpath( 'httpd.pid' ) }
ScoreBoardFile $E{ $this->logpath( 'httpd.scoreboard' ) }
Timeout         300
MinSpareServers     1
MaxSpareServers     5
StartServers        2
MaxClients 150
MaxRequestsPerChild $E{ $this->single_request? 1: 0 }
KeepAlive           $E{ $this->single_request? 'Off': 'On' }
MaxKeepAliveRequests 100
KeepAliveTimeout    15

ClearModuleList
AddModule mod_log_config.c
AddModule mod_asis.c
AddModule mod_access.c
AddModule mod_auth.c
AddModule mod_so.c
AddModule mod_setenvif.c
AddModule mod_mime.c

AddModule mod_perl.c

Port $E{ $this->port }

ServerAdmin  simoniki\@irsay.devel.gts.cz
DocumentRoot "$E{ $this->server_path('htdocs') }

UseCanonicalName On
DefaultType text/plain
HostnameLookups Off

ErrorLog $E{ $this->logpath( 'error_log' ) }
LogLevel error

LogFormat "%h %l %u %t \\"%r\\" }s %b" common
CustomLog $E{ $this->logpath( 'access_log' ) } common

ServerSignature On

#<Perl>
#use lib '$E{ Akar::Base->perl5lib }';
#use Akar::Base;
#use Akar::Base::Profile;
#use $this_package;
#$this_package->check_modules;
#</Perl>

SetHandler perl-script
PerlSetVar options "compress_threshold => 10000"

<Location /soap>
$E{ $this->basic_auth
    ? join( "\n",
        'AuthType Basic',
        'AuthName "By Invitation Only"',
        'AuthUserFile ' . $this->basic_auth_file,
        'Require valid-user',
        )
    : ''
}
PerlHandler ${this_package}::soap_handler 
</Location>

<Location /wsdl>
PerlHandler ${this_package}::wsdl_handler
</Location>
END_HTTPD_CONF

    if ( $this->uses_ssl ) {
        $httpd_conf .= <<"END_SSL_CONF";

LoadModule ssl_module         libexec/libssl.so
AddModule mod_ssl.c

Listen $E{ $this->port }
Listen $E{ $this->ssl_port }

AddType application/x-x509-ca-cert .crt
AddType application/x-pkcs7-crl    .crl

SSLPassPhraseDialog  builtin
SSLSessionCache         dbm:$E{ $this->logpath( 'ssl_scache' ) }
SSLSessionCacheTimeout  300
SSLMutex  file:$E{ $this->logpath( 'ssl_mutex' ) }
SSLRandomSeed startup builtin
SSLRandomSeed connect builtin
SSLLog      $E{ $this->logpath( 'ssl_engine_log' ) }
SSLLogLevel error

<VirtualHost _default_:$E{ $this->ssl_port }>
DocumentRoot    "$E{ $this->server_root('htdocs') }
ServerName      aurelius.in.gtsgroup.cz
ServerAdmin     machacep\@irsay.devel.gts.cz
ErrorLog        $E{ $this->logpath( 'error_log' ) }
TransferLog     $E{ $this->logpath( 'access_log' ) }
SSLEngine on
SSLCipherSuite ALL:!ADH:!EXPORT56:RC4+RSA:+HIGH:+MEDIUM:+LOW:+SSLv2:+EXP:+eNULL
SSLCertificateFile      $E{ $this->server_path('conf/ssl.crt/server.crt') }
SSLCertificateKeyFile   $E{ $this->server_path('conf/ssl.key/server.key') }
CustomLog $E{ $this->logpath( 'ssl_request_log' ) } \\
          "%t %h %{SSL_PROTOCOL}x %{SSL_CIPHER}x \\"%r\\" %b"
</VirtualHost>
END_SSL_CONF
    }
    return $httpd_conf;
}


# returns the body of the apache config file

sub start_apache {
    my ($this) = @_;

    my $apache_pid = $this->apache_pid;
    !$apache_pid
        or croak "$0 start: httpd (pid $apache_pid) already running\n";

    my $httpd = join ' ', $this->apache_binary, '-f', $this->apache_config_file;
    system($httpd ) == 0
        or croak "$0 start: httpd could not be started\n";

    warn "$0 start: httpd started\n";
}

sub stop_apache {
    my ($this) = @_;

    my $apache_pid = $this->apache_pid
        or croak "$0 stop: httpd not running\n";

    kill 'TERM', $apache_pid
        or croak "$0 stop: httpd could not be stopped\n";

    warn "$0 stop: httpd stopped\n";
}

sub apache_pid {
    my ($this) = @_;

    return if !-f $this->pid_file;

    my $apache_pid = 0 + FileHandle->new( $this->pid_file )->getline();

    # Process with the PID exists?
    return $apache_pid if kill 0, $apache_pid;
    return;
}

sub restart_apache {
    my ($this) = @_;

    if ( my $apache_pid = $this->apache_pid ) {
        $this->stop_apache;
        $this->wait_until_apache_dies($apache_pid);
    }
    $this->start_apache;
}

sub wait_until_apache_dies {
    require Time::HiRes;

    my ( $this, $apache_pid ) = @_;

    # waiting for until process really dies
    my $total_sleep     = 0;
    my $max_total_sleep = int( APACHE_DEATH_TIMEOUT * 1e6 ); # in microseconds
         # starts the wait with
    my $sleep      = int( APACHE_DEATH_START_WAIT * 1e6 );
    my $last_sleep = 0;
    while ( my $process_exists = kill 0, $apache_pid ) {
        croak
            "Even after $max_total_sleep microseconds the Apache hasn't stopped\n "
            if $total_sleep > $max_total_sleep;
        Time::HiRes::usleep($sleep);
        $total_sleep += $sleep;

        # fibonacci number - I heard that they are good for repetitive tries
        my $new_sleep = $sleep + ( $last_sleep || $sleep );
        $last_sleep = $sleep;
        $sleep      = $new_sleep;
    }
}

# checks whether the configuration is OK
sub check_config {
    my ($this) = @_;

    for my $dispatched ( @{ $this->dispatch_to } ) {
        eval qq{ require $dispatched };
        die "Require of dispatched module '$dispatched' failed: $@" if $@;
    }

    for my $auth_module ( @{ $this->authorized_by } ) {
        eval qq{ require $auth_module };
        die $@ if $@;
        die "Require of authorized_by module '$auth_module' failed: $@" if $@;
        $auth_module->can('authorize_soap_call')
            or die
            "Authorization module doesn't have authorize_soap_call method\n";
    }
}

sub uses_ssl {
    my ($this) = @_;

    return $this->ssl_port >= 0;
}

{
    my $server;

    sub soap_handler {
        my $this = __PACKAGE__;

        if ( !$server ) {

            # following code is copied from Apache::SOAP
            #   ($server has to be of Akar::SOAP::Apache class)
            $server = Akar::SOAP::Manager2::SOAPHandler->new;
            $server->dispatch_to( @{ $this->dispatch_to } );
            $server->dispatch_with( $this->dispatch_with );
            $server->raw_logging_file( $this->raw_logging_file );
            $server->raw_logging( $this->raw_logging );
            $server->authorized_by( $this->authorized_by );

       # 2007-09-27 danielr, the response element may not use default_namespce
            $server->serializer->use_default_ns(0);
        }

        return $server->handle(@_);
    }
}

sub wsdl_handler {
    my $r    = shift;
    my $this = __PACKAGE__;

    # splice removes wsdl prefix from uri
    my $soap_package = join '::',
        splice @{ [ grep {$_} split m{/}, $r->uri ] }, 1;
    if ( grep { $soap_package eq $_ } @{ $this->dispatch_to } ) {
        eval {

            # wsdl handler uses https or http according to port it got
            my $location =
                  $r->get_server_port == $this->ssl_port
                ? $this->ssl_soap_proxy_url
                : $this->soap_proxy_url;

            # stupid determination of the service
            # Akar::SOAP::Service is used only for old packages
            # they come with Akar::SOAP::Service preloaded
            # so I don't require it here
            my $service
                = UNIVERSAL::can( 'Akar::SOAP::Service', 'get_by_package' )
                && Akar::SOAP::Service->get_by_package(
                $soap_package)    #old ones
                || $soap_package;    # new packages
            if ( $service->can('create_wsdl') ) {
                my $wsdl_content = $service->create_wsdl($location);
                $r->send_http_header();
                $r->print($wsdl_content);
            }
            else {

                # package doesn't produce WSDL
                $r->status(HTTP_NOT_FOUND);
                $r->send_http_header();
                $r->print(
                    "Service $soap_package doesn't produce WSDL description\n"
                );
            }
        };
        if ($@) {
            warn $@;
            $r->status(HTTP_INTERNAL_SERVER_ERROR);
            $r->send_http_header();
        }
    }
    else {

        # package is not dispatched
        $r->status(HTTP_NOT_FOUND);
        $r->send_http_header();
        $r->print("Service $soap_package is not provided by this server\n");
    }
}


{

    package Akar::SOAP::Manager2::SOAPHandler;
{
  $Akar::SOAP::Manager2::SOAPHandler::VERSION = '1.994';
}

    # using SOAP::Transport::HTTP must precede use base
    # since SOAP::Transport::HTTP::Apache has not its own module
    use SOAP::Transport::HTTP;
    use base qw(SOAP::Transport::HTTP::Apache Class::Accessor::Fast);

    use Apache;
    use URI;

    # I copy some properties from Akar::SOAP::Manager2 to make the 
    # soap handler easier to test
    __PACKAGE__->mk_accessors(
        qw(current_user raw_logging raw_logging_file authorized_by));

    # hook for make fault
    sub unathorized_fault_code {
        return 'Client.UnauthorizedAccessToSOAPMethod';
    }

    # authorization is
    sub find_target {
        my $this = shift();

        my ( $class, $method_uri, $method_name )
            = $this->SUPER::find_target(@_);
        die SOAP::Fault->new( 'faultcode' => $this->unathorized_fault_code )
            if !$this->authorize_soap_call( $class, $method_name,
            $this->current_user );
        return ( $class, $method_uri, $method_name );
    }

    sub authorize_soap_call {
        my ( $this, $class, $method_name, $user ) = @_;

        for my $auth_module ( @{ $this->authorized_by } ) {
            my $is_authorized
                = $auth_module->authorize_soap_call( $class, $method_name,
                $user );
            return $is_authorized if defined $is_authorized;
        }
        return 1;
    }

    sub make_fault {
        my ( $this, $code, @other_args ) = @_;
        if ( $code eq $this->unathorized_fault_code ) {
            $this->make_response(
                Apache::Constants::FORBIDDEN() => 'You are forbidden to use this service' );
        }
        else {
            $this->SUPER::make_fault( $code, @other_args );
        }
        return;
    }

    # 2004-07-30 danielr - temporary redefinition logging SOAP
    my $Id;

    sub handle {
        my $this = shift;
        my $r    = shift;

        $this->current_user( $r->user );
        return $this->raw_logging
            ? $this->handle_with_logging( $r, @_ )
            : $this->SUPER::handle(@_);
    }

    sub handle_with_logging {

    # danielr - I need SUPER:: to be relative to SOAP::Transport::HTTP::Apache
        package SOAP::Transport::HTTP::Apache;
{
  $SOAP::Transport::HTTP::Apache::VERSION = '1.994';
}

        my $self = shift->new;
        my $r    = shift || Apache->request;

        $self->request(
            HTTP::Request->new(
                $r->method => $r->uri,
                HTTP::Headers->new( $r->headers_in ),
                do {
                    my $buf;
                    $r->read( $buf, $r->header_in('Content-length') );
                    $buf;
                    }
            )
        );

        # danielr - radek pridany do puvodniho kodu
        my $id = $$ . '-' . ++$Id;
        $self->log_raw_data( 'Request', $id, $self->request->content );

        $self->SUPER::handle;

        # we will specify status manually for Apache, because
        # if we do it as it has to be done, returning SERVER_ERROR,
        # Apache will modify our content_type to 'text/html; ....'
        # which is not what we want.
        # will emulate normal response, but with custom status code
        # which could also be 500.
        $r->status( $self->response->code );
        $self->response->headers->scan( sub { $r->header_out(@_) } );
        $r->send_http_header( join '; ', $self->response->content_type );

        # danielr - radek pridany do puvodniho kodu
        $self->log_raw_data( 'Response', $id, $self->response->content );

        $r->print( $self->response->content );
        &Apache::Constants::OK;
    }

    sub log_raw_data {
        my ( $this, $request_response, $id, $data ) = @_;

        my $fh = FileHandle->new( '>> ' . $this->raw_logging_file )
            or die $!;
        if ( Encode::is_utf8($data) ) {
            binmode( $fh, ':utf8' );
        }

        $fh->printf( "%s - SOAP %s %s\n---------------\n%s\n\n",
            Akar::Time->new->text, $request_response, $id, $data );
        $fh->close;
    }
}


=begin COMMENT_CONFIG_VIA_APACHE_READCONFIG

sub apache_config {
    my ($this) = @_;

    my $this_package = ref($this) || $this;
    return <<"END_APACHE_CONFIG";
<Perl>
use lib '$E{ Akar::Base->perl5lib }';
use Akar::Base;
use Akar::Base::Profile;
use $this_package;
</Perl>

# 2007-11-27 danielr
# I fail to setup the configuration in one section
# It seems that some directives (LoadModule, AddModule)
# has to be processed in particular order 
# which is impossible to achieve when they are set at once
# as Apache::ReadConfig variables

<Perl>
$this_package->setup_apache_load_modules;
</Perl>

<Perl>
$this_package->setup_apache_add_modules;
</Perl>

<Perl>
$this_package->setup_apache;
</Perl>

END_APACHE_CONFIG
}

sub setup_apache_load_modules {
    my ($this) = @_;

    package Apache::ReadConfig;
    no strict 'vars';

    @LoadModule = ($this->uses_ssl? ['ssl_module', 'libexec/libssl.so']: ());
}

sub setup_apache_add_modules {
    my ($this) = @_;

    package Apache::ReadConfig;
    no strict 'vars';

    @AddModule = grep {! Apache->module($_) } 
        qw(mod_log_config.c mod_asis.c mod_access.c mod_auth.c mod_so.c
        mod_setenvif.c mod_mime.c), ( $this->uses_ssl ? 'mod_ssl.c' : () ),
        qw(mod_perl.c);
}

# Configures the Apache by setting appropriate package variables 
# in Apache::ReadConfig package
sub setup_apache {
    my ($this) = @_;

    # checks (loads) the modules in dispatch_to and authorized_by
    $this->check_modules;

    my $this_package = ref($this) || $this;

    package Apache::ReadConfig;
    no strict 'vars';

    # quoting function, I am in different package so I will use anonymous  function
    my $quote = sub {
        return join ' ', map {
            my $quoted = $_;
            if ( $quoted =~ /[\s"]/ ) {

                # only strings containing " or whitespace are quoted
                $quoted =~ s/"/\\"/g;
            }
            "\"$quoted\"";
        } @_;
    };

    #my $mod_sslc_defined = Apache->module('mod_ssl.c');
    $ServerName   = 'aurelius.in.gtsgroup.cz';
    $ServerAdmin  = 'machacep@irsay.devel.gts.cz';
    $ErrorLog     = $this->logpath('error_log');
    $TransferLog  = $this->logpath('access_log');

    $ServerType           = 'standalone';
    $ServerRoot           = $this->server_root;
    $PidFile              = $this->logpath('httpd.pid');
    $ScoreBoardFile       = $this->logpath('httpd.scoreboard');
    $Timeout              = '300';
    $MinSpareServers      = '1';
    $MaxSpareServers      = '5';
    $StartServers         = '2';
    $MaxClients           = '150';
    $MaxRequestsPerChild  = '0';
    $KeepAlive            = 'On';
    $MaxKeepAliveRequests = '100';
    $KeepAliveTimeout     = '15';

    $ServerAdmin  = 'simoniki@irsay.devel.gts.cz';
    $DocumentRoot = $this->server_path('htdocs');

    $UseCanonicalName = 'On';
    $DefaultType      = 'text/plain';
    $HostnameLookups  = 'Off';

    $ErrorLog = $this->logpath('error_log');

    $Port            = $this->port;
    $LogLevel        = 'error';
    $LogFormat = $quote->( '%h %l %u %t "%r" %>s %b', 'common' );
    $CustomLog = $quote->( $this->logpath('access_log'), 'common' );
    $ServerSignature = 'On';
    $SetHandler      = 'perl-script';
        #'PerlSetVar' => [[ 'options', "compress_threshold => 10000" ]],

    if ( $this->uses_ssl ) {
        @Listen = ( $this->port, $this->ssl_port );

        push @AddType, [ 'application/x-x509-ca-cert', '.crt' ],
            [ 'application/x-pkcs7-crl', '.crl' ];

        $SSLPassPhraseDialog    = 'builtin';
        $SSLSessionCache        = 'dbm:' . $this->logpath('ssl_scache');
        $SSLSessionCacheTimeout = '300';
        $SSLMutex               = 'file:' . $this->logpath('ssl_mutex');
        $SSLRandomSeed          = $quote->( 'startup', 'builtin' );
        $SSLRandomSeed          = $quote->( 'connect', 'builtin' );
        $SSLLog                 = $this->logpath('ssl_engine_log');
        $SSLLogLevel            = 'error';

        %VirtualHost = (
            '_default_:'
                . $this->ssl_port => {
                'SSLEngine'      => 'on',
                'SSLCipherSuite' =>
                    'ALL:!ADH:!EXPORT56:RC4+RSA:+HIGH:+MEDIUM:+LOW:+SSLv2:+EXP:+eNULL',
                'SSLCertificateFile' =>
                    $this->server_path('conf/ssl.crt/server.crt'),
                'SSLCertificateKeyFile' =>
                    $this->server_path('conf/ssl.key/server.key'),
                'CustomLog' => $quote->(
                    $this->logpath('ssl_request_log'),
                    '%t %h %{SSL_PROTOCOL}x %{SSL_CIPHER}x "%r" %b'
                )
                }
        );
    }
    
    %Location = (
        '/soap' => {
            'PerlHandler' => join('::', $this_package, 'soap_handler'),
            $this->basic_auth
            ? ( 'AuthType'     => 'Basic',
                'AuthName'     => $quote->('By Invitation Only'),
                'AuthUserFile' => $this->app_data_path('htusers.pwd'),
                'Require'      => 'valid-user'
                )
            : (),
        },
        '/wsdl' => { 'PerlHandler' => join('::', $this_package, 'wsdl_handler') }
    );
}

# installs the Apache configuration file
sub install {
    my ($this) = @_;

    mkpath( $this->logpath );
    write_file( $this->config_file, $this->apache_config);
    return;
}

=end COMMENT_CONFIG_VIA_APACHE_READCONFIG

=cut


1;


# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
