package Akar::Test::Time;
{
  $Akar::Test::Time::VERSION = '1.994';
}
use strict;
use warnings;


use base qw(Test::Class);

use Data::Dumper;
# Test::More imports: 
#   ok use_ok require_ok is isnt like unlike is_deeply
#   cmp_ok skip todo todo_skip pass fail eq_array
#   eq_hash eq_set $TODO plan can_ok isa_ok diag BAIL_OUT
use Test::More;
use Test::MockObject;
use Akar::Test::XML;
use Akar::Iconv qw(utf8_il2 il2_utf8 cp1250_utf8 cp1250_il2 utf8_cp1250);

use Akar::Time;

use Carp qw(carp croak);
$SIG{__DIE__} = \&Carp::confess;

sub tested_module { return 'Akar::Time' }

sub t01_add_months : Test(2) {
  my $this = shift;  
  
  is(Akar::Time->new('2009-08-31')->add('mon',18)->text_date,'2011-02-28',tname('2009-08-31 + 18 months'));
  is(Akar::Time->new('2009-08-20')->add('mon',18)->text_date,'2011-02-20',tname('2009-08-20 + 18 months'));
  
} 

sub tname {
  my @data = caller(1);
  my $line = (caller)[2];
  my $shortname = (split(/::/,$data[3]))[-1];
  $shortname = (split(/::/,(caller(4))[3]))[-1]
    if $shortname eq '__ANON__';
  return "$shortname($line) : ".join('',@_);
}  



1;

__END__

=head1 NAME

Akar::Test::Time - Testing class for Akar::Time

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
