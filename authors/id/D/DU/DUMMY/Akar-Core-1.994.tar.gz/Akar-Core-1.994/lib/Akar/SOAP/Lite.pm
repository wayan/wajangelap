package Akar::SOAP::Lite;
{
  $Akar::SOAP::Lite::VERSION = '1.994';
}
use strict;

=head1 NAME

Akar::SOAP::Lite - enhancing SOAP::Lite with some default settings and akar specifics

=head1 SYNOPSIS

  use Akar::SOAP::Lite;

  my $service = Akar::SOAP::Lite->service($wsdl);
  $service->basic_auth(['adslos', 'adslos']);

  my $moai_service = Akar::SOAP::Lite->akar_service(
	'package' => 'Moai::ADSLOS::Info',
	'basic_auth_magic' => 'adslos');

=head1 DESCRIPTION

Akar::SOAP::Lite adds a few akar specific functionalities to SOAP::Lite.

=over 4

=item 

sets default error handler to

	sub {
		my($soap, $som) = @_;
		die(Akar::SOAP::Exception->new($soap, $som));
	}

=item

enable user friendly settings of basic authentication for SOAP 
and service objects via basic_auth method.

=back

=head1 Methods

=over 4

=item wsdl_url

  my $url = $service->wsdl_url('Moai::ADSLOS::Info');

Returns the wdsl file for remote package according to configuration parameters.

=item akar_service

  my $service = $soap->akar_service(
	'package'		=> 'Moai::ADSLOS::Info',
	'basic_auth_magic'	=> 'adslos');

Reteurns service which wsdl is taken and basic authentication set
according to configuration parameters.

=item basic_auth

  $soap->basic_auth([$user, $passwd]);
  $service->basic_auth([$user, $passwd]);

  $soap->basic_auth;

Setter-getter for basic authentication, which then will be used for all
calls coming from service or soap object. If the authentication 
is set to undef, it is not used.

  $service->basic_auth(undef);

=back

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

use base qw(SOAP::Lite);
BEGIN {
	# 2004-07-14
	# I need default object to be of Akar::SOAP::Lite, 
	# so it will be properly cloned 
	require SOAP::Lite;
	SOAP::Lite->self(__PACKAGE__);
	SOAP::Lite->import('on_fault' => sub {on_fault_handler(@_)});

	# redefinition of stub forever
	my $orig = \ &SOAP::Schema::stub;
	local $^W;
	*SOAP::Schema::stub = sub {
		my $this = shift;
		my $stub = &$orig($this, @_);
		if ($stub){
			$stub .= <<'*PROXY_ALL*';
sub proxy_all {
# sets the proxy for all methods
	my $this = shift; 
	my($proxy) = @_;
	$$_{'endpoint'} = $proxy for values(%methods);
}
# service inherites from Akar::SOAP::Lite
@ISA = map { /^SOAP::Lite$/? 'Akar::SOAP::Lite': $_} @ISA;
sub akar_methods {
	return(\%methods);
}

# returns SOAP object for certain method
# creation of this object is normally hidden inside SERVICE->METHOD call
# 2004-11-04 literal copy from SOAP::Lite 0.60
sub soap_for_method {
    my $this    = shift;
    my($method) = @_;

    my %method = %{$methods{$method}};
    my $self = UNIVERSAL::isa($_[0] => __PACKAGE__) 
      ? ref $_[0] ? shift # OBJECT
                  # CLASS, either get self or create new and assign to self
                  : (shift->self || __PACKAGE__->self(__PACKAGE__->new))
      # function call, either get self or create new and assign to self
      : (__PACKAGE__->self || __PACKAGE__->self(__PACKAGE__->new));
    $self->proxy($method{endpoint} || Carp::croak "No server address (proxy) specified") unless $self->proxy;
    my @templates = @{$method{parameters}};
    $self
      -> endpoint($method{endpoint})
      -> uri($method{uri})
      -> on_action(sub{qq!"$method{soapaction}"!});
    $self;
}
1;
*PROXY_ALL*
			}
		return($stub);
	};

    # 2004-11-04 danielr - redefinition of SOAP::SOM::parts
    {
        package SOAP::SOM;
{
  $SOAP::SOM::VERSION = '1.994';
}
        no warnings;
        no strict 'refs';
        for my $method (qw(parts)) { 
            my $field = '_' . $method; 
            *$method = sub { 
                ## this is a problem since the new instance knows nothing about existing parts
                ### my $self = shift->new; 
                my $self = shift; 
                @_ ? ($self->{$field} = shift, return $self) : return $self->{$field}; 
            } 
        }
    }
} # BEGIN

use URI;
use Carp;
use Data::Dumper;
# use Akar::Config;
use Akar::SOAP::Exception;

sub on_fault_handler {
	my($soap, $som) = @_;

	die(Akar::SOAP::Exception->new($soap, $som));
}

sub service {
	shift->SUPER::service(@_)->on_fault( 	
		sub {on_fault_handler(@_)});
} 

# creates a service based on package and user according to Akar configuration conventions
sub akar_service {
	my $this = shift;
	my %params = @_;

	my $package = $params{'package'} or die "No package supplied\n ";
	my($subs)   = lc($package) =~ /^(.*?)::/;

	# looking for the configuration
	my $service = $this->service($this->wsdl_url($package));
	if (my $magic = $params{'basic_auth_magic'}){
		my $basic_auth = Akar::Config->get_param_or_die("$subs/soap/basic_auth/$magic");
		$service->basic_auth([@$basic_auth{qw(username auth)}]);
	}
	return($service);
}


# returns URL to WSDL file for package
sub wsdl_url {
	my $this = shift;
	my($package) = @_;

	my($subs)   = lc($package) =~ /^(.*?)::/;
	return(Akar::Config->get_param_or_die("$subs/soap/package/$package/wsdl"));
}

# sets the basic authentication
sub basic_auth {
	my $this = shift->new;
	my $fld = '_akar_basic_auth';
	return(@_? do { $$this{$fld} = $_[0]; $this} : $$this{$fld});
}

# redefinition of call - to be able to process basic_auth
sub call {
	my $this = shift;
	my $basic_auth = $this->basic_auth 
	or return($this->SUPER::call(@_));

	# with basic auth
	local *SOAP::Transport::HTTP::Client::get_basic_credentials = sub {
		return(@$basic_auth);
	};
	return($this->SUPER::call(@_));
}

1;

__END__

#old approach
# enhances all proxys with basic autentication
sub endpoint {
	my $this = shift;
	$this->SUPER::endpoint($this->_modify_url_ba(@_));
}

sub proxy {
	my $this = shift;
	$this->SUPER::proxy($this->_modify_url_ba(@_));
}

sub _modify_url_ba {
	my $this = shift;
	if (ref($this) and @_ and not(ref($_[0])) and my $auth = $this->basic_auth){
		my $url = URI->new(shift(@_));
		$url->userinfo(join(':', @$auth)) unless $url->userinfo;
		unshift(@_, $url. '');
	}
	return(@_);
}

sub akarize {
	my $this = shift;
	my($package) = @_;

	my $new_package = $package . '_akarized';	
	no strict 'refs';
	for my $method (@{"${package}::EXPORT_OK"}){
		my $qualified = $package . '::'. $method;
		*{"${new_package}::$method"} = sub {
			my $this = shift;

			my $auth = $this->basic_auth;
			local *SOAP::Transport::HTTP::Client::get_basic_credentials = sub { 
    				return(@$auth);
			} if $auth;
			return($this->$qualified(@_));
		}; 
	}
	*{"${new_package}::ISA"} = [$package];

	# ->basic_auth([$user, $pwd]) sets basic autentication for service, returns service
	# ->basic_auth() returns [$user, $pwd] array reference
	# ->basic_auth(undef) resets the autentication, so it is not used
	*{"${new_package}::basic_auth"} = sub {
		my $this = shift;
		if (my($auth) = @_){
			$$this{'_akar_basic_auth'} = $auth;
			return($this);
		}
		else {
			return($$this{'_akar_basic_auth'});
		}
	};
	return($new_package);
}
