package Akar::PL_SQL::Type::Record;
{
  $Akar::PL_SQL::Type::Record::VERSION = '1.994';
}
use strict;

use base qw(Akar::PL_SQL::Type::Base);
__PACKAGE__->mk_ro_accessors(qw(fields));

use Akar::PL_SQL::Caller::Functions qw(psql_value indent2);

sub new_type {
    my ($proto, $params) = @_;

    my $fields = $$params{'fields'} || {};
    $fields = map(($_ => Akar::PL_SQL::Type->new_type), @$fields)
      if UNIVERSAL::isa($fields, 'ARRAY');

    #$_ = psql_sql for grep(!ref($_), values(%$fields));
    $$params{'fields'} = $fields;
    $proto->SUPER::new_type($params);
}

sub dump_input_value {
    my ($this, $value) = @_;

    indent2(
        $this->name . "(" . join(
            ",",
            map {
                my $the_value = indent2(psql_value($$value{$_})->dump);
                "\n$_ => $the_value";
              } keys %$value
          )
          . ")"
    );
}

1;
