package Akar::PL_SQL::Type::Sequence;
{
  $Akar::PL_SQL::Type::Sequence::VERSION = '1.994';
}
use strict;

use base qw(Akar::PL_SQL::Type::Base);

# base type of sequence
__PACKAGE__->mk_ro_accessors(qw(base_type));
use Akar::PL_SQL::Caller::Functions qw(psql_value indent2);

sub dump_input_value {
    my ($this, $value) = @_;

    indent2(
        $this->name . "(" . join(
            ",",
            map {
                my $the_value = indent2(psql_value($_)->dump);
                "\n$the_value";
              } @$value
          )
          . ")"
    );
}

1;
