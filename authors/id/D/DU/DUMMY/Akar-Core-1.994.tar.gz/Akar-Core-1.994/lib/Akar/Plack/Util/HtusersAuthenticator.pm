package Akar::Plack::Util::HtusersAuthenticator;
{
  $Akar::Plack::Util::HtusersAuthenticator::VERSION = '1.994';
}
use Moose;

# very simple class producing authenticator sub
# for Apache htusers.pwd based Basic authentication
use File::Slurp qw(slurp);

has file => (is => 'ro', required => 1);


sub authenticator {
    my $this = shift;

    my $file = $this->file;
    my ( $content, $mtime );

    return sub {
        -r $file or return;

        # if the file is modified, content is reread
        my $new_mtime = ( stat $file )[9];
        if ( !$mtime || $new_mtime != $mtime ) {
            $mtime   = $new_mtime;
            $content = {
                map { chomp $_; split /:/, $_, 2 }
                grep { /\S/ && !/^\s*#/ } slurp($file)
            };
        }

        my ( $user, $password ) = @_;
        my $crypted = $content->{$user} or return 0;
        my ($salt) = $crypted =~ /^(..)/;
        return crypt( $password, $salt ) eq $crypted;
    };
}

around authenticator => sub {
    my $orig = shift;
    my $this = shift;

    return blessed($this) ? $this->$orig(@_) : $this->new(@_)->$orig;
};

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
