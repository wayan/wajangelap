package Akar::DBI::Statement::LegacyInterface;
{
  $Akar::DBI::Statement::LegacyInterface::VERSION = '1.994';
}
use strict;
use warnings;

# old deprecated interface
use base qw(Class::Accessor);
__PACKAGE__->mk_accessors(qw(dbh sth));

sub sth {
    my ($this) = @_;
   
    my $sth = $this->_sth_accessor;
    if (!$sth){
        $sth = $this->dbh->prepare( $this );
        $this->_sth_accessor($sth);
    } 
    return $sth;
}

=item execute

  $statement->execute

Prepares statement handle, performs all bindings and calls execute on the handle. 

=cut

sub execute {
    my ($this) = @_;

    my $sth = $this->sth;
    #$this->bind_all_params($sth);
    return $sth->execute;
}

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
