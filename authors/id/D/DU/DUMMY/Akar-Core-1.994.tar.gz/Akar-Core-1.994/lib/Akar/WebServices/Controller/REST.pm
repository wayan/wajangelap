package Akar::WebServices::Controller::REST;
{
  $Akar::WebServices::Controller::REST::VERSION = '1.994';
}
use Moose;

BEGIN { extends 'Catalyst::Controller::REST' }

with 'Akar::WebServices::Controller::AssertUserRoles',
    'Akar::WebServices::Controller::Statuses';

use Params::Validate;

# very simple REST controller - the serialization/deserialization
# is left to root controller

# 
sub base : Chained('../base') : PathBasename : CaptureArgs(0) {
}

# I want that pa
sub _parse_PathBasename_attr {
    my ( $this, $c ) = @_;

    my ($path_part) = reverse split m{/}, $this->path_prefix($c);
    return PathPart => $path_part;
}

# begin/end is here to cancel inherited attributes
sub begin { }

sub end { }

# READER and WRITER are names of elements from schema
sub _parse_READER_attr {
    my ( $this, $c, $name, $value ) = @_;

    return ( 'READER', $value );
}

sub _parse_WRITER_attr {
    my ( $this, $c, $name, $value ) = @_;

    return ( 'WRITER', $value );
}

sub validate_with {
    my $this = shift;
    my $c    = shift;

    Params::Validate::validate_with(
        on_fail => sub {
            $this->status_unprocessable_entity( $c, message => shift() );
            $c->detach;
        },
        called => $c->req->method . ' on ' . $c->action,
        @_
    );
}


__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

