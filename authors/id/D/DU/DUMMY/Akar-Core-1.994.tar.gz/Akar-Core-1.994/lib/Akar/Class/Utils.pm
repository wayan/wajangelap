package Akar::Class::Utils;
{
  $Akar::Class::Utils::VERSION = '1.994';
}
use strict;

use base qw(Exporter);

# very miscellaneous utilitites - nothing exported on demand
our @EXPORT_OK = qw(singleton_accessor autodefine_accessor inh_classdata_accessor
    require_package
    add_singleton_method make_named_sub lexical_cleaner
    wrap_method
    find_defining_package);

use Carp qw(croak);
use Scalar::Util qw(blessed refaddr reftype);
use List::MoreUtils qw(first_value);
use Class::ISA;

# finds the package where the method is located
sub find_defining_package {

    my ( $obj_or_package, $method_name ) = @_;

    # stupid way
    my $method_code = $obj_or_package->can($method_name)
        or return;
    my ($defining_package) = first_value {
        my $super_code = $_->can($method_name);
        $super_code && refaddr($super_code) == refaddr($method_code);
        }
        reverse Class::ISA::self_and_super_path( ref($obj_or_package)
            || $obj_or_package );
    return $defining_package;
}

sub singleton_accessor {
    my $value;

    return sub {
        my ( $this, $new_value ) = @_;

        if ( @_ == 1 ) {

            # getter
            return $value;
        }
        elsif ( @_ == 2 ) {

            # setter
            $value = $new_value;
            return $this;
        }
        else {
            croak("Invalid number of parameters to singleton accessor\n ");
        }
    };
}

sub autodefine_accessor {
    my ( $accessor_sub, $define_sub ) = @_;

    return sub {
        my ( $this, $new_value ) = @_;

        return $this->$accessor_sub($new_value) if @_ > 1;    # setter

        my $value = $this->$accessor_sub;
        if ( !defined($value) ) {
            $value = $this->$define_sub;
            $this->$accessor_sub($value);
        }
        return $value;
        }
}

# inheritable class data
sub inh_classdata_accessor {
    my %set_for;
    my %inherited_for;

    return sub {
        my ( $this, $new_value ) = @_;

        my $package = ref($this) || $this;

        if ( @_ == 1 ) {

            # value may be set for package or inherited
            return $set_for{$package} if exists $set_for{$package};
            return $inherited_for{$package}
                if exists $inherited_for{$package};

            my ($super_class) = sort { $a->isa($b) ? -1 : 1 }
                grep { $package->isa($_) } keys %set_for
                or return;
            return $inherited_for{$package} = $set_for{$super_class};
        }
        else {

           # everytime a value is set, all inherited values are computed again
            undef(%inherited_for);
            return $set_for{$package} = $new_value;
        }
    };
}

# requires package on demand, the package may already be present
# the way is copied from base pragma module
sub require_package {
    no strict 'refs';
    my ($package) = @_;

    my $vglob;
    if ( $vglob = ${"$package\::"}{'VERSION'} and *$vglob{'SCALAR'} ) {
        $$vglob = "-1, set by " . __PACKAGE__ unless defined $$vglob;
    }
    else {
        eval "require $package";

        # Only ignore "Can't locate" errors from our eval require.
        # Other fatal errors (syntax etc) must be reported.
        die if $@ && $@ !~ /^Can't locate .*? at \(eval /;

        # package namespace is not present yet
        unless ( %{"$package\::"} ) {
            require Carp;
            Carp::croak(
                "Package \"$package\" is empty.\n",
                "\t(Perhaps you need to 'use' the module ",
                "which defines that package first.)"
            );
        }
        ${"$package\::VERSION"} = "-1, set by " . __PACKAGE__
            unless defined ${"$package\::VERSION"};
    }
}

# copied from Advaced Perl Programming by Simon Cozens (2nd edition p 24, 25)

my $SINGLETON_SUFFIX = '::singleton';

# the number of singleton packages derived from a package (hash key)
my %singletons_from;

sub add_singleton_method {
    my ( $obj, $method, $subref, $options ) = @_;

    $options ||= {};
    blessed($obj) && reftype($subref) eq 'CODE'
        or croak "add_singleton_method(\$obj, \$method => \$subref)\n ";

    # if true then package is deleted when object is destroyed
    my $delete_package = $options->{'clean_when_destroy'};

    my $package = ref($obj);
    my $singleton_package = $package =~ /$SINGLETON_SUFFIX(\d+)$/
        ? $package
        : $package . $SINGLETON_SUFFIX . (++$singletons_from{$package});

    no strict 'refs';
    if ( $singleton_package ne $package ) {
        *{ $singleton_package . '::ISA' } = [$package];
        bless( $obj => $singleton_package );

        if ($delete_package) {
            require Symbol;
            my $orig_destroy_sub = $obj->can('DESTROY');
            *{ $singleton_package . '::DESTROY' } = sub {
                my ($this) = @_;

                if ($orig_destroy_sub) {
                    $this->$orig_destroy_sub;
                }

                Symbol::delete_package($singleton_package);
            };
        }
    }

    *{ $singleton_package . '::' . $method } = $subref;
}

sub wrap_method {
    my ($obj_or_pkg, $method, $subref, $options) = @_;

    my $package = ref($obj_or_pkg) || $obj_or_pkg;
    my $orig_code = $package->can($method)
        or croak "No $package->$method found, nothing to wrap\n ";

    my $wrapper = sub {
        # the orig_method is passed as last parameter
        push @_, $orig_code;
        goto $subref;
    }; 

    if ( ref($obj_or_pkg) ) {

        # called on object adds a singleton
        add_singleton_method( $obj_or_pkg, $method, $wrapper, $options );
    }
    else {  
        # called on package adds a new method to the package
        no strict 'refs';
        *{ join '::', $obj_or_pkg, $method } = $wrapper;
    }
    return $wrapper;
}

# I keep all closures in package level array
# because they are referenced from named subs and I want to avoid warning
# Variable "%s" will not stay shared
my @closures;

sub make_named_sub {
    my ( $qname_or_glob, $closure ) = @_;

    # qualified name may be glob
    my $qname = reftype( \$qname_or_glob ) eq 'GLOB'
        ? substr( $qname_or_glob, 1 )    # strips '*'
        : $qname_or_glob;

    my ($name) = $qname =~ /([^:]+)$/;
    my $package = $qname =~ /^(.+)::/ ? $1 : caller;

    if ( !$closure ) {

        # if closure is not supplied I suppose to find it in the symbol table
        no strict 'refs';
        $closure = *{ $package . '::' . $name }{'CODE'};
    }

    push @closures, $closure;
    my $closure_idx = $#closures;

    my $code = <<"END_CODE";
        package $package;
        sub $name {
            goto \&{\$closures[$closure_idx]};
        }
END_CODE

    eval $code;
    croak "make_named_sub failed for $package\:\:$name: $@" if $@;
    return;
}

sub lexical_cleaner(&;@) {
    my ( $sub, @args ) = @_;

    reftype $sub eq 'CODE'
        or croak "lexical_cleaner(\$subref)\n ";

    defined(wantarray)
        or croak "lexical_cleaner is called in void context\n ";

    return bless sub { $sub->(@args) } => 'Akar::Class::Utils::LexCleaner';
}

sub Akar::Class::Utils::LexCleaner::DESTROY {
    my ($this) = @_;
    local $@;
    eval { $this->(); }
}

1;

__END__

=head1 NAME

Akar::Class::Utils - miscellaneous class utilities

=head1 FUNCTIONS

All following functions are imported on demand.

=over 4

=item require_package($package)

Ensures the package to be loaded, using require eventually.
It was copied from C<base> pragma module but the required_package
is not use as base class.

=item add_singleton_method($obj, $method, $subref)

  my $super_open = $obj->can('open');
  add_singleton_method($obj1, 'open', sub {
        my ($this) = @_;

        my $fh = $this->$super_open('r');
        $fh->print($this->header);

        return $fh;
    });

Adds method with $name into object $obj (reblesses $obj), 
$subref is a reference to method subroutine.

=item make_named_sub($name_or_globref, $closure)

When a trait is applied the methods in trait package which come (were imported) 
from other packages are not imported into the target class.

While it is usually usefull, sometimes you want to treat some method
as the trait's own. 

c<make_named_sub> actually create a new wrapper sub in target package 
which calls the original sub.

It can be used as:

  make_named_sub($qname => $closure);

where $qname is qualified name or

  make_named_sub(\*glob => $closure);
  make_named_sub(\*glob);

In this case make_named_sub changes sub which already exists
in the symbol table.

=item lexical_cleaner($sub, @args)

given sub returns object which DESTRUCTOR call this sub
use it to ensure lexical validity of something.

    {
        my $f = Something->open;
        # close is called even if current block fails
        my $cleaner = lexical_cleaner(sub {$f->close});
        .....

  }

=item wrap_method($obj_or_pkg, $method, $subref)

    {
        package Department;

        my %Salary = (
            'wayan' => 70000,
            'body'  => 16000,
            ...
        );

        sub salary {
            my ($this, $employee) = @_;
        
            return $Salary{$employee};
        }
    }

    use Akar::Class::Utils qw(wrap_method);

    warn Department->salary('wayan');   # yields 70000
    warn Department->salary('body');    # yields 16000

    wrap_method(
        'Department', 'salary',
        sub {
            my $orig_sub = pop(@_);

            my ($this, $employee) = @_;
            return $employee eq 'wayan'? 100000: $this->$orig_sub($employee); 
            # since $orig_sub is a code ref
            # it is equivalent to $orig_sub->($this, $size);
        }
    );

    warn Department->salary('wayan');   # yields 100000
    warn Department->salary('body');    # yields 16000


When called with object like first parameter works like add_singleton_method,
when called with package install the $method (name) into $obj_or_pkg 
namespace.

If both cases when $subref is called it is given the original method as the last
parameter.

=back

=cut

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96:
