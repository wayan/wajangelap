package Akar::SOAP::Service;
{
  $Akar::SOAP::Service::VERSION = '1.994';
}

=head1 NAME

Akar::SOAP::Service - publishing of Perl package as SOAP service via WSDL

=head1 SYNOPSIS

  package MyService;
  use strict;

  use Akar::SOAP::Service;
  use Akar::SOAP::Method;
  use Akar::SOAP::Param;

  # SOAP service implemented by MyService package 
  # Following new can be omitted, in such case the minimal Akar::SOAP::Service # object
  # is created automatically by Akar::SOAP::Method->new 
  
  Akar::SOAP::Service->new('doc' => il2_utf8('Detailed phone statement processing')); 

  Akar::SOAP::Method->new('process_statement')
    ->doc('receives request for statement to be processed')    
    ->params([
        Akar::SOAP::Param->new('statementRequest')
                    ->doc('selection of calls to be included to statement'), 
        ])
    ->output_params([
        Akar::SOAP::Param->new('statementId')
            ->type('xsd:integer')
                    ->doc('id of statement for later identification') 
        ])
    ->body(
  sub { 
  ....
  });

=head1 DESCRIPTION

Akar::SOAP::Service is very simple WSDL creator for Perl package implementing SOAP service.

=head1 METHODS

=over 4

=item new(KEY=>VALUE, KEY=>VALUE)

Constructor. KEYs are the names of setter-getters mentioned further.

=item doc

=item documentation

  Akar::SOAP::Method->new->doc("Creates a detailed phone call statement");

Setter - getter for service WSDL documentation. 

=item package 

Getter for the package implementing the service. Caller's package by default.
Can be set by new only.

=item get_by_package(PACKAGE, AUTO_CREATE)

  my $service = Akar::SOAP::Service
    ->get_by_package('Durian::SAPI::Phone::Statement', 1)

Static method. Returns Akar::SOAP::Service object for given PACKAGE. If object doesn't exist and AUTO_CREATE is 1 
then object is created automatically.

=item create_wsdl(LOCATION)

  Akar::SOAP::Service
    ->get_by_package('Durian::SAPI::Phone::Statement')
    ->create_wsdl('http://irsay:8882/wsdl/Durian/SAPI/Phone/Statement');

Returns string containing WSDL file generated for the service. 
LOCATION is the URI of resulting WSDL (has to of http[s] scheme).


=back 

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

use strict;

use base qw(Class::Accessor);

use Akar::Text::Mason;
use Akar::Base;
use Akar::Property qw(package methods|_methods 
    documentation documentation|doc 
    types);

__PACKAGE__->mk_accessors(qw(package methods documentation types));
sub set { my $this = shift; $this->SUPER::set(@_); $this } 
sub doc { shift()->documentation(@_) } # synonym

my %all_services;

sub get_by_package {
    my $this = shift;
    my($package, $auto_create) = @_;

    return($all_services{$package} 
        or $auto_create && $this->new('package' => $package));
}

# one package - one service 
sub new {
    my $proto = shift;
    my %fields = @_;

    my $package = $fields{'package'} ||= caller;
    not($all_services{$package})
    or die "Akar::SOAP::Service for package $package is already defined\n ";
    $fields{'methods'} ||= {};
        
    # I change the package so its ISA contains SOAP::Server::Parameters 
    # and SOAP::Lite push SOM as last parameter of every call
    UNIVERSAL::isa($package, 'SOAP::Server::Parameters')
    or do {
        no strict 'refs';
        push @{$package .'::ISA'}, 'SOAP::Server::Parameters';
    };

    # service is registered
    $all_services{$package} = $proto->SUPER::new(\%fields);
}

# methods used for WSDL generation
my $sep = '.';
sub ident { join($sep, split(/::/, shift()->package)) }

sub urn { 'perl:'. join('/', split(/::/, shift()->package)) }

# array shortcut
sub methods {
    my $this = shift;

    not(@_) && wantarray
        ? values(%{$this->_methods_accessor || {}})
        : $this->_methods_accessor(@_);
}

sub add_method {
    my $this = shift;
    my($method) = @_;
    
    $this->methods->{$method->name} = $method;
}

sub method {
    my $this  = shift;
    my($name) = @_;

    $this->methods->{$name};
}

sub create_wsdl {
    my $this = shift;
    my($location) = @_;

    Akar::Text::Mason->process_file(
        Akar::Base->app_home('lib/mason/Akar/SOAP/WSDL.mc'),
        'service'  => $this,
        'location' => $location);    
}

1;

