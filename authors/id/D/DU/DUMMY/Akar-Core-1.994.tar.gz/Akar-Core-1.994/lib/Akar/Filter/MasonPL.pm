package Akar::Filter::MasonPL;
{
  $Akar::Filter::MasonPL::VERSION = '1.994';
}
use strict;

=head1 NAME

Akar::Filter::Mason - Filtering PL files via Mason 

=head1 SYNOPSIS

File: statement.doc.PL

  use File::Spec;
  use Akar::Base;
  use Durian::Phone::Statement;
  use Akar::Filter::Mason; # code below this line is processed by Mason 
  <%once>
  use Sys::Hostname qw(hostname);
  </%once>
  <article>
  ...
      This article was processed on <% hostname() %>
  </article>

Processed by

  perl statement.doc.PL  # outputs to statement.doc
  perl statement.doc.PL statement2.doc  # outputs to statement2.doc
  perl --param date='2004-10-11' --param type=ANY

=head1 DESCRIPTION

The lines after C<use Akar::Filter::MasonPL;> until the end of the current
source file are processed as a Mason component. 

The result of processing is written to file, which name is supplied as a script argument. 
Without arguments output file is determined by stripping F<.PL> suffix from
the name of script.

Parameters can be passed to component via C<--param> line option.

  --param KEY1=VALUE1 --param KEY2=VALUE2


=cut

use Filter::Util::Call;
use FileHandle;
use Getopt::Long qw(GetOptions);
use File::Spec;

use base qw(Akar::Filter::MasonPL::Base);

# variables to be localized
our $Propagated;
our %Created_ofiles;

# accessors (I dont' want to be dependent on Class::Accessor or anything else
BEGIN {
    for my $property (qw(buffer ifile is_propagated params ofile component)) {
        my $sub = sub {
            my $this = shift;
            @_
              ? do { $$this{$property} = $_[0]; $this }
              : $$this{$property};
        };
        no strict 'refs';
        *$property = $sub;
    }
}

sub new {
    my ($package, $fields) = @_;

    $fields ||= {};
    $$fields{'buffer'} = '';
    bless($fields, $package);
}


# default output file is input file with .PL suffix stripped
sub default_ofile {
    my ($this, $ifile) = @_;

    my $ofile = $ifile;
    $ofile =~ s/\.PL$//
      or die "use "
      . __PACKAGE__
      . " can be used from *.PL files only,\n"
      . "not from "
      . $ifile . "\n";
    $ofile;
}

sub import {
    my $package = shift;

    if ($Propagated) {
        filter_add($Propagated);
        undef($Propagated);
    }
    else {
        local $SIG{__WARN__} = sub { die @_; };
        my %params;
        GetOptions('param=s%' => \%params) or die "Invalid params\n ";

        my $ifile = (caller)[1];
        my $ofile = @ARGV ? $ARGV[0]: $package->default_ofile($ifile);
        filter_add(
            $package->new(
                {
                    'ifile'  => $ifile,
                    'ofile'  => $ofile,
                    'params' => [%params],
                }
            )
        );
    }
}

sub filter {
    my ($this) = @_;

    my $status = filter_read();
    if ($status == 0) {

        # the end of file
        my $component = $this->make_component('comp_source' => $this->buffer);
        $this->set_component_source_file($component, $this->ifile);
        $this->component($component);

        # the propagated files are processed in caller's scope not here
        unless ($this->is_propagated) {
            local %Created_ofiles = (%Created_ofiles, $this->ofile => 1);
            $this->process;
        }
    }
    elsif ($status > 0) {

        # an ordinary line
        $this->buffer($this->buffer . $_);
        $_ = '';
    }
    $status;
}

# the file to write is determined
# 1. from argument if any
# 2. from caller's file by stripping .PL suffix if present
sub process {
    my ($this) = @_;

    warn 'writing into file ' . $this->ofile . "\n";
    my $fh = FileHandle->new("> " . $this->ofile);
    $fh->print($this->process_comp($this->component, @{$this->params}));
    $fh->close;
}

sub filename {
    my ($this, $ifile, @params) = @_;

    $this->filename_io($ifile, $this->default_ofile($ifile), @params);
}

sub filename_io {
    my ($this, $ifile, $ofile, @params) = @_;

    my $package = ref($this) || $this;
    $ifile = $this->rel2abs($ifile);
    $ofile = $this->rel2abs($ofile);

    unless ($Created_ofiles{$ofile}) {
        my $filter = $package->new(
            {
                'ifile'         => $ifile,
                'ofile'         => $ofile,
                'params'        => \@params,
                'is_propagated' => 1,
            }
        );
        local $Propagated     = $filter;
        local %Created_ofiles = (%Created_ofiles, $ofile => 1);

        do($filter->ifile);
        die $@ if $@;
        $filter->process;
    }

    $ofile;
}

sub comp {
    my ($this, $ifile) = @_;

    my $package = ref($this) || $this;
    my $filter = $package->new(
        {
            'ifile'         => $this->rel2abs($ifile),
            'is_propagated' => 1
        }
    );

    local $Propagated = $filter;
    do($filter->ifile);
    die $@ if $@;

    $filter->component;
}

# a modification warning - notify user about processed file
sub mod_warning {
    my ($this) = @_;

    my $file = $this->get_component_source_file(HTML::Mason::Request->instance->current_comp)
      or die "Can't find component file\n";

    my @warning = (
        "This file was generated automatically from '$file'",
        "at " . localtime() . ",",
        "don't modify it or your changes will be lost"
    );

    wantarray
      ? @warning
      : join(' ', @warning);
}


=head1 Functions to be used inside Mason code

=over 4 

=item PL_filename(INPUT_FILE, @COMPONENT_PARAMS);

  <% PL_filename('tbl_customer.sql.PL') %>

Processes another PL file and returns the processed file name (F<tbl_customer.sql>).
Relative input file path is evaluated relatively to current PL file.

=item PL_filename_io(INPUT_FILE, OUTPUT_FILE, @COMPONENT_PARAMS);

  <% PL_filename_io('tbl_customer.sql.PL', 'tbl_partner.sql', 'name' => 'partner') %>

Same as PL_filename, but output filename is passed, not determined automatically.

=item PL_comp(INPUT_FILE, @COMPONENT_PARAMS)

    <% +PL_comp('tbl_customer.PL') %>

Creates and inserts Mason component created from PL file.
The C<+> sign in example forces Mason to evaluate C<PL_comp> 
as expression not a component path.

=back

=cut

sub HTML::Mason::Commands::PL_filename { __PACKAGE__->filename(@_) }

sub HTML::Mason::Commands::PL_filename_io { __PACKAGE__->filename_io(@_) }

sub HTML::Mason::Commands::PL_comp { __PACKAGE__->comp(@_) }

sub HTML::Mason::Commands::PL_mod_warning { __PACKAGE__->mod_warning(@_) }

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz> 

=cut

# vim: ts=4:et:sts=0:tw=96

1;
