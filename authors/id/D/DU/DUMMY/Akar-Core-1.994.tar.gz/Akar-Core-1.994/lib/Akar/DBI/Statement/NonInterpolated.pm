package Akar::DBI::Statement::NonInterpolated;
{
  $Akar::DBI::Statement::NonInterpolated::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);
use base qw(Akar::DBI::Statement::Object);

use List::Util qw(sum);
use Akar::DBI::Statement::Interpolated;

sub has_param {
    my ($this, $param_name) = @_;

    for my $elem ($this->elements){
        return 1 if $elem->has_param($param_name);
    }
    return;
}

sub replace_param {
    my ( $this, $param_name, $replacement ) = @_;

    return sum map { $_->replace_param( $param_name, $replacement ) }
        $this->elements;
}

1;

__END__

=head1 NAME

Akar::DBI::Statement::NonInterpolated - base class for statements consisting of other statements

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
