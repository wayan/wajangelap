package Akar::Trait::PackageConfig;
{
  $Akar::Trait::PackageConfig::VERSION = '1.994';
}
use strict;
use warnings;


use Class::Trait qw(base);

use Carp qw(carp croak);
use Akar::PackageConfig;
use Akar::List::Utils qw(pop_options);

sub package_config {
    my ($this) = @_;
    my $class_called = ref($this) || $this;

    my $stored_method = '_stored_package_config';

    # I keep class which declared the package config together with the package
    # config
        my ( $package_config, $class_declared ) =
          $class_called->can($stored_method)
        ? $class_called->$stored_method
        : ();

    return $package_config
        if $package_config && $class_called eq $class_declared;

    my $new_package_config = Akar::PackageConfig->new( $class_called,
        { $package_config ? ( 'parent_config*' => $package_config ) : (), } );
    no strict 'refs';
    *{ $class_called . '::' . $stored_method } = sub {
        return ( $new_package_config, $class_called );
    };
    return $new_package_config;
}

my $add_config_param = sub {
    my $add_method = shift;
    my ($class) = map { ref($_) || $_ } shift;
    my $name    = shift;
    my $options = pop_options( \@_ ) || {};

    my $package_config = $class->package_config;
    $package_config->$add_method( $name, @_ );

    # the name of subroutine it is used to access the value
    my $accessor_name = $options->{'reader'} || $name;
    my $accessor = sub {
        shift();
        return $package_config->$name(@_);
    };
    no strict 'refs';
    *{"${class}::$accessor_name"} = $accessor;

    # 2008-03-23 danielr
    # I had to add legacy name - should not be used
    *{"${class}::get_${accessor_name}_or_die"} = $accessor;
    };

# creates new configuration parameter
sub add_config_param { $add_config_param->('add_param', @_);   }

sub add_optional_config_param { $add_config_param->('add_optional_param', @_);   }

# creates new configuration mapping
sub add_config_mapping { $add_config_param->('add_mapping', @_); }

1;

__END__

=head1 NAME

Akar::Trait::PackageConfig - very simple package based configuration 

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
