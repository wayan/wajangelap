package Akar::DBIC::Result::ExtendResultSetClass;
{
  $Akar::DBIC::Result::ExtendResultSetClass::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(DBIx::Class);

use Carp qw(carp croak);
use Sub::Name;

# creates resultset class specific for a particular result class
# so it can be changed without affecting other result classes
# can add methods to this resultset class
sub extend_resultset_class {
    my $class = shift;

    my $private_rs_class = _private_rs_class($class, $class->resultset_class);
    # adding methods
    while (@_){
        my $method = shift;
        my $code   = shift;

        my $qname = $private_rs_class . '::'. $method;
        no strict 'refs';
        no warnings 'redefine';
        *$qname = Sub::Name::subname( $qname, $code);
    }
    return $private_rs_class;
}

sub _private_rs_class {
    my ( $class, $rs_class, $suffix ) = @_;

    my $private_rs_class
        = $class . '::_private_resultset' . ( $suffix || '' );

    # already defined
    return $private_rs_class if $rs_class eq $private_rs_class;

    # very hypothetical possibility I want to prevent circular
    # hierarchy
    return _private_rs_class( $class, $rs_class, $suffix ? $suffix++ : 2 )
        if $rs_class->isa($private_rs_class);

    # defining the class
    no strict 'refs';
    @{ $private_rs_class . '::ISA' } = ($rs_class);
    $class->resultset_class($private_rs_class);

    return $private_rs_class;
}


1;

__END__

=head1 NAME

Akar::DBIC::Result::ExtendResultSetClass - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
