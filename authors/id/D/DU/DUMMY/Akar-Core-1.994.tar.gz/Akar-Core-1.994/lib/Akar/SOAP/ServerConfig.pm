package Akar::SOAP::ServerConfig;
{
  $Akar::SOAP::ServerConfig::VERSION = '1.994';
}
use strict;
use warnings;

=head1 NAME

Akar::SOAP::ServerConfig - instance of SOAP server (Apache + SOAP::Lite) configuration

=head1 SYNOPSIS

  # this module is used mainly from Akar::SOAP::ServerConfig
  
  my $config = Akar::SOAP::ServerConfig->new('test');
  $config
    ->port(3001)
    ->auth(['config'])
    ->dispatch_to([qw(
        Durian::SAPI::Phone::Statement 
        Durian::SAPI::Phone::Number)])
  $config->install;
  $config->save;

=head1 DESCRIPTION

Instance of Akar::SOAP::ServerConfig represents a configuration of 
SOAP server based on Apache and Perl SOAP::Lite. 

You can manipulate with the configuration, 
modify list of modules which SOAP server dispatches to (dispatch_to), 
modify dispatching rules (dispatch_with), 
modify users for basic authentication.

Finally you can create Apache configuration file and Apache controller based 
on the configuration.

=head1 METHODS

=over 4

=item new(NAME, KEY1=>VALUE1, KEY2=>VALUE2)

Constructor.

=item load(NAME)

  my $config = Akar::SOAP::ServerConfig->load();
  my $config = Akar::SOAP::ServerConfig->load('test');

Loads and returns named configuration. 

=item save
    
  $config->save;

Saves the configuration into CONFIG_HOME/instance.pm file.

=item install

  $config->install;

Creates home directory for the configuration, 
directory for Apache logs and Apache configuration file.

=item uninstall

Deletes home directory for the configuration.

=item run_apache_action(ACTION)

  $config->run_apache_action('stop')

Creates Apache runner on the fly and runs respective action on it.

=back

The following methods are setter-getter with some added semantics.

=over 4

=item port

Port on which Apache will listen. Has to be supplied for valid configuration.

=item ssl_port

SSL port on which Apache will listen. When not supplied PORT + 1 is used. 

=item dispatch_to

  $config->dispatch_to([qw(
    +Durian::SAPI::Phone::Statement 
    -Durian::SAPI::Phone::Process)]);
  $config->dispatch_to([qw(
    Durian::SAPI::Phone::Statement 
    Durian::SAPI::Phone::Process)]);

List of package names. When set, you can add, resp. remove packages to current configuration 
by prepending package name with '+', resp. '-' sign.

=item dispatch_with

  $config->dispatch_to({'http://www.openuri.org/' => 'Durian::SAPI::Phone::Statement'})

Hash with mapping from URIs to package names used by SOAP::Lite for dispatching.

=item auth

  $config->auth(['basic', 'file=/usr/myusr.pwd', 'config']);
  $config->auth(['none']);

Sets the authorization. Currently understands basic authorization only.
If set to none, no authorization is used.
If set to config, then basic authorization (users and their passwords)
are read from conofiguration.
If set to file=FILE then file (Apache passwords file) is read
and appended (same users are rewritten) to current passwords file.

=item raw_logging 

When set (Akar-SOAP-Manager --raw_logging) the raw non deserialized 
SOAP requests and serialized SOAP responses are logged into SOAP_raw_data.log
file in Apache logs directory.

=back

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

use base qw(Class::Accessor);

use File::Path qw(mkpath rmtree);
use File::Basename qw(dirname basename);
use File::Temp; 
use File::Spec;
use Carp qw(croak carp);
use Sys::Hostname qw(hostname);
use List::MoreUtils qw(uniq);

use Akar::Base;
use File::Slurp qw(write_file);
use Akar::SOAP::ServerConfig::BasicAuth;
use Interpolation 'E' => 'eval';

use constant 'DEFAULT_NAME'  => 'default';
use constant 'INSTANCE_FILE' => 'instance.pm';

# maximum waiting period until Apache dies
use constant 'APACHE_DEATH_TIMEOUT' => 20;

# initial period of waiting for apache deathe (very unimportant constant)
use constant 'APACHE_DEATH_START_WAIT' => 0.1,    # 0.1 second

__PACKAGE__->mk_ro_accessors(qw(name));
__PACKAGE__->mk_accessors(qw(port ssl_port));
__PACKAGE__->mk_accessors(qw(dispatch_to dispatch_with));
__PACKAGE__->mk_accessors(qw(basic_auth));
__PACKAGE__->mk_accessors(qw(raw_logging));

# if single_request is set then only one request is served by child 
__PACKAGE__->mk_accessors(qw(single_request));

sub server_root { return '/usr/local/httpd-test'; }

sub apache_binary {
    my ($this) = @_;

    return File::Spec->catfile( $this->server_root . '/bin/httpd' );
}

sub new {
    my ( $proto, $fields ) = @_;

    $fields ||= {};
    my $this = $proto->SUPER::new(
        {   'name'          => $proto->DEFAULT_NAME,
            'dispatch_to'   => [],
            'dispatch_with' => {},
            'basic_auth'    => 0,
            %{$fields}
        }
    );
    $this->_fix_old_dispatch();
    return $this;
}

sub set_dispatch_to {
    my ( $this, $new_value ) = @_;

    @{ $this->dispatch_to } = sort { $a cmp $b } uniq @{$new_value};
}

# serialization
sub as_string {
    my ($this) = @_;

    return sprintf( '%s->new(%s)',
        ref($this),
        Data::Dumper->new( [ {%$this} ] )->Terse(1)->Sortkeys(1)->Dump );
}

# default ssl_port is port + 1
sub ssl_port {
    my ( $this, $new_walue ) = @_;

    return @_ == 1
        ? $this->_ssl_port_accessor || $this->port + 1    #getter
        : $this->_ssl_port_accessor($new_walue);
}

# returns root for all instances
sub root {
    return Akar::Base->app_data('akar-soap-serverconfig');
}

# returns the root of instance
sub instance_root {
    my ($this, $instance_name) = @_;

    $instance_name ||= $this->name;
    return File::Spec->catfile( $this->root, $instance_name );
}

# filename relative to instance_root
sub filename {
    my ( $this, $filename, $instance_name ) = @_;

    $instance_name ||= $this->name;
    return File::Spec->rel2abs( $filename, $this->instance_root($instance_name));
}

# directory for Apache logs
sub log_dir {
    my ($this) = @_;

    return $this->filename('logs');
}

# configuration file
sub config_file {
    my ($this) = @_;

    return $this->filename('httpd.conf');
}

# Apache basic authorization file
sub basic_auth_file {
    my ($this) = @_;

    return $this->filename('htusers.pwd');
}

# returns file where PID is stored
sub pid_file {
    my ($this) = @_;

    return File::Spec->catfile( $this->log_dir, 'httpd.pid' );
}

# returns all available server configurations
sub all_instances {
    my ($this) = @_;

    my @files = glob( $this->instance_root('*') );
    return grep { $this->exists($_) } map { basename($_) } @files;
}

# checks the consistency of configuration
sub check {
    my ($this) = @_;

    $this->port             or die "No port supplied\n";
    $this->port >= 2000     or die "Port     < 2000 supplied\n ";
    $this->ssl_port >= 2000 or die "SSL port < 2000 supplied\n ";
    return 1;
}

# install the configuration, creates the apache configuration
sub install {
    my ($this) = @_;

    $this->check;
    mkpath( $this->log_dir );

    # writes the configuration 
    write_file( $this->config_file, $this->apache_config);
    return;
}

# uninstall the configuration
sub uninstall {
    my ($this) = @_;

    if ( $this->apache_pid ) {
        $this->stop_apache;
    }
    rmtree( $this->instance_root );

    warn sprintf "Apache instance %s uninstalled\n", $this->name;
}

# returns the instance by name or throws an exception
sub load {
    my ( $package, $name ) = @_;

    $name ||= $package->DEFAULT_NAME;

    my $instance_file = $package->filename( INSTANCE_FILE, $name );
    -f ($instance_file) or die "No instance $name found\n ";
    my $server_config = do($instance_file);
    die $@ if $@;

    # the value returned must be the server config object
    UNIVERSAL::isa( $server_config, __PACKAGE__ )
        or croak "Invalid result returned from file\n";
    return $server_config;
}

sub exists {
    my ($package, $name) = @_;

    return -f $package->filename( INSTANCE_FILE, $name || $package->DEFAULT_NAME);
}

# saves the instance
sub save {
    my ($this, $file) = @_;

    $file ||= $this->filename(INSTANCE_FILE);
    mkpath( dirname($file) );
    write_file( $file, $this->as_string );
    return $this;
}

# returns URI of SOAP server 
sub proxy {
    my ($this) = @_;

    return sprintf('http://%s:%s/soap/', hostname(), $this->port);
}

sub wsdl_uri {
    my ( $this, $package ) = @_;

    grep { $_ eq $package } @{ $this->dispatch_to }
        or croak "Package $package is not dispatched to\n";

    return sprintf( 'http://%s:%s/wsdl/%s',
        hostname(), $this->port, join( '/', split '::', $package ) );
}

sub ssl_proxy {
    my ($this) = @_;

    return sprintf('https://%s:%s/soap/', hostname(), $this->ssl_port);
}

sub _fix_old_dispatch {
    my ($this) = @_;

    # turns old dispatch_to object into simple array
    my $dispatch_to = $this->dispatch_to;
    if (UNIVERSAL::isa(
            $dispatch_to, 'Akar::SOAP::ServerConfig::DispatchTo'
        )
        )
    {
        $this->dispatch_to( $dispatch_to->{'modules'} );
    }

    # turns old dispatch_with object into simple hash
    my $dispatch_with = $this->dispatch_with;
    if (UNIVERSAL::isa(
            $dispatch_with, 'Akar::SOAP::ServerConfig::DispatchWith'
        )
        )
    {
        $this->dispatch_with( $dispatch_with->{'mapping'} );
    }

    my $basic_auth = $this->basic_auth;
    if (UNIVERSAL::isa( $basic_auth, 'Akar::SOAP::ServerConfig::BasicAuth' ) )
    {
        $this->basic_auth( $basic_auth->{'enabled'} );
    }
}

# returns the body of the apache config file
sub apache_config {
    my ($this) = @_;

    my $auth_config = $this->basic_auth
        ? join( "\n",
        'AuthType Basic',
        'AuthName "By Invitation Only"',
        'AuthUserFile ' . $this->basic_auth_file,
        'Require valid-user',
        )
        : '';

    return <<"END_APACHE_CONFIG";
ServerType standalone
ServerRoot $E{ $this->server_root }
PidFile $E{ $this->log_dir }/httpd.pid
ScoreBoardFile $E{ $this->log_dir }/httpd.scoreboard
Timeout         300
MinSpareServers     1
MaxSpareServers     5
StartServers        2
MaxClients 150
MaxRequestsPerChild $E{ $this->single_request? 1: 0 }
KeepAlive           $E{ $this->single_request? 'Off': 'On' }
MaxKeepAliveRequests 100
KeepAliveTimeout    15

<IfDefine SSL>
LoadModule ssl_module         libexec/libssl.so
</IfDefine>

ClearModuleList
AddModule mod_log_config.c
AddModule mod_asis.c
AddModule mod_access.c
AddModule mod_auth.c
AddModule mod_so.c
AddModule mod_setenvif.c
AddModule mod_mime.c

<IfDefine SSL>
AddModule mod_ssl.c
</IfDefine>
AddModule mod_perl.c

Port $E{ $this->port }

<IfDefine SSL>
Listen $E{ $this->port }
Listen $E{ $this->ssl_port }
</IfDefine>

ServerAdmin  simoniki\@irsay.devel.gts.cz
DocumentRoot "$E{ $this->server_root }/htdocs"

UseCanonicalName On
DefaultType text/plain
HostnameLookups Off

ErrorLog $E{ $this->log_dir }/error_log
LogLevel error

LogFormat "%h %l %u %t \\"%r\\" }s %b" common
CustomLog $E{ $this->log_dir }/access_log common

ServerSignature On

<Perl>
use lib '$E{ Akar::Base->perl5lib }';
use Akar::Base;
use Akar::Base::Profile;
</Perl>

SetHandler perl-script
PerlHandler Akar::SOAP::Apache
PerlSetVar dispatch_to "$E{ join ' ', @{$this->dispatch_to} }" 
PerlSetVar dispatch_with "$E{ join(', ', map {
        $_ . ' => '. $this->dispatch_with->{$_};
    } keys %{$this->dispatch_with} ) || ' ' }"
PerlSetVar options "compress_threshold => 10000"
PerlSetVar raw_logging "$E{ $this->raw_logging || 0 }"
PerlSetVar raw_logging_file "$E{ $this->log_dir . '/SOAP_raw_data.log' }"

<Location /soap>
$auth_config
</Location>

<IfDefine SSL>
AddType application/x-x509-ca-cert .crt
AddType application/x-pkcs7-crl    .crl
</IfDefine>

<IfModule mod_ssl.c>
SSLPassPhraseDialog  builtin
SSLSessionCache         dbm:$E{ $this->log_dir }/ssl_scache
SSLSessionCacheTimeout  300
SSLMutex  file:$E{ $this->log_dir }/ssl_mutex
SSLRandomSeed startup builtin
SSLRandomSeed connect builtin
SSLLog      $E{ $this->log_dir }/ssl_engine_log
SSLLogLevel error
</IfModule>

<IfDefine SSL>
<VirtualHost _default_:$E{ $this->ssl_port }>
DocumentRoot "$E{ $this->server_root }/htdocs"
ServerName aurelius.in.gtsgroup.cz
ServerAdmin machacep\@irsay.devel.gts.cz
ErrorLog $E{ $this->log_dir }/error_log
TransferLog $E{ $this->log_dir }/access_log
SSLEngine on
SSLCipherSuite ALL:!ADH:!EXPORT56:RC4+RSA:+HIGH:+MEDIUM:+LOW:+SSLv2:+EXP:+eNULL
SSLCertificateFile $E{ $this->server_root }/conf/ssl.crt/server.crt
SSLCertificateKeyFile $E{ $this->server_root}/conf/ssl.key/server.key
CustomLog $E{ $this->log_dir }/ssl_request_log \\
          "%t %h %{SSL_PROTOCOL}x %{SSL_CIPHER}x \\"%r\\" %b"
</VirtualHost>                                  
</IfDefine>
END_APACHE_CONFIG
}

sub start_apache {
    my ($this) = @_;

    my $apache_pid = $this->apache_pid;
    !$apache_pid
        or croak "$0 start: httpd (pid $apache_pid) already running\n";

    my $httpd = join ' ', $this->apache_binary, '-f', $this->config_file,
        '-DSSL';
    system($httpd ) == 0
        or croak "$0 start: httpd could not be started\n";

    warn "$0 start: httpd started\n";
}

sub stop_apache {
    my ($this) = @_;

    my $apache_pid = $this->apache_pid
        or croak "$0 stop: httpd not running\n";

    kill 'TERM', $apache_pid
        or croak "$0 stop: httpd could not be stopped\n";

    warn "$0 stop: httpd stopped\n";
}

sub apache_pid {
    my ($this) = @_;

    return if !-f $this->pid_file;

    my $apache_pid = 0 + FileHandle->new( $this->pid_file )->getline();

    # Process with the PID exists?
    return $apache_pid if kill 0, $apache_pid;
    return;
}

sub restart_apache {
    my ($this) = @_;

    if ( my $apache_pid = $this->apache_pid ) {
        $this->stop_apache;
        $this->wait_until_apache_dies($apache_pid);
    }
    $this->start_apache;
}

sub wait_until_apache_dies {
    require Time::HiRes;

    my ( $this, $apache_pid ) = @_;

    # waiting for until process really dies
    my $total_sleep     = 0;
    my $max_total_sleep = int( APACHE_DEATH_TIMEOUT * 1e6 ); # in microseconds
         # starts the wait with
    my $sleep      = int( APACHE_DEATH_START_WAIT * 1e6 );
    my $last_sleep = 0;
    while ( my $process_exists = kill 0, $apache_pid ) {
        croak
            "Even after $max_total_sleep microseconds the Apache hasn't stopped\n "
            if $total_sleep > $max_total_sleep;
        Time::HiRes::usleep($sleep);
        $total_sleep += $sleep;

        # fibonacci number - I heard that they are good for repetitive tries
        my $new_sleep = $sleep + ( $last_sleep || $sleep );
        $last_sleep = $sleep;
        $sleep      = $new_sleep;
    }
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
