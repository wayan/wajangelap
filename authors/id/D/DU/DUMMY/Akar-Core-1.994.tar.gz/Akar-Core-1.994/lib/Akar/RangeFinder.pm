package Akar::RangeFinder;
{
  $Akar::RangeFinder::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);

sub new {
    my ($package) = @_;

    return bless( [] => $package );
}

sub add_value {
    my ( $this, $value, $from, $to ) = @_;

    croak "No undefined value can be stored\n " if !defined($value);
    unshift @{$this}, [ $value, $from, $to ];
}

sub get_value {
    my ( $this, $day ) = @_;

    for my $row ( @{$this} ) {
        my ( $value, $from, $to ) = @$row;
        return $value if $from le $day && ( !defined($to) || $to ge $day );
    }

    # returns undefined value (nothing was found)
    return;
}

1;

__END__

=head1 NAME

Akar::RangeFinder - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
