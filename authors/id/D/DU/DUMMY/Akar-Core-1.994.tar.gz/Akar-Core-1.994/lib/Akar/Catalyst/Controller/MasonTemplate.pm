package Akar::Catalyst::Controller::MasonTemplate;
{
  $Akar::Catalyst::Controller::MasonTemplate::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor::Grouped);

# controller which has the Mason template joined with it

__PACKAGE__->mk_group_accessors( inherited => '_dispatcher_options' );
__PACKAGE__->mk_group_accessors( simple => 'default_template' );
__PACKAGE__->mk_group_accessors( inherited => 'default_template_name' );

# this controller uses no template - no rendering
sub has_no_template { shift()->default_template_name(''); }

sub COMPONENT {
    my $class = shift;
    my ($app_class) = @_;

    my $comp          = $class->next::method(@_);
    my $template_name = $class->default_template_name;
    return $comp if defined $template_name && !length($template_name);

    # if template name is '' it means no template
    my $default_template;

    # if template name is '' then there is no default_template
    $template_name ||= $comp->action_namespace($app_class);
    $default_template = '/'
        . lc(
        join '/',
        split( /::/, $app_class ),
        ( $template_name ? $template_name : () )
        )
        . '.mc';

    # default_template is determined from the action namespace
    $comp->default_template($default_template);

    # 2010-06-29 danielr
    # application has to have postsetup
    $app_class->postsetup(
        sub {
            $comp->_check_template($app_class);
        }
    );
    return $comp;
}

# checks whether controller has their templates
sub _check_template {
    my ( $this, $c ) = @_;

    my $template = $this->can('default_template') && $this->default_template
        or return;

    my $abs_path = $c->view('Mason')->config->{comp_root} . '/' . $template;
    -f $abs_path
        or die "Controller ". (ref $this || $this) . " needs mason template '$abs_path', which is missing\n";
}

sub default_template_method {
    my ( $this, $c ) = @_;

    return $c->action->name;
}

1;

__END__

=head1 NAME

Akar::Catalyst::Controller::MasonTemplate - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

v
