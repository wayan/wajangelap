package Akar::Log::Any::Adapter::File;
{
  $Akar::Log::Any::Adapter::File::VERSION = '1.994';
}
use strict;
use warnings; 
use base qw(Log::Any::Adapter::File);

# does exactly the same as Log::Any::Adapter::File without printing the time
# to be used with JSON logging where the time is included in the message
__PACKAGE__->make_logging_methods(
    sub {
        my ( $self, $text ) = @_;
        $self->{fh}->print("$text\n");
    }
);

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
