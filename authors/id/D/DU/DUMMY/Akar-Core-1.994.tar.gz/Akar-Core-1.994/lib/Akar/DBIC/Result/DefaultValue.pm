package Akar::DBIC::Result::DefaultValue;
{
  $Akar::DBIC::Result::DefaultValue::VERSION = '1.994';
}
use strict;
use warnings;

# simple and stupid ancestor od result class setting default values in new
use base qw(DBIx::Class);

use Carp qw(carp croak);

sub new {
    my ($class, $fields_ref) = @_;

    for my $column ($class->columns){
        if (!exists $fields_ref->{$column}){
            my $column_info = $class->column_info($column);
            if (exists $column_info->{default_value}){
                $fields_ref->{$column} = $column_info->{default_value};
            }
        }
    }
    return $class->next::method($fields_ref);
}

1;

__END__

=head1 NAME

Akar::DBIC::Result::DefaultValue - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
