package Akar::Time;
{
  $Akar::Time::VERSION = '1.994';
}

=head1 NAME

Akar::Time - Flexibilni a jednoduch� pr�ce s datem a �asem

=head1 SYNOPSIS

  # nastav� aktu�ln� �as 
  my $time = Akar::Time->new;  

  # nastav� na ur�it� �as
  my $time = Akar::Time->new('2002-03-19 14:22:10'); 

  # datum v textove podobe
  $time->text; 

  # nastav� �as na 1999-07-04 05:46:29, t.j. 923456789 s od 1.1.1970
  my $time = Akar::Time->new(923456789); 

  # nastav� �as na aktu�ln� a zm�n� datum na 30.12
  my $time = Akar::Time->new('day' => 30, 'mon' => 12);

  # rozd�l v sekund�ch mezi dv�ma �asy
  $time1->diff($time2);

  # time1 je pozd�ji ne� time2
  $time1->diff($time2) > 0

  # �as plus 1 mesic
  $time->add('mon' => 1);

  # do roka a do dne
  $time->add('year' => 1, 'day' => 1)

=head1 DESCRIPTION

Modul Akar::Time umo��uje rychlou a pohodlnou pr�ci 
s "datov�m typem datetime". Ukl�d� �as i datum od rok�
a� po vte�iny. Um� skl�dat datum a �as z jednotliv�ch polo�ek, 
ode��tat �asy a p�i��tat k �asu. 

=head1 METODY

=over 4

=cut

use strict;

use Time::Local qw(timelocal timegm);
use Time::localtime qw();
use Time::gmtime qw();
use POSIX qw(!ctime);
use Carp;

my %cz_state_holidays = (
  '01-01' => 1,
  '05-01' => 1,
  '05-08' => 1,
  '07-05' => 1,
  '07-06' => 1,
  '09-28' => 1,
  '10-28' => 1,
  '11-17' => 1,
  '12-24' => 1,
  '12-25' => 1,
  '12-26' => 1
);

=item new

	Akar::Time->new('2002-05-17 12:22:19');
	Akar::Time->new('2002-05-12');
	Akar::Time->new('11:30');

Konstruktor. Vytvo�� objekt z aktu�ln�ho �asu a zavol� funkci 
C<set> s p�edan�mi parametry.

=cut

sub new {
	my $class = shift;
	bless({'time'=>time()}, ref($class) || $class)->set(@_);
}

sub new0 {
	my $class = shift;
        # 2005-01-03 unix epoch is Thu Jan  1 01:00:00 1970, so I need to reset time 
	bless({'time'=>0}, ref($class) || $class)
          ->set('hour' => 0, 'min' => 0, 'sec' => 0)
          ->set(@_);
}

=item day_begin

  my $t = $date->day_begin

Returns time (copy or current time) with time part set to 00:00:00 

=cut

# constructor
sub day_begin {
    my $proto = shift;
    (ref($proto)? $proto->copy: $proto->new)
      ->set('hour' => 0, 'min' => 0, 'sec' => 0);
}

=item day_end

  my $t = $date->day_end

Returns time (copy or current time) with time part set to 23:59:59 

=cut

sub day_end {
    my $proto = shift;
    (ref($proto)? $proto->copy: $proto->new)
      ->set('hour' => 23, 'min' => 59, 'sec' => 59);
}

=item copy

	$time->copy('2002-05-17 12:22:19');
	$time->copy('mon' => 11, 'hour' => 7);
	$time->copy('11:30');

Konstruktor. Vytvo�� kopii objektu a zavol� na ni funkci 
C<set> s p�edan�mi parametry.

=cut

sub copy {
	my $this = shift;
	bless({%$this}, ref($this))->set(@_);
}

=item set

	$time->set('mon' => 12, 'day' => 23 );
	$time->set('2002-12-04');

Nastavuje polo�ky v objektu �asu. M�-li jedin� 
celo��seln� argument (krom� C<$this>), potom nastavuje
�as na zadan� po�et sekund od epochy (1.1.1970 00:00:00).

M�-li jedin� necelo��seln� argument, pak je tento pova�ov�n
za datum ve form�tu C<YYYY-MM-DD HH24:MI:SS>. 
Tento argument m��e b�t ne�pln�, nap��klad

	$time->set('17:30');

nastav� hodiny a minuty, zat�mco

	$time->set('8-12')

nastav� m�s�c a den.

Pokud je argument� v�ce ne� 1, pova�uj� se za dvojice kl�� - hodnota
a nastavuj� p��slu�n� polo�ky v datu. Polo�ky jsou pojmenov�ny
year, mon, day, hour, min, sec.

	$time->set('year' => 2002, 'mon' => 4, 'day' => 17);

=cut 

sub set {
	my $this = shift;

	# pokud ma funkce jediny celociselny argument,
	# je to cas v sekundach od epochy
	# je-li to necelociselny argument, je to
	# textova podoba casu

	if (@_ == 1){
		local $_ = shift;
		if (!defined($_)){
			# nenastavuje se nic
		}
		elsif (/^\d+$/){
			$$this{'time'} = $_;
		}
		else {
			$this->set('text' => $_);
		}
		return $this;
	}

	# nastaveny nektere elementy casu
	my @ary  = $this->elements;
	while(my($k,$v) = splice @_,0,2){
		if ($k eq 'text'){
			local $_ = $v;
			# datum je v jednom z formatu 
			# YYYY-MM-DD HH:MM:SS
			# YYYY-MM-DD
			# HH:MM
			# HH
			if( s/^([0-9]+-[-0-9]+)// ){
				my @d = split /-/, $1;
				unshift @_, 'day'  => pop @d if @d;
				unshift @_, 'mon'  => pop @d if @d;
				unshift @_, 'year' => pop @d if @d;
			}
			if ( s/\s*([0-9:]+)// ){
				my @d = split /:/, $1;
				unshift @_, 'hour' => shift @d if @d;
				unshift @_, 'min'  => shift @d if @d;
				unshift @_, 'sec'  => shift @d if @d;
			}
			$_ eq '' or die "Chybne zadane datum '$v'";
		} elsif ($k eq 'hour'){
			$ary[2] = $v;
		} elsif ( $k eq 'min' ){
			$ary[1] = $v;
		} elsif ( $k eq 'day' ){
			$ary[3] = $v;
		} elsif ( $k eq 'mon' ){
			$ary[4] = $v - 1;
		} elsif ( $k eq 'year' ){
			$ary[5] = $v;
		} elsif ( $k eq 'sec' ){
			$ary[0] = $v;
		} elsif ($k eq 'GMT' ){
			$$this{'GMT'} = $v;
		} elsif ($k eq 'LOCAL' ){
			$$this{'GMT'} = !$v;
		} elsif ($k eq 'DST' && $v == 0){
			# lokalni cas, ale bez DST
			$$this{'NODST'} = 1;
		} elsif ($k eq 'time' or $k eq 'timestamp'){
			$$this{'time'} = $v;
			@ary = $this->elements(); 
		}
		else {
			die "Neznamy parametr '$k' pro nastaveni casu";
		}
	}

	$$this{'time'} = $this->parts2number(@ary); 
	$this;
}

=item add

	$this->add('mon' => 2);
	$this->add('hour' => 1);

P�i��t� k �asu ur�it� po�et jednotek. Od revize 1.5 um� krom� norm�ln�ch dn�
p�i��st i pracovn� dny:

  $this->add('bday' => 14 );
  
Algoritmus nen� nijak efektivn�, ale zohled�uje krom� v�kend� i v�echny �esk� st�tn� sv�tky
platn� k 1.9.2006 v�etn� Velikonoc. Algoritmus pro v�po�et Velikonoc d�v� spr�vn� 
v�sledky pro rozmez� let 1583-4099.

=cut

sub add {
	my $this = shift;
	my @ary  = $this->elements;

	while(my($k,$v) = splice @_,0,2){
		if ($k eq 'sec'){
			$$this{'time'} += $v;
		} elsif ($k eq 'min'){
			$$this{'time'} += 60*$v;
		} elsif ($k eq 'hour'){
			$$this{'time'} += 3600*$v;
		} elsif ($k eq 'day'){
			$$this{'time'} += 24*3600*$v;
		} elsif ($k eq 'year'){
			$this->set('year' => $this->get('year') + $v);
		} elsif ($k eq 'mon'){
			my $mon  = $this->get('mon') + $v;
			my $year = (($mon - 1) - ($mon - 1) % 12) / 12;
			$mon -= 12 * $year;

      my $day = $this->get('day');
      
			$this->set(
				'year' => $this->get('year') + $year,
				'mon'  => $mon,
				'day'  => 1
			);
			
			return $this if $day == 1;
			
			my $max_day = $this->add('mon',1)->add('day',-1)->get('day');
			$this->set('day' => ($day > $max_day)?$max_day:$day );
		} elsif ($k eq 'bday') {
		  $this->bday_add($v);
		} else {
			die "K casu zatim nelze pricitat jednotky $k";
		}
	}
	$this;
	
}

=item get

  my $day = $time->get('day');
  my $letni_cas = $time->get('dst');
  my($mesic,$rok) = $time->get('mon',  'year');
  my $bday = $time->get('bday') # vraceno: 0 - volny den, 1 - pracovni den

Vrac� rozli�n� slo�ky z �asu.

=cut



sub get {
	my $this = shift;
	my @elem = $this->elements;
	
	my @ret = map {
		$_ eq 'time'? $$this{'time'}:
		$_ eq 'timestamp'? $$this{'time'}:
		$_ eq 'wday'? $elem[6]:
		$_ eq 'year'? $elem[5] + 1900:
		$_ eq 'mon'?  $elem[4] + 1:
		$_ eq 'day'?  $elem[3]:
		$_ eq 'hour'? $elem[2]: 
		$_ eq 'min'?  $elem[1]:
		$_ eq 'sec'?  $elem[0]:
		$_ eq 'dst'?  (localtime($$this{'time'}))[8]:
		$_ eq 'bday'? $this->is_bday:
		              die "Neznama cast casu $_";
		 
	} @_;
	wantarray? @ret: $ret[0];
}

sub diff {
	my $this = shift;
	my $what = shift;

	$$this{'time'} - $$what{'time'};
}

sub cmp {
	my $this = shift;
	my $what = shift;

	$$this{'time'} <=> $$what{'time'};	
}

sub between {
	my $this = shift;
	my($from, $to) = @_;
	$this->diff($from)    >= 0 
	&& $this->diff($to)   <= 0;
}

sub minus {
	my $this = shift;
	$$this{'time'} --;
	$this;
}

sub num {
	my $this = shift;
	$$this{'time'};
}

sub elements {
	my $this = shift;

	my $tm  = $this->number2parts($$this{'time'});
	($tm->sec, $tm->min, $tm->hour, $tm->mday, $tm->mon, $tm->year, $tm->wday);
}

sub formatted {
	my $this = shift;
	my($format) = @_;
	POSIX::strftime($format, $this->elements);
}

sub text {
	my $this = shift;
	my $format = shift || '%Y-%m-%d %H:%M:%S';
	POSIX::strftime($format, $this->elements);
}

sub text_xsi {
	my $this = shift;
	my $format = '%Y-%m-%dT%H:%M:%S';
	POSIX::strftime($format, $this->elements);
}  

sub text_date {
	my $this = shift;
	$this->text('%Y-%m-%d');
}

sub text_time {
	my $this = shift;
	$this->text('%H:%M:%S');
}

sub dbtext {
	my $this = shift;
	$this->text;
}

# formatovani data podle formatu ORACLE
# staci mi jen omezena mnozina
sub ora_text {
	my $this = shift;
	my($format) = @_;

	# formatovaci retezce oraclu
	# nahradim retezci pro strftime 

	$format =~ s/YYYY/\%Y/g;
	$format =~ s/MM/\%m/g;
	$format =~ s/DD/\%d/g;

	# tohle uz je vcelku zbytecne, 
	# ale jen pro uplnost
	$format =~ s/HH24/\%H/g;
	$format =~ s/MI/\%M/g;
	$format =~ s/SS/\%S/g;

	POSIX::strftime($format, $this->elements);
}

sub parts2number {
	my $this = shift;
	return(
		$$this{'GMT'}?   timegm(@_):
		# posun proti GMT casu
		$$this{'NODST'}? timegm(@_) + timegm(localtime(0)):
			timelocal(@_)
	);
}

sub number2parts {
	my $this = shift;
	
	return(
		$$this{'GMT'}?
			Time::gmtime::gmtime(shift(@_)):
		$$this{'NODST'}?
			Time::gmtime::gmtime(shift(@_) - timegm(localtime(0))):
			Time::localtime::localtime(shift(@_))
	);
}

sub catholic_easter_sunday {
  my $this = shift;
  my ($year) = @_;
  $year = $this->get('year')
    if !$year && ref($this);
    
  my ($day, $month, $century, $rmd19, $temp, $tA, $tB, $tC, $tD, $tE);
  
  $century = int($year/100);
  $rmd19 = $year % 19;
  $temp = int(($century - 15)/2) + 202 - 11 * $rmd19;
  
  $temp -= 1 if grep { $century == $_ } (21,24,25,27,28,29,30,31,32,34,35,38);
  $temp -= 2 if grep { $century == $_ } (33,36,37,39,40);
  $temp %= 30;
          
  $tA = $temp + 21;
  $tA -= 1 if $temp == 29 || $temp == 28 && $rmd19 > 10;


  $tB = ($tA - 19) % 7;

  $tC = (40 - $century) % 4;
  $tC += 1 if $tC == 3;
  $tC += 1 if $tC > 1;
  

  $temp = $year % 100;
  $tD = ( $temp + int($temp/4) ) % 7;

  $tE = (20 - $tB - $tC - $tD) % 7 + 1;
  $day = $tA + $tE;
  
  if ($day > 31) {
    $day -= 31;
    $month = 4;
  } else {
    $month = 3;
  };

  return Akar::Time->new('day' => $day, 'mon' => $month, 'year' => $year)->day_begin;
}  

sub is_bday {
  my $this = shift;
  
  return 0 if !$this->get('wday') || $this->get('wday') == 6;
  return 0 if exists $cz_state_holidays{$this->text('%m-%d')};
  return 0 unless $this->cmp($this->catholic_easter_sunday()->set($this->text_time)->add('day' => 1));
  return 1;
}
  
sub bday_add {
  my ($this) = shift;
  my ($bdays) = @_;
  
  my $work = $this->copy('12:00:00');
  my $ddays = 0;
  while ( $ddays != $bdays ) {
    $work->add('day' => ($bdays > 0)?1:-1);
    $work->set('12:00:00');
    next unless $work->is_bday;
    $ddays += ($bdays > 0)?1:-1;
  };    
  return $this->set($work->text_date);    
}  

1;

__END__
