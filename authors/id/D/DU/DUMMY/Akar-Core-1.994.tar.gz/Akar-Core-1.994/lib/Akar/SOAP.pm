package Akar::SOAP;
{
  $Akar::SOAP::VERSION = '1.994';
}
use strict;


=head1 NAME

Akar::SOAP - soap (SOAP::Lite) enhancements

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

1;


