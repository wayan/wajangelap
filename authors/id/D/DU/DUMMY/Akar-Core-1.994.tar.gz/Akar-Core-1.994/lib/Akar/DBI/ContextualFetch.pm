package Akar::DBI::ContextualFetch;
{
  $Akar::DBI::ContextualFetch::VERSION = '1.994';
}
use strict;

use base qw(Akar::DBI);
use DBIx::ContextualFetch;
# include DBIx::ContextualFetch::db into superclasses of returned db handle 

sub enhanced_package {
    my $this     = shift;
    my($package) = @_;

    my $new_package .= $package. '::with_contextual_fetch';
    no strict 'refs';
    unless (@{$new_package. '::ISA'}){
        @{$new_package. $_. '::ISA'} = ($package. $_, 'DBIx::ContextualFetch'. $_) 
          for '', '::db', '::st';
        DBI::init_rootclass($new_package);
    }
    $new_package;
}

1;
