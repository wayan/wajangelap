package Akar::IOC::Root::WebServices::REST;
{
  $Akar::IOC::Root::WebServices::REST::VERSION = '1.994';
} 
use MooseX::Role::Parameterized;

use namespace::autoclean;
use XML::LibXML::XPathContext;
use Akar::BreadBoard;
use Path::Class;

parameter use_common_schemas => ( default => 1, );

# whether Atom linkType should be stripped of type="mixed" attribute
parameter hack_atom_link => ( default => 1);

role {
    my $p = shift;
    before build_content => sub { build_content( $p, @_ ) };
};

sub build_content {
    my $p = shift;
    my $this = shift;

    service schema_parser => (
        class     => 'XML::LibXML',
        lifestyle => 'Singleton',
    );

    # returns list of XML::LibXML documents
    service schemas => (
        block => sub {
            my $params = shift()->params;

            my $parser = $params->{schema_parser};
            my $base   = $params->{schema_files_base};
            my @files  = map {@$_}
                grep {$_} @$params{qw(schema_files common_schema_files)};

            my @schemas;
            for my $rel (@files) {
                my $file = file($rel)->absolute($base);
                -f $file or die "Schema file $file doesnot exist";

                my $doc = $parser->parse_file($file);
                if ( $p->hack_atom_link ) {
                    my $xp = XML::LibXML::XPathContext->new($doc);

                    # hacking atom:link
                    $xp->registerNs(
                        xs => "http://www.w3.org/2001/XMLSchema" );
                    if (my ($atom_link_type) = $xp->findnodes(
                            '/xs:schema/xs:complexType[@name="linkType"]')
                        )
                    {
                        $atom_link_type->removeAttribute('mixed');
                    }
                }

                push @schemas, $doc;
            }

            return \@schemas;
        },
        dependencies => [
            'schema_files',      'common_schema_files',
            'schema_files_base', 'schema_parser'
        ]
    );

    # the main reason for this are serializers
    # and deserializers
    service xml_compile_schema => (
        class => 'Akar::XML::Compile::Schema',
        block => sub {
            my $s = shift;

            my $schema = $s->class->new;
            $schema->importDefinitions($_) for @{ $s->param('schemas') };
            return $schema;
        },
        dependencies => [qw(schemas)],
    );

    service common_schema_files => (
        $p->use_common_schemas
        ? ( block => sub {
                my $s = shift;
                return [
                    map { $s->class->xsd_path($_) } 'www.w3.org/Atom2005.xsd',
                    'www.w3.org/XML1998.xsd',
                    'Akar/REST.xsd',
                ];
            },
            class => 'Akar::WebServices::XSD',
            )
        : []
    );

    # base directory for xsd_files
    service schema_files_base => dir( Akar::Base->app_home('lib/xsd/REST') );
}


1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:


