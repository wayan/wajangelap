package Akar::Javascript::YUILoader;
{
  $Akar::Javascript::YUILoader::VERSION = '1.994';
}
use strict;
use warnings;

# 2008-12-09 danielr
# TENHLE MODUL JE TROSKU MIMO
# MEL BY BYT JINAK A LEPE ZAKOMPONOVAN DO SABLON V MASONU

use base qw(Class::Accessor::Fast);
use URI;
use overload
    '""'       => sub { shift()->as_string },
    'fallback' => 1;
use Scalar::Util qw(weaken);

use Class::Trait qw(Akar::Trait::PackageConfig);
{
    my $config = __PACKAGE__->package_config;
    $config->add_param('skin' => 'sam');
    $config->add_param('js_type' => 'min');
    $config->add_param('yui_version' => '2.5.2');
    $config->add_param('remote_site' => 'http://yui.yahooapis.com');
    $config->add_param('use_remote'  => 0);
}

use Akar::List::Utils qw(pop_options);

__PACKAGE__->mk_accessors(
    qw(skin yui_version remote_site use_remote module_is_required js_type));

# 2008-12-09 danielr
# temporary hack until cancelation of this module
__PACKAGE__->mk_ro_accessors('application'); # application is needed for c->uri_for

# different type of modules, copied from
# http://developer.yahoo.com/yui/articles/hosting/
my @css_foundation = qw(reset base fonts grids);
my @control_skins
    = qw(container menu autocomplete button calendar colorpicker datatable
    editor imagecropper layout resize tabview
    treeview);
my @core      = qw(yahoo dom event);

my @utilities = qw(
    element-beta
    animation
    connection
    cookie-beta
    datasource-beta
    dragdrop
    get
    history
    imageloader
    json
    resize-beta
    selector-beta
    yuiloader-beta);

my @ui_controls = qw(
    container
    menu
    autocomplete
    button
    calendar
    charts-experimental
    colorpicker
    datatable-beta
    editor-beta
    imagecropper-beta
    layout-beta
    slider
    tabview
    treeview
    uploader-experimental
);

# devtools
my @devtools_skins = qw(logger profilerviewer);

# devtools - min.js
my @devtools = qw(logger profiler-beta profilerviewer-beta yuitest);

# here should be added the dependencies
my %depends_on = ( 'button' => [qw(element)], );

# allowed modules
my %is_module = map {
    my $name = $_;
    $name =~ s/-beta//;
    ( $name => 1 );
} @css_foundation, @core, @utilities, @ui_controls, @devtools;

sub require_module {
    my ( $this, $module ) = @_;

    $is_module{$module}
        or die "Unknown module '$module', allowed are "
        . join( ', ', keys %is_module ) . "\n";

    $this->module_is_required->{$module} = 1;
}

sub require_modules {
    my $this = shift;
    for my $module (@_) {
        $this->require_module($module);
    }
}

sub as_string {
    my $this = shift;

    # selects the required modules from list
    my %module_is_required = (%{$this->module_is_required}, map { $_ => 1} @core);
    # dependency closure
    while ( my @deps = grep { !$module_is_required{$_} }
        map { @{$_} } grep {$_} @depends_on{ keys %module_is_required } )
    {
        @module_is_required{ @deps } = (1) x @deps;
    }
    
    my $_select = sub {
        return grep {
            my $m = $_;
            $m =~ s/-beta$//;
            $module_is_required{$m};
        } @_;
    }; 

    my @code;
    # core css
    for my $module ( $_select->(@css_foundation) ) {
        my $url = $this->_module_url( $module,
            $module . '-' . $this->js_type . '.css' );
        push @code,
            "<link rel=\"stylesheet\" type=\"text/css\" href=\"$url\"></link>";
    }

    # skins
    for my $module ( $_select->( @control_skins, @devtools_skins ) ) {
        my $url = $this->_module_url( $module,
            'assets/skins/' . $this->skin . '/' . $module . '.css' );
        push @code, '<link rel="stylesheet" type="text/css" href="' . $url
            . '"></link>';
    }

    # javascript
    for my $module (
        $_select->( @core, @utilities, @ui_controls, @devtools ) )
    {
        my $module_stripped = $module;
        $module_stripped =~ s/-beta$//;
        my $url = $this->_module_url( $module_stripped,
            $module . '-' . $this->js_type . '.js' );
        push @code,
            '<script type="text/javascript" src="' . $url . '"></script>';
    }

    return join "\n",
        '<!-- Libraries needed for YUI (Yahoo User Interface) -->', @code;
}

# constructor - if first argument is array reference, it is considered
# as the list of modules
sub new {
    my $class = shift;
    my $options_ref = pop_options( \@_ ) || {};
    my @modules
        = ( @_ && UNIVERSAL::isa( $_[0], 'ARRAY' ) ) ? @{ shift() } : ();

    my $yui_loader = $class->SUPER::new(
        {   (   map {
                    my $default = $class->package_config->$_;
                    defined $default ? ( $_ => $default ) : ();
                    } qw(skin yui_version use_remote remote_site js_type)
            ),
            %{$options_ref},
            'module_is_required' => {},
        }
    );

    for my $module (@modules) {
        $yui_loader->require_module($module);
    }
    weaken( $yui_loader->{'application'} ) if $yui_loader->{'application'};
    return $yui_loader;
}

sub _module_url {
    my ( $this, $module, $relative_url ) = @_;

    my $url = join '/',
        (
        $this->use_remote
        ? ( $this->remote_site, $this->yui_version )
        : '', 'yui'
        ),
        'build', $module, $relative_url;

    # 2008-12-10 danielr
    # temporary hack until cancelation of this module
    if (!$this->use_remote && $this->application){
        $url = $this->application->uri_for($url);
    }
    return $url;
}

1;

__END__

=head1 NAME

Akar::Javascript::YUILoader - emits code for YUI (Yahoo User Interface) loading 

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
