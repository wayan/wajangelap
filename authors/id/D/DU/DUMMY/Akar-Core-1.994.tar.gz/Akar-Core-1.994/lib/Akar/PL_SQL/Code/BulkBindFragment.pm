package Akar::PL_SQL::Code::BulkBindFragment;
{
  $Akar::PL_SQL::Code::BulkBindFragment::VERSION = '1.994';
}
use strict;

# PL/SQL package fragment with methods for bulk binds DML 
# methods are
# init ... initialize (deletes) 
# add  ... add rows to the 
# flush ... flushes  to database

use base qw(Akar::PL_SQL::Code);

use Carp qw(croak);
use Akar::List::Utils qw(first_defined);

use Akar::PL_SQL::Code::Functions qw(iblock truncate_ident join_ilines ilist);

__PACKAGE__->mk_accessors(
    'dml_statement',    # (insert, update, delete)
    'table',            # table for DML
    'columns',          # stored columns
    'input_params',     # params for add procedure
    'id',               # id (for identifiers)
);

{
    my $id = 0;

    sub new {
        my ( $proto, $fields ) = @_;

        my $name = $fields->{'name'}
            or croak "No fragment name supplied\n ";

        length($name) <= 24    # 30 - length(_flush)
            or croak
            "Name ($name) is too long, max length is 24 characters\n ";

        return $proto->SUPER::new(
            {   %$fields,
                'columns'      => [],
                'input_params' => [],
                'id'           => ++$id,
            }
        );
    }
}

# columns and params
{

    # container package for columns and params
    my $column_package = __PACKAGE__ . '::column';
    {
        no strict 'refs';
        @{ $column_package . '::ISA' } = qw(Class::Accessor);
    }

    $column_package->mk_accessors(
        'name',
        'type',               # SQL type (usually table.column%TYPE
        'style',              # (asis, key, sum, count, ..)
        'input_value',        # contribution to this column (usually in_$NAME)
        'collection',         # name of the appropriate collection (may be undef)
        'collection_elem',    # collection element (collection(i))
    );

    sub column_package { return $column_package }
}

sub add_column {
    my ( $this, $name, $style, $input_value, $fields ) = @_;

    $style       ||= 'asis';
    $fields      ||= {};
    $input_value ||= 'in_' . $name;

    my $type       = sprintf( '%s.%s%%TYPE', $this->table, $name );
    my $collection = truncate_ident( 'col' . $this->id . '_' . $name );
    my $column     = $this->column_package->new(
        {   'type'             => $type,
            'name'             => $name,
            'style'            => $style,
            'collection'       => ( $style eq 'seq' ? undef : $collection ),
            'collection_elem'  => $collection . '(i)',
            'input_value'      => $input_value,

            %$fields,
        }
    );

    push @{$this->columns}, $column;
    return $column;
}

# new input parameter
sub add_input_param {
    my ( $this, $name, $fields ) = @_;

    $fields ||= {};

    my $type = sprintf( '%s.%s%%TYPE', $this->table, $name );
    my $param = $this->column_package->new(
        {   'name' => $name,
            'type' => $type,
            %$fields,
        }
    );
    push @{$this->input_params}, $param;
    return $param;
}

sub columns {
    my ($this) = @_;

    my $columns = $this->_columns_accessor;
    return wantarray ? @$columns: $columns;
}

sub key_columns {
    my ($this) = @_;

    return grep { $_->style eq 'key' } $this->columns;
}

# columns having a collection
sub value_columns {
    my ($this) = @_;

    return grep { $_->style ne 'key' } $this->columns;
}

sub stored_columns {
    my ($this) = @_;

    return grep { $_->collection } $this->columns;
}

sub input_params {
    my ($this) = @_;

    my $input_params = $this->_input_params_accessor;
    return wantarray ? @$input_params: $input_params;
}

# returns name of the procedure (
# proc_type = (add, init, flush)
# qualified = 1 name is prepended by package name is returned
sub proc_name {
    my ( $this, $proc_type, $qualified ) = @_;

    my $name = $this->name . '_' . $proc_type;
    return $qualified ? $this->package->name . '.' . $name : $name;
}

sub dump_proc {
    my ( $this, $name ) = @_;

    return (
        $this->dump_part( $name . '_proc_header' ),
        (   $this->dumping_body
            ? ( 'is',
                iblock( $this->dump_part( $name . '_proc_decl' ) ),
                'begin',
                iblock( $this->dump_part( $name . '_proc_body' ) ),
                'end ' . $this->proc_name($name),
                )
            : ()
        ),
        ';'
    );
}

# dumps the procedures
sub dump {
    my ($this) = @_;

    return map { $this->dump_proc($_); } qw(init add flush);
}

# returns collection names
sub collections {
    my ($this) = @_;

    return map { $_->collection } $this->stored_columns;
}


# first collection for the indexes
sub collection0 {
    my ($this) = @_;

    return scalar( ( $this->collections )[0] );
}


# returrn package declaration of the fragment
sub dump_package_decl {
    my ($this) = @_;

    return if !$this->dumping_body;

    return map {
        my $type            = $_->type;
        my $collection      = $_->collection;
        my $collection_type = truncate_ident( $collection, '_t' );

        (   "type $collection_type is table of $type;",
            "$collection $collection_type := $collection_type();"
        );

        }
        $this->stored_columns;
}

# dml flushing to database
sub dump_bulkbind_update {
    my ($this) = @_;

    return (
        "update " . $this->table,
        'set', ilist( $this->dump_dml_set ),
        'where', join_ilines( 'and ', $this->dump_dml_where )
    );
}

sub dump_bulkbind_delete {
    my ($this) = @_;

    return ( "delete from " . $this->table,
        'where', join_ilines( 'and ', $this->dump_dml_where ) );
}

sub dump_bulkbind_insert {
    my ($this) = @_;

    my %the_value = map {
        my $value =
              $_->style eq 'seq'
            ? $_->input_value . '.nextval'
            : $_->collection_elem;
        ( $_->name => $value );
    } $this->columns;

    return (
        "insert into " . $this->table . "(",
        ilist( keys %the_value ),
        ')', 'values (', ilist( values %the_value ), ')'
    );
}

sub dump_dml_set {
    my ($this) = @_;

    return map { $this->dump_dml_set_column($_) } $this->value_columns;
}

sub dump_dml_set_column {
    my ($this, $column) = @_;

    return ($column->name . '='. $column->collection_elem);
}

# returns rows of where condition for UPDATE and DELETE
sub dump_dml_where {
    my ($this) = @_;

    return map { $_->name . '=' . $_->collection_elem } $this->key_columns;
}

# init procedure (initializes the collections)
sub dump_init_proc_header {
    my ($this) = @_;
    return ( 'procedure ' . $this->proc_name('init') );
}

sub dump_init_proc_decl { 
    return () 
}

sub dump_init_proc_body {
    my ($this) = @_;

    return $this->dump_delete_collections;
}


# flush procedure
sub dump_flush_proc_header {
    my ($this) = @_;
    return ( 'procedure ' . $this->proc_name('flush') );
}

sub dump_flush_proc_body {
    my ($this) = @_;

    return ( 
        $this->dump_bulkbind,
        $this->dump_delete_collections 
    );
}

my %PAST_TENSE = (
    'insert' => 'inserted',
    'delete' => 'deleted',
    'update' => 'updated',
);

sub dump_bulkbind {
    my ($this) = @_;

    my $collection0 = $this->collection0;
    my $method      = 'dump_bulkbind_' . $this->dml_statement;
    my $table       = $this->table;
    my $past_tense  = $PAST_TENSE{ $this->dml_statement };
    my $statement   = $this->dml_statement;
    my $show_start  = "sys.dbms_output.put_line( "
        . "to_char(sysdate, 'YYYY-MM-DD HH24:MI:SS') || "
        . "' $table: $statement started');";
    my $show_end = "sys.dbms_output.put_line( "
        . "to_char(sysdate, 'YYYY-MM-DD HH24:MI:SS') || "
        . "' $table: ' || l_processed || ' rows $past_tense');";
    return (
        "if $collection0.count > 0 then",
        iblock(
            $show_start,
            "forall i in $collection0.first .. $collection0.last",
            iblock( $this->$method, ';' ), 
            'l_processed := SQL%ROWCOUNT;',
            $show_end,
        ),
        'end if;',
    );
}

sub dump_add_proc_header {
    my ($this) = @_;

    return (
        "procedure " . $this->proc_name('add'), '(',
        ilist( $this->dump_add_proc_params ), ')'
    );
}

# returns parameters for add proc
sub dump_add_proc_params {
    my ($this) = @_;

    return map { sprintf( 'in_%s in %s', $_->name, $_->type ) }
        $this->input_params;
}

sub dump_add_proc_body {
    my ($this) = @_;

    return ( $this->dump_extend_collections, $this->dump_assign_collections );
}

# extends all collections by one row and sets i to the last index
sub dump_extend_collections {
    my ($this) = @_;

    return (
        ( map { $_ . '.extend;' } $this->collections ),
        'i := ' . $this->collection0 . '.last;'
    );
}

# deletes all  collections
sub dump_delete_collections {
    my ($this) = @_;

    return map {"$_.delete;"} $this->collections;
}

# local declarations of the flush proc
sub dump_flush_proc_decl { 
    return ('i pls_integer;', 'l_processed pls_integer;');
}

sub dump_add_proc_decl { 
    return ('i pls_integer;') 
}

# most typical cases
sub new_update {
    my ( $proto, $fields ) = @_;

    my $bbf = $proto->new( { %$fields, 'dml_statement' => 'update' } );
    for my $key_column ( @{ $fields->{'key_columns'} } ) {
        $bbf->add_column( $key_column, 'key' );
        $bbf->add_input_param($key_column);
    }
    for my $value_column ( @{ $fields->{'value_columns'} } ) {
        $bbf->add_column($value_column);
        $bbf->add_input_param($value_column);
    }

    return $bbf;
}

sub new_delete {
    my ( $proto, $fields ) = @_;

    my $bbf = $proto->new( { %$fields, 'dml_statement' => 'delete' } );
    my @columns = @{ $fields->{'key_columns'} };
    for my $key_column (@columns) {
        $bbf->add_column( $key_column, 'key' );
        $bbf->add_input_param($key_column);
    }
    return $bbf;
}

sub new_insert {
    my ( $proto, $fields ) = @_;

    my @columns = @{ delete( $fields->{'value_columns'} )
            || delete( $fields->{'columns'} ) };
    my $bbf = $proto->new( { %$fields, 'dml_statement' => 'insert' } );
    my $sequence = $fields->{'sequence'};
    for my $column (@columns) {

        # so far only id can be from sequence
        my %opt;
        if ( $sequence && $column eq 'id' ) {
            $bbf->add_column( $column, 'seq', $sequence );
        }
        else {
            $bbf->add_column($column);
            $bbf->add_input_param($column);
        }
    }
    return $bbf;
}

# assigns into the 
sub dump_assign_collections {
    my ($this) = @_;

    return map {
        $_->collection_elem . ':='. $_->input_value . ';';
    } $this->stored_columns;
}


{

    # handle - bulk bind fragment can be used to insert data into database
    #
    # my $handle = $bulk_bind_fragment->init_handle({'db_Main' => $dbh});
    # ...
    # $handle->add(@values);
    # $handle->add(@values);
    # ....
    # $handle->flush;

    # handle is just a bunch of closures
    my $handle_package = __PACKAGE__ . '::_handle';

    for my $proc (qw(add flush added)) {
        no strict 'refs';
        *{ $handle_package . '::' . $proc } = sub {
            my ($this) = shift;

            my $subref = $this->{$proc}
                or croak "$proc can't be called in this phase\n";
            return $this->$subref(@_);
        };
    }

    # opens handle to database for adding the rows and flushing
    sub init_handle {
        my ( $this, $fields ) = @_;

        my $dbh = $fields->{'db_Main'} or croak "No db handle supplied\n ";
        my $database_link = $fields->{'database_link'};

        # complete proc names with database links
        my ($init_proc, $add_proc, $flush_proc) = map {
            my $proc_name = $this->proc_name( $_, 1 );
            if ($database_link) {
                $proc_name .= '@' . $database_link;
            }
            $proc_name;
        } qw(init add flush);

        # initializes (empties) collections
        $dbh->do("BEGIN $init_proc(); END;");

        my $added        = 0;
        my @input_params = $this->input_params;
        my $sth = $dbh->prepare( sprintf "BEGIN $add_proc(%s); END;",
            join ',', map {'?'} @input_params );

        my $add = sub {
            @_ == @input_params + 1
                or croak sprintf( "Expected %s args, got %s\n ",
                scalar(@input_params), scalar(@_) - 1 );

            my $handle = shift;
            $sth->execute(@_);
            $added++;
        };

        my $flush = sub {
            my ( $handle, $options ) = @_;

            # only verbose option is recognized
            my $verbose = $options->{'verbose'};

            if ($verbose) {
                warn sprintf( "Flushing of %s (%d additions) started\n",
                    $this->name, $handle->added );
                $dbh->func(1e5, 'dbms_output_enable');
            }

            $dbh->do("BEGIN $flush_proc(); END;");

            if ($verbose) {
                # flushing output from sys.dbms_output.put_line
                for my $psql_line ( $dbh->func('dbms_output_get') ) {
                    warn 'psql: ', $psql_line, "\n";
                }
                warn sprintf( "Flushing of %s (%d additions) finished\n",
                    $this->name, $handle->added );
            }

            # just for sure - nothing can be called after flush
            $handle->{'add'} = $handle->{'flush'}
                = sub { croak("Handle already flushed\n "); };
        };

        # handle is just a hash of closures
        my %handle = (
            'add'   => $add,
            'added' => sub { return $added },
            'flush' => $flush,
        );
        return bless \%handle => $handle_package;
    }
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96: 
