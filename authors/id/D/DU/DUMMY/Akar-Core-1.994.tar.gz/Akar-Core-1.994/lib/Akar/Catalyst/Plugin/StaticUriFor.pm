package Akar::Catalyst::Plugin::StaticUriFor;
{
  $Akar::Catalyst::Plugin::StaticUriFor::VERSION = '1.994';
}
use strict;
use warnings;


# introduces static_uri_for which does the same as uri_for
# and checks whether the file exists on disk

use Carp qw(carp croak);
use Akar::Base;
use File::Spec;

# so far hardcoded
my $www_root = Akar::Base->app_home('lib/www');
my %checked;

sub static_uri_for {
    my $this = shift;
    @_ == 1 or die "static_uri_for(\$path)";
    my ($path) = @_;

    $checked{$path} ||= do {
        my $abs_path = File::Spec->catfile($www_root, $path);
        -f $abs_path or die "File $abs_path doesnot exist\n";
    };
    return $this->uri_for(@_);
}

1;

__END__

=head1 NAME

Akar::Catalyst::Plugin::StaticUriFor - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
