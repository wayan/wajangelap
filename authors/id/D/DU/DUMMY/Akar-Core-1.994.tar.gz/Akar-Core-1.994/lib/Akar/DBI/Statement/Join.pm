package Akar::DBI::Statement::Join;
{
  $Akar::DBI::Statement::Join::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Akar::DBI::Statement::NonInterpolated);

use overload
    '@{}' => sub { shift()->_elements_accessor },
    'fallback' => 1;

use Carp qw(croak);
use Akar::DBI::Statement::Interpolated;

# elements
__PACKAGE__->mk_accessors(qw(elements));

# glue between elements
__PACKAGE__->mk_accessors(qw(separator));

# 1 if each member should be parenthesized
# if undef then depends on separator (and, or => 1, others => 0)
__PACKAGE__->mk_accessors(qw(parenthesized));

# if false then elements producing empty text are omitted
# when composing the sql
__PACKAGE__->mk_accessors(qw(includes_empty));

sub elements {
    my ($this) = @_;

    my $elements_ref = $this->_elements_accessor or return;

    # every text is turned into interpolated object
    # this is because
    # 1: only interpolated text can work with text
    # 2: when parameter is replaced in text it occurs inside the object
    #     so the number of elements remains same
    for my $text_elem ( grep { !ref($_) } @{$elements_ref} ) {
        $text_elem = Akar::DBI::Statement::Interpolated->new(
            { 'layout' => [$text_elem] } );
    }
    return @{$elements_ref};
}

sub _build {
    my ( $this, $param_callback ) = @_;

    my $parenthesized = $this->parenthesized;

    return join $this->separator, map {
        my $text = $_->_build($param_callback);
        length($text) > 0
            || $this->includes_empty
            ? ( $parenthesized ? "($text)" : $text )
            : ()

    } $this->elements;
}

# returns 1 if every element should be surrounded by parens
sub parenthesized {
    my ($this) = @_;

    my $parenthesized = $this->_parenthesized_accessor;
    return $parenthesized if defined($parenthesized);
    return $this->separator =~ /^\s+(and|or)\s+$/si ? 1 : 0;
}

1;

__END__

=head1 NAME

Akar::DBI::Statement::Join - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
