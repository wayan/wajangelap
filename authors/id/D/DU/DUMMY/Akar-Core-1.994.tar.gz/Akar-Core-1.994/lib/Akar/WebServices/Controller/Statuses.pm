package Akar::WebServices::Controller::Statuses;
{
  $Akar::WebServices::Controller::Statuses::VERSION = '1.994';
}
use Moose::Role;

use Params::Validate qw(SCALAR);

# additional statuses to Catalyst::Controller::REST
sub status_unprocessable_entity {
    my $self = shift;
    my $c    = shift;
    my %p
        = Params::Validate::validate( @_, { message => { type => SCALAR }, },
        );

    $c->response->status(422);
    $c->log->debug( "Status Unprocessable Entity " . $p{'message'} )
        if $c->debug;
    $self->_set_entity( $c, { error => $p{'message'} } );
    return 1;
}

sub status_conflict {
    my $self = shift;
    my $c    = shift;
    my %p
        = Params::Validate::validate( @_, { message => { type => SCALAR }, },
        );

    $c->response->status(409);
    $c->log->debug( "Status Conflict " . $p{'message'} )
        if $c->debug;
    $self->_set_entity( $c, { error => $p{'message'} } );
    return 1;
}

sub status_unauthorized {
    my $self = shift;
    my $c    = shift;
    my %p
        = Params::Validate::validate( @_, { message => { type => SCALAR }, },
        );

    $c->response->status(401);
    $c->log->debug( "Status Unauthorized " . $p{'message'} )
        if $c->debug;
    $self->_set_entity( $c, { error => $p{'message'} } );
    return 1;
}

# these messages has to be serialized differently
# using different writer
after [
    qw(status_bad_request status_not_found status_gone status_unprocessable_entity status_forbidden status_unauthorized)
    ] => sub {
    my ( $this, $c ) = @_;

    $c->stash->{rest_is_error} = 1;
    };



1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
