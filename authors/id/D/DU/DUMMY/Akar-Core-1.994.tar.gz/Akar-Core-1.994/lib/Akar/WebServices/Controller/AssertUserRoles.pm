package Akar::WebServices::Controller::AssertUserRoles;
{
  $Akar::WebServices::Controller::AssertUserRoles::VERSION = '1.994';
}
use Moose::Role;

# this is role not class
requires 'status_forbidden';

# user roles support

# must have all roles otherwise => status_forbidden
sub assert_user_roles {
    my $this = shift;
    my $c    = shift;

    return if $this->check_user_roles( $c, @_);

    $this->status_forbidden( $c, message => 'status forbidden' );
    $c->detach;
}

sub assert_any_user_role {
    my $this = shift;
    my $c    = shift;

    return if $this->check_any_user_role( $c, @_ );

    $this->status_forbidden( $c, message => 'status forbidden' );
    $c->detach;
}

my $check_user_roles = sub {
    my $any = shift;
    my ( $this, $c, $roles ) = @_;

    $c->user_exists or return 0;
    my $user = $c->user or return 0;
    my %has_role = map { ( $_ => 1 ) } $user->roles;
    for my $role ( ref $roles ? @$roles : $roles ) {
        my $has = $has_role{$role};
        return 1 if $has  && $any;
        return 0 if !$has && !$any;
    }
    return !$any;
};

sub check_user_roles { $check_user_roles->(0, @_); }

# returns 1 if user has any of the user roles
sub check_any_user_role { $check_user_roles->( 1, @_ ); }

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
