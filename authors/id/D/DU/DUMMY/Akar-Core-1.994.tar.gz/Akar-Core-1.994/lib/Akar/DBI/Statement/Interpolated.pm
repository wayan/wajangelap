package Akar::DBI::Statement::Interpolated;
{
  $Akar::DBI::Statement::Interpolated::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Akar::DBI::Statement::Object);
use Carp qw(carp croak);

# sequence of texts and statements
__PACKAGE__->mk_accessors(qw(layout));

use overload 'fallback' => 1;

sub new {
    my ($package, $fields) = @_;

    $fields ||= {};
    my $layout = delete $fields->{'layout'};
    my $sql = $package->SUPER::new($fields);
    $sql->set_layout( @{$layout || []} );
    return $sql;
}

sub is_interpolated {
    my ($this) = @_;

    return ref($this) && $this->isa(__PACKAGE__);
}

sub set_layout {
    my ($this, @layout) = @_;

    # concatenates the adjacent texts and flattens nested statements 
    my @new_layout;
LAYOUT: while (@layout) {
        my $elem = shift(@layout);
        if ( is_interpolated($elem) ) {

            # flattening nested
            unshift @layout, $elem->layout;
        }
        elsif ( !ref($elem) && @new_layout && !ref( $new_layout[-1] ) ) {

            # joining texte
            $new_layout[-1] .= $elem;
        }
        else {
            push @new_layout, $elem;
        }
    }
    $this->_layout_accessor(\@new_layout);
    return \@new_layout;
}

sub _build {
    my ( $this, $param_callback ) = @_;

    return join '', map {
        ref($_)
            ? $_->_build($param_callback)    # SQL statement
            : $_                                 # text
    } $this->layout;
}

# layout is read only method
sub layout { return @{ shift()->_layout_accessor || [] }; }

# legacy method, appends text or SQL at the end of current text
# 2008-04-08 danielr
# DEPRECATED, should not be used
sub append {
    my ( $this, @args ) = @_;

    $this->set_layout( $this->layout, @args );
    return $this;
}

sub concatenate {
    my ( $this, $arg, $reversed ) = @_;

    if ( !defined $reversed ) {
        # assignment .= 
        $this->set_layout( $this->layout, $arg);
        return $this;
    }
    return $this->SUPER::concatenate($arg, $reversed);
}

#------------------------------------------------------------------------------
# Replacing parameters in text
#------------------------------------------------------------------------------

sub param_re {
    my ( $this, $param_name ) = @_;
    return qr(\Q$param_name\E\b);
}

sub replace_param_in_text {
    use integer;

    my ( $this, $text, $param_name, $replacement ) = @_;
    my $param_re = $this->param_re($param_name);
    my @texts = split $param_re, $text, -1;
    return ( shift(@texts), map { ( $replacement, $_ ) } @texts );
}

sub has_param {
    my ( $this, $param_name ) = @_;

    my $param_re = $this->param_re($param_name);
    for my $sql ( $this->layout ) {
        my $has_param
            = ref($sql) ? $sql->has_param($param_name) : $sql =~ /$param_re/;
        return 1 if $has_param;
    }
    return;
}

# replace param name in text, returns the number of replacements
sub replace_param {
    my ( $this, $param_name, $replacement ) = @_;

    my $replaced = 0;
    my @new_layout;
    for my $child ( $this->layout ) {
        if ( ref($child) ) {
            # SQL
            $replaced += $child->replace_param( $param_name, $replacement );
            push @new_layout, $child;
        }
        else {
            # text, there must be one parameter left
            my @replaced = grep { defined($_) }
                $this->replace_param_in_text( $child, $param_name,
                $replacement );
            $replaced += @replaced - 1;
            push @new_layout, @replaced; 
        }
    }

    $this->set_layout(@new_layout);
    return $replaced;
}


1;

__END__

=head1 NAME

Akar::DBI::Statement::Interpolated - sequence of texts and sql statements

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
