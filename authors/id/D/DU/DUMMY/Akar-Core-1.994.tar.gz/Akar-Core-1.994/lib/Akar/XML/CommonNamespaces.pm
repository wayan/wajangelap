package Akar::XML::CommonNamespaces;
{
  $Akar::XML::CommonNamespaces::VERSION = '1.994';
}
use strict;
use warnings;


use base qw(Exporter);

# methods exported on demand (preferred)
# is filled further
our @EXPORT_OK;
use Carp qw(carp croak);

# version '-' means I don't know
my %common_namespaces = (

    # soap schema used in wsdl file
    'wsdl'       => [ '-' => 'http://schemas.xmlsoap.org/wsdl/', ],
    'wsdl_soap'  => [ '-' => 'http://schemas.xmlsoap.org/wsdl/soap/', ],
    'xml_schema' => [
        '2001' => 'http://www.w3.org/2001/XMLSchema',
        '1999' => 'http://www.w3.org/1999/XMLSchema',
    ],
    'wsdl_http' => [ '-' => 'http://schemas.xmlsoap.org/soap/http', ],

    'xml_schema_instance' => [
        '2001' => 'http://www.w3.org/2001/XMLSchema-instance',
        '1999' => 'http://www.w3.org/1999/XMLSchema-instance',
    ],
);

sub _add_function {
    my ( $name, $code ) = @_;

    no strict 'refs';
    *{$name} = $code;

    push @EXPORT_OK, $name;
}

while ( my ( $name, $versions_ref ) = each %common_namespaces ) {
    my $default_version = $versions_ref->[0];
    my %versions        = @{$versions_ref};

    # version

    # wsdl_namespace - returns WSDL namespace for given version
    _add_function(
        $name . '_namespace' => sub {
            my $version = shift() || $default_version;
            return $versions{$version};
        }
    );

    # wsdl_versions - returns WSDL versions
    _add_function(
        $name . '_versions' => sub {
            return keys %versions;
        }
    );

    # find_wsdl_version - returns version for given namespace
    # may be used as test whether namespace is wsdl
    _add_function(
        'find_' . $name . '_version' => sub {
            my $namespace = shift();

            my ($version) = grep { $versions{$_} } keys %versions;
            return $version;
        }
    );
}

1;

__END__

=head1 NAME

Akar::XML::CommonNamespaces - commonly used namespaces (XML Schema, WSDL, SOAP)

=head1 SYNOPSIS

    use Akar::XML::CommonNamespaces 
        qw(wsdl_namespace find_wsdl_version xml_schema_versions xml_schema_versions);


    ...
    my $elem = $doc->createElementNs(wsdl_namespace(), 'wsdl:definitions');

    my $xml_schema_ns = xml_schema_namespace; #  'http://www.w3.org/2001/XMLSchema',
    my $xml_schema1999_ns = xml_schema_namespace; # 'http://www.w3.org/1999/XMLSchema',

    my $xml_schema_version = find_xml_schema_version('http://www.w3.org/2001/XMLSchema'); # returns 2001

    my $elem_is_wsdl = $elem->find_wsdl_version($elem->namespaceURI);

=head1 DESCRIPTION
    
Exports functions for commonly used namespaces (XML schema, WSDL, ...).
For each symbolic namespace name NAME (xml_schema, wsdl_soap, wsdl_http) exports function:

=over 4

=item NAME_namespace

    $xml_schema_ns = xml_schema_namespace;
    $xml_schema_ns = xml_schema_namespace('2001');

Returns the namespace. Version can be passed to this function.

=item find_NAME_version

    my $elem_is_wsdl = $elem->find_wsdl_version($elem->namespaceURI);

Returns version for given namespace or undef if the namespace doesn't
conform to any version. Could be used to determine whether an element
is a wsdl:Something for example.

=item NAME_versions

Returns list of all available namespace versions.

=back

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz>

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
