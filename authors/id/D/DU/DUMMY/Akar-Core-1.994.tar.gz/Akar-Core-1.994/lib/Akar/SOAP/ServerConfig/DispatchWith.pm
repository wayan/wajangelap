package Akar::SOAP::ServerConfig::DispatchWith;
{
  $Akar::SOAP::ServerConfig::DispatchWith::VERSION = '1.994';
}
use strict;

use overload '""' => 'as_string';
use base qw(Class::Accessor);

__PACKAGE__->mk_accessors('mapping');

sub as_string {
    my $mapping = shift()->mapping;
    join(' , ', map("$_ => $$mapping{$_}", keys(%$mapping)));
}

sub new { 
    my $proto   = shift;
    my $fields  = shift || {};
    $proto->SUPER::new({'mapping' => {}, %$fields});
}

sub add {
    my $this = shift;
    while(my($k, $v) = splice(@_, 0, 2)){
        $this->mapping->{$k} = $v;
    }
    $this;
}

sub remove {
    my $this = shift;
    delete($this->mapping->{$_}) for @_;
}

1;
