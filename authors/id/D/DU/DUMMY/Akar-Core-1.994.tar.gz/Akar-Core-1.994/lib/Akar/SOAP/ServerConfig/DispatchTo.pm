package Akar::SOAP::ServerConfig::DispatchTo;
{
  $Akar::SOAP::ServerConfig::DispatchTo::VERSION = '1.994';
}
use strict;

use base qw(Class::Accessor);
use overload '""' => 'as_string';

__PACKAGE__->mk_accessors('modules');

sub new { 
    my $proto   = shift;
    my $fields  = shift || {};
    $proto->SUPER::new({'modules' => [], %$fields});
}

sub as_string { join(' ', @{shift()->modules}) }

sub add {
    my $this = shift;

    my %modules = map {$_ => 1} @{$this->modules};
    push @{$this->modules}, grep {!$modules{$_}} @_;
    $this;
}

sub remove {
    my $this = shift;
    my %to_remove = map {$_ => 1} @_;

    $this->modules([ grep(!$to_remove{$_}, @{$this->modules}) ]);
    $this;
}

1;

