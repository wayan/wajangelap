package Akar::AQ::_Queue;
{
  $Akar::AQ::_Queue::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);

use base qw(Class::DBI Akar::AQ::Dbize);

__PACKAGE__->table('sys.all_queues');

# database fields
__PACKAGE__->columns( 'Primary' => 'qid' );
__PACKAGE__->columns(
    'Essential' => qw(owner name queue_table qid queue_type
        max_retries retry_delay enqueue_enabled dequeue_enabled retention)
);

# retrieves by qualified name of the queue 
sub retrieve_by_qname {
    my ($this, $qname) = @_;

    my ( $owner, $queue_name ) = $qname =~ /(.*?)\.(.*)/
        or die "Queue name must be qualified, $qname isnot\n ";

    my ($queue) = $this->search('owner' => $owner, 'name' => $queue_name);
    return $queue;
}

sub retrieve_by_qname_or_die {
    my ( $this, $qname ) = @_;

    my $queue = $this->retrieve_by_qname($qname)
        or die "Queue $qname doesn't exist\n ";
    return $queue;
}

# qualified name of the queue
sub qname {
    my ($this) = @_;
    return $this->owner . '.' . $this->name;
}

sub is_exception_queue {
    return shift()->queue_type eq 'EXCEPTION_QUEUE';
}

# returns all queues in table
sub table_queues {
    my ( $this, $table ) = @_;

    return $this->table_queues( join '.', $this->owner, $this->queue_table )
        if !$table;

    my ( $owner, $queue_table_name ) = split /\./, $table;

    # NORMAL QUEUES goes FIRST
    return $this->search(
        'owner'       => $owner,
        'queue_table' => $queue_table_name,
        { 'order_by' => "decode(queue_type, 'EXCEPTION_QUEUE', 2, 1), qid", }
    );
}

sub dequeue_enabled {
    return shift()->_dequeue_enabled_accessor =~ /yes/i ? 1 : 0;
}

sub enqueue_enabled {
    return shift()->_enqueue_enabled_accessor =~ /yes/i ? 1 : 0;
}

1;

__END__

=head1 NAME

Akar::AQController::Queue - ORM on sys.all_queues

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
