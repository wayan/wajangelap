package Akar::Catalyst::Server;
{
  $Akar::Catalyst::Server::VERSION = '1.994';
}
use strict;
use warnings;

BEGIN {
    $ENV{CATALYST_ENGINE} ||= 'HTTP';
    $ENV{CATALYST_SCRIPT_GEN} = 30;
    require Catalyst::Engine::HTTP;
}

use base qw(Akar::Catalyst::Server::Base);

use Akar::CLI;
use Data::Dump qw(pp);
use Interpolation 'E' => 'eval';
use Akar::Base;
use YAML;

__PACKAGE__->mk_group_accessors('inherited', qw(port application restart debug));

__PACKAGE__->load_config;

use Carp qw(carp croak);

# command line interface
sub run { return shift()->build_cli->run(@_); }

sub application_subname { return 'server'; }

sub build_cli {
    my ($this) = @_;

    my $cli = Akar::CLI->new(
        { 'title' => 'Simple customized personal Catalyst server runner', } );
    $cli->add_option(
        'port|p=i{Port number} -  port number (if not supplied it is taken from config)'
    );
    $cli->add_option('debug|d - force debug mode');
    $cli->add_option('restart|r - restart when files get modified');

#$cli->add_option('fork|f - handle each request in a new process (defaults to false)');
#      -host           host (defaults to all)
#   -p -port           port (defaults to 3000)
#   -k -keepalive      enable keep-alive connections
#   -r -restart        restart when files get modified
#    ( defaults to false )

    #   -rd -restartdelay  delay between file checks
    #   -rr -restartregex  regex match files that trigger
    #                      a restart when modified
    #                      (defaults to '\.yml$|\.yaml$|\.pm$')
    #   -restartdirectory  the directory to search for
    #                      modified files
    #                      (defaults to '../')

    $cli->add_arg('application - the name of application module');
    $cli->set_on_run(
        sub {
            my ($script_call) = @_;

            my %fields = (
                %{ $script_call->options },
                $script_call->value_of('application')
                ? ( 'application' => $script_call->value_of('application') )
                : ()
            );
            $this->new( \%fields )->run_application;
        }
    );
    return $cli;
}

sub run_application {
    my ($this) = @_;

    # restart handling must precede the require of application
    if ( $this->restart && $ENV{'CATALYST_ENGINE'} eq 'HTTP' ) {
        $ENV{'CATALYST_ENGINE'} = 'HTTP::Restarter';
    }
    if ( $this->debug ) {
        $ENV{'CATALYST_DEBUG'} = 1;
    }

    my $application = $this->application
        or die
        "No application set, neither in configuration nor from command line\n ";
    my $port = $this->port
        or die
        "No port set, neither in configuration nor from command line\n ";

    eval qq{ require $application };
    die $@ if $@;

    my $host;    # I don't know what it means
    my @argv;    # same
    $application->run(
        $port, $host,
        {

            'argv' => \@argv,

            #     'fork'            => $fork,
            #     keepalive         => $keepalive,
            'restart' => $this->restart,

            # 2008-05-13 danielr, let us try
            # it may be pretty slow
            'restart_directory' => Akar::Base->perl5lib,

            #     restart_delay     => $restart_delay,
            #     restart_regex     => qr/$restart_regex/,
            #     restart_directory => $restart_directory,
        }
    );
}

1;

__END__

=head1 NAME

Akar::Catalyst::Server - one runner for catalyst server

=head1 SYNOPSIS

=head1 DESCRIPTION

2008-04-04 danielr
I don't like the idea to have one catalyst script for each user and
application. So there is one script with local (very minimal) configuration.

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
