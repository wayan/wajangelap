package Akar::Deploy::GitHook;
{
  $Akar::Deploy::GitHook::VERSION = '1.994';
}
use Moose::Role;

use namespace::autoclean;
use autodie qw(:all);
use IPC::System::Simple qw(capture systemx);

use Akar::CLI;
use File::Temp qw(tempdir);
use Try::Tiny;
use Path::Class;
use Capture::Tiny qw(tee_merged);
use Data::Dump qw(pp);
use MIME::Entity;

# the the name of environment where the application is deployed (demo, production,...)
has env_name => ( is => 'ro', required => 1 );

# the name of the site (gtscz, gtssk for Durian, may be ommitted)
has site => ( is => 'ro' );

# the name of the branch to be deployed
has branch        => ( is => 'ro' );

has called_from_stdin => (
    is      => 'ro',
    lazy    => 1,
    default => sub { shift()->script eq '-' },
);

has script => (
    is      => 'ro',
    lazy    => 1,
    default => sub {
        $0 eq '-' ? $0 : file($0)->absolute->resolve;
    },
);

# list of recipients, where to send and email
has recipients => (
    is      => 'ro',
    isa     => 'ArrayRef',
    default => sub { [] },
    traits  => ['Array'],
    handles => {
        has_recipients => 'count',
        get_recipients => 'elements',
    }
);

# list of cc recipients
has cc => (
    is      => 'ro',
    isa     => 'ArrayRef',
    default => sub { [] },
    traits  => ['Array'],
    handles => { get_cc => 'elements', }
);

has sendmail => (
    is      => 'ro',
    default => '/usr/sbin/sendmail'
);

has deploy_branch => ( is => 'ro', );
has no_bare_check => ( is => 'ro', );
has inplace       => ( is => 'ro', );
has commit        => ( is => 'rw', );
has install_dir   => ( is => 'rw', lazy_build => 1 );

has git_root => ( is => 'ro', lazy_build => 1, );

# It checks the installation also
has akar_base => (
    is         => 'ro',
    lazy_build => 1,
    handles    => [ 'perl5lib', 'app_bin' ]
);

requires 'dirs_to_extract', 'dirs_to_install', 'app_name';

sub _build_akar_base {
    return try {
        require Akar::Base;
        'Akar::Base';
    }
    catch {
        die "It seems that Akar is not installed and setup: $_";
    };
}

sub run {
    my ( $this, @args ) = @_;

    $this->build_cli()->run(@args);
}

sub _build_install_dir {
    return tempdir( CLEANUP => 1 );
}

sub _build_git_root {
    my $this = shift;

    my $f = $this->script;
    while (1) {
        my $parent = $f->resolve->parent;
        die "Cannot find git root\n" if !$parent || $parent eq $f;
        return $parent if -d "$parent/.git";
        $f = $parent;
    }
}

sub build_cli {
    my $class = shift;

    my $cli = Akar::CLI->new(
        {   description => 'Deployment of application via githook',
            on_run      => sub {
                my ($script_call) = @_;
                $class->new_from_options( $script_call->options )->deploy;
            },
        }
    );
    $class->modify_cli($cli);
    return $cli;
}

sub modify_cli {
    my ( $this, $cli ) = @_;

    $cli->add_option(
        'branch=s - the branch which is deployed (the one the hook was called on)'
    );
    $cli->add_option(
        'deploy-branch|d=s - the branch which should be deployed (if supplied must he same as branch)'
    );
    $cli->add_option( 'env_name|env=s - the name of environment (demo, production)' );
    $cli->add_option( 'site=s - the name of the site (gtscz, gtssk)');
    $cli->add_option(
        'recipients|rcpts=s@ - where to send the email with deploy log' );
    $cli->add_option(
        'cc=s@ - where to send the email with deploy log (cc)' );
    $cli->add_option(
        'no-bare-check - Omit the check whether the git repository is bare');
    $cli->add_option(
        'inplace - Development option only. Installs from git repository (must not be bare), does not export.'
    );
}

sub new_from_options {
    my ( $class, $options ) = @_;

    my %opt;
    while ( my ( $k, $v ) = each %$options ) {
        $k =~ s/-/_/g;
        $opt{$k} = $v;
    }

    return $class->new(%opt);
}

# check options
sub check {
    my $this = shift;

    if ( $this->inplace ) {

        # this is for devel only
        die "--inplace can't use for scripts called from stdin"
            if $this->called_from_stdin;
    }
    else {
        my $branch = $this->branch
            or die "Don't know which branch (-branch=NAME) to deploy\n";

        my $commit = try {
            capture( 'git log --format="%h %s" ' . $branch . ' -1' );
        }
        catch {
            die "Can't find commit for branch $branch: $_";
        };
        chomp($commit);
        $this->commit($commit);

        if ( my $deploy_branch = $this->deploy_branch ) {
            $branch eq $deploy_branch
                or $branch eq "refs/heads/$deploy_branch"
                or die
                "You can only deploy from branch '$deploy_branch' not from '$branch'\n";
        }
    }
}

sub BUILD {
    shift()->check;
}

sub deploy {
    my $this = shift;

    my $cwd;
    chomp( $cwd = capture('pwd') );

    if ( $this->called_from_stdin ) {
        $this->no_bare_check
            or capture( 'git', 'rev-parse', '--is-bare-repository' )
            =~ /^true/
            or die "Git repository is not bare\n";
    }
    else {
        warn "Switching into " . $this->git_root . "\n";

        # going up to git root
        chdir( $this->git_root );
    }

    if ( !$this->inplace ) {
        $this->extract_repo;
        warn "Deploying commit" . $this->commit . "\n";
    }

    # checks exported repo
    $this->check_repo;

    my $error;
    my $output = tee_merged {
        try {
            $this->install;
            warn $this->title . " - installation successfull\n";
        }
        catch {
            $error = $_;
            warn $error. "\n";
            warn $this->title . " - installation failed\n";
        }
        finally {
            chdir($cwd) if $cwd;
        };
    };

    if ( $this->has_recipients ) {
        try {
            $this->send_email(
                $this->build_email_entity($output, !$error)->stringify );
        }
        catch {
            warn "Email sending failed: $_\n";
        };
    }
    die $error if $error;
}

sub check_repo {
    my $this = shift;
    for my $dir ( $this->dirs_to_install ) {
        -d $dir or die "Missing directory $dir in repo\n";
        -f "$dir/Build.PL" or die "Missing $dir/Build.PL\n";
    }
}

sub extract_repo {
    my $this = shift;

    my $install_dir = $this->install_dir;
    my $branch      = $this->branch;
    my $the_dirs    = join( ' ', $this->dirs_to_extract );
    try {
        system(
            join "\n",
            "git archive --format=tar $branch $the_dirs | (cd $install_dir; tar -xf - )",
            'exit ${PIPESTATUS[0]}'
        );
    }
    catch {
        die "Can't extract the branch $branch: $_";
    };

    chdir($install_dir);
}

sub install {
    my $this = shift;

    $this->stop_services;
    $this->install_deps;
    $this->install_modules;
    $this->start_services;
    $this->run_tests;
}

sub services {
    return ();
}

# returns the names of test files or test dirs to be run after installation
sub test_files {
    return ();
}

sub stop_services {
    my $this = shift;

    my @services = $this->services or return;

    warn "Stopping services\n";
    SERVICE: for my $service ( @services ) {
        # there can be fresh installation
        # so the services aren't available yet
        my $path = file($service)->absolute( $this->app_bin );
        -f $path or next SERVICE;
        system( $path, 'stop');
    }
}

sub start_services {
    my $this = shift;

    my @services = $this->services or return;

    warn "Starting services\n";
    for my $service ( @services ) {
        system( file($service)->absolute( $this->app_bin ), 'start' );
    }
}

sub install_deps {
    my $this = shift;

    warn "Installing dependencies from cpan (darkpan)\n";
    for my $dir ( $this->dirs_to_install ) {
        system 'cpanm', '--installdeps', $dir;
    }
}

sub install_modules {
    my $this = shift;
    warn "Installing modules\n";
    system 'Akar-Module-Install', $this->dirs_to_install;
}

sub send_email {
    my ( $this, $entity ) = @_;

    open( my $fh, '|-', $this->sendmail, $this->get_recipients, $this->get_cc );
    $fh->print($entity);
    close($fh);
}

sub build_email_entity {
    my ( $this, $content, $ok ) = @_;

    return MIME::Entity->build(
        To      => join( ',', $this->get_recipients ),
        Cc      => join( ',', $this->get_cc ),
        Subject => $this->title. ' '.($ok? 'OK': 'FAILED'),
        Data    => [$content],
        # From => 'roman@daniel.cz',
    );
}

sub run_tests {
    my $this = shift;

    my @tests = $this->test_files or return;

    warn "Running postinstallation tests\n";
    systemx "prove", '-v', '-r', @tests;
}

# The title of the deployment
sub title {
    my $this = shift;

    return sprintf '%s installation at %s',
        join( ' ', grep {$_} $this->app_name, $this->site ), $this->env_name;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
