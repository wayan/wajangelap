package Akar::XML::Compile::Util;
{
  $Akar::XML::Compile::Util::VERSION = '1.994';
}
use strict;
use warnings;

use Exporter qw(import);

our @EXPORT_OK = qw(autoexpand_all_xsi_types);

sub autoexpand_all_xsi_types {
    my ($xml_compile) = @_;

    # probably very slow and uneffective
    my $namespaces = $xml_compile->namespaces;
    my %all;
    for my $type ( map { ( $_->simpleTypes, $_->complexTypes ) }
        $namespaces->allSchemas )
    {
        my @extensions
            = grep { $_ ne $type } $namespaces->findTypeExtensions($type);
        $all{$type} = \@extensions if @extensions;
    }
    return \%all;
}

1;
