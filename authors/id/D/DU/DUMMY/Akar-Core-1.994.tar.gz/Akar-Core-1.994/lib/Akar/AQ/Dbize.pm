package Akar::AQ::Dbize;
{
  $Akar::AQ::Dbize::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor::Grouped);
use Scalar::Util qw(refaddr blessed);

use Carp qw(carp croak);
use Akar::AQ::PseudoStorage;


# predavani spojeni mezi tridami - jakasi "pseudoemulace" schematu z
# DBIx::Class
# pro Class::DBI
__PACKAGE__->mk_group_accessors('inherited', 'storage');

sub dbize {
    my $this = shift;

    if ( !ref( $_[0] ) ) {

        # passing my storage to other class
        my $other_class = shift;
        my $storage     = $this->storage
            or die "Invocant ($this) is not dbized\n ";
        return dbize( $other_class, $storage );
    }

    # arguments are (package, storage) next arg may be connection sub
    my $storage = shift();

    !ref($this)
        or die "package->dbize(\&connection_sub)";

    # Legacy code - subroutine passed as connection
    if ( !blessed($storage) && ref $storage eq 'CODE' ) {
        my $connection_sub = $storage;
        $storage = Akar::AQ::PseudoStorage->new(
            { connection_sub => $connection_sub } );
    }

    if ( $this->storage ) {
        $this->storage == $storage
            or die "Package dbized with different connection";
        return $this;
    }

    my $derived_package = $this . '::dbized' . refaddr($storage);
    return $derived_package if $derived_package->isa($this);

    no strict 'refs';
    @{ $derived_package . '::ISA' } = ($this);
    $derived_package->storage($storage);
    return $derived_package;
}

sub txn_do {
    my $this = shift;
    return $this->storage->txn_do(@_);
}

sub db_Main {
    my $this = shift;
    return $this->storage->dbh;
}

1;

__END__

=head1 NAME

Akar::AQ::Dbize - passing db_Main to classes

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
