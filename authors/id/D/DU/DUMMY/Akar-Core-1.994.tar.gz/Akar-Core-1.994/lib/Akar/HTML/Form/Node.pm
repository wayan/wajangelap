package Akar::HTML::Form::Node;
{
  $Akar::HTML::Form::Node::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor::Fast);

use Carp qw(carp croak);
use Scalar::Util qw(weaken blessed);
use Akar::HTML::Form::Utils qw(is_array auto_expand);
use Data::Dumper;
use Akar::HTML::Form::Exceptions;

use Class::C3;

__PACKAGE__->mk_ro_accessors(qw(basename name parent_form));
__PACKAGE__->mk_ro_accessors('label');
__PACKAGE__->mk_ro_accessors('inflators', 'deflators');

# validation rules
__PACKAGE__->mk_ro_accessors('validations');

# if 1 the value is not included into its parent form
__PACKAGE__->mk_ro_accessors('omit_value');

# the value is included in parent form even it is undef
__PACKAGE__->mk_accessors('force_value');

# characters joining the input_basenames of nested field (form)
# to get input name
sub input_name_separator { return '-' };

sub new {
    my ( $class, $fields_ref ) = @_;

    $fields_ref ||= {};

    my $parent_form = $fields_ref->{'parent_form'};
    my $basename    = $fields_ref->{'basename'};

    # 2009-01-14 danielr
    # basename may be '0' but not '' or undef
    die "No basename supplied\n"
        if $parent_form
        && ( !defined $basename || $basename eq '' );

    my $validation = delete $fields_ref->{'validation'};

    # input basename can be undefined
    my $node = $class->next::method(
        {   input_basename => $basename,
            label          => $basename,
            %$fields_ref,
            inflators   => [],
            deflators   => [],
            validations => [],
        }
    );
    #weaken $node->{parent_form}        if $parent_form;
    $node->add_validation($validation) if $validation;
    return $node;
}

#-------------------------------------------------------------------------------
#   Navigation
#-------------------------------------------------------------------------------

# finds field according to relative path
sub field {
    my ( $this, $path ) = @_;

    # special case
    return $this              if $path eq '.';
    return $this->parent_form if $path eq '..';

    # /+ is for typo case /a//c
    if ( my ( $first, $rest ) = $path =~ m{^(.*?)/+(.*)$} ) {
        my $field = $first eq '' ? $this->root_form : $this->field($first)
            or return;
        return $rest eq '' ? $field : $field->field($rest);
    }
    return $this->subfield($path);
}

#-------------------------------------------------------------------------------
#   Properties (values, ....)
#-------------------------------------------------------------------------------

sub _value_of {
    my ( $this, $method, $path ) = @_;

    if ( UNIVERSAL::isa( $path, 'ARRAY' ) ) {
        my @value_of = map {
            my $value = $this->_value_of( $method, $_ );
            defined $value ? ( $_ => $value ) : ();
        } @$path;
        return wantarray ? @value_of : {@value_of};
    }
    my $field = $this->field($path)
        or die "No field $path found in form\n";
    return $field->$method;
}

# if value_of is passed ARRAY it returns hashref  
for my $property (qw(input_name id value path is_supplied raw_value)) {
    no strict 'refs';
    *{ $property . '_of' } = sub {
        my $this = shift;
        return $this->_value_of( $property, @_ );
    };
}

#-------------------------------------------------------------------------------
#   Validation and values
#-------------------------------------------------------------------------------

# it is redefined in form, so I can simply
sub validation_context {
    my $this = shift;
    return $this->parent_form->validation_context;
}

sub value { return shift()->inflated_value }

# 2009-01-11 danielr
# it allways returns one value
# because of $key => $x->value_of('field')
sub inflated_value {
    my $this = shift;

    my $inflated_values = $this->validation_context->{inflated_values};
    my $name            = $this->name;

    # already inflated
    $inflated_values->{$name} = $this->inflate_value( $this->raw_value )
        if !exists $inflated_values->{$name};
    return $inflated_values->{$name};
}

# very simple "user" error 
# i.e. error which can be displayed to user
sub throw_validation_failed {
    my $this = shift;
    my ($message) = @_;

    Akar::HTML::Form::Exceptions::ValidationFailed->throw(
        message => $message,
        origin  => $this,
    );
}

sub throw_missing_field {
    my $this = shift;

    Akar::HTML::Form::Exceptions::MissingField->throw(
        message => 'Field is missing',
        origin  => $this
    );
}

sub is_missing {
    my $this = shift;
    return $this->validation_context->{is_missing}{$this->name};
}

# adds inflate and deflate subroutines
sub add_inflator {
    my $this = shift;
    my ( $inflator, $deflator ) = @_;

    if ($inflator) {
        push @{ $this->inflators }, $inflator;
    }
    if ($deflator) {
        unshift @{ $this->deflators }, $deflator;
    }
}

# runs the inflators on a value
sub inflate_value {
    my ( $this, $raw_value ) = @_;

    my @inflators   = @{ $this->inflators } or return $raw_value;
    my @inflated    = auto_expand $raw_value;
    for my $inflator (@inflators) {
        eval { @inflated = map { $inflator->( $_, $this ) } @inflated };
        if ($@){
            $this->handle_validation_exceptions;
            $this->validation_context->{'inflation_failed'}{ $this->name } = 1;
            return undef;
        }
    }
    return scalar auto_expand(@inflated);
}

sub deflate_value {
    my ( $this, $inflated_value ) = @_;
    
    my @deflators = @{$this->deflators} or return $inflated_value;

    my @deflated = auto_expand $inflated_value;
    for my $deflator ( @deflators){
        # only references are deflated
        @deflated = map { ref $_ ? $deflator->( $_, $this ) : $_; } @deflated;
    }
    return scalar auto_expand @deflated;
}

#  very temporary way how to display a value
sub dump_value {
    my $this  = shift;
    my $value = @_ ? shift() : $this->value;

    my $dumper = Data::Dumper->new( [$value] );
    $dumper->Terse(1);

    no warnings;
    local *UNIVERSAL::dump_form_value = sub {
        my $this = shift;
        return {
            class => ref $this,
            value => "$this",
        };
    };
    $dumper->Freezer('dump_form_value');
    return $dumper->Dump;
}

sub add_validation {
    my ($this, $rule) = @_;

    # validation rule can be a regular expression qr{...}
    # not string
    if (ref($rule) && ref($rule) eq 'Regexp'){
        my $re = $rule;
        $rule = sub {

            # field is taken from the argument not $this
            # to prevent circular reference
            my ( $field_value, $field, $form ) = @_;
            $field_value =~ $re
                or $field->throw_validation_failed('Neplatn� hodnota "' . $field->label . '"' . "\n");
        };
    }
    
    UNIVERSAL::isa($rule, 'CODE')
        or die "Invalid rule format for field '". $this->basename . "'\n"; 

    push @{ $this->validations }, $rule;
}

sub process_validations {
    my $this = shift;

    for my $rule ( @{ $this->validations } ) {
        # rule is processed even if OK is false
        $this->process_validation($rule)
    }
}

sub process_validation {
    my ( $this, $rule ) = @_;

    # rule is CODE
    my $value = local $_ = $this->value;

    # rule is not called when the inflation went wrong
    return if $this->validation_context->{'inflation_failed'}{$this->name};
    
    eval {
        $rule->( $value, $this );
    };
    if ($@){
        $this->handle_validation_exceptions;
        return 0;
    }
    return 1;
}

sub handle_validation_exceptions {
    my ($this) = @_;

    my $context = $this->validation_context;
    my $error;
    if ( $error = Akar::HTML::Form::Exceptions::MissingField->caught ) {
        my $origin = $error->origin || $this;
        # name can be field as well as name
        my $name = ref($origin)? $origin->name: $origin;
        $context->{is_missing}{ $name } = 1;
        $context->{ok} = 0;
    }
    elsif ( $error = Akar::HTML::Form::Exceptions::ValidationFailed->caught )
    {
        my $origin = $error->origin || $this;
        # name can be field as well as name
        my $name = ref($origin)? $origin->name: $origin;

        push @{ $context->{validation_messages}{ $name } },
            $error->message;
        $context->{ok} = 0;
    }
    elsif ( $error = $@ ) {

        # 2009-03-13 danielr let's die
        die $error;
    }
}

# validation messages for a field 
sub validation_messages {
    my $this = shift;

    my $msgs
        = $this->validation_context->{validation_messages}{ $this->name };
    return $msgs ? @$msgs : ();
}

sub is_invalid { return scalar shift->validation_messages }

1;

__END__

=head1 NAME

Akar::HTML::Form::Node - common ancestor of form and field

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
