package Akar::DBI::Statement::Object;
{
  $Akar::DBI::Statement::Object::VERSION = '1.994';
}
use strict;
use warnings;

use DBI;
use Carp qw(croak);

# modifies (hacks) DBI::db so it can work with sql statement in place of text
no strict 'refs';
no warnings 'redefine';

# if reference is caught it is passed unmodified
# otherwise space is appended so the croak reports
# the origin of the error
my $die_with = sub {
    my ($err) = @_;

    die $err if ref $err; # object is passed unchanged

    # string is modified
    my $file = __FILE__;
    croak $err if $err =~ s/ at $file line (\d+).\n//;
    die $err;
};

# wraps methods in db_handler package so they are able
# to work with statement whenever a text statement should be used 
sub inject_into_db {
    my ($db_package) = @_;

    for my $method (
        qw(selectall_arrayref selectall_hashref selectcol_arrayref
        selectrow_array selectrow_arrayref selectrow_hashref
        )
        )
    {
        my $orig_method = $db_package->can($method)
            or croak
            "Package $db_package doesn't have the expected method $method\n ";
        *{ $db_package . '::' . $method } = sub {

            # parameters are: $sth, $sql_statement, \%attr , @arguments)
            if ( Akar::DBI::Statement::is_sql( $_[1] ) ) {
                my ( $text, @values ) = $_[1]->text_and_values;
                @_ = (
                    $_[0], $text, $_[2] || undef,
                    @values, @_ > 2 ? splice( @_, 3 ) : ()
                );
            }

            # handling context
            if (wantarray) {
                my @retval = eval { $orig_method->(@_); };
                $die_with->($@) if $@;
                return @retval;
            }
            else {
                my $retval = eval { $orig_method->(@_); };
                $die_with->($@) if $@;
                return $retval;
            }
        };
    }

    # do is specific - there may be inout parameters
    for my $do_method (qw(do)) {
        my $orig_method = $db_package->can($do_method);

        *{ $db_package . '::' . $do_method } = sub {
            my $rows = eval {
                Akar::DBI::Statement::is_sql( $_[1] )
                    ? do {

                    # sql is passed
                    my $sth = $_[1]->prepare_and_bind( $_[0] );
                    $sth->execute;
                    $sth->rows || '0E0';
                    }
                    : $orig_method->(@_);
            };
            $die_with->($@) if $@;
            return $rows;
        };
    }

    for my $prepare_method (qw(prepare prepare_cached)) {
        my $orig_method = $db_package->can($prepare_method);

        *{ $db_package . '::' . $prepare_method } = sub {
            my $sth;    #return value
            if ( Akar::DBI::Statement::is_sql( $_[1] ) ) {
                my ( $text, $bindings_ref ) = $_[1]->build_numbered();
                eval {
                    splice( @_, 1, 1, $text );
                    $sth = $orig_method->(@_) or return;
                    for my $binding ( @{$bindings_ref} ) {
                        $binding->($sth);
                    }
                };
            }
            else {
                eval { $sth = $orig_method->(@_); };
            }
            $die_with->($@) if $@;
            return $sth;
        };
    }
}

inject_into_db('DBI::db');

1;

__END__

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
