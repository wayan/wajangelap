package Akar::Mason::Compiler::Filters;
{
  $Akar::Mason::Compiler::Filters::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(HTML::Mason::Compiler::ToObject Class::Accessor::Grouped);
use Class::C3;

use Carp qw(carp croak);
use Sub::Name qw(subname);
use Data::Dumper;

__PACKAGE__->mk_group_accessors('inherited' => '_abraka' );

my %closing_callback_for = (
    start_component        => 'end_component',
    start_block            => 'end_block',
    start_named_block      => 'end_named_block',
    component_content_call => 'component_content_call_end',
);
my %opening_callback_for
    = map { ( $closing_callback_for{$_} => $_ ); } keys %closing_callback_for;

my @callbacks = (
    qw(
        raw_block
        doc_block
        perl_block
        text
        text_block
        variable_declaration
        key_value_pair
        substitution
        component_call
        perl_line
        ), %closing_callback_for
);

sub callbacks { return @callbacks; }

sub new {
    my $class    = shift;
    my $compiler = $class->next::method(@_);

    $compiler->_abraka(
        {

          # where am I currently nested (component with content, methods, ...)
            stack   => [],
            filters => [],    # array of filters currently in process
            max_filters => 30, # to check for adding filters in wrong place
        }
    );
    return $compiler;
}

my %is_callback = map { ( $_ => 1 ) } @callbacks;

# 2011-02-10 danielr
# adding filters in compile is leads to too many filters
# I'll check

sub add_filter {
    my ( $this, $filter, $priority ) = @_;

    ref $filter eq 'HASH'
        or die
        "Invalid filter - hash of handlers is expected, not $filter\n ";

    $priority ||= 50;

    # filters are sorted by the priority
    my $filters     = $this->_abraka->{filters};
    my $max_filters = $this->_abraka->{max_filters};

    @$filters < $max_filters
        or die "You try to add too many filters, maximum is $max_filters\n";

    my $i = @$filters;
    $i-- while $i && $filters->[$i - 1]{_priority} > $priority; 
    splice @$filters, $i, 0, { %$filter, _priority => $priority };
}

# every callback is changed
for my $callback (@callbacks) {
    no strict 'refs';
    *$callback = subname $callback => _callback_sub($callback);
}

sub stop_callbacks {
    my $this = shift;

    $this->_abraka->{stopped} = 1;
}

sub _callback_sub {
    my $callback = shift;

    return sub {
        my $this = shift;

        my $abraka = $this->_abraka;
        my ( $filters, $stack ) = @$abraka{qw(filters stack)};

        if ( $closing_callback_for{$callback} ) {

            # opening callback
            push @$stack, {
                callback => $callback,

                line_number => $this->lexer->line_number,

                component_name => $this->lexer->name,

                # current state of filters is remembered
                # and the filters are restored with closing
                filters => [@$filters],
            };
        }

       # returns 1 if the message was processed so the compiler could not care
        local $abraka->{stopped} = 0;

        # going through all filters until some processes the callback
        # the level is decreased so the compiler calls from a filter
        # are processed only by filters on lower levels
        my @current_filters = @{$abraka->{current_filters} || $filters};
        local $abraka->{current_filters} = \@current_filters;
        while ( my $filter = !$abraka->{stopped} && pop @current_filters ) {
            my $handler = $filter->{$callback} or next;
            $handler->( $this, @_ );
        }

        if ( my $opening_callback = $opening_callback_for{$callback} ) {

            # closing callback
            my $last_stack = pop @$stack;
            if ($opening_callback ne $last_stack->{callback}){
                my $line_number = $this->lexer->line_number;
                my $component_name = $this->lexer->name;
                die
                "Opening ($last_stack->{callback}, $last_stack->{component_name}: $last_stack->{line_number}) ". 
                    "and closing ($callback, $component_name: $line_number) callbacks mismatch\n";
            }

            # restoring filters
            # removing all filters created inside the block
            $abraka->{filters} = $last_stack->{filters};
        }

        # finally callback is processed by the original method
        $abraka->{stopped} or $this->next::method(@_);
        };
}

# utils
sub output_perl {
    my $this = shift;
    my $code = shift();

    if ( my ($closing_code) = @_ ) {
        my $callback_stopped = $this->_abraka->{stopped};
        $this->on_close(
            sub {
                $this->output_perl($closing_code);
                $this->stop_callbacks if $callback_stopped;
            }
        );
    }

    my @bt = qw(block_type perl);
    $this->start_block(@bt);
    $this->raw_block( @bt, block => $code);
    $this->end_block(@bt);
}

sub output_text {
    my $this = shift;
    my $text = shift;

    $this->text( 'text' => $text );
}


# sets the handler to be called when current block (method, component content call, ...)
# is closed
sub on_close {
    my $this = shift;
    my $handler = shift;

    my $stack            = $this->_abraka->{stack};
    my $closing_callback = $closing_callback_for{ $stack->[-1]{callback} };
    my $stack_level      = @$stack;
    $this->add_filter(
        {   $closing_callback => sub {
                my $self = shift;
                if ( @{ $self->_abraka->{stack} } == $stack_level ) {
                    $handler->( $self, @_ );
                }
                }
        }, @_
    );
}

1;

__END__

=head1 NAME

Akar::Mason::Compiler::Filters - enables to stash independent filters 

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
