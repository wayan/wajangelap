package Akar::PL_SQL::ArgList;
{
  $Akar::PL_SQL::ArgList::VERSION = '1.994';
}
use strict;

sub _arg {
    my ($name, $value, $is_named) = @_;
    Akar::PL_SQL::Arg->new(
        {
            'name'     => $name,
            'value'    => $value,
            'is_named' => $is_named
        }
    );
}

# create
sub new {
    my ($proto, $value, $named) = @_;

    return $value if UNIVERSAL::isa($value, __PACKAGE__);

    my @args;
    if (UNIVERSAL::isa($value, 'HASH')) {
        while (my ($k, $v) = each(%$value)) {
            push @args, _arg($k, $v, 1);
        }
    }
    elsif (UNIVERSAL::isa($value, 'ARRAY')) {
        if ($named) {
            my @value = @$value;
            while (my ($k, $v) = splice(@value, 0, 2)) {
                push @args, _arg($k, $v, 1);
            }
        }
        else {
            my $k = 0;
            for my $v (@$value) {
                push @args, _arg(++$k, $v, 0);
            }
        }
    }
    else {
        die "Very internal error\n ";
    }
    bless(\@args, $proto);
}

sub is_empty { not @{shift()} }

{

    package Akar::PL_SQL::Arg;
{
  $Akar::PL_SQL::Arg::VERSION = '1.994';
}

    # function or procedure argument - just container
    use base qw(Class::Accessor);
    __PACKAGE__->mk_ro_accessors(qw(name value is_named));

    sub placeholder {
        my ($this) = @_;

        ':' . ($this->is_named ? '' : 'p') . $this->name;
    }
}

1;
