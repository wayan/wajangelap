package Akar::PL_SQL::Caller;
{
  $Akar::PL_SQL::Caller::VERSION = '1.994';
}
use strict;

=head1

=cut

use base qw(Class::Accessor);

use Akar::PL_SQL::Call;

__PACKAGE__->mk_accessors(qw(dbh package debug_level));

sub create_call {
    my ($this, $is_function, $method, $args, $return_type) = @_;

    Akar::PL_SQL::Call->new(
        {
            'is_function' => $is_function,
            'dbh'         => $this->dbh,
            'method'      => join('.', grep $_, $this->package, $method),
            'args' => $args || [],
            'return_type' => $return_type
        }
    );
}

sub call { shift()->create_call(defined(wantarray()), @_)->execute }

sub dump_call { shift()->create_call(defined(wantarray()), @_)->dump }

1;
