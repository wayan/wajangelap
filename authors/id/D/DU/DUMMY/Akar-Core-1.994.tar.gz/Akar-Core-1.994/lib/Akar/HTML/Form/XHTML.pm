package Akar::HTML::Form::XHTML;
{
  $Akar::HTML::Form::XHTML::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);

# all methods return xhtml in form ['element', \%attr, content1, content2 ]
# for example ['input', {type => 'text', disabled => 'disabled'}]
# or ['select', {name=>'region'}, ['option', {value='Prag'}, 'Praha'], ...]
#
# in minimal form
sub xhtml_envelope {
    my $this = shift;

    return [
        'form',
        {   method  => $this->method,
            enctype => $this->enctype,
            action  => $this->action,
        }
    ];
}

sub xhtml_input {
    my ($this, $field, $requested_type) = @_;

    ref $field or $field = $this->field($field);
    my $type = $requested_type || $field->type || 'text';
    my $method = "xhtml_input_$type";
    return $this->$method($field);
}

sub xhtml_option {
    my ($this, $field, $option, $requested_type) = @_;

    ref $field or $field = $this->field($field);
    my $type = $requested_type || $field->type || 'text';
    my $method = "xhtml_option_$type";
    return $this->$method($field, $option);
}

sub _if_defined { return defined $_[1]? @_:(); }

# renders text field
sub xhtml_input_text {
    my $this  = shift;
    my $field = shift;

    return [
        'input',
        {   type => 'text',
            name => $field->name,
            _if_defined( value => $field->elem_value )
        }
    ];
}

sub xhtml_input_hidden {
    my $this  = shift;
    my $field = shift;

    return [
        'input',
        {   type  => 'hidden',
            name  => $field->name,
            _if_defined(value => $field->elem_value),
        }
    ];
}

sub xhtml_input_select {
    my $this = shift;
    my $field = shift;
    my %args = @_;

    my @options;
    if (my $select_name = delete $args{select_name} || $field->select_name){
        push @options, ['option', {value => ''}, $select_name];
    }

    for my $opt ( $field->normalized_options ) {
        my ( $value, $label, $selected ) = @$opt;

        push @options,
            [
            'option',
            {   value => $value,
                ( $selected ? ( selected => 'selected' ) : () )
            }, $label
            ];
    }
    return ['select', {name =>$field->name}, @options];

    #     <select id="customer_type" name="customer_type">
    #     #   <option value="">-select-</option>
    #     #   <option selected="selected" value="jako">jako</option>
    #     #   <option value="mako">mako</option>
    #     #   <option value="pako">pako</option>
    #     #   </select>
    #
}

sub xhtml_input_textarea {
    my $this  = shift;
    my $field = shift;
    my %args  = @_;

    delete $args{type};
    my $elem_value = $field->elem_value;
    $elem_value = '' if !defined $elem_value;
    return ['textarea', {name => $field->name}, $elem_value ];
}

sub xhtml_input_file {
    my $this  = shift;
    my $field = shift;

    return [ 'input', { name => $field->name, type => 'file' } ];
}

sub xhtml_input_password {
    my $this = shift;
    my $field = shift;
    
    # password is forgotten?
    return [ 'input', { name => $field->name, type => 'password' } ];
}

sub xhtml_input_submit {
    my $this  = shift;
    my $field = shift;

    return [
        'input',
        {   name  => $field->name,
            type  => 'submit',
            value => $field->def_value
        }
    ];
}

sub xhtml_input_checkbox {
    my $this  = shift;
    my $field = shift;
    my @args  = @_;

    return
        map { $this->xhtml_option_checkbox( $field, $_ ); }
        $field->normalized_options;
}

sub xhtml_input_radio {
    my $this  = shift;
    my $field = shift;
    my @args  = @_;

    return
        map { $this->xhtml_option_radio( $field, $_ ); }
        $field->normalized_options;
}

sub xhtml_option_radio {
    my $this   = shift;
    my $field  = shift;
    my $option = shift;

    return [
        'input',
        {   type  => 'radio',
            name  => $field->name,
            value => $option->[0],
            ( $option->[2] ? ( checked => 'checked' ) : () ),
        }
    ];
}

sub xhtml_option_checkbox {
    my $this   = shift;
    my $field  = shift;
    my $option = shift;

    return [
        'input',
        {   name  => $field->name,
            type  => 'checkbox',
            value => $option->[0],
            ( $option->[2] ? ( checked => 'checked' ) : () ), @_
        }
    ];
}

1;

__END__

=head1 NAME

Akar::HTML::Form::XHTML - rendering of form inputs

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
