package Akar::DFA;
{
  $Akar::DFA::VERSION = '1.994';
}
use strict;

sub new {
	my $proto = shift;
	my $class = ref($proto) || $proto;
	my $self  = {};

	bless ($self, $class);
	$self->clear;
	return $self;
}

sub clear {
	my $self = shift;
	
	$self->{MAXNODE} = 0;
	$self->{FINAL_STATES} = ();
	$self->{DELTA} = ();
}

sub add_string {
	my $self = shift;
	my ($string,$final_value) = @_;

	my $state = 0;
	my $key = '';
	my $len = length($string);

	for (my $next = $state; $next < $len; $next++) {
		$key = substr($string,$next,1);
		if (not exists($self->{DELTA}[$state]->{$key})) {
			$self->{MAXNODE}++;
			$self->{DELTA}[$self->{MAXNODE}] = {};
			$self->{DELTA}[$state]->{$key} = $self->{MAXNODE};
		}
		$state = $self->{DELTA}[$state]->{$key};
	}
	
	if (defined($self->{FINAL_STATES}{$state})
		and $self->{FINAL_STATES}{$state} ne $final_value) {
		# Oops, we're trying to redefine older final state :(
		# so return error...
		return 0;
	}
	$self->{FINAL_STATES}{$state} = $final_value;
	return 1;
}

sub match_short {
	_match('SHORT', @_);
}

sub match_long {
	_match('LONG', @_);
}

sub match_full {
	_match('FULL', @_);
}

# don't call this function directly! it's a lowlevel function.
# call $dfa->match_full, $dfa->match_long, $dfa->match_short instead
sub _match {
	my $match_type = shift;
	my $self = shift;
	my ($string) = @_;
#print "($match_type, $self, $string)\n";
	my $state = 0;
	my $next = 0;
	my $key = '';
	my $len = length($string);
	my $ret = undef;

	while(defined($state) and $next < $len) {
		$key = substr($string, $next, 1);
		$state = $self->{DELTA}[$state]->{$key};
		$next++;
		$ret = $self->{FINAL_STATES}{$state} if ($match_type eq 'LONG'
				or $match_type eq 'SHORT')
				and defined($state)
				and exists($self->{FINAL_STATES}{$state});
		last if $match_type eq 'SHORT' and defined($ret);
	}

	$ret = $self->{FINAL_STATES}{$state} if $match_type eq 'FULL';
	return $ret;
}

sub empty
{
	my $self = shift;
	
	return ($self->{MAXNODE} == 0);
}

1;

__END__
