package Akar::DBIC::Result::Dispatcher;
{
  $Akar::DBIC::Result::Dispatcher::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(DBIx::Class);

use Carp qw(carp croak);
use Module::Find;

# this class can be used to make dispatcher as well as dispatched classes
# dispatcher class is a result (row) class with overridden inflate_result
# so the resulted object is one of its "subclasses", i.e. dispatched
# classes
#
# !!! dispatched classes are not subclasses of the dispatcher
# they have to share some common subclass which contains 
# all table, columns and relationships definition

__PACKAGE__->mk_classdata('dispatched_class_for');
__PACKAGE__->mk_classdata('dispatched_moniker');

sub is_dispatcher { return shift()->dispatched_class_for ? 1 : 0; }

sub is_dispatched { return shift()->dispatched_moniker ? 1 : 0 }

sub new {
    my $class = shift;

    die "You cannot call create, insert, .. on dispatcher resultset"
        . "you need to call \$rs->dispatched_resultset(XYZ) first\n"
        if $class->is_dispatcher;
    return $class->next::method(@_);
}

sub inflate_result {
    my $class = shift;

    $class->is_dispatcher or return $class->next::method(@_);

    my $moniker = $class->find_dispatched_class(@_)
        or die "Can't find dispatched class\n ";
    my $dispatched_class = $class->dispatched_class_for->{$moniker}
        or die "No dispatched class for moniker $moniker\n ";
    return $dispatched_class->inflate_result(@_);
}

# returns the dispatched subclass
sub find_dispatched_class {
    my $class = shift;
    my ( $source, $me, @rest ) = @_;

    my $dispatched_class_for = $class->dispatched_class_for or return;
    for my $moniker ( keys %$dispatched_class_for ) {
        my $dispatched_class = $dispatched_class_for->{$moniker};
        return $moniker if $dispatched_class->result_is_mine(@_);
    }
    return;
}

# I need resultset_class to behave like class data for dispatched classes 
__PACKAGE__->mk_classdata('_resultset_class_cdata');

our $_is_dispatched; # set when loading dispatched classes

sub resultset_class {
    my $class = shift;

    $class->is_dispatched || $_is_dispatched
        or return $class->next::method(@_);

    # wanting classdata
    my $retval = $class->_resultset_class_cdata(@_);
    if (!@_ && !$retval){
        # getter not found anything 
        $class->_resultset_class_cdata($retval = $class->next::method);
    }
    return $retval;
}

# load "sources" under current source
sub setup_dispatcher_class {
    my $class            = shift;
    my $result_namespace = shift;

    $result_namespace
        or die
        "\$class->setup_dispatcher_class(\$result_namespace)\n ";

    die "You cannot call setup_dispatcher_class on dispatcher class\n "
        if $class->is_dispatcher;

    {
        my $required_rs = 'Akar::DBIC::ResultSet::Dispatcher';
        $class->resultset_class->isa($required_rs)
            or die
            "To use setup_dispatcher_class your resultset has to inherit from $required_rs";
    }

    # prefix for dispatched classes
    Module::Find::findsubmod($result_namespace) or die "No dispatched classes found\n ";

    my $orig_result_class = $class->result_source_instance->resultset_class;

    # I need the dispatcher (UserTicket) source to instantiate results
    # into this class not Akar::SchemaExt::UserTicket
    $class->result_source_instance->result_class($class);

    my %dispatched_class_for;
    local $_is_dispatched = 1;
    for my $subclass ( Module::Find::usesub($result_namespace) ) {
        my ($moniker) = $subclass =~ /^\Q$result_namespace\E::(.*)/;
        $dispatched_class_for{$moniker} = $subclass;

        # 2010-07-14 danielr
        # Cannot call setup_dispatched_class because it may be too late
        # (if the subclass had set resultset_class it would be changed
        # for all classes of result source)
        #$subclass->setup_dispatched_class();
        $subclass->result_source_instance == $class->result_source_instance
            or die "Dispatched class has share result_source_instance\n";
        not( $subclass->isa($class) )
            or die
            "Dispatched class cannot be subclass of $class\n";
        $subclass->dispatched_moniker($moniker);
    }

    $class->dispatched_class_for( \%dispatched_class_for );
}

1;

__END__

=head1 NAME

Akar::DBIC::Result::Dispatcher - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
