package Akar::HTML::Form::Exceptions;
{
  $Akar::HTML::Form::Exceptions::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);
use Scalar::Util qw(weaken blessed);
use Exporter 'import';

our @EXPORT_OK = qw(throw_validation_failed throw_missing_field);

BEGIN {
    require Exception::Class;
    my $class_prefix = __PACKAGE__;

    my $base_class = "$class_prefix\::UserException";
    Exception::Class->import(

        # origin is the node where the exception occured
        $base_class                    => => { fields => [qw(origin)] },
        "$class_prefix\::MissingField" => {
            isa     => $base_class,
            'alias' => 'throw_missing_field'
        },
        "$class_prefix\::ValidationFailed" => {
            isa     => $base_class,
            'alias' => 'throw_validation_failed'
        },
    );
}

1;

__END__

=head1 NAME

Akar::HTML::Form::Exceptions - exceptions for form 

=head1 SYNOPSIS

=head1 DESCRIPTION

So far it only contains validation exception and missing exception

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
