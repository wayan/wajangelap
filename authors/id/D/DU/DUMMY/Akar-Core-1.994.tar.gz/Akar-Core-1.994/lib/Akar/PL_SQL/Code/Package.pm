package Akar::PL_SQL::Code::Package;
{
  $Akar::PL_SQL::Code::Package::VERSION = '1.994';
}
use strict;

use base qw(Akar::PL_SQL::Code);
# rows of PL/SQL package 
use Akar::PL_SQL::Code::Functions qw(parse_proc);

sub package {
    my ($this) = @_;
    return $this;
}

sub dump_header {
    my ($this) = @_;

    return (  'create or replace package '
            . ( $this->dumping_body ? 'body ' : '' )
            . $this->name );
}

sub dump_decl {
    return ();
}

sub dump_footer {
    my ($this) = @_;

    my $name = $this->name;
    $name =~ s/.*\.//;
    return 'end '. $name;
}

sub dump {
    my ($this) = @_;

    return (
        $this->dump_header,
        'is',
        $this->dump_decl,
        map( $_->dump_package_decl, @{ $this->children } ),
        map( $_->dump,              @{ $this->children } ),
        $this->dump_footer,
        ';',
    );
}

# dumps package and package_body
sub dump_all {
    my ($this) = @_;

    return join "\n", $this->dump_text(0),
        '/', 'show errors', '',
        $this->dump_text(1),
        '/', 'show errors', '';
}

sub dump_package_decl {
    return ()
}

# adds proc (procedure or function)
# ensures right part of the proc to appear in package and package body
# $proc can be rows of code or text
sub add_proc {
    my ( $this, $proc_or_text ) = @_;

    my $proc =
        UNIVERSAL::isa( $proc_or_text, 'Akar::PL_SQL::Code::Proc' )
        ? $proc_or_text
        : parse_proc($proc_or_text);

    $this->add_child($proc);
    return $proc;
}

1;
