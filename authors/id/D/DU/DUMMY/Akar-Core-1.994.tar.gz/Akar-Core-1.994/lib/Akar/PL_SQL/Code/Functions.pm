package Akar::PL_SQL::Code::Functions;
{
  $Akar::PL_SQL::Code::Functions::VERSION = '1.994';
}
use strict;

use base qw(Exporter);
our @EXPORT_OK
    = qw(join_lines iblock join_ilines 
    ilist
    block_opener block_closer parse_proc
    truncate_ident);

require Akar::PL_SQL::Code::Proc;

use constant 'MAX_IDENT_LENGTH' => 30;

sub block_opener {
    return '-- {{';
}

sub block_closer {
    return '-- }}';
}

# prepend all lines but the first by the separator
sub join_lines {
    my ( $sep, $first, @rest ) = @_;

    return ( $first, map {"$sep$_"} @rest );
}

# indented (inner) block
sub iblock {
    my (@rows) = @_;

    return ( block_opener, @rows, block_closer );
}


# indented joined lines
sub join_ilines {
    my ( $sep, @rows ) = @_;

    return iblock( join_lines( $sep, @rows ) );
}

# indented comma separated list
sub ilist {
    return join_ilines( ', ', @_);
}

# given text or lines of complete procedure (or functions)
# returns procedure object to be placed in package or package body
# (slightly parses the text and finds header and  body of the procedure)
sub parse_proc {
    my ($code) = @_;

    if ( UNIVERSAL::isa($code, 'ARRAY') ) {
        $code = Akar::PL_SQL::Code->join_rows(@$code);
    }

    my ( $header, $decl, $body )
        = $code =~ (/^(.*?)\bis\b(.*)\bbegin\b(.*)\bend\b/s)
        or die "Unparsable code $code\n ";

    my ($name) = $header =~ /(?:procedure|function)\s+(\w+)/
        or die "Can't find proc name\n ";

    s/\n\s*$//s for $header, $decl, $body;
    s/^\s+//s   for $header, $decl, $body;

    my @header = split( /\n/, $header );
    my @decl   = split( /\n/, $decl );
    my @body   = split( /\n/, $body );

    # looking for header (line must begin with is)
    return Akar::PL_SQL::Code::Proc->new(
        {   'name'   => $name,
            'body'   => \@body,
            'header' => \@header,
            'decl'   => \@decl,
        }
    );
}

# truncates identifier to maximum MAX_IDENT_LENGTH (30) chars
# when called twice for the same identifier returns same value
{
    my $ident_no;
    my %truncated_of;

    sub truncate_ident {
        my ( $ident_start, $ident_suffix ) = @_;
        $ident_suffix = '' if !defined($ident_suffix);

        my $ident = $ident_start . $ident_suffix;

        # short enough
        return $ident if length($ident) <= MAX_IDENT_LENGTH;

        # cached
        return $truncated_of{$ident} if $truncated_of{$ident};

        # first time truncated 
        my $truncated = substr($ident_start, 0, MAX_IDENT_LENGTH - length($ident_suffix) - 4)
            . sprintf( '%04X', ++$ident_no )
            . $ident_suffix;
        $truncated_of{$ident} = $truncated;
        return $truncated;
    }
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96:
