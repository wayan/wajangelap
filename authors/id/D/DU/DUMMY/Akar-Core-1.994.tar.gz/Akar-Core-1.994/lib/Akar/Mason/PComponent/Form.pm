package Akar::Mason::PComponent::Form;
{
  $Akar::Mason::PComponent::Form::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Akar::Mason::PComponent);

# rendering to mason for Akar::HTML::Form
use Carp qw(carp croak);
use Akar::Mason::Utils ();

our $Form;      # form currently being rendered
our $FormDisabled; # current form is disabled
our $Field;     # field currently being set by the environment
our $Option;    # option currently being processed [value, label, selected]
our %Args;      # arguments set by the component with content (field, options)

sub element_tag {
    shift();
    return Akar::Mason::Utils::element_tag(@_);
}

# Renders the complete form
sub form : Local : Global {
    my ( $this, $m, %args ) = @_;
    die "Cannot call form inside form\n " if $Form;
    local $Form = delete $args{form} or die "No form supplied\n ";

    local $FormDisabled = delete $args{disabled};
    my $xhtml = $Form->xhtml_envelope();
    my ( $open, $close ) = $this->element_tag($xhtml->[0], %{$xhtml->[1]}, %args );
    $m->print($open);
    $m->pcomp_render_content();
    $m->print($close);
}

# sets only the form but doesnot render the form envelope
sub form_body : Local {
    my ( $this, $m, %args ) = @_;

    local $Form = $args{form} or die "No form supplied\n ";
    local $FormDisabled = delete $args{disabled};
    $m->pcomp_render_content();
}

sub _require_form {
    my $where = shift;
    $Form or die "$where cannot be called outside form\n";
}

# returns field object and its type
sub _get_field {
    my $this     = shift;
    my $args_ref = shift;

    my ( $field, $type );
    if ( my $name = delete $args_ref->{field} ) {
        # explicit field 
        if ( ref $name ) {
            $field = $name;
        }
        else {
            $field = $Form->field($name)
                or die "There is no field $name in current form\n";
        }
        $type = $args_ref->{type} || $field->type || 'text';
    }
    elsif ($Field) {
        # implicit field - may be set by option
        $field = $Field;
        $type = $args_ref->{type} || $Args{type} || $Field->type || 'text';
    }
    else {
        die "No field passed or set\n";
    }
    return wantarray ? ( $field, $type ) : $field;
}

# returns the option for a field
# option is triplet [ $value, label, $is_selected ]
sub _get_option {
    my $this     = shift;
    my $field    = shift;
    my $args_ref = shift;

    if ( exists $args_ref->{option} ) {
        my $option_value = delete $args_ref->{option};
        my @options      = $field->normalized_options;
        my ($option) = grep { $_->[0] eq $option_value; } @options
            or die "No option $option_value found\n";
        return $option;
    }
    elsif ($Option) {
        return $Option;
    }
    else {
        die "No option set or passed\n";
    }
}

# renders field input
sub input : Local {
    _require_form('input');

    my ( $this, $m, %args ) = @_;

    # environment - field is called with content
    die "input cannot have content" if $m->pcomp_has_content;
    if ($FormDisabled){
        $args{disabled} = 'disabled';
    }

    my ( $field, $type ) = $this->_get_field( \%args );
    for my $xhtml ( $field->parent_form->xhtml_input( $field, $type ) ) {
        $m->print( $this->_render_xhtml( $xhtml, { %Args, %args } ) );
    }
}

sub _render_xhtml {
    my ( $this, $xhtml, $attr_append) = @_;

    my ($elem, $attr, @content) = @$xhtml;
    my @attr_all = (%$attr, ($attr_append? %$attr_append: ()));

    # single tag
    @content or return scalar $this->element_tag( $elem, @attr_all );

    # tag with content
    my ( $open, $close ) = $this->element_tag( $elem, @attr_all );
    return join( '',
        # text musi projit nejakym escape
        $open, ( map { ref($_) ? $this->_render_xhtml($_) : $_; } @content ),
        $close );
}

sub label : Local {
    _require_form('label');

    my ( $this, $m, %args ) = @_;
    my $field = $this->_get_field( \%args );
    $m->print( $field->label );
}

# this is the environment for rendering all options
sub options : Local {
    _require_form('options');

    my ( $this, $m, %args ) = @_;
    my ( $field, $type ) = $this->_get_field( \%args );
    my $optref = $args{optionref} || do { \my @option; };

    local $Field = $field;
    local %Args  = ( %Args, %args );
    for my $opt ( $field->normalized_options ) {
        local $Option = $opt;
        @$optref = @$opt;
        $m->pcomp_render_content();
    }
}

sub option : Local {
    _require_form('option');

    my ( $this, $m, %args ) = @_;
    if ($FormDisabled){
        $args{disabled} = 'disabled';
    }

    my ( $field, $type ) = $this->_get_field( \%args );
    my $option = $this->_get_option( $field, \%args );
    my $xhtml = $field->parent_form->xhtml_option($field, $option, $type);
    $m->print( $this->_render_xhtml($xhtml, \%args) );
}

sub option_label : Local {
    _require_form('option_label');

    my ( $this, $m, %args ) = @_;

    my $field = $this->_get_field( \%args );
    my $option = $this->_get_option( $field, \%args );
    $m->print( $option->[1] );
}

sub hidden_fields : Local {
    _require_form('hidden_fields');

    my ( $this, $m ) = @_;
    $this->input( $m, field => $_ ) for $Form->hidden_fields;
    return;
}

1;

__END__

=head1 NAME

Akar::Mason::Form - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
