package Akar::SOAP::Utils;
{
  $Akar::SOAP::Utils::VERSION = '1.994';
}
use strict;
use warnings;

=head1 NAME

Akar::SOAP::Utils - miscellaneous usefull utilities

=head1 SYNOPSIS

    use Akar::SOAP::Utils qw(xml_data xml_return_data); 
    use SOAP::Lite;

    my $soap = SOAP::Lite->new(...);

    my $xml = '<SendOHS xmlns="http://tempuri.org">'
        . '<customerID>23</customerID>'
        . '<Cli>4569696</Cli>'
        . '<ComplexOrder>28</ComplexOrder>'
        . '</SendOHS>';
    $soap->call(soap_xml_data($xml_data));

    # inside dispatched function
    sub my_function {
        ...
        my $data_returned = '<BodyContent>'.
            'This is exactly the content of SOAP:Body response, '.
            'no method element should be added'.
            '</BodyContent>';

        return soap_response_body(soap_xml_data($data_returned));
    }

=head1 DESCRIPTION

All methods are exported on demand

=over 4

=item soap_xml_data(DATA)

    my $soap_data = xml_data($text);
    my $soap_data = xml_data($xml_libxml_document);
    my $soap_data = xml_data($xml_libxml_element);

Returns SOAP::Data instance, which goes unmodified through serialization.
Can be used ( via SOAP::Lite->call($xml_data) ) to call document/literal SOAP
service with the exact SOAP body content (no encoding, no method wrapping on the way).

=item soap_response_body($soap_data)

   ....
   return soap_response_body(soap_xml_data('<see>This is the only content of SOAP:Body</see>'));

Accept any SOAP::Data and modify them (hack) them so they can pass through
return from dispatched function and return to the client without being wrapped
by 'method'Response element

=item soap_document_passed(SOM)

    sub my_method {
        my $som = pop(@_);

        my $document_passed = soap_document_passed($som);
    }

Called in SOAP server, returns the whole content of SOAP body as XML (text).
Accepts the soap message - SOAP::SOM object 

=item soap_document_passed_as_doc(SOM)

Returns the content as XML::LibXML::Document

=item soap_xml_as_string_data($xml, %params)

Given $xml (document or string), creates SOAP::Data instance with type string
which will pass the SOAP unharmed.

=item guess_local_soap_proxy

    my $soap = SOAP::Lite->proxy( guess_local_soap_proxy, \%options);

Tries to guess from Akar::SOAP::Manager(2) configuration the local SOAP sever proxy.
Options are so far:

=over 4

=item ssl

If set to true. https server proxy is guessed instead of http one.

=back

=item guess_local_soap_wsdl_url_for

    my $wsdl_url
        = guess_local_soap_wsdl_url_for( 'CSR::SOAP::GP::TeleHouse', \%options );

Tries to guess from Akar::SOAP::Manager(2) configuration, where is WSDL url
for a perl package.

=back

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz>

=cut

use base qw(Exporter);
our @EXPORT_OK
    = qw(soap_xml_data soap_response_body soap_document_passed_as_doc
    soap_document_passed
    soap_xml_as_string_data
    guess_local_soap_proxy
    guess_local_wsdl_url_for);

use URI;
use XML::LibXML;
use Encode;
use Carp qw(carp croak);
use Akar::XML::DOMBuilder;

sub soap_xml_data { return Akar::SOAP::Data::XMLLiteral->new_data(@_); }

sub soap_response_body {
    my ($soap_data) = @_;

    return Akar::SOAP::Data::ResponseBody->new_data($soap_data);
}

sub soap_document_passed {
    return soap_document_passed_as_doc(@_)->documentElement->toString;
}

# 2008-04-04 danielr
# because this "reverse" engineering of XML doesn't work reliably
# I have to add another terrible SOAP::Lite hack
# I mangle deserialize so it stores the original XML
{
    no warnings 'redefine';
    use SOAP::Lite;    # I redefine deserializer

    my $orig_method = SOAP::Deserializer->can('deserialize');
    *SOAP::Deserializer::deserialize = sub {
        my $xml_passed = $_[1];
        my $som        = $orig_method->(@_);
        if ( UNIVERSAL::isa( $som, 'SOAP::SOM' ) ) {
            $som->{'akar_xml_passed'} = $xml_passed;
        }
        return $som;
    };
}

sub soap_document_passed_as_doc {
    my ($som) = @_;

    my $xml = eval { $som->{'akar_xml_passed'} };
    if (!$@ && $xml){
        my $doc = XML::LibXML->new->parse_string($xml);

        # content node lies under envelope and body
        my ($content_node) = $doc->findnodes("/*/*[local-name() = 'Body']/*");

        my $xb = Akar::XML::DOMBuilder->new;;
        return $xb->create_doc($content_node);
    }

    # old way
    $som->match( ref($som)->method );
    my $xml_obtained = SOAP::Lite->serializer->xmlize( $som->current );
    return XML::LibXML->new->parse_string($xml_obtained);
}

sub soap_xml_as_string_data {
    my ($value, %options) = @_;

    my $text; 
    if (!ref($value)){
        # text passed it is serialized and deserialized
        my $doc = XML::LibXML->new->parse_string($value);
        $doc->setEncoding('utf8');
        $text = $doc->toString;
    }
    elsif ( UNIVERSAL::isa( $value, 'XML::LibXML::Document' )){
        # document passed 
        my $doc = $value;
        my $encoding = $doc->encoding;
        if ($encoding =~ /^utf-?8$/i){
            $text = $doc->toString;
        }
        else {
            $doc->setEncoding('utf8');
            $text = $doc->toString;
            $doc->setEncoding($encoding);
        }
    }
    else {
        die "Argument os soap_xml_as_string_data must be either string "
            . " or XML::LibXML::Document, not $value\n ";
    }

    return SOAP::Data->new(
        'type'  => 'string',
        'value' => (
            Encode::is_utf8($text) ? Encode::encode( 'utf-8', $text ) : $text
        ),
        %options
    );
}

sub guess_local_soap_proxy {
    my ($options) = @_;

    $options ||= {};
    my $ssl = $options->{'ssl'};

    # tries old configuration
    require Akar::SOAP::Manager;

    # the newest way - new version of Akar::SOAP::Manager available
    if ( Akar::SOAP::Manager->can('soap_proxy_url') ) {
        return $ssl
            ? Akar::SOAP::Manager->ssl_soap_proxy_url
            : Akar::SOAP::Manager->soap_proxy_url;
    }

    # the old way, presumes that Akar::SOAP::Manager loaded Akar::SOAP::ServerConfig
    if ( UNIVERSAL::can( 'Akar::SOAP::ServerConfig', 'load' ) ) {
        my $server_config = Akar::SOAP::ServerConfig->load;
        return $ssl ? $server_config->ssl_proxy : $server_config->proxy;
    }

    return;
}

sub guess_local_wsdl_url_for {
    my $package = shift();

    # tries new configuration
    my $soap_proxy = guess_local_soap_proxy(@_) or return;
    my $wsdl_url = URI->new($soap_proxy);
    $wsdl_url->path( join '/', 'wsdl', split /::/, $package );
    return $wsdl_url->as_string;
}

{

    package Akar::SOAP::Data::XMLLiteral;
{
  $Akar::SOAP::Data::XMLLiteral::VERSION = '1.994';
}

# SOAP::Data imunni vuci set_value (krome konstruktoru)
# tudiz zkurveny kod
# v SOAP::Serializer::envelope  (nize)
#        # This is breaking a unit test right now...
#        $body->set_value(
#            SOAP::Utils::encode_data( $parameters ? \$parameters : () ) )
#            if $body;
# nezkombinuje $body (SOAP::Data, ktera jsem poslal jako method) s prazdnym seznamem
# parametru a $body zachova, tudiz
# SOAP obalka obsahuje uvnitr elementu body presne to co jsem poslal
# Na dalsi brodeni SOAP::Lite nemam cas
    use strict;

    use SOAP::Lite;
    use Akar::Iconv qw(utf8_as_bytes utf8_as_chars);
    our @ISA = qw(SOAP::Data);

# new SOAP::Lite requires strings to be character utf8, 
# they are mercifully converted via Encode::encode('utf-8', ...)
# which causes bytes in utf-8 to be encoded again
    *_utf8_for_soaplite = $SOAP::Lite::VERSION >= 0.712 ?
        \&utf8_as_chars
        : \&utf8_as_bytes;

    # the constructor new_data to avoid conflict with SOAP::Data->new
    sub new_data {
        my ( $package, $value, $flags ) = @_;

        # value can be text, XML::LibXML::Document, XML::LibXML::Element
        my $node =
            !ref($value)
            ? XML::LibXML->new->parse_string($value)->documentElement
            : UNIVERSAL::isa( $value, 'XML::LibXML::Element' ) ? $value
            : UNIVERSAL::isa( $value, 'XML::LibXML::Document' )
            ? $value->documentElement
            : die "Invalid param of XML data\n ";

        my $text = $node->toString;

        # 2008-09-22 danielr, 
        # protoze se nedari poslat UTF8 data do O2 (nesedi delka obalky)
        # pokusim se zakodovat UT8 entity
        if ($flags && $flags->{'encode_unicode_entities'}){
            $text = utf8_as_chars($text);   
            # all non ascii characters are turned into unicode entities
            $text =~ s/([^[:ascii:]])/'&#'. ord($1). ';'/xeg;
        }

        # 2007-09-12 danielr, I guess that the text for SOAP::Lite
        # should be byt not character UTF8 otherwise
        #   Wide character error occur as it was in cabernet
        my $data = SOAP::Data->new(
            'type'   => 'xml',
            # 2008-09-25 danielr 
            # !!!!!!!!!!
            # XML::LibXML DOM methods (name, prefix, ...)
            # return character UTF8,
            # But the name MUST be turned to utf8_as_bytes
            # because its passed into HTTP::Request as SOAPAction header
            # and when joined with other headers and context which are
            # character UTF8 causes them to be double encoded 
            'value'  => _utf8_for_soaplite($text),
            'name'   => _utf8_for_soaplite($node->localname),
            'prefix' => _utf8_for_soaplite($node->prefix),
            'uri'    => _utf8_for_soaplite($node->namespaceURI),
        );
        return bless $data => $package;
    }

    # object can't be broken by set_value
    sub set_value { return shift(); }

}

{

    package Akar::SOAP::Data::ResponseBody;
{
  $Akar::SOAP::Data::ResponseBody::VERSION = '1.994';
}

# response serializovany s temito daty neobaluje data obalkou metody kruty hack
    use Carp qw(carp croak);

    sub new_data {

        # invocant  passed is ignored
        my ( undef, $value ) = @_;

        # argument must be SOAP::Data descendant object
        croak __PACKAGE__ . '->new_data($soap_data_obj)'
            if !ref($value) || !UNIVERSAL::isa( $value, 'SOAP::Data' );

        return $value if UNIVERSAL::isa( $value, __PACKAGE__ );

        # new package is constructed
        my $derived_package = ref($value) . '::akar_response_body';
        my $isa_ref = do {
            no strict 'refs';
            \@{ $derived_package . '::ISA' };
        };
        if ( !@{$isa_ref} ) {
            @{$isa_ref} = ( __PACKAGE__, ref($value) );
        }

        # object is just reblessed
        return bless $value => $derived_package;
    }

    # value can't be set
    sub set_value { return shift(); }

    my $orig_envelope_sub = \&SOAP::Serializer::envelope;
    no warnings 'redefine';
    *SOAP::Serializer::envelope = sub {

        # if the only value returned is xml data then
        # method name (parameter 2) is removed from the parameter list
        if (   $_[1] eq 'response'
            && UNIVERSAL::isa( $_[3], __PACKAGE__ )
            && @_ == 4 )
        {
            splice( @_, 2, 1 );
        }
        goto $orig_envelope_sub;
    };

}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
