package Akar::XML::DOMBuilder::Functions;
{
  $Akar::XML::DOMBuilder::Functions::VERSION = '1.994';
}
use strict;
use warnings;


use base qw(Exporter);

# methods exported on demand (preferred)
our @EXPORT_OK = qw(create_xml_doc);

# methods exported automatically
our @EXPORT = qw();

use Carp qw(carp croak);
use Akar::XML::DOMBuilder;

{
    my $xb = Akar::XML::DOMBuilder->new;

    sub create_xml_doc {
        return $xb->create_doc(@_);
    }
}

1;

__END__

=head1 NAME

Akar::XML::DOMBuilder::Functions - imports functions for XML creations 

=head1 SYNOPSIS

    use Akar::XML::DOMBuilder::Functions qw(create_xml_doc);

    my $doc = create_xml_doc(
        'a',
        { 'id' => 100 },
        [ 'b1' => 'B1' ],
        [ 'b2' => 'B2' ]
    );
    warn $doc->toString(1);

    # prints:
    #   <?xml version="1.0"?>
    #   <a id="100">
    #     <b1>B1</b1>
    #     <b2>B2</b2>
    #    </a>

=head1 DESCRIPTION

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz>

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
