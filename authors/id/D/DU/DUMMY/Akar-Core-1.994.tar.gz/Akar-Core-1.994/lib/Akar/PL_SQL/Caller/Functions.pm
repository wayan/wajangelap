package Akar::PL_SQL::Caller::Functions;
{
  $Akar::PL_SQL::Caller::Functions::VERSION = '1.994';
}
use strict;
use warnings;

=head1 NAME

Akar::PL_SQL::Caller::Functions - types and values used to call PL/SQL code 

=head1 FUNCTIONS

All following functions are imported on demand

=over4

=cut

use base qw(Exporter);

our @EXPORT_OK = qw(
    psql_record
    psql_boolean psql_true psql_false
    psql_sql
    build_psql_call
    dump_psql_call
    _psql_context
);

# 2008-03-24 these objects are not ready yet
# psql_sqlobject
# psql_sequence

use Data::Dump qw(pp);
use Akar::DBI::Statement qw(sql sql_param sql_join sql_param_inout);
use Interpolation 'E' => 'eval', 'sqlp' => sub { sql_param(@_) };
use Class::Prototyped;
use Scalar::Util qw(blessed);

sub build_psql_call {
    my ($method, $args, $retval_ref) = @_;

    my $context = _psql_context();
    my @arglines;
    if ( $args && UNIVERSAL::isa( $args, 'ARRAY' ) && @{$args} ) {
        my $i;
        @arglines = map {
            my $line = psql_sql()->new($_)->build_statement($context);
            $i++ ? ", $line" : $line;
        } @{$args};
    }
    elsif ( $args && UNIVERSAL::isa( $args, 'HASH' ) && %{$args} ) {
        my $i;
        @arglines = map {
            my $line = "$_ => "
                . psql_sql()->new( $args->{$_} )->build_statement($context);
            $i++ ? ", $line" : $line;
        } keys %{$args};
    }

    my @body = @arglines ? ( "$method(", @arglines, ");" ) : ("$method;");
    if ($retval_ref){
        #function call
        $body[0] = psql_sql()->new($retval_ref)->build_statement($context) . ':=' . $body[0]; 
    }
    return $context->statement( \@body );
}

sub _dump_param {
    my ($param) = @_;
    return $param->is_inout
        ? '{ \$var }'
        : '{ ' . pp($param->value) . '}';
}

sub dump_psql_call {
    my ($statement) = @_;

    return $statement->_build( \&_dump_param );
}

sub _psql_context {
    my ( @decl, @prologue, @epilogue );

    my $varno = 0;
    return Class::Prototyped->new(
        'decl'            => sub { return @decl },
        'prologue'        => sub { return @prologue },
        'epilogue'        => sub { return @epilogue },
        'add_to_decl'     => sub { shift; push @decl, @_; return;},
        'add_to_prologue' => sub { shift; unshift @prologue, @_; return; },
        'add_to_epilogue' => sub { shift; push @epilogue, @_; return; },
        'add_var_for'         => sub {
            my ( $this, $value ) = @_;

            my $type = $value->typename;
            my $varname = join '_', split /[^a-z0-9_]/i, $type;
            substr($varname,24) = '' if length($varname) > 24;
            my $var  = 'l_' . $varname . ( $varno++ || '' );
            $this->add_to_decl( $var . ' ' . $value->typename . ';' );
            return $var;
        },
        'statement' => sub {
            my ( $this, $body ) = @_;
            return sql_join( "\n", 'DECLARE', $this->decl, 'BEGIN',
                $this->prologue, @{ $body || [] },
                $this->epilogue, 'END;' );
        }
    );
}

{
    my $base_type = Class::Prototyped->newPackage(
        __PACKAGE__ . '::_Type',
        'new' => sub {
            my ( $this, $value ) = @_;
            return Class::Prototyped->new(
                'type*' => $this,
                'value' => $value,
            );
        },
        'is_output_value' => sub {
            my ($this) = @_;
            my $value_ref = ref($this->value);
            return $value_ref && ($value_ref eq 'SCALAR' || $value_ref eq 'REF');
        },
    );

    sub _new_type {
        my ( $typename, %fields ) = @_;
        return Class::Prototyped->new(
            'parent*' => $base_type,
            'typename'    => $typename,
            %fields
        );
    }
}
{
    my $psql_sql = _new_type(
        '',
        'build_statement' => sub {
            my ( $this, $context, $var ) = @_;

            return $this->is_output_value
                ? sql_param_inout( $this->value, 512 )
                : sql_param( $this->value );
        }
    );
    $psql_sql->reflect->addSlot(
        [qw(new METHOD superable)] => sub {
            my ( $this, $value ) = @_;
            return blessed($value) && $value->can('typename')
                ? $value
                : $this->reflect->super( 'new', $value );
        }
    );
    sub psql_sql { return $psql_sql }
}

{
    my $psql_boolean = _new_type(
        'boolean',
        'build_statement' => sub {
            my ( $this, $context, $var ) = @_;
            $var ||= $context->add_var_for($this);

            return (
                $this->is_output_value
                ? do {
                    my $sqlp = sql_param_inout( $this->value, 5 );
                    $context->add_to_epilogue(
                        "if $var then $sqlp := 1 else $sqlp := 0; end if;" );
                    }
                : $context->add_to_prologue(
                    "$var := $sqlp{$this->value} <> 0;"),
                $var
            );
        }
    );
    my $psql_true  = $psql_boolean->new(1);
    my $psql_false = $psql_boolean->new(0);

    sub psql_boolean { return $psql_boolean }
    sub psql_true    { return $psql_true }
    sub psql_false   { return $psql_false }
}

my $build_record = sub {
    my ($this, $context, $var) = @_;
        
    $var ||= $context->add_var_for($this);
    
    my $is_out = $this->is_output_value;
    my %output;
    for my $field ( $is_out ? $this->fields : keys %{ $this->value } ) {
        my $fvar  = "$var.$field";
        my $ftype = $this->field_type($field) || psql_sql;
        my $fstat = $ftype->new(
            $is_out
            ? \$output{$field}
            : $this->value->{$field}
        )->build_statement( $context, $fvar );
        if ($is_out) {
            $context->add_to_epilogue("$fstat := $fvar;");
        }
        else {
            $context->add_to_prologue("$fvar := $fstat;");
        }
    }
    return $var;
};

sub psql_record {
    my ( $name, $type_of_ref ) = @_;

    my %type_of = %{ $type_of_ref || {} };
    return _new_type(
        $name,
        'fields'      => sub { return keys %type_of },
        'field_type'  => sub { return $type_of{ $_[1] }; },
        'build_statement' => $build_record,
    );
}

sub psql_sqlobject {
    my ( $name, $fields_ref ) = @_;

    my %type_of = @{$fields_ref};
    my @fields = @{$fields_ref}[ grep { $_ % 2 == 0 } 0 .. $#$fields_ref ];
    return _new_type(
        $name,
        'fields'  => sub { return @fields },
        'field_type' => sub { return $type_of{ $_[1] }; },
    );
}

sub psql_sequence {
    my ( $name, $base_type ) = @_;
    return _new_type(
        $name,
        'base_type' => $base_type || psql_sql,
        'build_statement' => sub {
            my ( $this, $context, $var ) = @_;

            die "No output sequence allowed\n" if $this->is_output_value;

            $var ||= $context->add_var_for($this);
            my $value = $this->value;
            for ( my $i = 0; $i < @{$value}; $i++ ) {
                $context->add_to_prologue( "$var($i) := "
                        . $this->base_type->new( $value->[$i] )
                        ->build_statement( $context, "$var($i)" ) . ";" );
            }
            return $var;
        },
    );
}


1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
