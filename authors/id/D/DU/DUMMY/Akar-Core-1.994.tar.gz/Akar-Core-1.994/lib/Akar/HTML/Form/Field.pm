package Akar::HTML::Form::Field;
{
  $Akar::HTML::Form::Field::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Akar::HTML::Form::Node);

use Carp qw(carp croak);

use Akar::HTML::Form::Utils qw(is_array auto_expand);
use overload    
    '""' => sub { return shift()->name; },
    'fallback' => 1;

# use Smart::Comments;

__PACKAGE__->mk_accessors('required');
__PACKAGE__->mk_accessors('required_message');
__PACKAGE__->mk_accessors('required_if');
__PACKAGE__->mk_accessors('validates');
__PACKAGE__->mk_accessors('is_static');
__PACKAGE__->mk_accessors('type');
__PACKAGE__->mk_accessors('options');
__PACKAGE__->mk_accessors('select_name');

# should the value from input be trimmed?
__PACKAGE__->mk_accessors('trimmed');


sub def_value {
    my $this = shift;

    return $this->parent_form->def_values->{$this->name};
}

#-------------------------------------------------------------------------------
#   Values, inflate, deflate
#-------------------------------------------------------------------------------

# raw (unprocessed) value passed by user
sub raw_value {
    my $this = shift;

    my $value = $this->parent_form->params->{ $this->name };

    # string containing only spaces is considered empty
    my $trimmed = $this->trimmed;
    return scalar auto_expand(
        map {
            if ($trimmed)
            {
                s/^\s+//s;
                s/\s+$//s;
                $_ = undef if $_ eq '';
            }
            defined $_ ? $_ : ();
        } auto_expand $value);
}

# processed value (e.g. DateTime object) passed by user
sub inflated_value {
    my $this = shift;

    return $this->is_static ? $this->def_value : $this->next::method();
}

# element value - inflated value used to output to element
sub elem_value {
    my $this = shift;

    return $this->parent_form->submitted?
        $this->value:
        $this->def_value;
}

# return 1 if value is supplied
# empty string is considered nothing
sub is_supplied {
    my $this = shift;

    return defined $this->raw_value;
}

# returns options as list of [value, label]
sub normalized_options {
    my $this = shift;

    my $options_ref = $this->options
        or die "No options set on field\n";
    my @values = auto_expand $this->elem_value;
    return map {
        my ( $option, $label ) = ref $_ && ref $_ eq 'ARRAY' ? @$_ : $_;
        [   $option,
            defined $label ? $label : $option,
            ( grep { $option eq $_ } @values ) ? 1 : 0
        ];
    } @$options_ref;
}


1;

__END__

=head1 NAME

Akar::HTML::Form::Field - field of Akar::HTML::Form form

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
