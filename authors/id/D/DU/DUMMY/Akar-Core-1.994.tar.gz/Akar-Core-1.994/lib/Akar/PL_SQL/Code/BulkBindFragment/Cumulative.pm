package Akar::PL_SQL::Code::BulkBindFragment::Cumulative;
{
  $Akar::PL_SQL::Code::BulkBindFragment::Cumulative::VERSION = '1.994';
}
use strict;

# cumulative (for reports, etc.) bulk bind fragment
use base qw(Akar::PL_SQL::Code::BulkBindFragment);

use Akar::Class::Utils qw(add_singleton_method);
use Akar::PL_SQL::Code::Functions qw(iblock join_ilines ilist);

__PACKAGE__->mk_accessors( qw(bi_key));

# determines names and properties of the input parameters
__PACKAGE__->mk_ro_accessors( qw(primary_table)  );

# returns true if new_rows are handled
__PACKAGE__->mk_ro_accessors( qw(new_rows_handling) );

sub new {
    my ( $proto, $fields ) = @_;

    return $proto->SUPER::new(
        {   'new_rows_handling' => 1,
            %$fields,
        }
    );
}

sub add_input_param {
    my ($this, $name, $options) = @_;

    my %options = (
        'type' => $this->primary_table . '.'. $name. '%TYPE',
        %{$options || {}},
    );
    return $this->SUPER::add_input_param($name, \%options);
}

sub add_report_column {
    my ($this, @args) = @_;
    return $this->add_column(@args);
}

sub add_primary_column {
    my ($this, @args) = @_;
    return $this->add_input_param(@args);
}

# bulk binf fragment can decrement if it has at least
# one summary or count column
sub can_decrement {
    my ($this) = @_;

    return grep {
        $_->style eq 'sum'
        || $_->style eq 'count'
    } $this->columns;
}

# cursor checking the existence of the row in db
sub dump_decl_check_cursor {
    my ($this) = @_;

    my @params = map { "in_$_ " . $_->style } $this->key_columns;
    my @where  = map {"$_ = in_$_"} $this->key_columns;

    return (
        'cursor c_exists (', ilist( @params), ')',
        'is',
        'select 1', 
        'from ' . $this->table,
        'where', join_ilines('and ', @where), ';'
    );
}

sub dump_package_decl {
    my ($this) = @_;

    return $this->SUPER::dump_package_decl if !$this->dumping_body;

    # special collections
    my $first_col = $this->first_idx_collection;
    my $next_col  = $this->next_idx_collection;
    return (
        $this->SUPER::dump_package_decl,
        "type $first_col\_t is table of pls_integer index by binary_integer;",
        "$first_col $first_col\_t;",
        "type $next_col\_t is table of number(12);",
        "$next_col $next_col\_t := $next_col\_t();",
    );
}

sub dump_add_proc_body {
    my ($this) = @_;

    my $first_idx_collection = $this->first_idx_collection;
    my $next_idx_collection  = $this->next_idx_collection;

    return (
        $this->dump_add_proc_init,
        $this->dump_find_idx,
        'if i is not null then',
            # index was found
        iblock( $this->dump_cumulate),
        'else',
        iblock(
            $this->dump_extend_collections,
            $this->dump_init_collections,

            'if l_last_idx is not null then',
            iblock("$next_idx_collection(l_last_idx) := i;"),
            'else',
            iblock("$first_idx_collection(l_bi_key) := i;"),
            'end if;',
        ),
        'end if;'
    );
}

# hook to be redefined
sub dump_add_proc_init { return () }

# ensures existency of the row in database
sub dump_ensure_existency {
    my ($this) = @_;

    return ( 
        $this->dump_check_existency,
        'if not l_exists then',
        iblock($this->dump_insert_row),
        'end if;'
    );
}

sub dump_find_idx {
    my ($this) = @_;

    # this part looks for row (collection index) 
    # to add the contributions 
    # result must be in local variable i
    
    my $condition = join( ' and ',
        map { sprintf( '%s = %s', $_->collection_elem, $_->input_value ); }
            $this->key_columns );

    my @bi_key     = ($this->bi_key);
    my $bi_key_var = pop(@bi_key);

    my $first_idx_collection = $this->first_idx_collection;
    my $next_idx_collection  = $this->next_idx_collection;

    return (
        @bi_key,
        'l_bi_key := ' . $bi_key_var . ';',
        "if $first_idx_collection.exists(l_bi_key) then",
        iblock(
            "i := $first_idx_collection(l_bi_key);",
            "while i is not null and not($condition)",
            'loop',
            iblock('l_last_idx := i;', "i := $next_idx_collection(i);"),
            'end loop;',
        ),
        'end if;'
    );
}

# insert new roe via new_row fragment
sub dump_insert_row {
    my ($this) = @_;

    return $this->new_row_fragment->dump_add_proc_body;
}

# inits cumulative collections (first assignment to new row)

# adds new row to collection
sub dump_cumulate {
    my ($this) = @_;

    return map { $this->dump_cumulate_column($_) } $this->columns;
}

sub dump_cumulate_column {
    my ($this, $column) = @_;

    my $collection_elem = $column->collection_elem;
    my $input_value      = $column->input_value;
    my $style            = $column->style;

    if ($style eq 'sum'){
        return sprintf( '%s := %s + (in_increment * %s);',
            $collection_elem, $collection_elem, $input_value );
    }

    if ($style eq 'count'){
        return sprintf( '%s := %s + in_increment;', $collection_elem, $collection_elem );
    }

    if ( grep { $style eq $_ } qw(min max) ) {
        my $comp_op = $style eq 'min' ? '<' : '>';
        return (
            "if $input_value $comp_op $collection_elem then",
            iblock("$collection_elem := $input_value;"),
            'end if;'
        );
    }

    return ();
}

sub dump_init_collection {
    my ( $this, $column ) = @_;

    my $collection_elem = $column->collection_elem;
    my $input_value     = $column->input_value;
    my $style           = $column->style;

    return (
        ( grep { $style eq $_ } qw(key asis min max) )
        ? "$collection_elem := $input_value;"
        : $style eq 'sum' ? "$collection_elem := in_increment * $input_value;"
        : $style eq 'count' ? "$collection_elem := in_increment;"
        : ()
    );
}

sub dump_init_collections {
    my ( $this, $column ) = @_;

    return map { $this->dump_init_collection($_); } $this->stored_columns;
}

sub dump_dml_set {
    my ($this) = @_;

    return map { $this->dump_dml_set_column($_); } $this->columns;
}

sub dump_dml_set_column {
    my ( $this, $column ) = @_;

    my $collection_elem = $column->collection_elem;
    my $table_column     = $column->name;
    my $style            = $column->style;

    if ( grep { $style eq $_ } qw(sum count) ) {
        return sprintf( '%s = %s + %s',
            $table_column, $table_column, $collection_elem );
    }

    if ( grep { $style eq $_ } qw(min max) ) {
        my $sign = $style eq 'min' ? '-1' : 1;
        return sprintf( '%s = decode(sign(%s - %s), %s, %s, %s)',
            $table_column, $collection_elem, $table_column, $sign,
            $collection_elem, $table_column );
    }

    if ( $style eq 'asis' ) {
        return sprintf( '%s = %s', $table_column, $collection_elem );
    }


    return ();
}

# creates trigger on input table refreshing the report table
sub create_refreshing_trigger {
    my ( $this, $name, $options ) = @_;

    my $level = $options->{'level'}
        or die "No level (statement,row) supplied\n ";
    my $when = $options->{'when'}
        or die "No phase (before,after)  supplied\n ";
    my $statements = $options->{'statement'} || [qw(insert update delete)];

    # is supply report is refreshed only when the condition is true
    my $condition = $options->{condition};

    # there may be more reports refreshed in one trigger
    # by default actual report (cumulative fragment) is refreshed
    my $refreshes = $options->{'refreshes'} || [$this];

    my $uname = $name;    # unquealified name
    $uname =~ s/.*\.//;

    # trigger is a object which through singleton methods know
    # how to dump whole and body
    my $trigger = Akar::PL_SQL::Code->new;
    add_singleton_method(
        $trigger,
        'dump' => sub {
            my ($this_trigger) = @_;

            return (
                "create or replace trigger $name",
                sprintf( '%s %s on %s',
                    $when, join( ' or ', @$statements ),
                    $this->primary_table ),
                ( $level eq 'row' ? 'for each row' : () ),
                'begin',
                (   $condition
                    ? iblock(
                        "if $condition then",
                        iblock( $this_trigger->dump_body ),
                        "end if;"
                        )
                    : iblock( $this_trigger->dump_body ),
                ),

                "end $uname",
                ';'
            );
        }
    );

    add_singleton_method(
        $trigger,
        'dump_body' => sub {
            return
                map { $_->dump_trigger_body( $name, $options ) } @$refreshes;
        }
    );

    # returns text not rows
    return $trigger;
}

sub dump_trigger_body {
    my ($this, $name, $options) = @_;

    my $level = $options->{'level'}
        or die "No level (statement,row) supplied\n ";
    my $when = $options->{'when'}
        or die "No phase (before,after)  supplied\n ";
    my $statements = $options->{'statement'} || [qw(insert update delete)];
    my %for_statement = map { $_ => 1 } @$statements;

    my @body;
    if ( $level eq 'row' ) {

        # if the column is nut summed (for example minimal traffic_start)
        # and trigger is ony for insert is undesirable for this part
        # to appear in code
        if ( $this->can_decrement && grep { $for_statement{$_} }
            qw(delete update) )
        {
            push @body, 'if deleting or updating then',
                iblock( $this->get_trigger_row( ':old', -1 ) ), 'end if;';
        }
        if ( grep { $for_statement{$_} } qw(insert update) ) {
            push @body, 'if inserting or updating then',
                iblock(
                $this->get_trigger_row(
                    ':new', $this->can_decrement ? 1 : ()
                )
                ),
                'end if;';
        }
    }
    else {

        # statement level trigger
        push @body,
            ( $when eq 'before' ) ? $this->proc_name( 'init', 1 ) . ';'
            : ( $when eq 'after' ) ? $this->proc_name( 'flush', 1 ) . ';'
            : die "Invalid when $when\n ";

    }

    return @body;
}

sub get_trigger_row {
    my ( $this, $record, $increment ) = @_;

    my @args = (
        ( map {$record. '.'. $_->name} $this->input_params ),
        defined($increment) ? $increment : ()
    );

    return ( $this->proc_name( 'add', 1 ) . '(',
        ilist( @args ), ');' );
}

###################################################################################
# two special collections
sub first_idx_collection {
    my ($this) = @_;

    return 'col'. $this->id. '_first_idx';
}

sub next_idx_collection {
    my ($this) = @_;

    return 'col_'. $this->id. '_next_idx';
}

sub dml_statement { 
    return 'update';
}

sub dump_delete_collections {
    my ($this) = @_;

    return (
        $this->SUPER::dump_delete_collections,
        sprintf( '%s.delete;', $this->first_idx_collection ),
        sprintf( '%s.delete;', $this->next_idx_collection ),
    );
}

sub dump_extend_collections {
    my ($this) = @_;

    return (
        $this->SUPER::dump_extend_collections,
        sprintf( '%s.extend;', $this->next_idx_collection ),
    );
}

sub dump_add_proc_decl {
    my ($this) = @_;

    return (
        $this->SUPER::dump_add_proc_decl,
        'l_last_idx pls_integer;',
        'l_bi_key pls_integer;',
        'l_exists boolean;',
        'l_one pls_integer;',
        # $this->dump_decl_check_cursor
    );
}

# add_proc_contains the increment parameter
sub dump_add_proc_params {
    my ($this) = @_;

    return (
        $this->SUPER::dump_add_proc_params,
        $this->can_decrement? ('in_increment in number'): ());
}

sub dump_bulkbind {
    my ($this) = @_;

    return $this->SUPER::dump_bulkbind if !$this->new_rows_handling;

    return (
        $this->SUPER::dump_bulkbind,
        $this->dump_remove_updated,
        do {
            local *dml_statement = sub {'insert'};
            $this->SUPER::dump_bulkbind,;
            }
    );
}

# removes updated rows from collections
# so the rest of the rows can be inserted
sub dump_remove_updated {
    my ($this) = @_;

    my $collection0 = $this->collection0;
    my @copy_row = map {
        sprintf( '%s(l_first_deleted) := %s(i);',
            $_->collection, $_->collection );
    } $this->stored_columns;

    my @remove_updated = (
        'declare',
        iblock( 'l_first_deleted number;', 'l_last_deleted  number;', ),
        'begin',
        iblock(
            "l_last_deleted := $collection0.last;",
            "l_first_deleted := $collection0.first;",
            "for i in $collection0.first .. $collection0.last",
            'loop',
            iblock(
                'if SQL%BULK_ROWCOUNT(i) = 0 then',
                'if l_first_deleted < i then',
                iblock(@copy_row),
                'end if;',
                'l_first_deleted := l_first_deleted + 1;',
                'end if;',
            ),
            'end loop;',
            '-- deletes collections',
            (   map {
                    $_->collection
                        . '.delete(l_first_deleted, l_last_deleted);';
                    } $this->stored_columns
            ),
        ),
        'end;',
    );

    return ( "if $collection0.count > 0 then",
        iblock(@remove_updated), 'end if;' );
}

sub dump_dml_new_rows {
    my ($this) = @_;

    my %the_value_of = map {
        my $value = $_->style eq 'seq'
            ? $_->input_value . '.nextval'
            : $_->collection_elem;
        ( $_->name => $value );
    } $this->columns;

    return (
        'insert into ' . $this->table . '(',
        ilist( keys %the_value_of ),
        ')', 'select',
        ilist( values %the_value_of ),
        'from dual',
        'where ('
            . join( ', ', map { $_->collection_elem } $this->key_columns )
            . ')',
        'not in (',
        iblock(
            'select ' . join( ', ', map { $_->name } $this->key_columns ),
            'from ' . $this->table
        ),
        ')'
    );
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96: 
