package Akar::AQ;
{
  $Akar::AQ::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);

1;

__END__

=head1 NAME

Akar::AQ - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
