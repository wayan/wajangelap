package Akar::PL_SQL::Code;
{
  $Akar::PL_SQL::Code::VERSION = '1.994';
}
use strict;

# a piece of PL/SQL code (usually part of the package)
use base qw(Class::Accessor);

use Akar::PL_SQL::Code::Functions qw(block_opener block_closer);
use Akar::Class::Utils qw(add_singleton_method);

__PACKAGE__->mk_accessors( qw(name parent children code) );

sub new {
    my ( $proto, $fields ) = @_;

    $fields ||= {};
    return $proto->SUPER::new(
        {   'children' => [],
            %$fields,
        }
    );
}

# returns the package the object belongs to
sub package {
    my ($this) = @_;

    return $this->parent->package;
}

# adds child under the object
sub add_child {
    my ($this, $child) = @_;

    push @{$this->children}, $child;
    $child->parent($this);

    return $child;
}

sub get_child_by_name {
    my ( $this, $name ) = @_;

    my ($child) = grep { $_->name eq $name } @{ $this->children };
    return $child;
}

# returns info whether package body is dumped
our $dumping_body;
sub dumping_body {$dumping_body}

# dumps the object ($body = 1 part belonging to package body, = 0 belonging to package)
sub dump_text {
    my ( $this, $body, $part, @args ) = @_;

    local $dumping_body = $body;

    my @rows = $part
        ? do {
        my $method = $this->can( 'dump_' . $part );
        $method ? $this->$method(@args) : ();
        }
        : $this->dump;
    
    return $this->join_rows(@rows);
}

sub join_rows {
    my ( $this, @rows ) = @_;

    my $indent = 0;
    return join "\n", map {
        my $indent_inc
            = $_ eq block_opener() ? 1 : $_ eq block_closer() ? -1 : 0;
        $indent += $indent_inc;
        $indent_inc ? () : ( '  ' x $indent ) . $_;
    } @rows;
}

# returns the lines of code

sub dump_putline {
    my ( $this, @str ) = @_;

    my $str = join( ' || ', @str );
    return ("sys.dbms_output.put_line($str);");
}

sub dump_package_decl {
    return ();
}

sub dump_part {
    my ( $this, $part, @args ) = @_;

    my $method = $this->can( 'dump_' . $part );
    return $method ? $this->$method(@args) : ();
}

# redefines dump_PART so it returns original content + rows supplied
sub append_after {
    my ( $this, $part, $rows ) = @_;

    my $method = 'dump_' . $part;
    # current method 
    my $super_method = $this->can($method) || sub { () };
    add_singleton_method(
        $this,
        $method => sub {
            my ( $this, @args ) = @_;
            return ( $this->$super_method(@args), @$rows );
        }
    );
}

# redefines dump_PART so it returns rows supplied
sub replace {
    my ($this, $part, $new_content) = @_;
    my $method = 'dump_' . $part;

    my $new_sub =
          UNIVERSAL::isa( $new_content, 'CODE' ) ? $new_content
        : UNIVERSAL::isa( $new_content, 'ARRAY' )
        ? sub { return @$new_content }
        : die "Invalid content supplied to replace\n ";
    add_singleton_method($this, $method => $new_sub);
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96: 
