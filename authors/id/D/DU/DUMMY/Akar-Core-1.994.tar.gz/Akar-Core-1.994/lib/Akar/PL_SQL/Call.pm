package Akar::PL_SQL::Call;
{
  $Akar::PL_SQL::Call::VERSION = '1.994';
}
use strict;

# one call produced by the caller
use base qw(Class::Accessor);
use Data::Dumper;
use Akar::PL_SQL::Caller::Functions qw(:all indent2);
use Akar::PL_SQL::ArgList;
use Akar::DBI::Statement qw(sql);

__PACKAGE__->mk_ro_accessors(qw(dbh method args return_type is_function));
__PACKAGE__->mk_accessors(qw(statement return_psql_value));

sub new {
    my ( $proto, $fields ) = @_;

    my $arg_list
        = Akar::PL_SQL::ArgList->new( delete( $fields->{'args'} ) || [] );
    return $proto->SUPER::new(
        {   'args' => $arg_list,
            ( $fields->{'is_function'} ? ( 'return_type' => psql_sql ) : () ),
            %{$fields}
        }
    );
}

# 2007-02-21 danielr je to hruza, ale momentalne nic jineho nezbyva
sub _apply_on_text {
    my ($statement, $sub) = @_;

    for my $elem (@{$statement->layout}){
        if (ref($elem)){
            _apply_on_text($elem, $sub);
        }
        else {
            $elem = $sub->($elem);
        }
    } 
}

for my $type (qw(decl epilogue)) {
    no strict 'refs';
    *{ 'add_' . $type } = sub {
        my ( $this, $line ) = @_;

        _apply_on_text(
            $this->statement,
            sub {
                my ($text) = @_;
                $text =~ s/(?=--$type--)/$line\n/;
                return $text;
            }
        );
    };
}

sub add_prologue {
    my ( $this, $line ) = @_;

    _apply_on_text(
        $this->statement,
        sub {
            my ($text) = @_;
            $text =~ s/(?<=--prologue--)/\n$line/;
            return $text;
        }
    );
}

sub dump {
    my ($this) = @_;

    my $dump = $this->method;
    if (@{$this->args}) {
        $dump .= '(';

        my $sep = '';
        for my $arg (@{$this->args}) {
            my $the_value = indent2(psql_value($arg->value)->dump);

            $dump .= $sep . "\n";
            $dump .=
                $arg->is_named
              ? $arg->name . ' => ' . $the_value
              : $the_value;
            $sep = ",";
        }

        $dump .= ')';
    }

    indent2($dump);
}

sub _dump_output_value {
    my ($this, $value) = @_;

    # I create input value of the same type and dump it
    my $psql_value = psql_value($value);
    my $input_value = $psql_value->type->new(${$psql_value->value});
    indent2($input_value->dump);
}

sub dump_output {
    my ($this) = @_;

    my $sep  = ''; # separator - the result imitates join
    my $dump = '';
    for my $arg (@{$this->args}) {
        is_output($arg->value) or next;

        $dump .= $sep . $arg->name . ' := ' . $this->_dump_output_value($arg->value);
        $sep = "\n";    # join
    }

    if ($this->is_function) {
        $dump .= $sep . 'return := ' . $this->_dump_output_value($this->return_psql_value);
    }

    $dump;
}

sub execute {
    my ($this) = @_;

    $this->build_statement;
    $this->statement->dbh($this->dbh)->execute;
    $this->is_function
      ? $this->get_return_value
      : undef;
}

sub build_statement {
    my ($this) = @_;

    my $sql = "DECLARE\n--decl--\nBEGIN\n--prologue--\n";
    $sql .= ':return := ' if $this->is_function;
    $sql .= $this->method;

    # arguments
    unless ($this->args->is_empty) {
        $sql .= '(';

        my $sep = '';
        for my $arg (@{$this->args}) {
            $sql .= $sep;
            $sql .= (
                  $arg->is_named
                ? $arg->name . ' => ' . $arg->placeholder
                : $arg->placeholder
            );
            $sep = ",\n";
        }
        $sql .= ')';
    }

    $sql .= ";\n--epilogue--\nEND;";

    $this->statement(sql($sql));
    $this->bind_param($_->placeholder => $_->value) for @{$this->args};

    my $return_value;
    if ($this->is_function) {
        $this->return_psql_value($this->return_type->new(\$return_value));
        $this->bind_param(':return' => $this->return_psql_value);
    }
    $this->statement;
}

sub get_return_value { ${shift()->return_psql_value->value} }

sub is_output {
    my ($value) = @_;
    $value = $value->value if UNIVERSAL::isa($value, 'Akar::PL_SQL::Value');

    ref($value) && (UNIVERSAL::isa($value, 'SCALAR') || UNIVERSAL::isa($value, 'REF'));
}

sub bind_param {
    my ($this, $name, $psql_value) = @_;

    unless (UNIVERSAL::isa($psql_value, 'Akar::PL_SQL::Value')) {
        return is_output($psql_value)
          ? $this->statement->bind_param_inout($name, $psql_value, 512)
          : $this->statement->bind_param($name, $psql_value);
    }

    my $type  = $psql_value->type;
    my $value = $psql_value->value;
    if (UNIVERSAL::isa($type, 'Akar::PL_SQL::Type::SQL')) {
        return $this->bind_param($name, $value);
    }
    elsif (UNIVERSAL::isa($type, 'Akar::PL_SQL::Type::SQLObject')
        && is_output($value))
    {

        # output par behaves like record so I cheat and create the record for it
        my $record = psql_record($type->name, $type->fields)->new($value);
        return $this->bind_param($name => $record);
    }

    # other types for which the variable must be created
    my $var = 'l_' . ($name =~ /:(.*)/)[0];
    $this->add_decl("$var " . $type->name . ";");
    $this->statement->bind_param($name, sql($var));

    if (UNIVERSAL::isa($type, 'Akar::PL_SQL::Type::Sequence')) {
        if (is_output($value)) {
            die "Can't use sequence as output parameter\n ";
        }
        else {
            for (my $i = 0 ; $i < @$value ; $i++) {
                $this->add_prologue("$var($i) := ${name}__$i;");
                $this->bind_param("${name}__$i" => $type->base_type->new($$value[$i]));
            }
        }
    }
    elsif (UNIVERSAL::isa($type, 'Akar::PL_SQL::Type::Boolean')) {
        if (is_output($value)) {
            $this->add_epilogue("if $var then $name := 1; else $name := 0; end if;");
        }
        else {
            $this->add_prologue("$var := $name <> 0;");
        }
        $this->bind_param($name => $value);
    }
    elsif (UNIVERSAL::isa($type, 'Akar::PL_SQL::Type::Record')) {
        my $fields = $type->fields;
        if (is_output($value)) {

            # output par is transformed to input one
            my %output_value;

            for my $k (keys %$fields) {
                my $type = $$fields{$k} || psql_sql;
                $this->add_epilogue("${name}__$k := $var.$k;");
                $this->bind_param("${name}__$k" => $type->new(\$output_value{$k}));
            }
            $$value = \%output_value;
        }
        else {
            while (my ($k, $v) = each %$value) {
                my $type = $$fields{$k} || psql_sql;
                $this->add_prologue("$var.$k := ${name}__$k;");
                $this->bind_param("${name}__$k" => $type->new($v));
            }
        }
    }
    elsif (UNIVERSAL::isa($type, 'Akar::PL_SQL::Type::SQLObject')) {

        # input we have to create call like this TYPE(:x, :y, :z)
        $this->add_prologue(
            sprintf("%s := %s(%s);",
                $var, $type->name, join(', ', map("${name}__$_", @{$type->fields_order})))
        );
        for my $k (@{$type->fields_order}) {
            my $field_type = $type->fields->{$k};
            $this->bind_param("${name}__$k" => $field_type->new($$value{$k}));
        }
    }
}

1;
