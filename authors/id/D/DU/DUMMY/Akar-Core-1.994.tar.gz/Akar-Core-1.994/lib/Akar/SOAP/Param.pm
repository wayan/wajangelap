package Akar::SOAP::Param;
{
  $Akar::SOAP::Param::VERSION = '1.994';
}
use strict;

=head1 NAME

Akar::SOAP::Param - declaration of SOAP method parameter to be published via WSDL  

=head1 SYNOPSIS

  my $param = Akar::SOAP::Param->new('statementRequest')
      ->type('xsd:string')
    ->doc('selection of calls to be included to statement'); 

Look at Akar::SOAP::Method

=head1 DESCRIPTION

The purpose of Akar::SOAP::Param is to declare parameter
for later publishing WSDL for SOAP service implemented
by perl package.

=head1 METHODS

=item new(NAME, key1=>value1, ...)

  Akar::SOAP::Param->new('statementRequest', 'type' => 'xsd:string');

Constructor.

=item type

Setter - getter for parameter type. Currently works for XML schema types,
with XML schema namespace prefix being 'xsd:'.

=item doc

=item documentation

Setter - getter for parameter documentation to be put into WSDL.

=head1 AUTHOR

Roman Daniel <roman.daniel@gstgroup.cz>

=cut

use base qw(Class::Accessor);

__PACKAGE__->mk_accessors(qw(name type documentation));
sub set { my $this = shift; $this->SUPER::set(@_); $this } 
sub doc { shift()->documentation(@_) } # synonym

sub new {
    my $proto = shift;
    my %fields = ('name' => @_);
    my($name, %fiels) = @_;

    $fields{'type'} ||= 'xsd:string';
    $proto->SUPER::new(\%fields);
}

1;
