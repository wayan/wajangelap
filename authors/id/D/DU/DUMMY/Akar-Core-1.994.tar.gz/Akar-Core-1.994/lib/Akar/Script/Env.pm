package Akar::Script::Env;
{
  $Akar::Script::Env::VERSION = '1.994';
}

=head1 NAME

Akar::Script::Env - environment for modules called outside any installed scriptmodule

=head1 SYNOPSIS

  use lib qw(/opt/durian/app/lib/perl);
  use Akar::Base 'app_home' => '/opt/durian/app';
  use Akar::Script::Env;

=cut

# reads profile
use strict;
use File::Spec;
use Akar::Base;

my $profile = Akar::Base->app_config('profile.pm');
if (-e($profile)){
	eval { require($profile) };
         die $@ if $@;
}

1;
