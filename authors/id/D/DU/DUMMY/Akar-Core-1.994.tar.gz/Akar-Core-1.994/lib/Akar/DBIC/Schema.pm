package Akar::DBIC::Schema;
{
  $Akar::DBIC::Schema::VERSION = '1.994';
}
use strict;
use warnings;

use base qw/DBIx::Class::Schema/;

use Carp qw(carp croak);
use Akar::Class::Utils qw(lexical_cleaner);

# redefined to be able to register inner source classes 
# (one source file can contain more classes)
sub register_class {
    my ( $self, $moniker, $to_register ) = @_;


    $to_register->can('classes_to_register')
        or return $self->next::method($moniker, $to_register);

    # one (file based) class can register more than one class to schema 
    for my $ar ( $to_register->classes_to_register($moniker) ){
        $self->next::method( @{$ar} );
    }
}

# 2009-01-16 danielr
# txn_do_auto performs txn_do but in autonomous transaction
# it:
#   locally replaces the current schema storage by a new one
#
sub txn_do_auto {
    my $this = shift;

    # storage must be set back
    my $storage = $this->storage;
    my $lc      = lexical_cleaner { $this->storage(@_) } $storage;

    # creates new storage
    # 2009-01-21 if the content of connect_info is a reference
    # (sub returning db_handler - Anoa) I can't use it - since I
    # would use same db handler as surrounding transaction
    # thus the whole thing would be pointless
    my @connect_info = @{ $storage->connect_info };
    $this->connection( @connect_info);
    return $this->txn_do(@_);
}

1;

__END__

=head1 NAME

Akar::Schema - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
