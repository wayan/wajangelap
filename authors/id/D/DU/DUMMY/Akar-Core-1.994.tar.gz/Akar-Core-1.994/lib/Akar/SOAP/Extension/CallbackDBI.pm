package Akar::SOAP::Extension::CallbackDBI;
{
  $Akar::SOAP::Extension::CallbackDBI::VERSION = '1.994';
}
use strict;

# simplified, DBI version of callback
use base qw(Class::DBI);

use Akar::SOAP::Lite;

__PACKAGE__->table('akar.soap_ext_callback');
__PACKAGE__->columns('Primary'   => qw(id));
__PACKAGE__->columns('Essential' => qw(wsdl method uri proxy id dt_inserted));
#__PACKAGE__->columns('TEMP'      => qw(soap));

__PACKAGE__->set_sql('Nextval', 'SELECT %s.NEXTVAL from DUAL');
__PACKAGE__->sequence('akar.soap_ext_callback_seq');

sub namespace_uri { 'http://akar.gtsgroup.cz/Akar/SOAP/Extension/Callback' }

sub namespace_prefix { 'asec' }

sub element_name     { 'callback' }

# returns SOAP header from callback 
sub create_soap_header {
    my ($package, $fields) = @_;

    # This trick is from http://search.cpan.org/~byrne/SOAP-Lite-0.65_6/lib/SOAP/Data.pm (COMPLEX TYPES)
    my @data;
    for my $property (qw(wsdl method uri proxy)) {
        my $value = $$fields{$property} or next;

        push @data,
          SOAP::Data->new(
            'name'   => $property,
            'uri'    => $package->namespace_uri,
            'prefix' => $package->namespace_prefix,
            'value'  => $value
          );
    }

    SOAP::Header->new(
        'name'           => $package->element_name,
        'uri'            => $package->namespace_uri,
        'prefix'         => $package->namespace_prefix,
        'mustUnderstand' => 1,
        'value'          => \SOAP::Data->value(@data),
    );
}

# looks for callback headers in SOAP::SOM object, returns Akar::SOAP::Exrension objects
sub parse_som {
    my ($package, $som) = @_;

    return map     { $package->create($_); }
        map {
        my $v = $_->value;

        # 2012-11-28 danielr
        # since some version of SOAP::Lite the $v - header value
        # is not hashref but a reference to another SOAP::Data
        # which value is a list of SOAP::Data objects -
	# one for each element (method, uri, proxy)
        if ( ref $v eq 'REF' ) {
            my @nested = $$v->value;
            $v = { map { $_->name => $_->value } @nested };
        }
        $v;
        }
        grep {
               $_->name eq $package->element_name
            && $_->uri  eq $package->namespace_uri
        } $som->headerof( ref($som)->headers );
}

sub get_soap {
    my ($this) = shift;

    my $soap;
    if ($this->wsdl){
	    $soap = Akar::SOAP::Lite->service($this->wsdl)->soap_for_method($this->method);
	    $soap->proxy($this->proxy) if $this->proxy;
    }
    else {
	    $this->proxy or die "No proxy\n ";

	    $soap = Akar::SOAP::Lite->proxy($this->proxy);
	    $soap->uri($this->uri) if $this->uri;
    }
    
    $soap;
}

sub call {
	my ($this) = shift;

	my $method = $this->method or die "No method\n ";
    $this->get_soap->$method(@_)->result;
}

1;
