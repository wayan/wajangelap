package Akar::WebServices::Controller::REST::Root;
{
  $Akar::WebServices::Controller::REST::Root::VERSION = '1.994';
}
use Moose;

BEGIN { extends 'Catalyst::Controller::REST' }

# root REST container
# who knows how to serialize and deserialize
use XML::LibXML;
use JSON;
use XML::Compile::Util qw(unpack_type);
use File::Slurp qw(slurp);
use Scope::Guard qw(scope_guard);

with 'Akar::WebServices::Controller::AssertUserRoles',
    'Akar::WebServices::Controller::Statuses';

has xml_parser => ( is => 'rw', lazy_build => 1 );

has json => ( is => 'rw', lazy_build => 1 );

has xml_compile_schema => (
    is       => 'ro',
    required => 1,
);

# mapping (READER|WRITER) => method => action => element ("{NS}localname)
# "READER|PUT|/rest/product/products" => "{...}localname"
has element_for => (
    is      => 'ro',
    isa     => 'HashRef',
    default => sub { return {} },
);

has default_content_type => (
    is         => 'rw',
    lazy_build => 1,
);

sub _build_default_content_type { return 'text/xml'; }

# builders
sub _build_xml_parser {
    my ($this, $c) = @_;

    return XML::LibXML->new;
}

sub _build_json {
    my ($this, $c) = @_;

    return JSON->new->utf8;
}

sub add_element_for {
    my ( $this, $direction, $method, $action, $element ) = @_;

    # normalize and checking element
    $this->element_for->{ join '|', $direction, $method, $action }
        = $this->xml_compile_schema->find_element($element);
}

sub get_element_for {
    my $this = shift;

    return $this->element_for->{join '|', @_} ||= $this->_element_from_attributes(@_);
}

sub _element_from_attributes {
    my ($this, $direction, $method, $action) = @_;
    my $method_action
        = $this->_app->dispatcher->get_action_by_path( join '_',
        $action->private_path, $method )
        or return;
    my $element_ary = $method_action->attributes->{$direction} or return;
    return $this->xml_compile_schema->find_element(@$element_ary);
}

# begin is here to cancel inherited attributes (parsing)
# we parse in base
sub begin {}

sub end: Private {
    my ( $this, $c ) = @_;
    $this->serialize_response($c);
}

sub base: Chained('/'): PathPrefix: CaptureArgs(0) {  
    my ($this, $c) = @_;

    $this->deserialize_request($c) or $c->detach;
}

# 2013-01-28 danielr
# it is more comfortable to have 404 for /rest/something/unknown 
# to be handled here
sub default : Chained('/') : PathPart('') {
    my ( $this, $c ) = @_;

    $c->res->status('404');
    $c->res->content_type("text/plain");
    $c->res->body("resource not found");
}

sub deserialize_request {
    my ( $this, $c ) = @_;

    # we have nothing to parse when GET
    #$c->req->method ne 'GET' or return 1;
	return 1 
		if ( $c->req->method eq 'GET' || 
			(defined($c->req->content_length) && $c->req->content_length == 0 )
			|| length($c->req->body || '') == 0 );

    my $content_type = $c->req->content_type || $this->default_content_type;
    my $ret = eval { $this->deserialize_request_from( $c, $content_type ); };
    if ( my $error = $@ ) {
        $c->log->debug("Request deserialization failed: $error") if $c->debug;
        $this->_serialize_bad_request( $c, $content_type, $error );
        return 0;
    }
    elsif ( !$ret ) {
        $c->log->debug("Unsupported media passed: $content_type") if $c->debug;
        $this->_unsupported_media_type( $c, $content_type );
        return 0;
    }
    else {
        return 1;
    }
}

sub deserialize_request_from {
    my ( $this, $c, $content_type ) = @_;

    if ( $content_type eq 'application/json' ) {
        # slurp has to be called in scalar context
        # otherwise it returns the list of lines
        $c->req->data(
            $this->json->decode(
                map { ref $_ ? scalar(slurp($_)) : $_ } $c->req->body
            )
        );
        return 1;
    }
    elsif ( $content_type eq 'text/xml' ) {
        my $body   = $c->req->body;
        my $parser = $this->xml_parser;
        my $doc = ref $body
            ? $parser->parse_fh($body)
            : $parser->parse_string($body);
        my $reader = $this->get_reader_for( $c->req->method, $c->action );
        my $data = $reader->( $doc->documentElement );
        $c->req->data($data);
        return 1;
    }
    else {
        return 0;
    }
}

sub serialize_response {
    my ( $this, $c ) = @_;

    return 1 if $c->req->method eq 'HEAD';
    return 1 if $c->response->has_body;
    return 1 if scalar @{ $c->error };
    return 1 if $c->response->status =~ /^(?:204)$/;

    my $content_type = $c->req->content_type || $this->default_content_type;

    $this->serialize_response_to( $c, $content_type )
        or $this->_unsupported_media_type( $c, $content_type );
}

sub serialize_response_to {
    my ($this, $c, $content_type) = @_;

    my $res = $c->stash->{rest} or return 1; # no answer
    if ( $content_type eq 'text/xml' ) {
        # res can be structure => WRITER or document|element => passed
        if ( blessed $res && grep { $res->isa("XML::LibXML::$_") }
            qw(Document Element) )
        {
            # document / element passed as is
            $c->res->body($res->toString);
        }
        elsif (ref($res)){
            # XML is generated by writer
            my $rest_is_error = $c->stash->{rest_is_error};
            my $writer
                = $rest_is_error
                ? $this->get_error_writer()
                : $this->get_writer_for( $c->req->method, $c->action );
            my $doc     = XML::LibXML::Document->new;
            my $element = $writer->($doc, $res );
            $doc->setDocumentElement($element);
            $c->res->body($doc->toString);
        }
        else {
            die "Unserializable response $res\n ";
        }
        $c->res->content_type($content_type);
        return 1;
    }
    elsif ($content_type eq 'application/json'){
        $c->res->content_type($content_type);
        
        my $json = $this->json;
        my $guard;
        if ($c->req->header('X-PrettyPrint')){
            # we temporarily make the output pretty
            $guard  = scope_guard(sub { $json->pretty(0); });
            $json->pretty;
        }
        $c->res->body($json->encode($res));
        return 1;
    }
    else {
        return 0;
    }
}

sub get_reader_for {
    my $this = shift;
    return $this->get_compiler_for( READER => @_ );
}

sub get_writer_for {
    my $this = shift;
    return $this->get_compiler_for( WRITER => @_ );
}

sub get_compiler_for {
    my $this = shift;
    my ($direction) = @_;
    my $element = $this->get_element_for(@_)
        or die "No element found for ". join(',', @_). "\n "; 

    return $this->xml_compile_schema->get_compiler_for($direction => $element);
}

sub get_error_writer {
    my ($this) = @_;

    my $element = $this->xml_compile_schema->find_element('REST:error')
        or die "No error element found in schemas\n";
    return $this->xml_compile_schema->get_compiler_for( WRITER => $element );
}

# own helpers - shamelessly copied from Catalyst::Action::SerializeBase
sub _unsupported_media_type {
    my ( $self, $c, $content_type ) = @_;

    $c->res->content_type('text/plain');
    $c->res->status(415);
    if ( defined($content_type) && $content_type ne "" ) {
        $c->res->body(
            "Content-Type " . $content_type . " is not supported.\r\n" );
    }
    else {
        $c->res->body(
            "Cannot find a Content-Type supported by your client.\r\n");
    }
}

sub _serialize_bad_request {
    my ( $self, $c, $content_type, $error ) = @_;

    $c->res->content_type('text/plain');
    $c->res->status(400);
    $c->res->body(
        "Content-Type " . $content_type . " had a problem with your request.\r\n***ERROR***\r\n$error" );
}


__PACKAGE__->meta->make_immutable;
1;
__END__
/usr/local/share/perl5/Catalyst/Action/SerializeBase.pm
400 Bad Request
Content-Length: 259
Content-Type: text/plain

Content-Type text/xml had a problem with your request.
***ERROR***
/tmp/OvbMrFS3R3:3: parser error : xmlParseStartTag: invalid element name
    <ns:messageDate>2012-06-06T12:33:33</ns:messageDate><

---------------------------------------------
415 Unsupported Media Type
Content-Length: 54
Content-Type: text/plain

Cannot find a Content-Type supported by your client.
t/t_pokus2.t .. ok
All tests successful.
Files=1, Tests=2,  8 wallclock secs ( 0.07 usr  0.01 sys +  7.53 cusr  0.27
csys =  7.88 CPU)
Result: PASS

--------------------------------------------------
400 Bad Request
Content-Length: 289
Content-Type: text/plain

Content-Type application/json had a problem with your request.
***ERROR***
malformed JSON string, neither array, object, number, string or atom, at
character offset 0 (before "<ns:auditLog xmlns:n...") at
/usr/local/share/perl5/Cata
lyst/Action/Deserialize/JSON.pm line 32, <$fh> line 5.
t/t_pokus2.t .. ok
All tests successful.
Files=1, Tests=2,  8 wallclock secs ( 0.07 usr  0.01 sys +  7.58 cusr  0.24
csys =  7.90 CPU)
Result: PASS

                                

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
