package Akar::Mason::PComponent;
{
  $Akar::Mason::PComponent::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);
use base qw(Class::Accessor::Grouped);

use Class::C3;

BEGIN {
    __PACKAGE__->mk_group_accessors( inherited => '_actions_attr' );
    __PACKAGE__->_actions_attr( [] );
}

sub MODIFY_CODE_ATTRIBUTES {
    my ( $class, $code, @attrs ) = @_;

    $class->_actions_attr( [ @{ $class->_actions_attr }, [$code, @attrs] ] );
    return ();
}


1;

__END__

=head1 NAME

Akar::Mason::PComponent - perl (or pseudo) component for mason - i.e. mason
"components" written as perl modules for faster processing and better
debugging

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
