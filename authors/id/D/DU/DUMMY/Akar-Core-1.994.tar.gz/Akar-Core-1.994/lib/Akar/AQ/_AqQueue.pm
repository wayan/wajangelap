package Akar::AQ::_AqQueue;
{
  $Akar::AQ::_AqQueue::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);

use base qw(Class::DBI Akar::AQ::Dbize);

__PACKAGE__->table('akar.aq_queue');

# database fields
__PACKAGE__->columns( 'Primary' => 'queue' );
__PACKAGE__->columns( 'Essential' => qw(auto_start) );


1;

__END__

=head1 NAME

Akar::AQController::Queue - ORM on sys.all_queues

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
