package Akar::Plack::Middleware::SOAPRawData;
{
  $Akar::Plack::Middleware::SOAPRawData::VERSION = '1.994';
}
use Moose;

# old style logging for SOAP raw data ala Akar::SOAP::Manager

use namespace::autoclean;

use Data::Uniqid qw/uniqid/;
use Plack::Request;
use Plack::Response;
use Plack::Util;
use HTTP::Headers;
use FileHandle;
use DateTime;
use Data::Dump qw(quote);

has app => ( is => 'rw', required => 1 );

# no special logger, directly to file
has file => ( is => 'ro', required => 1 );

has fh => ( is => 'ro', lazy_build => 1 );

sub _build_fh {
    my $this = shift;
    my $file = $this->file;

    my $fh = FileHandle->new( $file, '>>' )
        or die "Can't open $file to append: $!";
    $fh->autoflush(1);
    return $fh;
}

sub wrap {
    my $class = shift;
    return $class->new( app => @_ )->psgi_app;
}

# the "constructor" returning subroutine to be used in
# Plack Builder enable
sub wrapper {
    my ( $class, @args ) = @_;
    return sub {
        my $app = shift;
        return $class->new( @args, app => $app )->psgi_app;
    };
}

sub psgi_app {
    my $this = shift;
    my $app  = $this->app;

    return sub {
        my $env = shift;

        my $request_id;
        eval {
            $request_id = $this->new_request_id;
            my $req = Plack::Request->new($env);
            $this->log_raw_data( 1, $env->{HTTP_SOAPACTION},
                $request_id, $req->raw_body );
        };
        return Plack::Util::response_cb(
            $app->($env),
            sub {
                my $ret = shift;
                eval {
                    $this->log_raw_data( 0, $env->{HTTP_SOAPACTION},
                        $request_id, $this->get_response_body($ret) );
                };
            }
        );
    };
}

my $Id = 0;

sub new_request_id {
    return $$ . '-' . ++$Id;
}

sub get_response_body {
    my ( $this, $ret ) = @_;

    ref $ret && ref $ret eq 'ARRAY' or return '?';

    my ( $status, $headers, $raw_content ) = @$ret;
    if ( Plack::Util::is_real_fh($raw_content) ) {
        my $content;

        # tohle je pofiderni
        my $cl = Plack::Util::content_length($raw_content);
        $raw_content->read( $content, $cl, 0 );
        $raw_content->seek( 0, 0 );
        return $content;
    }
    elsif ( ref $raw_content eq 'ARRAY' ) {
        return join '', @$raw_content;
    }
    else {
        return '??';
    }
}

my $tz_local = DateTime::TimeZone->new( name => 'local' );

sub log_raw_data {
    my ( $this, $is_request, $soap_action, $id, $data ) = @_;

    my $dt = DateTime->now( time_zone => $tz_local );
    $this->fh->print(
        join "\n",
        $dt->ymd . ' '
            . $dt->hms
            . " - SOAP "
            . ( $is_request ? 'Request' : 'Response' ) . " $id",
        (   $is_request
            ? ( '-' x 78, 'SOAPAction: ' . quote($soap_action) )
            : ()
        ),
        '-' x 78,
        $data,
        '-' x 78,
        '', ''
    );
}

__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
