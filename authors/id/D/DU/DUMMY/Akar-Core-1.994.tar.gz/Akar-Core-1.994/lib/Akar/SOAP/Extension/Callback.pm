package Akar::SOAP::Extension::Callback;
{
  $Akar::SOAP::Extension::Callback::VERSION = '1.994';
}
use strict;


use Akar::SOAP::Lite;
use Akar::SOAP::Headers;
# !!! imports dbh setter-getter
use Akar::Dbh;

use constant 'namespace_uri'    => 'http://akar.gtsgroup.cz/Akar/SOAP/Extension/Callback';
use constant 'namespace_prefix' => 'asec';

sub new {
	my $proto = shift;	

	my $this = bless({}, ref($proto) || $proto);
	while(my($k, $v) = splice(@_,0,2)){
		$this->$k($v);
	}
	return($this);
}


sub header {
	my $this = ref($_[0])? shift: shift->new;
	
	return(@_
		? do {
			# To access xml I have to serialize the whole header
			my $doc = XML::LibXML->new->parse_string($this->as_xml($_[0]));
			for my $node ($doc->findnodes('/*/*')){
				$node->namespaceURI eq namespace_uri 
				or die sprintf("Invalid element %s, unknown URI %s\n ",
					$node->nodeName,
					$node->namespaceURI);
				my $method = $node->localName;
				my $value  = $node->findvalue('.');
				$this->$method($value);
			}	
			$this;
		}
		: SOAP::Header
			->name('callback')
			->uri($this->namespace_uri)	
			->type('')
			# ->encodingStyle('http://xml.apache.org/xml-soap/literalxml')
			#->encodingStyle('')
			->prefix($this->namespace_prefix)
			->mustUnderstand(1)
			->value($this->_faked_soap_lite_value));
}

# 2004-10-11 danielr 
# I force the XML fragment (XML without the document element)
# to be the value of SOAP::Data for SOAP::Lite 
# which is UHM UHM ... but don't have better solution available
sub _faked_soap_lite_value {
	my $this = shift;
	join("\n", map {
		$this->$_ 
			? sprintf("<%s:%s>%s</%s:%s>", 
				$this->namespace_prefix, $_, 	
				$this->$_,
				$this->namespace_prefix, $_) 	
			: ();
	} qw(wsdl method uri proxy));
}

sub as_xml {
	my $this = shift;
	return(Akar::SOAP::Lite->serializer->serialize(@_? $_[0]: $this->header));
}

# setters getters
use Akar::Property qw(wsdl method uri proxy id dt_inserted _soap);

sub current {
	my $this = shift;
	return(Akar::SOAP::Headers->get_by_package(__PACKAGE__));
}

sub soap {
    my $this = shift;
    
    # no setter allowed
    $this->_create_soap unless $this->_soap;
    $this->_soap;
}


=begin OLD_COMMENT

# It is possible to call callback as SOAP (uri, proxy)
# or as service (method, wsdl)
sub soap {
    my $this = shift;
    
    # no setter allowed
    $this->_create_soap unless $this->_soap || $this->_service;
    $this->_soap;
}


sub service {
    my $this = shift;

    # no setter allowed
    $this->_create_soap unless $this->_soap || $this->_service;
    $this->_service;
}

sub _create_soap {
    my $this = shift;

    if ($this->wsdl){
	my $service = Akar::SOAP::Lite->service($this->wsdl);
	$service->proxy_all($this->proxy) if $this->proxy;
        $service->proxy($service->akar_methods->{$this->method}{'endpoint'});
        $this->_service($service);
    }
    else {
	my $soap = Akar::SOAP::Lite->proxy($this->proxy || die "No proxy\n ");
	$soap->uri($this->uri) if $this->uri;
        $this->_soap($soap);
    }
}

=end

=cut

sub _create_soap {
    my $this = shift;

    my $soap;
    if ($this->wsdl){
	$soap = Akar::SOAP::Lite->service($this->wsdl)->soap_for_method($this->method);
	$soap->proxy($this->proxy) if $this->proxy;
    }
    else {
	$soap = Akar::SOAP::Lite->proxy($this->proxy || die "No proxy\n ");
	$soap->uri($this->uri) if $this->uri;
    }
    $this->_soap($soap);
}

sub call {
	my $this = shift;

	my $method = $this->method or die "No method\n";
        $this->soap->$method(@_)->result;
}


sub call_test_with_attachments {
	my $this = shift;
        my $parts = shift;

	my $method = $this->method or die "No method\n";
	$this->wsdl
		? do {
			my $service = Akar::SOAP::Lite->service($this->wsdl);
			$service->proxy_all($this->proxy) if $this->proxy;
                        $service->parts(@$parts);
			$service->$method(@_);
		}
		: do {
			my $soap = Akar::SOAP::Lite
				->proxy($this->proxy || die "No proxy\n ");
			$soap->uri($this->uri) if $this->uri;
                        $soap->parts(@$parts);
			$soap->$method(@_)->result;
		};
}

# serialization
sub load {
	my $proto = shift;
	my($id)  = @_;

	my $sth = $proto->dbh->prepare("
	SELECT * FROM akar.soap_ext_callback WHERE id = ?");
	$sth->execute($id);
	my $hr = $sth->fetchrow_hashref('NAME_lc')
	or die "No callback with id $id\n ";
	return($proto->new(%$hr)->dbh($proto->dbh));
}

sub save {
	my $this = shift;

	$this->id($this->dbh->selectrow_array("
	SELECT akar.soap_ext_callback_seq.nextval FROM dual"));
	$this->dbh->do("
	INSERT INTO akar.soap_ext_callback (id, wsdl, method, uri, proxy)
	VALUES (?, ?, ?, ?, ?)", undef, 
		$this->id, $this->wsdl, $this->method, $this->uri, $this->proxy);
	$this->dbh->commit;
}

1;
