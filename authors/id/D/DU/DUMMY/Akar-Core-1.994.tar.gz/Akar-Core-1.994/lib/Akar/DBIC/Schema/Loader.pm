package Akar::DBIC::Schema::Loader;
{
  $Akar::DBIC::Schema::Loader::VERSION = '1.994';
}
use Moose;

# object wrapper to DBIx::Class::Schema::Loader
use FindBin qw($Bin);
use DBIx::Class::Schema::Loader qw(make_schema_at);

has schema_class => ( is => 'ro', required=>1 );

has connect_info => ( is => 'rw', required => 1, isa => 'ArrayRef' );

has dump_dir => ( is => 'ro', required => 1 );

has result_roles_map => (
    is         => 'ro',
    lazy_build => 1,
);

has result_base_class => (
    is         => 'ro',
    lazy_build => 1,
);

has result_roles => (
    is => 'ro',
    lazy_build => 1,
);

has use_moose => (is => 'ro', default => 1);

# should we find OCP::Schema::ResultRole::User
# for OCP::Schema::Result::User ?
has use_result_role_autoload => (
    is => 'ro',
    default => 1,
);

sub _build_result_roles_map { return {}; }

sub _build_result_roles {
    my $this = shift;
    return [
        $this->use_result_role_autoload
        ? 'Akar::DBIC::ResultRoleAutoload'
        : (),
    ];
}

sub _build_result_base_class {
    my $this = shift;
    return $this->schema_class . '::Result';
}

sub make_schema {
    my $this = shift;

    make_schema_at( $this->schema_class, $this->loader_params(@_),
        $this->connect_info, );
}

sub filter_schema_code {
    my ($this, $class, $text) = @_;
    return $text;
}

sub filter_result_code {
    my ( $this, $class, $text ) = @_;

    $text
        .= "\n# loads the schema defined in the ResultRole (if exists)\n"
        . "__PACKAGE__->complete_schema();\n"
        if $this->use_result_role_autoload;
    return $text;
}

sub loader_params {
    my $this = shift;
    my $other_params = shift;

    return {

        dump_directory     => $this->dump_dir,

        skip_load_external => 1,

        ( $this->result_base_class
            ? ( result_base_class => $this->result_base_class )
            : () ),

        # excluding views
        # exclude => qr{BIN\$|^V_|\.V_},

        # only tables listed
        #constraint => qr{p_product|p_product_config},

        #    default_resultset_class => 'ResultSet',
        use_moose => $this->use_moose,

        overwrite_modifications => 0,

        #db_schema => [ 'ADMIN', 'BILL', 'CONFIG', 'SVC', 'TT', ],

        #moniker_parts => [ 'schema', 'name' ],

        inflect_singular => sub {
            my $arg = shift;
            $arg =~ s/_id$//;
            return $arg;
        },

        generate_pod => 0,

        result_roles_map => $this->result_roles_map,

        result_roles => $this->result_roles, 

        verbose => 1,

        #    result_roles_map => $this->result_roles_map,
        filter_generated_code => sub {
            my ($type, $class, $text) = @_;
            if ($type eq 'result'){
                return $this->filter_result_code($class, $text);
            }
            elsif ($type eq 'schema'){
                return $this->filter_schema_code($class, $text);
            }
            else {
                die "Unknown type $type\n";
            }
            return $text;
        },

        %{$other_params || {}},
    };
};

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:


