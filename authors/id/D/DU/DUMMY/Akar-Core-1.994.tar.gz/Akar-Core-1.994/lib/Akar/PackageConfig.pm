package Akar::PackageConfig;
{
  $Akar::PackageConfig::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor);

use Carp qw(carp croak);
use File::Spec;

use List::MoreUtils qw(uniq);
use Class::Prototyped;
use YAML;
use Akar::Base;
use Interpolation 'E' => 'eval';
use Encode;
use File::Slurp qw(slurp);

# 2008-02-13 danielr 
# before installation of new aurelius (with ORA10) global config is changed
use constant 'GLOBAL_CONFIG_ROOT' => '/usr/local/etc';

sub new {
    my ( $package, $master_package, $fields ) = @_;

    $fields ||= {};
    my $config_file_basename
        = join( '-', split /::/, $master_package ) . '.yml';
    my $local_config_file = Akar::Base->app_config($config_file_basename);
    my $global_config_file
        = File::Spec->catfile( GLOBAL_CONFIG_ROOT, $config_file_basename );
    return Class::Prototyped->new(
        'master_package'       => $master_package,
        'local_config_file'    => $local_config_file,
        'global_config_file'   => $global_config_file,
        'parent_config*'       => $package,
        'config_file_contents' => {},
        %{$fields},
    );
}

sub config_files {
    my ($this) = @_;

    return uniq grep { defined $_ } 
        $this->global_config_file,
        $this->local_config_file;
}

    # loads configuration file, returns its content (hash reference)
sub load_config_file {
    my ( $this, $config_file ) = @_;

    return $this->config_file_contents->{$config_file}
        ||= $this->_load_config_file($config_file);
}

sub _load_config_file {
    my ( $this, $config_file ) = @_;

    return {} if !-e $config_file;    # file doesn't exist

    my $config_data = slurp($config_file);

    my @content;
    eval { @content = YAML::Load($config_data); };

    # parsing error is propagated
    die "Loading of YAML '$config_file' failed: $@\n " if $@;

    # there should be only one hash value in config file
    @content == 1 && UNIVERSAL::isa( $content[0], 'HASH' )
        or die "Invalid configuration file '$config_file',"
        . " only single hash is expected\n ";

    return $content[0];
}

sub _add_param {
    my ( $this, $is_optional, $is_mapping, $name, $default_value ) = @_;

    my @config_files = $this->config_files;
    my @values = grep { defined $_ }
        ( map { $this->load_config_file($_)->{$name}; } @config_files ),
        $default_value;

    # the value of configuration parameter
    my $accessor;
    if ($is_mapping) {
        my %value = map { %{$_} } @values;
        $accessor = sub {
            my ( undef, $key ) = @_;
            return \%value if @_ == 1;

            # special case mapping with key
            exists $value{$key}
                or die <<"END_NO_KEY";
No value of configuration parameter '$name' found for key '$key'. 
Available keys are: ($E{ join(', ', keys %value) }).
Supply this value into configuration file(s):  $E{ 
    join( ', ', @config_files ) 
}.
END_NO_KEY
            return $value{$key};
        };
    }
    else {

        # 2008-07-22 danielr
        # optional parameter may not be called
        # the error is thrown only when the parameter
        # is asked

        # no value found error
        if ( !@values ) {
            my $error = <<"END_NO_VALUE";
No value of configuration parameter $name found.
Supply this value into configuration file(s): $E{ 
    join( ', ', $this->config_files ) 
}
END_NO_VALUE
            die $error if !$is_optional;
            $accessor = sub { die $error };
        }
        else {
            my $value = $values[0];
            $accessor = sub { return $value };
        }
    }

    $this->reflect->addSlot( $name => $accessor );
}

sub add_param {
    my $this = shift;
    return $this->_add_param( 0, 0, @_ );
}

sub add_optional_param {
    my $this = shift;
    return $this->_add_param( 1, 0, @_ );
}

sub add_mapping {
    my $this = shift;
    return $this->_add_param( 0, 1, @_ );
}

1;

__END__

=head1 NAME

Akar::PackageConfig - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
