package Akar::DBIC::InnerSource;
{
  $Akar::DBIC::InnerSource::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(DBIx::Class);

use Carp qw(carp croak);
use Sub::Name;

__PACKAGE__->mk_classdata('inner_source_base');

my %inner_source_for; # they are stored per class

# new source can be subroutine defining the source
sub add_inner_source {
    my $class = shift;
    my ($moniker, $definition) = @_;

    my $inner_class;
    if (!ref $definition){  
        $inner_class = $definition;
    }
    elsif ( ref $definition eq 'CODE' ) {
        $inner_class = $class . '::' . $moniker;
        $class->inject_base( $inner_class, $class->inner_source_base);
        $definition->($inner_class);
    }
    else {
        die "Invalid type of definition: $definition\n ";
    }

    $inner_source_for{$class}{$moniker} = $inner_class;
    return wantarray ? ( $moniker => $inner_class ) : $inner_class;
}

# relationship sources can be defined in place
for my $method (qw(has_one belongs_to might_have has_many)){
    my $code = sub {
        my $class = shift;
        my ($rel, $rel_class, @rest) = @_;

        # related class can be a subroutine (inner source)
        return $class->next::method(@_) if !ref($rel_class) || ref($rel_class) ne 'CODE';

        # related class
        my $inner_class = $class->add_inner_source($rel, $rel_class);
        return $class->next::method($rel, $inner_class, @rest);
    };

    no strict 'refs';
    *$method = Sub::Name::subname( $method, $code );
}

# returns list of classes 
sub classes_to_register {
    my ($class, $moniker) = @_;

    my $inner_sources = $inner_source_for{$class} || {}; 
    return (

        # self
        [ $moniker, $class ],

        # inner sources, they also can have inner sources
        map { $inner_sources->{$_}->classes_to_register( "$moniker-$_")  }
            keys %$inner_sources
    );
}

1;

__END__

=head1 NAME

Akar::DBIC::InnerSource - more DBIx::Classes created from one file 

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
