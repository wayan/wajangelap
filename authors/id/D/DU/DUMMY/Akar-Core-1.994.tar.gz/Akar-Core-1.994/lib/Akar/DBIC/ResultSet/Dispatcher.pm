package Akar::DBIC::ResultSet::Dispatcher;
{
  $Akar::DBIC::ResultSet::Dispatcher::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);

sub is_dispatcher {
    my $this = shift;
    return $this->result_class->is_dispatcher;
}

sub is_dispatched {
    my $this = shift;
    return $this->result_class->is_dispatched;
}

# returns the resultset which has the proper type and proper result_class set
# but still contains all records
sub _dispatched_resultset {
    my ( $this, $moniker ) = @_;

    $this->is_dispatcher
        or die
        "You can't call dispatched_resultset on class which is not dispatcher";

    my $dispatched_class
        = $this->result_class->dispatched_class_for->{$moniker}
        or die "Invalid subclass $moniker\n ";

    # cloning rs so we don't modify itself
    my $rs = $this->search_rs( {}, {} );
    bless( $rs, $dispatched_class->resultset_class );

    # passing the result_class
    $rs->result_class($dispatched_class);
    return $rs;
}

# returns tickets of particular type
sub dispatched_resultset {
    my $this = shift;

    # SELECT only those records belonging to proper class
    my $rs = $this->_dispatched_resultset(@_);

    # returns search_mine on the new resultset
    return $rs->search_mine;
}

# returns the names of resultsets available
sub dispatched_resultsets {
    my $this = shift;

    $this->is_dispatcher or return;
    return keys %{ $this->result_class->dispatched_class_for };
}

# these are for dispatched rs
sub search_rs {
    my $this = shift;

    my $rs = $this->next::method(@_);
    if ( $this->is_dispatched ) {

        # the class must be set it is set from result_source
        $rs->result_class( $this->result_class );
    }
    return $rs;
}

1;

__END__

=head1 NAME

Akar::DBIC::ResultSet::Dispatcher - dispatcher class for resultset

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
