package Akar::DBI::Statement::Object;
{
  $Akar::DBI::Statement::Object::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor);

# statemet object can be concatenated
# $object .= 'text'
# or even my $object = "... $other_object";
use overload
    '.'   => 'concatenate',
    'fallback' => 1;

use Carp qw(croak);
use List::MoreUtils qw(uniq any);
use Scalar::Util qw(blessed);

# suffix added to every param
use constant 'BOUND_PARAM_SUFFIX' => '_dxas';

# maximum length of placeholder (param)
use constant 'MAX_PH_LENGTH' => 16;

# default parameter size of inout parameter
use constant 'DEFAULT_INOUT_PARAM_SIZE' => 50;

# returns 1 if the argument is a SQL ancestor
# it is method to be easily used in subclasses
sub is_sql {
    my ( undef, $arg ) = @_;

    return blessed($arg) && $arg->isa(__PACKAGE__);
}

{

    package Akar::DBI::Statement::Param;
{
  $Akar::DBI::Statement::Param::VERSION = '1.994';
}
    use base qw(Akar::DBI::Statement::Object);

    sub _build {
        my ( $this, $param_callback ) = @_;

        return $param_callback->($this);
    }

    sub replace_param { return 0 }

    sub has_param { return 0 }
}
{

    package Akar::DBI::Statement::Param::In;
{
  $Akar::DBI::Statement::Param::In::VERSION = '1.994';
}

    use base qw(Akar::DBI::Statement::Param);

    sub is_inout { return 0; }

    # returns subroutine which called on sth binds the parameter
    sub bind_sub {
        my ( $this, $name ) = @_;

        return sub {
            my ($sth) = @_;
            $sth->bind_param( $name, $this->[1],
                defined $this->[2] ? $this->[2] : () );
            }
    }

    sub value { return shift()->[1]; }
}
{

    package Akar::DBI::Statement::Param::InOut;
{
  $Akar::DBI::Statement::Param::InOut::VERSION = '1.994';
}
    use base qw(Akar::DBI::Statement::Param);

    sub is_inout { return 1; }

    sub bind_sub {
        my ( $this, $name ) = @_;

        return sub {
            my ($sth) = @_;
            $sth->bind_param_inout( $name, $this->[1], $this->[2],
                defined $this->[3] ? $this->[3] : () );
            }
    }

    sub value {
        die "Inout parameter has no value\n";
    }
}

sub new_param {
    my ( $this, @bind_param_args ) = @_;
    return bless \@bind_param_args => 'Akar::DBI::Statement::Param::In';
}

sub new_param_inout {
    my ( $this, @bind_param_args ) = @_;

    if ( !defined( $bind_param_args[2] ) ) {
        # size of the inout parameter 
        $bind_param_args[2] = DEFAULT_INOUT_PARAM_SIZE;
    }
    return bless \@bind_param_args => 'Akar::DBI::Statement::Param::InOut';
}

# binds the parameter on statement
sub bind_param {
    my ( $this, $name, $value, $type_or_attr ) = @_;

    my $param =

        # value is  SQL statement
        $this->is_sql($value)
        ? $value

        # value is text
        : !ref($name) ? $this->new_param( $name, $value, $type_or_attr )
        : undef
        or croak "\$sql->bind_param(\$name, \$value)\n";
    $this->replace_param( $name => $param )
        or croak "No parameter $name\n ";
    return $this;
}

sub bind_param_inout {
    my ( $this, $name, $value_ref, $size, $type_or_attr ) = @_;

    my $param =
        $this->is_sql($value_ref) ? $value_ref
        : !ref($name)
        ? $this->new_param_inout( $name, $value_ref, $size, $type_or_attr )
        : undef
        or croak "\$sql->bind_param_inout(\$name, \$value_ref, [\$size])\n";
    $this->replace_param( $name => $param )
        or croak "No parameter $name\n ";
}

# 2007-02-06 danielr
# param name must be allways modified
# because I often use names unacceptable for Oracle
# as :from, :to, :any
#$param_num
#    ? substr( $this->name, 0, MAX_PH_LENGTH - length($suffix) )
#    . $suffix
#    : $this->name;


# build - returns the text and list of callbacks which called on statement
# handle will bind the parameters

# the parameter can be numbered
# parameter naming
# parameter names must be unique locally in the scope of current
# root_statement the one which is currently currently being prepared

sub build {
    my ( $this, $named_params ) = @_;

    my %param_name_for;
    my $param_num = 0;
    my @bind_subs;

    my $param_callback = $named_params
        ? sub {
        my ($param) = @_;

        # I make the name of parameter unique
        # the parameter was already used, so it is not returned again
        return ( $param_name_for{$param}, [] ) if $param_name_for{$param};

        # unique param_name is created
        my $suffix = BOUND_PARAM_SUFFIX . ( ++$param_num );
        my $param_name = substr( $param->[0] || ':p', 0,
            MAX_PH_LENGTH - length($suffix) )
            . $suffix;
        $param_name_for{$param} = $param_name;
        push @bind_subs, $param->bind_sub($param_name);
        return $param_name;
        }
        : sub {

        # numbered parameters
        my ($param) = @_;
        push @bind_subs, $param->bind_sub( ++$param_num );
        return '?';
        };

    return ( $this->_build($param_callback), \@bind_subs );
}

sub build_numbered {
    return shift()->build(0);
}

# returns only the text part not the callbacks
sub text {
    my $this = shift;
    return +( $this->build(@_))[0];
}

# return the text with parameter values quoted by a db handle
sub text_quoted {
    my ( $this, $dbh ) = @_;

    return $this->_build(
        sub {
            my ($param) = @_;

            die "build_quoted cannot be used with inout params\n"
                if $param->is_inout;
            return $dbh->quote( $param->value );
        }
    );
}

# concatenation operator
sub concatenate {
    require Akar::DBI::Statement::Interpolated;

    my ( $this, $arg, $reversed ) = @_;

    # assignment .=
    # only interpolated statement can make concatenation assignment
    die ref($this) . ' cannot make concatenation assignment '
        if !defined($reversed);

    # new Interpolated statement is created
    return Akar::DBI::Statement::Interpolated->new(
        { 'layout' => [ $reversed ? ( $arg, $this ) : ( $this, $arg ) ] } );
}

# returns (text, value1, value1, ..)
# to be used like
# my ($text, @values) = $sql->text_and_values;
# my $sth = $dbh->prepare($text);
# $sth->execute(@values);
sub text_and_values {
    my ($this) = @_;

    my @values;
    my $text = $this->_build(
        sub {
            my ($param) = @_;
            push @values, $param->value;
            return '?';
        }
    );
    return ($text, @values);
}

# build all param_names and param text

sub prepare_and_bind {
    my ($this, $dbh, @prepare_params) = @_;
    return $this->_prepare_and_bind('prepare', $dbh, @prepare_params);
}

sub prepare_cached_and_bind {
    my ($this, $dbh, @prepare_params) = @_;
    return $this->_prepare_and_bind('prepare_cached', $dbh, @prepare_params);
}

sub _prepare_and_bind {
    my ( $this, $prepare_method, $dbh, @prepare_params ) = @_;

    my ($text, $bindings_ref) = $this->build;
    my $sth = $dbh->$prepare_method( $text, @prepare_params )
        or return;
    for my $binding ( @{$bindings_ref} ) {
        $binding->($sth);
    }
    return $sth;
}

1;

__END__

=head1 NAME

Akar::DBI::Statement::Object - base class for all Akar::DBI::Statement classes

=head1 SYNOPSIS

See Akar::DBI::Statement

=head1 DESCRIPTION

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz>

=cut

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

