package Akar::DbhExporter;
{
  $Akar::DbhExporter::VERSION = '1.994';
}
use strict;
use warnings;

# importuje do baliku funkce pro automaticke pripojeni do databaze

use Carp qw(carp croak);
use Akar::Class::Utils qw(add_singleton_method);
use List::MoreUtils qw(firstval);

# *******************************************************************************
# 2011-03-14 danielr
# this module is relict, should not be used for new stuff
# *******************************************************************************

# there is import only 

# sub_name      - the name of the sub which will return opened db handle
# connect_sub   - subroutine connecting to db (is called once)
# opt_ref       - hash with named options
#   smart_disconnect - when set true, dbh returned by connect_sub is modified
#       so when disconnected, the handle is also removed from accessor
#   auto_reconnect - everytime a dbh is asked the ping is called 
#                       and if it fails the dbh is reconnected

sub import {
    my ( $this, $sub_name, $connect_sub, $opt_ref ) = @_;

    my $caller = caller;

    # plain accessor
    my $stored_dbh; # this is the stored db handle

    # smart_disconnect - when dbh is disconnected then stored filehandle is deleted
    if ( my $smart_disconnect = firstval { defined $_} $opt_ref->{'smart_disconnect'}, 1 ) {
        my $orig_connect_sub = $connect_sub;
        $connect_sub = sub {
            my $dbh             = $orig_connect_sub->();
            my $orig_disconnect_sub = $dbh->can('disconnect')
                or croak "No disconnect method found for dbh\n ";
            add_singleton_method(
                $dbh,
                'disconnect' => sub {
                    $dbh->$orig_disconnect_sub;
                    undef $stored_dbh;
                }
            );
            add_singleton_method(
                $dbh,
                'reconnect' => sub {
                    undef $stored_dbh;
                }
            );
            return $dbh;
        };
    }

    # auto_reconnect - everytime a dbh is served it is pinged 
    # and possibly reconnected
    my $auto_reconnect = firstval { defined $_} $opt_ref->{'auto_reconnect'}, 0;

    no strict 'refs';

    # returns the stored db handle opening it when needed
    *{"${caller}::${sub_name}"} = sub {
        if ( !defined($stored_dbh) || ( $auto_reconnect && !$stored_dbh->ping ) ) {

            # auto reconnect or connect
            $stored_dbh = $connect_sub->()
                or croak "Connection sub returned false value\n ";
        }
        return $stored_dbh;
    };

    # returns (or set) the stored db handle
    *{"${caller}::_${sub_name}_accessor"} = sub { return @_ ? $stored_dbh = $_[0] : $stored_dbh; };

    # localization
    *{"${caller}::localize_${sub_name}"} = sub {
        require Akar::Class::Utils;
        my $lc = Akar::Class::Utils::lexical_cleaner(
            sub { $stored_dbh = shift(); }, $stored_dbh);

        # accessor sub is undefined
        $stored_dbh = @_? shift(): undef;
        return $lc;
    };

    # disconnect (with auto_disconnect = 1 useless)
    *{"${caller}::disconnect_${sub_name}"} = sub {
        if ( defined($stored_dbh) ) {
            $stored_dbh->disconnect;
            undef $stored_dbh;
        }
    };
}

1;

__END__

=head1 NAME

Akar::DbhExporter - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
