package Akar::PL_SQL::Type::Boolean;
{
  $Akar::PL_SQL::Type::Boolean::VERSION = '1.994';
}
use strict;

use base qw(Akar::PL_SQL::Type::Base);

sub name     { 'boolean' }
sub new_type { __PACKAGE__ }

sub dump_input_value {
    my ($this, $value) = @_;

    $value ? 'true' : 'false';
}

1;
