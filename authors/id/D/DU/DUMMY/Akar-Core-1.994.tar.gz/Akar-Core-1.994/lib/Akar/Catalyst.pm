package Akar::Catalyst;
{
  $Akar::Catalyst::VERSION = '1.994';
}
use strict;
use warnings;

use Scalar::Util qw(blessed);
use Akar::Javascript::YUILoader;

use Carp qw(carp croak);
use Catalyst::Runtime '5.70';
use Akar::Base;

# Akar::Catalyst::View::Mason is configured 
# so the web root is not same as comp_root
use Akar::Catalyst::View::Mason;
Akar::Catalyst::View::Mason->config(
    'comp_root' => Akar::Base->app_home('lib/mason'),

    # 2008-06-13 danielr
    # object cache together with installation from CVS
    # is confusing
    'use_object_files' => 0
);

sub import {
    my ( $class, @arguments ) = @_;
    #return if $class ne __PACKAGE__;
    return if !$class->isa(__PACKAGE__);

    unshift @arguments, '+' . $class, 'Static::Simple';

    # I have to use string eval to cheat Catalyst
    # I add myself into args
    my $caller = caller();
    eval qq{
        package $caller;
        use Catalyst (\@arguments);
    };
    die $@ if $@;

    # default configuration
    # default view is mason
    $caller->config(
        'home' => Akar::Base->app_home,

        # web root
        'root'         => Akar::Base->app_home('lib/www'),
        'name'         => $caller,
        'default_view' => 'Akar::Catalyst::View::Mason',

        # I have to strip the Mason so the Module::Pluggable would find it
        'setup_components' => { 'search_extra' => ['Akar::Catalyst::View'] }
    );
}

# "Head" code management
# lines are added into 'head' field in stash and later flushed 
# in a template 

# adds line into head
sub add_head_code {
    my $this = shift;

    push @{ $this->stash->{'head_code'} ||= [] }, @_;
}

# adds javascript into header (javascript is either URI object or code)
sub add_javascript {
    my ( $this, $source_or_uri ) = @_;

    my $is_uri = blessed($source_or_uri) && $source_or_uri->isa('URI');

    my $js_code = '<script type="text/javascript"'
        . (
        $is_uri
        ? ' src="' . $source_or_uri . '">'
        : ">\n$source_or_uri\n"
        )
        . '</script>';
    $this->add_head_code($js_code);
}

# adds javascript (library) only once
sub add_javascript_once {
    my ($this, $source_or_uri, $unique_name) = @_;

    return if $this->stash->{'_js_unique'}{$unique_name}++;
    $this->add_javascript($source_or_uri);
}

sub yui_loader {
    my ( $this ) = @_;

    return $this->stash->{'yui_loader'} ||= do {
        my $yui_loader = Akar::Javascript::YUILoader->new;

        # YUI is added when needed for the first time
        # when head_code is printed out YUI is serialized via overload '""'
        $this->add_head_code($yui_loader);
        $yui_loader;
    };
}

1;




1;

__END__

=head1 NAME

Akar::Catalyst - defaults for catalyst based application

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
