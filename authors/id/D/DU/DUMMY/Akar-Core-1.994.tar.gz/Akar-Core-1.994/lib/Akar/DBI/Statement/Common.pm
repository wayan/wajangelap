package Akar::DBI::Statement::Common;
{
  $Akar::DBI::Statement::Common::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor);

use overload
    '@{}' => sub { shift()->layout },
    '.'   => '_concat',
    'fallback' => 1;

use Carp qw(croak);
use List::MoreUtils qw(uniq any);

our @CARP_NOT = qw(DBI::db DBI);

# suffix added to every param
use constant 'BOUND_PARAM_SUFFIX' => '_dxas';

# maximum length of placeholder (param)
use constant 'MAX_PH_LENGTH' => 16;

# default parameter size of inout parameter
use constant 'DEFAULT_INOUT_PARAM_SIZE' => 50;

# array of the layout
__PACKAGE__->mk_accessors(qw(layout));

# 1 if the parameters should be numbered (instead of named)
# and textified as question mark (?)
__PACKAGE__->mk_accessors(qw(has_numbered_params));

# caching name params
__PACKAGE__->mk_accessors(qw(param_names));

sub new {
    my ( $package, $fields ) = @_;

    $fields ||= {};
    return $package->SUPER::new(
        {   'param_names' => {},
            %{$fields},
        }
    );
}

sub is_sql {
    my ( $this, $arg ) = @_;

    return UNIVERSAL::isa( $arg, __PACKAGE__ );
}

# concatenate operator
sub _concat {
    my ( $this, $arg, $reversed ) = @_;

    if ( !defined $reversed ) {
        # assignment .= 
        push @{ $this->layout }, $arg;
        return $this;
    }
    else {
        my @new_layout = $reversed ? ( $arg, $this ) : ( $this, $arg );
        return __PACKAGE__->new( { 'layout' => \@new_layout } );
    }
}

{
    package Akar::DBI::Statement::Param;
{
  $Akar::DBI::Statement::Param::VERSION = '1.994';
}
    use base qw(Akar::DBI::Statement::Common);

    use overload
        '@{}'      => sub { return shift() },
        'fallback' => 1;

    sub text {
        my ($this) = @_;
        return $this->root_statement->param_text($this);
    }

    sub params {
        my ($this) = @_;

        return ($this);
    }

    sub layout { return [] }

    sub replace_param { return 0 }

    package Akar::DBI::Statement::Param::In;
{
  $Akar::DBI::Statement::Param::In::VERSION = '1.994';
}

    use base qw(Akar::DBI::Statement::Param);
    sub is_inout { return 0; }

    package Akar::DBI::Statement::Param::InOut;
{
  $Akar::DBI::Statement::Param::InOut::VERSION = '1.994';
}
    use base qw(Akar::DBI::Statement::Param);

    sub is_inout { return 1; }
}

sub new_param {
    my($this, @bind_param_args) = @_;
    return bless \@bind_param_args => 'Akar::DBI::Statement::Param::In';
}

sub new_param_inout {
    my($this, @bind_param_args) = @_;

    for my $size ($bind_param_args[2]){
        if (!defined($size)){
            $size = DEFAULT_INOUT_PARAM_SIZE;
        }
    }
    return bless \@bind_param_args => 'Akar::DBI::Statement::Param::InOut';
}

sub bind_param {
    my ( $this, $name, $value, $type_or_attr ) = @_;

    if ( $this->is_sql($value) ) {
        $this->replace_param( $name => $value )
            or croak "No parameter $name\n ";
       return $this;
    }
    elsif ( !ref($name) ) {
        return $this->bind_param( $name =>
            $this->new_param( $name, $value, $type_or_attr ) );
    }

    croak "\$sql->bind_param(\$name, \$value)\n";
}

sub bind_param_inout {
    my ( $this, $name, $value_ref, $size, $type_or_attr ) = @_;

    if ( $this->is_sql($value_ref) ) {
        return $this->bind_param( $name => $value_ref );
    }
    elsif ( !ref($name) ) {
        return $this->bind_param(
            $name => $this->new_param_inout(
                $name, $value_ref, $size, $type_or_attr
            )
        );
    }

    croak "\$sql->bind_param_inout(\$name, \$value_ref, [\$size])\n";
}

# replace param name in text, returns the number of replacements
sub replace_param {
    my ( $this, $param_name, $replacement ) = @_;

    my $replaced = 0;
    my @new_layout;
    for my $child ( @{ $this->layout } ) {
        if ( ref($child) ) {
            # SQL
            $replaced += $child->replace_param( $param_name, $replacement );
            push @new_layout, $child;
        }
        else {
            # text
            my @replaced = grep { defined($_) }
                $this->replace_param_in_text( $child, $param_name,
                $replacement );
            $replaced += @replaced - 1;
            push @new_layout,
                @replaced > 1
                ? __PACKAGE__->new( { 'layout' => \@replaced } )
                : @replaced;
        }
    }

    @{ $this->layout } = @new_layout;
    return $replaced;
}

sub has_param {
    my ( $this, $param_name ) = @_;

    my $param_re = $this->param_re($param_name);
    for my $sql ( @{ $this->layout } ) {
        my $has_param
            = ref($sql) ? $sql->has_param($param_name) : $sql =~ /$param_re/;
        return 1 if $has_param;
    }
    return;
}

sub param_re {
    my ( $this, $param_name ) = @_;
    return qr(\Q$param_name\E\b);
}

sub replace_param_in_text {
    use integer;

    my ( $this, $text, $param_name, $replacement ) = @_;
    my $param_re = $this->param_re($param_name);
    my @texts = split $param_re, $text, -1;
    return ( shift(@texts), map { ( $replacement, $_ ) } @texts );
}

# return list of params as they appear in text
# there may be duplicities
sub params {
    my ($this) = @_;

    return map { $_->params } grep { ref($_) } @{ $this->layout };
}

sub text {
    my ($this) = @_;

    @_ == 1
        or croak "\$statement->text(): method cannot be called as setter\n ";

    my $txt = '';
    for my $child ( @{ $this->layout } ) {
        $txt .= ref($child) ? $child->text : $child;
    }
    return $txt;
}

# text with quoted params, use for debugging only
sub text_quoted {
    no strict 'refs';
    no warnings 'redefine';

    my ( $this, $dbh ) = @_;
    my $package = ref($this);
    local *{ $package . '::' . 'param_text' } = sub {
        my ( $this, $param ) = @_;

        !$param->is_inout
            or croak "Inout parameter can't be quoted\n ";

        return $dbh->quote( $param->[1] );
    };

    return $this->text;
}

sub bind_all_params {
    my ( $this, $sth ) = @_;

    my @params
        = $this->has_numbered_params ? $this->params : uniq $this->params;
    for my $param (@params) {
        $param->bind_in_sth($sth);
    }
}

# legacy method, appends text or SQL at the end of current text
sub append {
    my ($this, $str_or_sql) = @_;

    push @{$this->layout}, $str_or_sql;
    return $this;
}

my %legacy_packages;

sub dbh {
    # only setter allowed, the legacy interface is 
    my ($this, $new_value) = @_;

    croak "\$sql->dbh(\$dbh)\n "
        if ! (ref($this) && @_ == 2);

    my $legacy_package = ref($this) . '::legacy';
    if ( !$legacy_packages{$legacy_package} ) {
        $legacy_packages{$legacy_package} = 1;
        no strict 'refs';

        require Akar::DBI::Statement::LegacyInterface;
        @{"${legacy_package}::ISA"}
            = ( 'Akar::DBI::Statement::LegacyInterface', ref($this) );
    }

    bless($this => $legacy_package);
    $this->dbh($new_value);
    return $this;
}

# parameter naming
# parameter names must be unique locally in the scope of current 
# root_statement the one which is currently currently being prepared 
sub param_name {
    my ($this, $param) = @_;

    return ++$this->param_names->{'param_num'}
        if $this->has_numbered_params;

    return $this->param_names->{ 0 + $param } ||= do {
        my $param_num = scalar keys %{ $this->param_names };
        my $param_name = $param->[0] || ':param';

        my $suffix = BOUND_PARAM_SUFFIX . $param_num;
        substr( $param_name, 0, MAX_PH_LENGTH - length($suffix) ) . $suffix;
    };

    # 2007-02-06 danielr
    # param name must be allways modified
    # because I often use names unacceptable for Oracle
    # as :from, :to, :any
    #$param_num
    #    ? substr( $this->name, 0, MAX_PH_LENGTH - length($suffix) )
    #    . $suffix
    #    : $this->name;

}

sub param_text {
    my ( $this, $param ) = @_;

    return $this->has_numbered_params
        ? '?'
        : $this->param_name($param);
}

{
    my $root_statement = __PACKAGE__->new;

    sub root_statement {
        return $root_statement;
    }
}

sub _prepare_and_bind {
    my ( $this, $dbh, $prepare_sub, @prepare_params ) = @_;

    no warnings 'redefine';
    local *root_statement = sub { return $this; };

    $this->param_names( {} );
    my $text   = $this->text;
    my @params = $this->params;
    my $sth    = $dbh->$prepare_sub( $text, @prepare_params )
        or return;
    for my $param ( $this->has_numbered_params ? @params : uniq @params ) {
        my @bind_param_args = @{$param};

        # the name is made unique
        splice @bind_param_args, 0, 1, $this->param_name($param);

        if ( $param->is_inout ) {
            $sth->bind_param_inout(@bind_param_args);
        }
        else {
            $sth->bind_param(@bind_param_args);
        }
    }
    return $sth;
}


1;

__END__

=head1 NAME

Akar::DBI::Statement::Common - the base class for all Akar::DBI::Statement
classes

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

