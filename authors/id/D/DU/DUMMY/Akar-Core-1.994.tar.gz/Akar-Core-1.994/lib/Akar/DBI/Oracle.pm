package Akar::DBI::Oracle;
{
  $Akar::DBI::Oracle::VERSION = '1.994';
}
use strict;
use warnings;

# $Id: Oracle.pm,v 1.5 2008/03/28 13:13:27 cvs Exp $

=head1 NAME

Akar::DBI::Oracle - upraven� DBI interface pro snadn�j�� pr�ci s datab�z�

=head1 SYNOPSIS

=head1 DESCRIPTION

=cut

use base qw(Akar::DBI);

sub default_attr {
    my ($package) = @_;

    return {
        %{ $package->SUPER::default_attr },

        # DBIx::ContextualFetch because of Class::DBI
        'RootClass'                  => 'DBIx::ContextualFetch',
        'AutoCommit'                 => 0,
        'ENV:NLS_DATE_FORMAT'        => 'YYYY-MM-DD HH24:MI:SS',
        'ENV:NLS_LANG'               => 'CZECH_CZECH REPUBLIC.EE8ISO8859P2',
        'ENV:NLS_NUMERIC_CHARACTERS' => '. '
    };
}

1;

__END__

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
