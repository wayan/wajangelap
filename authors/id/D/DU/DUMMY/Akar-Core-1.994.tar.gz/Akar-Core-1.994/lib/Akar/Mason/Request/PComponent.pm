package Akar::Mason::Request::PComponent;
{
  $Akar::Mason::Request::PComponent::VERSION = '1.994';
}
use strict;
use warnings;

use base qw(Class::Accessor::Grouped);

use Carp qw(carp croak);
use Module::Find;
use Class::Inspector;

# Mason request which can process PComponent (components written in perl)
__PACKAGE__->mk_group_accessors( inherited => 'pcomp_classes' );
__PACKAGE__->mk_group_accessors( inherited => 'pcomp_actions' );
__PACKAGE__->pcomp_actions( {} );

# I don't want to mess with HTML::Mason accessors and internals
# thus I use only one key in hash
sub _pcomponent {
    return shift()->{_pcomponent} ||= { cache => {}, comps => {} };
}

sub register_pcomp_actions {
    my ( $class, $ns, $pcomponent ) = @_;

    my %methods = map { ( scalar( $pcomponent->can($_) ) => $_ ); }
        @{ Class::Inspector->methods($pcomponent) || [] };

    for my $ar ( @{ $pcomponent->_actions_attr } ) {
        my ( $code, @attrs ) = @$ar;
        my $method = delete $methods{$code} or next;

        for my $attr (@attrs) {
            my $key;
            if ( $attr eq 'Local' ) {
                $key = $ns . ':' . $method;
            }
            elsif ( $attr eq 'Global' ) {
                $key = $method;
            }
            elsif ( $attr eq 'Auto' ) {
                $key = $ns . ':';
            }
            else {
                die "Unknown attribute $attr\n";
            }

            if ( $class->pcomp_actions->{$key} ) {
                warn "Action $key already registered\n ";
            }
            else {
                $class->pcomp_actions->{$key} = [ $pcomponent, $code ];
            }
        }
    }
}

# renders perl component
sub pcomp {
    my ( $this, $name, $args, $content_sub ) = @_;

    local $this->_pcomponent->{csub} = $content_sub;
    if (ref $name){
        if (ref $name eq 'CODE'){
            my $code = $name;
            return $code->($this, @$args);
        }
        elsif (ref $name eq 'ARRAY'){
            my ($pcomp, $method) = @$name;
            return $pcomp->$method($this, @$args);
        }
        else {
            die "Invalid name of pcomponent $name\n";
        }
    }
    else {
        my ( $pcomp, $code, @preargs ) = $this->fetch_pcomp($name);
        return $code->( $pcomp, $this, @preargs, @$args );
    }
}

# given NS:NAME returns ($pcomponent, $code, @preargs)
sub fetch_pcomp {
    my ( $this, $name ) = @_;

    # exact ns:method
    my $exact = $this->pcomp_actions->{$name};
    return @$exact if $exact;

    # auto method
    if ( my ( $ns, $method ) = $name =~ /(.*?:)(.*)/ ) {
        my $auto = $this->pcomp_actions->{$ns};
        return ( @$auto, $method ) if $auto;
    }
    die "Cannot find action $name\n";
}

# renders perl component content
sub pcomp_render_content {
    my $this = shift;

    my $code = $this->_pcomponent->{csub} or return;
    $code->();
}

sub pcomp_csub { return shift()->_pcomponent->{csub}; }

# has the perl component content
sub pcomp_has_content {
    my $this = shift;

    return $this->_pcomponent->{csub} ? 1 : 0;
}

1;

__END__

=head1 NAME

Akar::Mason::Request::PComponent - 

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
