package Akar::DBI::MySQL;
{
  $Akar::DBI::MySQL::VERSION = '1.994';
}
# $Id: MySQL.pm,v 1.1.1.1 2004/11/18 12:18:18 danielr Exp $

=head1 NAME

Akar::DBI::MySQL - upraven� DBI interface pro snadn�j�� pr�ci s datab�z�

=head1 SYNOPSIS

=head1 DESCRIPTION

=cut

use strict;
use vars qw(@ISA);

@ISA = qw(DBI);


# Preloaded methods go here.
use DBI;

sub akar_connect {
	my $class = shift;
	my ($connect_par, $magic) = @_;

	DBI::init_rootclass(__PACKAGE__); # aktualni balik

	my($datasource, $username, $auth, $attr) = 
		@$connect_par{qw(datasource username auth attr)};
	if (!$datasource){
		die "Nenalezen datasource k magicu $magic\n ";
	} 
	if (!defined($username)){
		die "Nenalezen username k magicu $magic\n ";
	}
	my $method = ($$connect_par{'cached'}? 'connect_cached': 'connect');
	if ( my $dbh = $class->$method($datasource, $username, $auth, $attr)){
		return($dbh);
		# return bless($dbh, $class->dbh_package);
	} else {
		die sprintf("Pripojeni ke zdroji '%s' s uzivatelem '%s' se nezdarilo",
		@$connect_par{qw(datasource username)});

	}
}

package Akar::DBI::MySQL::db;
{
  $Akar::DBI::MySQL::db::VERSION = '1.994';
}

use vars qw(@ISA);
@ISA = qw(Akar::DBI::db);


package Akar::DBI::MySQL::st;
{
  $Akar::DBI::MySQL::st::VERSION = '1.994';
}

use vars qw(@ISA);
@ISA = qw(Akar::DBI::st);

1;

__END__

=head1 HISTORIE

$Log: MySQL.pm,v $
Revision 1.1.1.1  2004/11/18 12:18:18  danielr
Vytvorena nova struktura

Revision 1.4  2004/03/31 09:33:15  danielr
Metoda connect prejmenovana na akar_connect, takze nyni nemusim zkoumat,
zda se jedna o volani ala DBI, nebo ala Akar::DBI

Revision 1.3  2004/02/03 14:34:15  danielr
zavedeno connect_cached, upravena hierarchie trid

Revision 1.2  2003/07/10 10:56:54  danielr
u�ivatel jest testov�n na definovanost, aby bylo mo�n� zadat pr�zdn�ho u�ivatele
pozd�ji z�ejm� test zcela vyhod�m

Revision 1.1  2003/04/01 07:59:44  danielr
uvodni verze (pro Moai)


=cut
