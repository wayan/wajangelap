package Akar::DBIC;
{
  $Akar::DBIC::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);

1;

__END__

=head1 NAME

Akar::DBIC - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
