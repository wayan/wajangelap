package Akar::Log::Message::Structured;
{
  $Akar::Log::Message::Structured::VERSION = '1.994';
}
use Moose;

with 'Log::Message::Structured',
    'Log::Message::Structured::Component::Date',
    'Log::Message::Structured::Component::Hostname',
    'Akar::Log::Message::Structured::StringifyAsJSON' => {
        keys_order => [ 'date', 'level', 'message', qr{.*}, 'class'],
    };

has message => (is => 'ro', required => 1);

# the arbitrary fields passed to constructor, any such field is stringified 
has _fields => (is => 'ro', required => 1);

around BUILDARGS => sub {
    my $orig   = shift;
    my $fields = $orig->(@_);

    return { %$fields, _fields => $fields };
};

sub as_hash {
    my ($this) = @_;

    # hardcoded filter
    my %hr = map {
        my $name  = $_->name;
        my $value = $_->get_value($this);
        $name eq '_fields' ? %$value : ( $name => $value );
    } $this->meta->get_all_attributes;

    # blessed values are either converted or stringified
    # the unblessed references are left as is
    for my $blessed ( grep { blessed $_ } values %hr ) {
        $blessed = $blessed->can('as_hash') ? $blessed->as_hash : "$blessed";
    }

    return \%hr;
}

no Moose;
1;
