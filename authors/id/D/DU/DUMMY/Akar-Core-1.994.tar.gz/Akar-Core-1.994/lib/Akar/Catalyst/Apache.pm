package Akar::Catalyst::Apache;
{
  $Akar::Catalyst::Apache::VERSION = '1.994';
}
use strict;
use warnings;

# SOAP::Transport::HTTP::Apache 
use base qw(Akar::Catalyst::Server::Base);

# use Class::Trait qw(Akar::Trait::PackageConfig);

use Encode;
use FileHandle;
use File::Path qw(mkpath);
use File::Basename qw(dirname basename);
use File::Spec;
use File::Slurp qw(write_file slurp);
use Carp qw(croak carp);
use Sys::Hostname qw(hostname);
use List::MoreUtils qw(uniq);
use HTML::Mason;

use Akar::Base;
use Interpolation 'E' => 'eval';
use HTTP::Status qw(RC_FORBIDDEN RC_OK RC_NOT_FOUND RC_INTERNAL_SERVER_ERROR);
use Akar::CLI;

__PACKAGE__->mk_classdata('ssl_port' => -1);

# 2009-01-27 danielr
# local is tried first (targeted to cowboy)
__PACKAGE__->mk_classdata('httpd_conf_template' => do {
    # first specific templates are tried
    my $config_basename = 'Akar-Catalyst-Apache/httpd.conf.mc';
    my $global = "/usr/local/etc/$config_basename";
    my $local = Akar::Base->app_config($config_basename);
    -f $local ? $local: $global;
});
__PACKAGE__->mk_classdata('apache_binary' => '/usr/sbin/httpd');
__PACKAGE__->mk_classdata('authorization_enabled' => 1);  

# maximum waiting period until Apache dies
__PACKAGE__->mk_classdata('apache_death_timeout' => 20);
__PACKAGE__->mk_classdata('single_request' => 0 );
__PACKAGE__->mk_classdata('single_client' => 0 );

# initial period of waiting for apache death (very unimportant constant)
# 0.1 second
__PACKAGE__->mk_classdata('apache_death_start_wait' => 0.1);  

# location
# to be used in Cow::Dashboard, e.g.
__PACKAGE__->mk_classdata('location' => '/');

# $APP/lib/www by default
__PACKAGE__->mk_classdata('document_root' => Akar::Base->app_home('lib/www'));
{
    my $document_root = __PACKAGE__->document_root;
    -e $document_root or mkpath $document_root; 
}

__PACKAGE__->load_config;

sub build_cli {
    my ($this) = @_;

    my $cli = Akar::CLI->new( { 'title' => 'Apache for Catalyst application control' } );

    # Command line interface
    $cli->add_action(
        'restart - Stops the apache, wait until its PID disappear and start it again',
        sub {
            my ($script_call) = @_;
            $this->restart_apache($script_call);
        }
    );
    $cli->add_action(
        'start - Starts the apache',
        sub {
            my ($script_call) = @_;
            $this->start_apache($script_call);
        }
    );
    $cli->add_action(
        'stop - Stops the apache',
        sub {
            my ($script_call) = @_;
            $this->stop_apache($script_call);
        }
    );
    $cli->add_action(
        'show - displays the current configuration (port, dispatched modules, ...)',
        sub {
            my ($script_call) = @_;
            $this->show_config($script_call);
        }
    );
    $cli->add_option(
        'X - runs the Apache on foreground (as with httpd -X)', 
    );

    return $cli;
}

sub run {
    my $this = shift;
    return $this->build_cli->run(@_);
}

sub run_application {
    my $class       = shift;
    my $application = shift;
    return $class->new( { 'application' => $application } )->run(@_);
}

sub logpath {
    my ( $this, $log_filename ) = @_;

    my $log_subdir = 'logs';
    return $this->app_data_path( @_ == 1
        ? $log_subdir
        : File::Spec->catfile( $log_subdir, $log_filename ) );
}

# configuration file
sub apache_config_file { return shift()->app_data_path('httpd.conf'); }

# returns file where PID is stored
sub pid_file { return shift()->logpath('httpd.pid'); }

sub install_apache_config {
    my ($this) = @_;

    mkpath( $this->logpath );
    print STDERR "... installing $E{ $this->apache_config_file } (from $E{ $this->httpd_conf_template }) ...";
    write_file( $this->apache_config_file, $this->httpd_conf);
    print " OK\n";
    return;
}

sub httpd_conf {
    my ($this) = @_;

    # processes the template by the Mason
    my $httpd_conf;
    eval {
        $httpd_conf = $this->process_mason($this->httpd_conf_template, $this);
    };
    die sprintf "Processing of the Mason httpd template '%s' failed: %s\n",
        $this->httpd_conf_template, $@
        if $@;
    return $httpd_conf;
} 

# returns the body of the apache config file
sub start_apache {
    my ( $this, $script_call ) = @_;

    $this->install_apache_config;

    my $apache_pid = $this->apache_pid;
    !$apache_pid
        or croak "$0 start: httpd (pid $apache_pid) already running\n";

    my $foreground = $script_call->value_of('X');
    my $httpd = join ' ', $this->apache_binary, '-f',
        $this->apache_config_file, ( $foreground ? '-X' : () );
 
    my $ok; 
    if ($foreground){   
        exec($httpd);
    } 
    else {
        $ok = system($httpd ) == 0;
    }
    # with proper exec this part won't be reached
    $ok or croak "$0 start: httpd could not be started\n";
    warn "$0 start: httpd started\n";
}

sub stop_apache {
    my ($this) = @_;

    my $apache_pid = $this->apache_pid
        or croak "$0 stop: httpd not running\n";

    kill 'TERM', $apache_pid
        or croak "$0 stop: httpd could not be stopped\n";

    warn "TERM signal sent to httpd\n";
}

sub apache_pid {
    my ($this) = @_;

    return if !-f $this->pid_file;

    my $apache_pid = 0 + FileHandle->new( $this->pid_file )->getline();

    # Process with the PID exists?
    return $apache_pid if kill 0, $apache_pid;
    return;
}

sub restart_apache {
    my ($this, $script_call) = @_;

    if ( my $apache_pid = $this->apache_pid ) {
        $this->stop_apache;
        $this->wait_until_apache_dies($apache_pid);
    }
    $this->start_apache($script_call);
}

sub wait_until_apache_dies {
    require Time::HiRes;

    my ( $this, $apache_pid ) = @_;

    # waiting for until process really dies
    my $total_sleep = 0;
    my $max_total_sleep
        = int( $this->apache_death_timeout * 1e6 );    # in microseconds
                                                       # starts the wait with
    my $sleep      = int( $this->apache_death_start_wait * 1e6 );
    my $last_sleep = 0;

    print STDERR "waiting until Apache process disappears ";
EXITED: {
        while ( $total_sleep <= $max_total_sleep ) {
            print STDERR '.';
            kill 0, $apache_pid or last EXITED;
            Time::HiRes::usleep($sleep);
            $total_sleep += $sleep;

          # fibonacci number - I heard that they are good for repetitive tries
            my $new_sleep = $sleep + ( $last_sleep || $sleep );
            $last_sleep = $sleep;
            $sleep      = $new_sleep;
        }
        croak " Failure\n".
            "Even after $max_total_sleep microseconds the Apache hasn't stopped\n ";
    }

    print STDERR " OK\n"; # terminating dot lines
}

sub uses_ssl {
    my ($this) = @_;

    return $this->ssl_port >= 0;
}

# to differentiate from server
sub application_subname { return 'apache'; }

# processes template via HTML::Mason, returns the buffer
my $interp;
sub process_mason {
    my ($this, $template, @args) = @_;

    $interp ||= HTML::Mason::Interp->new(
        'comp_root' => Akar::Base->app_home('lib/mason'), );

    my $comp = $interp->make_component('comp_file' => $template);

    my $buffer;
    $interp->out_method( \$buffer );
    $interp->exec($comp, @args);
    return $buffer;
}

1;


# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
