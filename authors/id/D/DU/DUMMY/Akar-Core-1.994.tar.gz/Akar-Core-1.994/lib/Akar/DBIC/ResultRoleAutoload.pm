package Akar::DBIC::ResultRoleAutoload;
{
  $Akar::DBIC::ResultRoleAutoload::VERSION = '1.994';
}
use MooseX::Role::Parameterized;

use Path::Class;
# If the consumer is OCP::Schema::Result::PProduct 
# looks whether there is a file OCP::Schema::ResultRole::PProduct
# and loads the role

parameter role_namespace => (
    is      => 'ro',
    default => 'ResultRole',
);

# I don't know how to add methods to $p object
my $class_exists = sub {
    my ( $this, $class ) = @_;

    return grep { -f file( $_, join( '/', split /::/, $class ) . '.pm' ); } @INC;
};

role {
    my $p        = shift;
    my %args     = @_;
    my $consumer = $args{consumer} or return;

    # consumer is meta
    my $role_class = $consumer->name;
    my $role_namespace = $p->role_namespace;
    $role_class =~ s/(?<=::)Result(?=::)/$role_namespace/
        or die "Unexpected result class $role_class"; # a bit hardcoded

    method complete_schema => sub {};

    return if !$p->$class_exists($role_class);
    with $role_class;
};

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 


