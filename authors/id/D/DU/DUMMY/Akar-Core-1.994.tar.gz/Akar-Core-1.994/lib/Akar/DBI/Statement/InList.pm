package Akar::DBI::Statement::InList;
{
  $Akar::DBI::Statement::InList::VERSION = '1.994';
}
use strict;
use warnings;

# list of values to be used in in_operator
use base qw(Akar::DBI::Statement::NonInterpolated);
use overload 
    '@{}' => sub { shift()->_values_accessor },
    'fallback' => 1;

use Akar::DBI::Statement qw(sql_param);

__PACKAGE__->mk_ro_accessors(qw(values));

sub _build {
    my ( $this, $param_callback ) = @_;

    return '('
        . join( ', ',
        map { sql_param($_)->_build($param_callback); }
            @{ $this->values } )
        . ')';
}

sub replace_param { return 0 }

sub has_param { return 0 }

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
