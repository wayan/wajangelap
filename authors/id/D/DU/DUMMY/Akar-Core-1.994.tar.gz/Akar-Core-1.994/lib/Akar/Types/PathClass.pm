package Akar::Types::PathClass;
{
  $Akar::Types::PathClass::VERSION = '1.994';
}
use Moose ();
use Moose::Exporter;

use Path::Class;

Moose::Exporter->setup_import_methods( as_is => [ 'dir_type', 'file_type' ] );

# utilities (dir_type, file_type) generating Moose types constraints based on
# Path::Class::File and Path::Class::Dir classes 
# with another properties set

sub dir_type  { return Akar::Types::PathClass::Dir->new(@_)->type; }

sub file_type { return Akar::Types::PathClass::File->new(@_)->type; }


# utility types
{
    package Akar::Types::PathClass::Path;
{
  $Akar::Types::PathClass::Path::VERSION = '1.994';
}
    use Moose::Role;
    use namespace::autoclean;

    use Moose::Util::TypeConstraints;    

    # base type (Path::Class::Dir or Path::Class::File)
    requires 'base_type';

    has type => (is => 'ro', lazy_build => 1);

    # the path must exists
    has must_exists => ( is => 'ro', );

    # path must be absolute
    has is_absolute => ( is => 'ro', );
 
    # base dir for absolute path
    has base => ( is => 'ro', predicate => 'has_base' );

    # generated type
    sub _build_type {
        my $this = shift;
        my $type = subtype as 'Object', where { $this->check_path(@_); },
            message { $this->get_message(@_) || $this->no_coerce_message(@_); };
        coerce $type, from 'Object|Str', via { $this->coerce_path(@_) };
        return $type;
    }

    sub check_path {
        my $this = shift;
        return !$this->get_message(@_);
    }

    sub get_message {
        my $this = shift;

        # message is called again on original path (it may be string)
        my $v =  $this->_get_message( $this->coerce_to_obj(@_) );
        return $v;
    }

    # when everyting seems ok, the proble may be with coerce => 1 not set
    sub no_coerce_message {
        my ( $this, $val ) = @_;

        return
            "Can't find the error, value '$val' seems ok. Do you have coerce => 1 set for your attribute?";
    }

    sub _get_message {

        # path is object now
        my ( $this, $path ) = @_;

        # this condition is pretty useless
        return 'Not a ' . $this->base_type . ' instance'
            if !$path->isa( $this->base_type );

        return "Path $path doesnot exist" if $this->must_exists && !-e $path;

        return "Path $path is not absolute"
            if $this->is_absolute && !$path->is_absolute;

        return;
    }

    sub coerce_to_obj {
        my ( $this, $path ) = @_;

        return blessed($path)
            && $path->isa( $this->base_type )
            ? $path
            : $this->base_type->new("$path");
    }

    sub coerce_path {
        my $this = shift;
        my $path = $this->coerce_to_obj(@_);

        if ( $this->is_absolute && !$path->is_absolute ) {
            $path = $path->absolute( ( $this->has_base ? $this->base : () ) );
        }

        return $path;
    }
}

{

    package Akar::Types::PathClass::File;
{
  $Akar::Types::PathClass::File::VERSION = '1.994';
}
    use Moose;
    use namespace::autoclean;

    with 'Akar::Types::PathClass::Path';

    # directory of the file must exists 
    has dir_exists => ( is => 'ro' );

    # directory has to be created
    has create_dir => ( is => 'ro' );

    sub base_type { return 'Path::Class::File' }

    around _get_message => sub {
        my $orig = shift;
        my $message = $orig->(@_);
        return $message if $message;

        my ( $this, $file ) = @_;
        return 'The directory not exists'
            if !-d $file->dir && ( $this->dir_exists || $this->create_dir );

        return;
    };

    around coerce_path => sub {
        my $orig = shift;
        my $file = $orig->(@_);

        my ($this) = @_;
        $file->dir->mkpath if $this->create_dir && !-d $file->dir;
        return $file;
    };

    __PACKAGE__->meta->make_immutable;
}

{

    package Akar::Types::PathClass::Dir;
{
  $Akar::Types::PathClass::Dir::VERSION = '1.994';
}
    use Moose;
    use namespace::autoclean;

    with 'Akar::Types::PathClass::Path';

    # directory is created if not exists
    has mkpath => ( is => 'ro' );

    around BUILDARGS => sub {
        my $orig = shift;
        my $fields = $orig->(@_);
        $fields->{must_exists} ||= $fields->{mkpath};
        return $fields;
    };


    around coerce_path => sub {
        my $orig = shift;
        my $dir = $orig->(@_);

        my ( $this ) = @_;
        $dir->mkpath if $this->mkpath && !-d $dir;
        return $dir;
    };

    sub base_type { return 'Path::Class::Dir'; };
    
    __PACKAGE__->meta->make_immutable;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
