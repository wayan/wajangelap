package Akar::XML::Compile::Schema::XsiType;
{
  $Akar::XML::Compile::Schema::XsiType::VERSION = '1.994';
}
use Moose::Role;

use XML::Compile::Util qw(pack_type unpack_type);

my $XMLSCHEMA_NS = 'http://www.w3.org/2001/XMLSchema';

# hash
# base_type => [extended_type1, extended_type2, .... ]
has xsi_type => (
    is      => 'rw',
    isa     => 'HashRef[ArrayRef]',
    lazy    => 1,
    default => sub { {} },
);

# zpracovani xsi, nechci to davat do Akar::XML::Compile::Schema
around importDefinitions => sub {
    my $orig = shift;
    my $this = shift;

    my @schemas = $this->$orig(@_);
    $this->extract_xsi_type($_) for @schemas;
    return @schemas;
};

sub _get_fullname {
    my ( $this, $qname, $node ) = @_;

    $qname or return;

    my ( $prefix, $basename ) = split /:/, $qname;
    my $ns = $node->lookupNamespaceURI($prefix)
        or return;
    return pack_type( $ns, $basename );
}

sub extract_xsi_type {
    my ( $this, $schema) = @_;

    my $schema_elem = $schema->schema;

    my $target_namespace = $schema_elem->getAttribute('targetNamespace');
    for my $type ( $schema_elem->findnodes('*[local-name() = "complexType"]') ) {
        for my $base_attr (
            $type->findnodes('*/*[local-name() = "extension"]/@base') )
        {
            my $base_fullname
                = $this->_get_fullname( $base_attr->getValue, $base_attr )
                or next;

            # 2013-05-16 danielr
            # cela tahle vec je pochybna, ale dokud ji pouzivam, 
            # alespon nepovolim zakladni XMLSchema typy jako base type
            next if (unpack_type($base_fullname))[0] eq $XMLSCHEMA_NS;

            my $extended_fullname
                = pack_type( $target_namespace, $type->getAttribute('name') );

            push @{ $this->xsi_type->{$base_fullname} },
                $extended_fullname;
        }
    }
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
