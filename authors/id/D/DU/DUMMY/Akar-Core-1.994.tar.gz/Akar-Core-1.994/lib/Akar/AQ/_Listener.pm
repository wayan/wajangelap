package Akar::AQ::_Listener;
{
  $Akar::AQ::_Listener::VERSION = '1.994';
}
use strict;
use warnings;


use Carp qw(carp croak);

use base qw(Class::DBI Akar::AQ::Dbize);
use Akar::DBI::Statement qw(sql_param sql sql_param_inout sql_and sql_join);
use Interpolation 'E' => 'eval', 'sqlp' => sub { return sql_param(@_) };

__PACKAGE__->table('akar.aq_listener');
__PACKAGE__->sequence('akar.aq_daemon_seq');
__PACKAGE__->set_sql( 'Nextval', 'SELECT %s.NEXTVAL from DUAL' );

# database fields
__PACKAGE__->columns( 'Primary' => 'id' );
__PACKAGE__->columns(
    'Essential' => qw(queue_table 
       hostname pid usessionid started)
);

# returns 1 if the listener usessionid is the same as id of existing session
sub is_alive {
    my ($this) = @_;

    return 0 if ! $this->usessionid;

    my $is_alive;
    my $is_alive_sqlp = sql_param_inout( \$is_alive, 20 );
    $this->db_Main->do(<<"END_PSQL");
        BEGIN
            if DBMS_SESSION.IS_SESSION_ALIVE($sqlp{ $this->usessionid}) then
                $is_alive_sqlp := 1;
            else 
                $is_alive_sqlp := 0;
            end if;
        END;
END_PSQL
    return $is_alive;
}

# the name to use in dbms_aq operations
sub agent_name {
    my ($this) = @_;
    return 'l'. $this->id;
}

1;

__END__

=head1 NAME

Akar::AQController::Queue - ORM on sys.all_queues

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

