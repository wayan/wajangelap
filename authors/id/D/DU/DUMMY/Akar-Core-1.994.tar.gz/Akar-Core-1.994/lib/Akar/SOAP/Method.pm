package Akar::SOAP::Method;
{
  $Akar::SOAP::Method::VERSION = '1.994';
}
# $Id: Method.pm,v 1.2 2006/03/31 12:02:43 danielr Exp $

=head1 NAME

Akar::SOAP::Method - declaration of SOAP methods to be published via WSDL

=head1 SYNOPSIS

  package Durian::SAPI::Phone::Statement;

  use Akar::SOAP::Method;

  ...
  Akar::SOAP::Method->new('process_statement')
    ->doc('receives request for statement to be processed')    
    ->params([
        Akar::SOAP::Param
            ->new('statementRequest')
               ->doc('selection of calls to be included to statement'), 
        ])
    ->output_params([
        Akar::SOAP::Param
            ->new('statementId')
            ->type('xsd:integer')
               ->doc('id of statement for later identification') 
        ])
    ->body(
  sub { 
    my $this = shift;
    my $request = Akar::SOAP::Method
        ->current_method
        ->param_value('statementRequest');
        ....
  });

=head1 DESCRIPTION

Via Akar::SOAP::Method you can add little information to your Perl subroutine,
so its containing package can be published via WSDL as a SOAP service.

It also wraps the method to provide some logging, parameter count check 
and accessing method parameters by name.

=head1 METHODS

=over 4

=item new 

  Akar::SOAP::Method->new($name, $key1=>$value1, $key2=>$value2, ...)

Constructor.

=item current_method

  Akar::SOAP::Method->current_method 

Returns method currently being called.

=item param_value(NAME)

  my($statementRequest) = Akar::SOAP::Method
      ->current_method 
      ->param_value('statementRequest');
  my($p1, $p2) = Akar::SOAP::Method
      ->current_method 
      ->param_value(qw(p1 p2));

Returns the value of input parameter. Works in scalar and list contexts.  

=back

The other methods work like setter-getters. They are

=over 4

=item params

List (array reference) of input parameters, instances of 
Akar::SOAP::Param. Empty list by default.

=item output_params

List (array reference) of output parameters, instances of Akar::SOAP::Param. 
Default is list with one string parameter.

=item doc

=item documentation

Function documentation. Propagated directly to WSDL.

=item body

The code of the function. Reference to subroutine.

=back

=head1 AUTHOR 

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

use strict;

use base qw(Class::Accessor);

use File::Path qw(mkpath);
use File::Basename qw(dirname);
use Akar::SOAP::Service;
use Akar::SOAP::Headers;
use Akar::Time;

__PACKAGE__->mk_accessors(qw(name package params output_params
  body documentation log_level 
  current_method
  current_params
  current_som
  auto_headers));
sub set { my $this = shift; $this->SUPER::set(@_); $this } 
sub doc { shift()->documentation(@_) } # synonym

# method actually being called
our($current_method);
sub current_method { $current_method; }

sub new {
    my $proto  = shift;
    my %fields = ('name' => @_);

    my $package = $fields{'package'} ||= caller;
    $fields{'params'}                ||= [];
    $fields{'output_params'}         ||= [ Akar::SOAP::Param->new('defaultReturn') ];
    $fields{'log_level'}             ||= 10;
    for ($fields{'auto_headers'}){
        defined($_) or $_ = 1;
    }

    my $this = $proto->SUPER::new(\%fields);
    # wrapped body body
    no strict 'refs';
    *{$package . '::'. $this->name} = sub{ $this->wrapper(@_) };

    # Register method with service
    Akar::SOAP::Service
        ->get_by_package($package, 1)
        ->add_method($this);
    $this;
}

sub current_params {
    my $this = shift;
    $this = $this->current_method unless ref($this);
    $this->_current_params_accessor(@_);
}

sub current_som {
    my $this = shift;
    $this = $this->current_method unless ref($this);
    $this->_current_som_accessor(@_);
}

sub wrapper {
    my $this = shift;

    # 2004-07-12 danielr - the processing inside this wrapper
    # should be probably done inside ->handle method 
    # but I don't want to change SOAP::Server::handle
    my $package = shift;
    local $current_method = $this;
    local @Akar::SOAP::Headers::Objects = @Akar::SOAP::Headers::Objects;
    local @$this{qw(current_params current_som)};

    # called via SOAP - last parameter is the deserialized request
    if (UNIVERSAL::isa($_[-1], 'SOAP::SOM')){
        my $som = pop(@_);
        $this->current_som($som);
        Akar::SOAP::Headers->process_som($som) if $this->auto_headers;
    }
    $this->current_params(\@_);
    $this->log_call if $this->log_level <= $this->Log_level;

    # parameter count check
    @{$this->params} == @_ 
    or die sprintf("Number of params doesn't match (requested %s, got %s)\n ",
        scalar(@{$this->params}), scalar(@_));

    return(&{$this->body}($package, @_));
}

sub _param_value {
    my $this = shift;
    my($name) = @_;

    my $index = 0;
    for (@{$this->params}){
        last if $_->name eq $name;
        $index++;
    } 
    
    $index < @{$this->params}
    or die sprintf("Method %s has no param %s\n", $this->name, $name);

    my $params = $this->current_params
    or die sprintf("Method %s is not currently being called\n ", $this->name);

    $$params[$index];
}

sub param_value {
    my $this  = shift;
    return(wantarray 
        ? map($this->_param_value($_), @_)
        : $this->_param_value(@_));
}

sub set_param {
    my $this = shift;
    my($k, $v) = @_;

    my $param = $$this{'params_hash'}{$k} or die "No param $k\n ";
    $param->is_out or die "Param $k is not output param\n ";
    $param->set_value($v);    
}

# system level of debugging
sub Log_level {
    my $this = shift;

    my $Log_level = $ENV{'AKAR_SOAP_LOG_LEVEL'};
    return(defined($Log_level)? $Log_level: 10);
}

sub log_file {
    my $this = shift;

    my $log_file = Akar::Script->app_data('log/soap-methods/'. $this->package. '.log');
    mkpath(dirname($log_file));
    return($log_file);
}

use Data::Dumper;
sub log_call {
    my $this = shift;

    my $log_file = $this->log_file;
    open(W, ">> $log_file") or die "Can't open $log_file for write: $!\n ";
    printf W "%s: %s - client %s\n%s(\n%s)\n\n",
        $$, Akar::Time->new->text,
        # 2004-07-27 danielr - volam-li metodu bez SOAPu, neni pritomen Apache
        do {
            my $request = eval {Apache->request};
            $@? 'LOCAL (NO SOAP)': $request->connection->remote_ip;
        },
        $this->name, 
        do {
            # hash of values
            my %hr  = map {
                ($_->name => $this->param_value($_->name));
            } @{$this->params}; 
            local $Data::Dumper::Pad = '    ';
            Dumper(\%hr) =~ /^.*?\{.*?\n(.*)\}/s
        };
    close(W);
}

1;
