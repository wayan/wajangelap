package Akar::Iconv;
{
  $Akar::Iconv::VERSION = '1.994';
}

=head1 NAME

Akar::Iconv - encoding conversions based on Perl encode, decode 
	(used to be based on Text::Iconv)

=head1 SYNOPSIS

  use Akar::Iconv qw(cp1250_il2 utf8_cp1250);

  my $ils = cp1250_il2($from_win);

  my $coder = Akar::Iconv->convertor($encoding1, $encoding2);
  my $str2 = &$coder($str1);

=head1 DESCRIPTION

Akar::Iconv is simple envelope based on perl Encode::encode, Encode::decode functions.
Its main purposed is to export conversion functions for the combinations of
iso-8859-2, cp1250, utf-8 encodings.

=head1 Methods

=over 4

=item convertor

  my $convertor = Akar::Iconv->convertor($enc1, $enc2);

  my $converted = &$convertor($str);

Returns callback function converting string from encoding $enc1 to $enc2.
The callback uses Encode::encode, Encode::decode iternally. 
All utf8 strings are returned as character utf8 (with wide characters).

=back

=head1 Exported functions 

utf8_il2, utf8_cp1250, cp1250_il2, il2_utf8, il2_cp1250, cp1250_utf8 conversion functions
with predictable meaning are exported on demand.

There are also 
utf8_il2_struct, utf8_cp1250_struct, cp1250_il2_struct, il2_utf8_struct, il2_cp1250_struct, cp1250_utf8_struct 
conversion functions which can recode structure (hash, array, even nested).
Although they return value, they modify the structure in place.

=over 4

=item utf8_as_chars

  utf8_as_chars($byte_or_char_utf8);

Returns character based UTF8 string.

=item utf8_as_bytes

  utf8_as_bytes($byte_or_char_utf8);

Return byte (octet) based UTF8 string.

=back

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsgroup.cz>

=cut

use strict;
use vars qw(@ISA @EXPORT_OK);

@ISA     = qw(Exporter);

@EXPORT_OK = qw(utf8_as_bytes utf8_as_chars);

require Exporter;
use Encode;
use Scalar::Util qw(reftype refaddr);

# exported are all combinations of utf-8, iso-8859-2 and cp1250
sub _czenc {
	my($from, $to) = @_;
	
    my $func        = $from . '_' . $to;
    my $func_struct = $func . '_struct';
    my $convertor = __PACKAGE__->convertor(
        map { /il2/ ? 'iso-8859-2' : /utf8/ ? 'utf-8' : /cp1250/ ? $_ : '' }
            $from,
        $to
    );

	push @EXPORT_OK, $func, $func_struct;
	no strict 'refs';
	*$func = $convertor;
    *$func_struct = sub { return _convert_struct($convertor, @_); };
}

for (['il2', 'utf8'], ['il2', 'cp1250'], ['cp1250', 'utf8']){
	_czenc(@$_);
	_czenc(reverse(@$_));
}


# uzaverove procedury
my %_closures;


sub convertor {
	my $this = shift;
	my($from, $to) = @_;

	my $sub = $_closures{"$from $to"} ||= 
		($from =~ /^utf-?8$/i && $to =~ /^utf-?8$/i) ? 
			sub {
				return($_[0]);
			}:
		($from =~ /^utf-?8$/i) ? 
			sub {
				my($str) = @_;
				return($str) unless defined($str);

				return(Encode::encode($to, 
					Encode::is_utf8($str)? $str: decode('utf-8', $str)));
			}:
		($to =~ /^utf-?8$/i) ? 
			sub {
				my($str) = @_;
				return($str) unless defined($str);

				return(Encode::decode($from, $str));
			}:
		# from utf8
			sub {
				my($str) = @_;
				return($str) unless defined($str);

				my $code = Encode::from_to($str, $from, $to);
				die "Invalid conversion $from => $to\n "
					unless(defined($code));
				return($str);
			};
	return($sub);
}

sub utf8_as_chars {
    return Encode::is_utf8($_[0])? $_[0]: Encode::decode('utf8', $_[0]);
}

sub utf8_as_bytes {
    return Encode::is_utf8($_[0])? Encode::encode('utf8', $_[0]): $_[0];
}

sub _convert_struct {
    my $convertor = shift;
    ref $_[0] or die "_struct convertor can be run on struct only\n ";

    my ($convert, %seen);
    $convert = sub {
        my $struct = shift;
        return if $seen{refaddr $struct}++;

        my $type = reftype $struct;
        if ($type eq 'HASH'){
            # I have to convert keys also 
            %$struct = map {
                ref $_? do { $convert->($_); $_ }: $convertor->($_)
            } %$struct;
        }
        elsif ($type eq 'ARRAY'){
            @$struct = map {
                ref $_? do { $convert->($_); $_ }: $convertor->($_)
            } @$struct;
        }
        else {
            die "Unknown reftype $type";
        }
    };
    $convert->(@_);
    return $_[0];
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 

