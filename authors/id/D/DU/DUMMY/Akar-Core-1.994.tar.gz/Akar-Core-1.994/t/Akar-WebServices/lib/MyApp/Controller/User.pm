package MyApp::Controller::User;
use Moose;

BEGIN { extends 'Akar::WebServices::Controller::REST' }

# imaginary user controller
sub search : Chained('base'): ActionClass('REST') {
    my ( $this, $c ) = @_;

}

sub search_GET: WRITER('searchResult'){
    my ($this, $c) = @_;

    $this->status_ok(
        $c,
        entity => {
            users => [ qw(wayan made nyoman ketut) ],
        },
    );
}

sub add: Chained('base'): ActionClass('REST') {
}

sub add_PUT: READER('addUser'): WRITER('Types:commonResponse'){
    my ($this, $c) = @_;

    $this->status_ok(
        $c, 
        entity => {
            dtExecuted => '2013-01-28T12:22:21',
            entityId => '2345678',
        }
    );
}


1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
