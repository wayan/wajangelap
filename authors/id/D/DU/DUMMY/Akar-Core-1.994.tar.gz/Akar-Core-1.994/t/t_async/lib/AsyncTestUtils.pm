package AsyncTestUtils;
use strict;
use warnings;

use Exporter 'import';

our @EXPORT = qw(qadd qflush sample_process);

my @queue;
sub qadd {
    my @ar = (@_, 0);
    my $i = @queue;
    $i-- while $i && $queue[$i - 1][1] > $ar[1];
    splice @queue, $i, 0, \@ar;
}

sub qflush {
    while (my $ar = shift @queue){
        $ar->[0]();
    }
}

# normalized test process
# returns list ( \@callbacks, $finish)
sub sample_process {
    my ( $ar, %opts) = @_;

    my $cb = ref $ar eq 'CODE'? $ar: sub { push @$ar, @_ };
    my $failed = $opts{failed} || 0;
    my $prefix = $opts{prefix} || '';
    my $processes = $opts{processes} || {}; 
    my $priorities = $opts{priorities} || {};

    if ( $prefix ){
        my $o = $cb;
        $cb = sub { my $f = shift; $o->( "$prefix$f", @_ ) };
    }
    my @cbs = map {
        my $n = $_;
        $processes->{$n}
            || sub {
            my $next = pop();
            $cb->( "c$n" => [@_] );
            qadd(
                sub {
                    $cb->( "r$n" => [@_] );
                    $next->(
                        $n == $failed
                        ? ("e$n")
                        : ( undef, $prefix. "p$n" )
                    );
                },

                # first callback is queued as least prior
                $priorities->{$n} // ( $n == 1 ? 2 : 1 )
            );
            };
    } 1 .. 3;
    return ( \@cbs, sub { $cb->( f => [@_] ); } );
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
