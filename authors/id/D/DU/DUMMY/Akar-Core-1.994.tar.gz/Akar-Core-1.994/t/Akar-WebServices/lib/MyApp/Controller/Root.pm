package MyApp::Controller::Root;
use Moose;

BEGIN { extends 'Akar::WebServices::Controller::REST::Root' }

__PACKAGE__->config->{namespace} = '';

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
