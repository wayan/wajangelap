package MyApp::Controller::User::Ninja;
use Moose;

BEGIN { extends 'Akar::WebServices::Controller::REST' }

# controller for specialized users
sub index : Chained('base'): PathPart(''): Args(0) {
    my ( $this, $c ) = @_;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
