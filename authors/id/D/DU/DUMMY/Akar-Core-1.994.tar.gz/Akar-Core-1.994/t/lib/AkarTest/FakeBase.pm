package AkarTest::FakeBase;
use strict;
use warnings;

use File::Temp qw(tempdir);

# fakes Akar::Base::Config
$INC{'Akar/Base/Config.pm'} = __FILE__;

my $tempdir = tempdir( CLEANUP => 1 );
*Akar::Base::akar_root = sub { return $tempdir; };
*Akar::Base::is_global = sub { return 0 };

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
