package MyApp;
use Moose;
use namespace::autoclean;
use Catalyst ();
extends 'Catalyst';

use Akar::XML::Compile::Schema;

my $app = __PACKAGE__;
$app->config( name => 'MyApp' );
# building schema
my  $schema = Akar::XML::Compile::Schema->new;
$schema->importDefinitions(user_xsd_schema());
$schema->importDefinitions(types_xsd_schema());
$app->config( 'Controller::Root' => { xml_compile_schema => $schema, } );
$app->setup;

sub user_xsd_schema {
    return <<'END_SCHEMA';
<?xml version="1.0" encoding="UTF-8"?>
<xs:schema 
	xmlns:xs="http://www.w3.org/2001/XMLSchema" 
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:tns="http://akar.davosro.cz/REST/User" 
	targetNamespace="http://akar.davosro.cz/REST/User" 
	elementFormDefault="qualified">

<!-- -->
  <xs:element name="searchResult">
    <xs:complexType>
      <xs:sequence>
	    <xs:element name="users" type="xs:string" minOccurs="1" maxOccurs="unbounded"/>
      </xs:sequence>
    </xs:complexType>
  </xs:element>

  <xs:element name="addUser">
    <xs:complexType>
      <xs:sequence>
	    <xs:element name="name" type="xs:string" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
<!-- -->
</xs:schema>
END_SCHEMA
}

sub types_xsd_schema {
    return <<'END_SCHEMA';
<?xml version="1.0" encoding="UTF-8"?>
<xs:schema 
	xmlns:xs="http://www.w3.org/2001/XMLSchema" 
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:tns="http://akar.davosro.cz/REST/Types" 
	targetNamespace="http://akar.davosro.cz/REST/Types" 
	elementFormDefault="qualified">

<!-- -->
  <xs:element name="commonResponse">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="dtExecuted" type="xs:dateTime"/>
        <xs:element name="entityId" type="xs:unsignedLong" minOccurs="0"/>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
<!-- -->
</xs:schema>
END_SCHEMA
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
