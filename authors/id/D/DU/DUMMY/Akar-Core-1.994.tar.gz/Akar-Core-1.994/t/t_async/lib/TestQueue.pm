package TestQueue;
use strict;
use warnings;

use Exporter 'import';

our @EXPORT = qw(qadd qflush);

my @queue;
sub qadd {
    my @ar = (@_, 0);
    my $i = @queue;
    $i-- while $i && $queue[$i - 1][1] > $ar[1];
    splice @queue, $i, 0, \@ar;
}

sub qflush {
    while (my $ar = shift @queue){
        $ar->[0]();
    }
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
