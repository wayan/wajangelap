package Akar::Test::Routine::Test::Note;
{
  $Akar::Test::Routine::Test::Note::VERSION = '1.978';
}
use Moose::Role;

# atribute note pro test
has note => (
    is      => 'ro',
    isa     => 'Str',
    lazy    => 1,
    default => sub { return $_[0]->name },
);

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 


