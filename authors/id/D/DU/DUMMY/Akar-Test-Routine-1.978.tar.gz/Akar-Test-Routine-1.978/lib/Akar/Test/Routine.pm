package Akar::Test::Routine;
{
  $Akar::Test::Routine::VERSION = '1.978';
}
use Moose::Exporter;

# ABSTRACT: Test::Routine with counting tests

use Moose::Util ();
use Test::Routine ();
use Test::Routine::Compositor ();
use Test::Routine::Runner ();
use Test::More;

Moose::Util::apply_all_roles( 'Test::Routine::Test',
    'Akar::Test::Routine::Test::Note',
);

Moose::Exporter->setup_import_methods(
    also  => 'Test::Routine',
    as_is => ['run_with_plan'],
);


my $runner_class     = 'Test::Routine::Runner';
my $compositor_class = 'Test::Routine::Compositor';

sub run_with_plan {
    my $caller = caller;

    my $builder
        = $compositor_class->instance_builder( $caller, undef );

    my $self = $runner_class->new(
        {   description   => '',
            instance_from => $builder,
        }
    );

    my $thing = $self->test_instance;

    my @tests
        = grep { Moose::Util::does_role( $_, 'Test::Routine::Test::Role' ) }
        $thing->meta->get_all_methods;

  # As a side note, I wonder whether there is any way to format the code below
  # to not look stupid. -- rjbs, 2010-09-28
    my @ordered_tests = sort {
               $a->_origin->{file} cmp $b->_origin->{file}
            || $a->_origin->{nth} <=> $b->_origin->{nth}
    } @tests;

    Test::More::plan( tests => scalar(@tests) );

    for my $test (@ordered_tests) {
        note ( "\n" .  ('-' x 80) . "\n");
        note ($test->note);
        $self->test_instance->run_test($test);
        $self->clear_test_instance if $self->fresh_instance;
    }
}

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 

