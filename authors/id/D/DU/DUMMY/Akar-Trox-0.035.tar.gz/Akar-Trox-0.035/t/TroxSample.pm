package t::TroxSample;
use OX;

use namespace::autoclean;

use Path::Class;

# simple Trox application for tests
with 'Akar::Trox::App' => {
    use_xml_schemas         => 1,
    exception_factory_class => 't::TroxSample::ExceptionFactory',
    xml_schema_files =>
        [ 'TroxSample/Types.xsd', 'TroxSample/Customer.xsd', ],
};

# one controller via Bread::Board::Declare
has customers => (
    is => 'ro',
    isa => 't::TroxSample::Controller::Customer',
    dependencies => [ qw(schema) ],
);

use Bread::Board;

sub BUILD {
    my $this = shift;

    container $this => as {
        service schema => (
            class => 't::TroxSample::Schema',
        );
    };

return;

    # one controller via "ordinary" Bread::Board
    container $this => as {
        service services => (
            class => 't::Trox::Controller::Service',
        );
    };
}

sub _build_xml_schemas_dir {
    return dir(file(__FILE__)->parent->parent, 'xsd');
};

router ['Akar::Trox::RouteBuilder::ControllerMethod'] => as {
    route 'customer/:id'             => 'customers.customer';
    route 'customer/:id/add_service' => 'customers.add_service';
    #route 'service/:id'              => 'services.service';
    #route 'service/:id/disable'      => 'services.enable';
};


# handling link elements

after configure_xml_schemas => sub {
    my ($this, $schemas) = @_;

    # writer hook which converts
    # { self=>$url1, ...} into [ {rel="self", url=$url1}, ... ]
    $schemas->addHook(
        {   before => sub {
                return $_[0] if @_ == 2;    # 2 args => reader hook

                my ( $doc, $data, $elem ) = @_;
                my $links = ref $data eq 'HASH' && $data->{link};
                if ( $links && ref($links) eq 'HASH' && $links->{self} ) {
                    $data->{link} = [
                        map {
                            my $v    = $links->{$_};
                            my %link = (
                                ( ref $v ? %$v : ( url => $v ) ),
                                rel => $_
                            );
                            \%link;
                            }
                            keys %$links
                    ];
                }
                return $data;
                }
        }
    );

    # reader hook which converts
    # [ {rel="self", url=$url1}, ... ] into
    # { self=>$url1, ...} into
    $schemas->addHook(
        {   after => sub {
                return $_[1] if @_ == 4;    # 4 args => writer hook
                     # my ($doc, $elem, $path, $data) = @_; # writer hook

                my ( $elem, $data, $path ) = @_;    # reader hook

                my $links = ref $data eq 'HASH' && $data->{link};
                if (   $links
                    && ref($links) eq 'ARRAY'
                    && @$links
                    && $links->[0]{rel} )
                {
                    $data->{link}
                        = { map { ( $_->{rel} => $_->{url} ); } @$links };
                }
                return $data;
                }
        }
    );
};

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
