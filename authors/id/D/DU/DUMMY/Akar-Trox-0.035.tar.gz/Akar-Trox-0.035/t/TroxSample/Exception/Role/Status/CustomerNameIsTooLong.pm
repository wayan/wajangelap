package t::TroxSample::Exception::Role::Status::CustomerNameIsTooLong;
use Moose::Role;

with 'Akar::Trox::ExceptionBuilder' => {
    http_status_code => 'BadRequest',
};

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
