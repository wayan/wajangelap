package t::TroxSample::Namespaces;
use strict;
use warnings;

use XML::Compile::Util qw(pack_type);
use Exporter 'import';

our @EXPORT;

sub _define_ns {
    my ( $name, $namespace ) = @_;

    no strict 'refs';
    *{"NS_$name"} = sub { return $namespace };
    *{"ELEM_$name"} = sub {
        my $localname = shift;
        return pack_type( $namespace, $localname );
    };
    push @EXPORT, "NS_$name", "ELEM_$name";
}

_define_ns( "Customer" => "http://troxsample.davosro.cz/Customer");
_define_ns( "Service" => "http://troxsample.davosro.cz/Service");


1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
