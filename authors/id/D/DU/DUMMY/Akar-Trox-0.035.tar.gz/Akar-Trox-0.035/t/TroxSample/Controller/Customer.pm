package t::TroxSample::Controller::Customer;
use Moose;

use t::TroxSample::Namespaces;

has schema => ( is => 'ro', required => 1, );

has rs => (
    is      => 'rw',
    lazy    => 1,
    default => sub {
        return shift()->schema->resultset('Customer');
    },
    handles => [ qw(find) ],
);

sub require_entity {
    my ( $this, $c, $customer_id ) = @_;

    my $customer = $this->find($customer_id)
        or $c->throw( CustomerNotFound => {} );
    return $customer;
}

sub customer_GET {
    my ( $this, $c, $customer_id ) = @_;

    my $customer = $this->require_entity($c, $customer_id);
    return $this->status_ok(
        $this->get_entity( $c, $customer ),
        xml_element => ELEM_Customer('customer'),
    );
}

sub customer_PUT {
    my ( $this, $c, $customer_id ) = @_;

    my $data = $c->get_data( xml_element => ELEM_Customer('customer') );
    my $name = $data->{name};
    length($name) < 15 or $c->throw(CustomerNameIsTooLong=>{});

    my $customer = $this->find($customer_id);
    if ($customer) {
        $customer->update($data);
    }
    else {
        $customer = $this->rs->create( { id => $customer_id, %$data } );
    }
    return $c->status_created(
        $this->get_entity( $c, $customer ),
        xml_element => ELEM_Customer('customer'),
    );
}

sub get_entity {
    my ( $this, $c, $customer ) = @_;

    return {
        id     => $customer->id,
        name   => $customer->name,
        'link' => {
            self => $c->uf(
                { name => 'customers.customer', id => $customer->id }
            ),
            add_service => $c->uf(
                { name => 'customers.add_service', id => $customer->id }
            ),
        },
    };
}

sub add_service {} 

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
