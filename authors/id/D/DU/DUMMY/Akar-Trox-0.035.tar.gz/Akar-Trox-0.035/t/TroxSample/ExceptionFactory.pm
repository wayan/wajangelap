package t::TroxSample::ExceptionFactory;
use Moose;

use namespace::autoclean;

extends 'Akar::Trox::ExceptionFactory';

sub BUILD {
    my $this = shift;

    $this->add_roles_for_ident( CustomerNameIsTooLong =>
            't::TroxSample::Exception::Role::Status::CustomerNameIsTooLong' );
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
