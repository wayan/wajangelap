package t::TroxSample::Schema;
use Moose;

has data =>
    ( is => 'ro', isa => 'HashRef', required => 1, default => sub { {} } );

sub resultset {
    my ( $this, $name ) = @_;

    my $data = $this->data->{$name} ||= {};
    return t::TroxSample::Schema::ResultSet->new(
        schema       => $this,
        data         => $data,
        result_class => __PACKAGE__ . '::Result::' . $name,
    );
}

# pseudodatabase
package t::TroxSample::Schema::ResultSet;
use Moose;

has data => (
    is      => 'ro',
    isa     => 'HashRef',
    required => 1,
    traits  => ['Hash'],
    handles => { '_find' => 'get', '_add' => 'set' }
);

has result_class => ( is       => 'ro', required => 1, isa => 'ClassName');
has schema => (is => 'ro', required =>1, weak_ref => 1);

sub new_result {
    my ($this, $fields) = @_;
    return $this->result_class->new(data => $fields, schema =>$this->schema);
}

sub find {
    my ( $this, $pk ) = @_;
    my $fields = $this->_find($pk) or return;

    return $this->new_result($fields);
}

sub create {
    my ( $this, $fields ) = @_;

    $this->_add($fields->{id}, $fields);
    return $this->new_result($fields);
}

package t::TroxSample::Schema::Result;
use Moose;

has data => ( is => 'ro', required => 1, isa => 'HashRef', );

has schema => (is => 'ro', required =>1, weak_ref => 1);

sub update {    
    my ($this, $fields) = @_;

    $fields ||= {};
    my $data = $this->data;
    %$data = (%$data, %$fields);
}

my $columns = sub {
    my $caller = caller();
    for my $col (@_){
        no strict 'refs';
        *{$caller . '::'. $col } = sub {
            my $this = shift;   
            return @_?
                do { $this->data->{$col} = shift() }:
                $this->data->{$col};
        };
    }
};
$columns->('id');

package t::TroxSample::Schema::Result::Customer;
use Moose;

extends 't::TroxSample::Schema::Result';
$columns->('name');


package t::TroxSample::Schema::Result::Service;
use Moose;

extends 't::TroxSample::Schema::Result';
$columns->('customer_id');
$columns->('state');


1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
