package Akar::Trox::RouteBuilder::ControllerMethod;
{
  $Akar::Trox::RouteBuilder::ControllerMethod::VERSION = '0.035';
}
use Moose;
use namespace::autoclean;

with 'OX::RouteBuilder';

use Try::Tiny;

sub allowed_methods {
    return qw(GET POST PUT DELETE);
}

sub compile_routes {
    my ( $this, $app ) = @_;

    my $spec = $this->route_spec;

    # controller is resolved eagerly
    my $controller = try {
        $app->resolve( service => $spec->{controller} );
    }
    catch {
        die "Can't resolve controller '$spec->{controller}': $_";
    };

    my $action = $spec->{action};
    my @methods
        = ( $action, map { $action . '_' . $_ } $this->allowed_methods );
    grep { $controller->can($_) } @methods
        or die "Controller '$spec->{controller}' has none of methods "
        . join( ', ', @methods );

    my $target = sub {
        my ( $req, @args ) = @_;

        # we try search_GET then search
        my $specific = join( '_', $action, uc $req->method );
        return
              $controller->can($specific) ? $controller->$specific(@_)
            : $controller->can($action)   ? $controller->$action(@_)
            :   [ 405, [], ["Method not allowed"] ];
    };

    my ( $defaults, $validations )
        = $this->extract_defaults_and_validations( $this->params );

    return {
        path        => $this->path,
        defaults    => { %$spec, %$defaults },
        target      => $target,
        validations => $validations,
    };
}

sub parse_action_spec {
    my ($class, $action_spec) = @_;

    return if ref($action_spec);
    return unless $action_spec =~ /^(\w+)\.(\w+)$/;

    return {
        controller => $1,
        action     => $2,
        name       => $action_spec,
    };
}

__PACKAGE__->meta->make_immutable;

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
