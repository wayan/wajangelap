package Akar::Trox::ExceptionBuilder;
{
  $Akar::Trox::ExceptionBuilder::VERSION = '0.035';
}
use MooseX::Role::Parameterized;

#use MooseX::StrictConstructor ();

# helper for throwable classes 

# coderef serializing the additional fields as key => value list 
parameter hash_fields => (
    is  => 'ro',
    isa => 'CodeRef',
);

# http_status_code as name
parameter http_status_code => ( required => 1, );

parameter code => ();

#MooseX::StrictConstructor->import( { into => __PACKAGE__->meta->parameters_metaclass } );

role {
    my ( $p, %args ) = @_;

    my $code
        = $p->code
        || (
        $args{consumer} ? ( split /::/, $args{consumer}->name )[-1] : undef )
        or die "Can't determine code for a class";

    method code => sub {$code};

    with 'HTTP::Throwable::Role::Status::' . $p->http_status_code;
    if ( my $hash_fields = $p->hash_fields ) {
        around as_hash => sub {
            my ($orig, $this) = @_;
            return { %{$this->$orig}, $this->$hash_fields };
        };
    }
};

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 


