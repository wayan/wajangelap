package Akar::Trox::Request::JSONData;
{
  $Akar::Trox::Request::JSONData::VERSION = '0.035';
}
use Moose::Role;

use JSON (); # no imports

has json => (
    is         => 'rw',
    lazy_build => 1,
);

has json_pretty => (
    is         => 'rw',
    lazy_build => 1,
);

sub json_content_types { return 'application/json' }

around default_content_types => sub {
    my $orig = shift;
    my ($this) = @_;
    return ( $orig->(@_), $this->json_content_types );
};

sub _build_json {
    return JSON->new;
}

sub _build_json_pretty {
    my $this = shift;
    $this->_build_json->pretty;
}

sub encode_json {
    my $this = shift;
    return $this->json->encode(@_); 
}

around deserialize_from => sub {
    my $orig = shift;
    my $this = shift;
    my $content_type = shift;
    grep { $content_type eq $_ } $this->json_content_types
        or return $this->$orig($content_type, @_);

    my $json    = $this->json;
    my $content = $this->content;

    # using eval here not try tiny because 
    # because Throwable role uses $@ in previous_exception
    my $entity = eval { $json->decode($content); }
        or $this->throw( MalformedJSON => {} );
    return $entity;
};

around serialize_into => sub {
    my $orig         = shift;
    my $this         = shift;
    my $content_type = shift;
    grep { $content_type eq $_ } $this->json_content_types
        or return $orig->( $this, $content_type, @_ );

    my ( $serialized_ref, $entity ) = @_;
    my $json
        = $this->header('X-PrettyPrint') ? $this->json_pretty : $this->json;
    $$serialized_ref = eval { $json->encode($entity); }
        or $this->throw( JSONEncodeFailed => {} );
    return 1;
};

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
