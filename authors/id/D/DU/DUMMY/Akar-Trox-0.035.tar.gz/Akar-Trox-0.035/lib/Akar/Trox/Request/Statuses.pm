package Akar::Trox::Request::Statuses;
{
  $Akar::Trox::Request::Statuses::VERSION = '0.035';
}
use Moose::Role;

requires 'serialize', 'new_response';

my $extract_headers = sub {
    my %args = @_;
    return $args{headers} ? @{ $args{headers} } : ();
};

# 2013-11-05 danielr
# what should I return?
# a triplet
# OX::Response
# something where the entity is also stored?
sub _controller_response {
    my ($this, $triplet) = @_;

    return $triplet;
    # return $this->new_response($triplet);
}

sub status_ok {
    my $this   = shift;
    my $entity = shift;
    my ( $content_type, $body ) = $this->serialize( $entity, @_ );

    return $this->_controller_response(
        [   200, [ 'Content-Type' => $content_type, $extract_headers->(@_) ],
            [$body]
        ]
    );
}

sub status_no_content {
    my $this = shift;

    return $this->_controller_response( [ 204, [ $extract_headers->(@_) ], [] ] );
}

sub status_created {
    my $this   = shift;
    my $entity = shift;

    if ( defined $entity ) {
        my ( $content_type, $body ) = $this->serialize( $entity, @_ );
        return $this->_controller_response(
            [   201,
                [ 'Content-Type' => $content_type, $extract_headers->(@_) ],
                [$body]
            ]
        );
    }
    else {
        return $this->_controller_response( [ 201, [ $extract_headers->(@_) ], [] ] );
    }
}

sub status_not_modified {
    my $this = shift;

    return $this->_controller_response( [ 304, [ $extract_headers->(@_) ], [] ] );
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
