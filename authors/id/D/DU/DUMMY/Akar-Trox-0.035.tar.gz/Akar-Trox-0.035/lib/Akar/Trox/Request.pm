package Akar::Trox::Request;
{
  $Akar::Trox::Request::VERSION = '0.035';
}
use Moose;

use Try::Tiny;
use Akar::Trox::ExceptionFactory;
use Scope::Guard qw(guard); 
use List::MoreUtils qw(uniq);
use Data::Uniqid qw(uniqid);

extends 'OX::Request';

has exception_factory => (
    is   => 'ro',
    lazy => 1,

    # !! default factory knows only Akar::Trox exceptions
    default => sub { Akar::Trox::ExceptionFactory->new },
    handles => [qw(new_exception)]
);


# what to do when the exception is thrown
# inside exception serialization ?
has _serializing_exception => (
    is       => 'rw',
#    init_arg => undef,
);

# content type which the application can process
sub default_content_types { return (); }

sub build_exception {
    my $this = shift;

    my $in_exc = sub { $this->_serializing_exception(@_) };

    # what to do when the exception is thrown
    # inside exception serialization ?
    if ( $in_exc->() ) {
        my $errorid = uniqid();
        $this->env->{'psgi.errors'}->print(
            "Error '$errorid' occured when exception serialization:"
                . join( ' ', @_ ) . "\n"
        );
        $this->throw_raw(
            InternalServerError => {
                message => "Internal error occured, reference num '$errorid'"
            }
        );
    }

    my $exception = $this->new_exception(@_);

    # we preset the exception serialization either to json
    # or to XML
    try {
        $in_exc->(1);
        $this->serialize_exception($exception);
    }
    catch {
        # what to do when exception is serialized
        # warn $_;
        } finally {
        $in_exc->(0);
        };
    return $exception;
}

sub throw {
    my $this =  shift;
    $this->build_exception(@_)->throw;
}


sub pretty_print {
    my $this = shift;
    return $this->header('X-PrettyPrint');
}

# serialization, deserialization
#
# deserialization - in roles
sub get_data {
    my $this = shift;

    my $content_type = $this->content_type
        or $this->throw(
        NoContentType => { message => 'Empty Content-Type header', } );

    $content_type =~ s/;.*//;
    return $this->deserialize_from( $content_type, $this->content, @_ );
}

sub deserialize_from {
    my ( $this, $content_type ) = @_;

    # throws error without serialization
    $this->new_exception( UnknownContentType =>
            { message => "Unrecognized Content-Type $content_type", } )
        ->throw;
}

sub serialize {
    my $this = shift;

    my @content_types
        = $this->select_content_type( [ $this->default_content_types ] );
    my $serialized;
    for my $content_type (@content_types) {
        # 2013-07-08 danielr
        # hardcoded
        # quickfix, there has to be charset in response
        return ( join( '; ', $content_type, 'charset=utf-8' ), $serialized )
            if $this->serialize_into( $content_type, \$serialized, @_ );
    }

    # this exception cannot undergo the default serialization
    $this->new_exception( EntityNotSerializable => {} )->throw;
}

sub serialize_into { return; }

# serializes the exception into JSON or XML according to request
# presets the exception body and body_headers 
sub serialize_exception {
    my $this      = shift;
    my $exception = shift;

    my ( $content_type, $body ) = $this->serialize(
        $exception->as_hash,
        (   $exception->can('xml_element')
            ? ( xml_element => $exception->xml_element )
            : ()
        )
    ) or return;

    $exception->preset_body($body);
    $exception->preset_body_headers(
        [   'Content-Type'   => $content_type,
            'Content-Length' => length $body
        ]
    );
}

# OX::Request produces only path
sub abs_uri_for { 
    my $this = shift;
    my $path  = $this->uri_for(@_);
    my $uri = $this->base_uri;
    $uri->path("$path");
    return $uri;
}

sub uf {
    my $this = shift;
    return ''. $this->uri_for(@_);
}

# working with content_type
# sort the Accept headers
sub parse_accept {
    my $this = shift;
    return map { $_->[0]; }
        sort   { $b->[1] <=> $a->[1]; }
        map {
        s/\s//g;
        my $q = s/;q=(.*)// ? $1 : 1;
        [ $_, $q ];
        }
        map { split /,/, $_; } $this->header('Accept');
}

# select appropriate content type(s) from the list of provided 
sub select_content_type {
    my ( $this, $provided ) = @_;

    my @res;
    if ( my $content_type = $this->content_type ) {
        $content_type =~ s/;.*//;

        push @res, $content_type if grep { $content_type eq $_ } @$provided;
    }


    for my $accepted ( $this->parse_accept ) {
    MIME: for my $content_type (@$provided) {
            if ( $content_type eq $accepted ) {
                push @res, $content_type;
                last MIME;
            }
            elsif ( $accepted =~ /\*/ ) {
                my ( $p1, $p2 ) = split /\//, $accepted;
                my ( $r1, $r2 ) = split /\//, $content_type;
                if (   ( $p1 eq '*' || $p1 eq $r1 )
                    && ( $p2 eq '*' || $p2 eq $r2 ) )
                {
                    push @res, $content_type;
                }
            }
        }
    }
    return wantarray ? uniq @res : $res[0];
}
    

# content_type is derived from header first 
# and also from content_type query parameter
around content_type => sub {
    my $orig = shift;
    my $this = shift;

    $this->$orig || $this->query_parameters->{'content-type'};
};

__PACKAGE__->meta->make_immutable;

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
