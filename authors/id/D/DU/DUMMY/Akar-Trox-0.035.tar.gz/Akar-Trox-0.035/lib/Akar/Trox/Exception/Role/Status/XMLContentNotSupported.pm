package Akar::Trox::Exception::Role::Status::XMLContentNotSupported;
{
  $Akar::Trox::Exception::Role::Status::XMLContentNotSupported::VERSION = '0.035';
}
use Moose::Role;

with 'HTTP::Throwable::Role::Status::UnsupportedMediaType';

no Moose::Role; 1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
