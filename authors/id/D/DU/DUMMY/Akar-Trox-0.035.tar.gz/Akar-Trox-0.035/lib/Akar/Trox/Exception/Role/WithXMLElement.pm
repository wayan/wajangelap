package Akar::Trox::Exception::Role::WithXMLElement;
{
  $Akar::Trox::Exception::Role::WithXMLElement::VERSION = '0.035';
}
use Moose::Role;

# only the attribute determining how to serialize it into XML

use XML::Compile::Util qw(pack_type);

# {namespace}localname
has xml_element => (
    is      => 'ro',
    builder => 'default_xml_element',
);

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

