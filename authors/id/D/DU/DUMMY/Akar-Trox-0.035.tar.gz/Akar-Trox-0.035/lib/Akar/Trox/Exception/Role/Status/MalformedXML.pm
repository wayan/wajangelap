package Akar::Trox::Exception::Role::Status::MalformedXML;
{
  $Akar::Trox::Exception::Role::Status::MalformedXML::VERSION = '0.035';
}
use Moose::Role;

with 'HTTP::Throwable::Role::Status::BadRequest';

no Moose::Role; 1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
