package Akar::Trox::HTTPThrowable::Factory;
{
  $Akar::Trox::HTTPThrowable::Factory::VERSION = '0.035';
}
use Moose;

extends 'HTTP::Throwable::Factory';

around roles_for_ident => sub {
    my $orig = shift;
    return ($orig->(@_), 'Akar::Trox::HTTPThrowable::InternalError');
};

http::URLNotFound

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
