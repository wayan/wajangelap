package Akar::Trox::Action;
{
  $Akar::Trox::Action::VERSION = '0.035';
}
use Moose;

use Scalar::Util qw(blessed);
use JSON;

has json => (
    is         => 'ro',
    lazy_build => 1,
);

has xml_reader => (
    is        => 'rw',
    predicate => 'can_read_xml',
    isa       => 'CodeRef',
);

has xml_writer => (
    is        => 'rw',
    isa       => 'CodeRef',
    predicate => 'can_write_xml',
);

has xml_parser => (
    is      => 'ro',
    default => sub { XML::LibXML->new }
);

use XML::LibXML;

# returns deserialized data
sub get_data {
    my ( $this, $req, %args ) = @_;

    if ( $req->content_type =~ /json/ ) {
        return $this->json->decode( $req->content );
    }
    elsif ( $req->content_type =~ /xml/ ) {
        my $doc        = $this->xml_parser->parse_string( $req->content );
        my $xml_reader = $this->xml_schemas->reader( $args{element} );
        return $this->xml_reader->($doc);
    }
}

sub status_ok {
    my ($this, $req, %args) = @_;

    if ($args{entity}){
    }
}

sub _build_json {
    return JSON->new;
}

sub handle_response {
    my ( $this, $res, $req ) = @_;

    if ( ref $res && ref $res eq 'HASH' ) {
        return $this->serialize_response($res, $req);
    }

    return $res;
}

sub serialize_response {
    my ( $this, $res, $req ) = @_;

    if ($req->content_type =~ /json/){
        return $this->json->encode( $res );
    }
    elsif ($req->content_type =~ /xml/){
        my $doc = XML::LibXML::Document->new;
        my $elem = $this->xml_writer->($doc, $res );
        $doc->setDocumentElement($elem);
        return $doc->toString(0);
    }
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
