package Akar::Trox::ExceptionFactory;
{
  $Akar::Trox::ExceptionFactory::VERSION = '0.035';
}
use Moose;

# ABSTRACT: exception generator with explicit list of exceptions, JSON and XML Schema support

extends 'HTTP::Throwable::Factory';

has xml_schemas => (
    is      => 'rw',
    trigger => sub {
        my $this = shift;
        $this->init_xml_schemas(@_);
    }
);

has roles_for_ident => (
    is      => 'ro',
    isa     => 'HashRef',
    default => sub { {} },
    reader  => '_roles_for_ident',
);

# prebuilt classes
has class_for => (
    is      => 'ro',
    isa     => 'HashRef',
    default => sub { {} },
    reader  => '_class_for',
);

around roles_for_ident => sub {
    my ($orig, $this, $ident ) = @_;

    my $roles_for_ident = $this->_roles_for_ident->{$ident};
    return $roles_for_ident? @$roles_for_ident: $this->$orig($ident);
};

sub add_roles_for_ident {
    my ( $this, $ident, @roles ) = @_;

    $this->_roles_for_ident->{$ident} = \@roles;

    # builds the class
    $this->class_for($ident);
}

sub new_exception {
    my ( $this, $ident, $arg ) = @_;

    $arg ||= {};
    $arg->{code} ||= $ident;

    # ident is passed as code to constructor
    $this->class_for( $ident, $arg ) ->new( $arg );
}

sub throw {
    my ($this, $ident, $arg) = @_; 

    $arg ||= {};
    $arg->{code} ||= $ident;

    $this->class_for($ident, $arg)->throw($arg);
}


around class_for => sub {
    my ($orig, $this, $ident) = @_;

    # classes are prebuilt
    return $this->_class_for->{$ident} ||= $this->$orig($ident);
};

sub default_xml_element_role {
    return 'Akar::Trox::Exception::Role::DefaultXMLElement';
}

override extra_roles => sub {
    my $this = shift;
    return (
        # HTTP::Throwable::Role::TextBody 
        # is replaced by PresetBody
        'Akar::Trox::Exception::Role::PresetBody',
        'Akar::Trox::Exception::Role::WithXMLElement',
        'Akar::Trox::Exception::Role::AsHash',
        'Akar::Trox::Exception::Role::Code',
        $this->default_xml_element_role,
    );
};

sub init_xml_schemas {
    my ( $this, $xml_schemas ) = @_;
    my $path = __FILE__;
    $path =~ s/\.pm/\/schema.xsd/;
    $xml_schemas->importDefinitions($path);
}

sub BUILD {
    my $this = shift;

    for my $ident (
        'NoContentType',         'UnknownContentType',
        'MalformedJSON',         'XMLContentNotSupported',
        'MalformedXML',          'XMLElementMismatch',
        'NoXMLReader',           'XMLReaderFailed',
        'EntityNotSerializable', 'NoXMLWriter',
        'XMLWriterFailed',       'JSONEncodeFailed',
        'UnprocessableEntity',   'InvalidFields',
        'TooManyRequests',       'PreconditionFailed',
        'Unauthorized',          'InternalServerError',
        'EntityNotFound',
        )
    {
        $this->add_roles_for_ident( $ident,
            "Akar::Trox::Exception::Role::Status::$ident" );
    }
}

__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

