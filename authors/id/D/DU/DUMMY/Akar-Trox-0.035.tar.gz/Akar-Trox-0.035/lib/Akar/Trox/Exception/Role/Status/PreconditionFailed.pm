package Akar::Trox::Exception::Role::Status::PreconditionFailed;
{
  $Akar::Trox::Exception::Role::Status::PreconditionFailed::VERSION = '0.035';
}
use Moose::Role;

with 'HTTP::Throwable::Role::Status::PreconditionFailed';

no Moose::Role; 1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
