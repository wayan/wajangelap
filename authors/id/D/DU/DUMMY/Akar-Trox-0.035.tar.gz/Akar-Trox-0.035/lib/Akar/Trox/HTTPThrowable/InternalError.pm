package Akar::Trox::HTTPThrowable::InternalError;
{
  $Akar::Trox::HTTPThrowable::InternalError::VERSION = '0.035';
}
use Moose::Role;

# role which allow the original (parser, ...) error to be stored 
# in HTTP::Throwable exceptions

has internal_error => ( is => 'ro', );

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
