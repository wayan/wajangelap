package Akar::Trox::Request::Async;
{
  $Akar::Trox::Request::Async::VERSION = '0.035';
}
use Moose::Role;

# stored responder
has responder => (
    is      => 'rw',
    isa     => 'CodeRef',
    clearer => 'clear_responder',
);

sub respond {
    my $this = shift;

    # we respond only once
    my $responder = $this->responder or return;
    $this->clear_responder;
    $responder->(@_);
    return;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
