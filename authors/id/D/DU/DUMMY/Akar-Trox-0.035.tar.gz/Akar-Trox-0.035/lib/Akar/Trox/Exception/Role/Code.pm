package Akar::Trox::Exception::Role::Code;
{
  $Akar::Trox::Exception::Role::Code::VERSION = '0.035';
}
use Moose::Role;

has code => (is => 'ro', required => 1);

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
