package Akar::Trox;
{
  $Akar::Trox::VERSION = '0.035';
}
use strict;
use warnings;

# ABSTRACT: Simple REST for Akar using OX from CPAN

1;

=head1 NAME

Akar::Trox - tiny REST via OX

=cut

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:


