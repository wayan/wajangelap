package Akar::Trox::App;
{
  $Akar::Trox::App::VERSION = '0.035';
}
use MooseX::Role::Parameterized;

use strict;
use warnings;

use Akar::Trox::Request;
use JSON;
use Path::Class;
use Akar::Base;
use Class::Load;

parameter use_xml_schemas => ( required => 1, );

parameter use_hal_links => ( required => 0 );

parameter exception_factory_class =>
    ( default => 'Akar::Trox::ExceptionFactory' );

parameter xml_schema_files => ( isa => 'ArrayRef', default => sub { [] } );

# if the application is async, responder is stored in request
# and inside target it is expected to call $c->respond($c->status_ok(...))
# for example
parameter async => ( default => 0 );

use Bread::Board;

role {
    my $p = shift;

    my $use_xml_schemas = $p->use_xml_schemas;
    Class::Load::load_class( $p->exception_factory_class );

    method request_base_class => sub { return 'Akar::Trox::Request' };

    method request_roles => sub {
        return [
            'Akar::Trox::Request::JSONData',
            ( $use_xml_schemas ? ('Akar::Trox::Request::XMLData') : () ),
            'Akar::Trox::Request::Statuses',

            # request is not asynchronous but it can have the responder
            ( $p->async ? ('Akar::Trox::Request::Async') : () ),
        ];
    };

    has request_class => (
        is       => 'ro',
        required => 1,
        default  => sub {
            my $this = shift;
            return Moose::Meta::Class->create_anon_class(
                superclasses => [ $this->request_base_class ],
                roles        => $this->request_roles,
                cache        => 1,
            )->name;
        }
    );

    if ( $p->async ) {

        # unfortunately I can't get into app_from_router,
        # so I have to copy app_from_router from
        # package OX::Application::Role::Router::Path::Router;
        # and change the lines in target_to_app
        override app_from_router => sub {
            my $self = shift;
            my ($router) = @_;

            return Plack::App::Path::Router::Custom->new(
                router      => $router,
                new_request => sub {
                    $self->new_request(@_);
                },
                target_to_app => sub {
                    my ($target) = @_;
                    my $app
                        = blessed($target)
                        && $target->can('to_app')
                        ? $target->to_app
                        : $target;
                    return sub {
                        my ( $req, @args ) = @_;
                        return sub {

                            # storing the responder in request object
                            my $responder = shift;
                            $req->responder($responder);
                            $app->( $req, @args );
                            return;
                        };
                    };
                },
                handle_response => sub {
                    $self->handle_response(@_);
                },
            )->to_app;
        };
    }

    if ($use_xml_schemas) {
        after BUILD => sub {
            my $this = shift;
            container $this => as {
                service xml_schemas => (
                    block => sub {
                        my $s = shift;
                        my $xml_schemas
                            = $s->class->new( allow_undeclared => 1 );
                        $s->parent->configure_xml_schemas($xml_schemas);
                        return $xml_schemas;
                    },
                    class     => 'XML::Compile::Cache',
                    lifecycle => 'Singleton',
                );
            };
        };

        has xml_schemas_dir => (
            is         => 'rw',
            lazy_build => 1,
        );

        # list of schema files
        has xml_schema_files => (
            is      => 'rw',
            default => sub { return $p->xml_schema_files; }
        );

        method _build_xml_schemas_dir =>
            sub { return dir( Akar::Base->app_home, 'lib', 'xsd' ) };

        method configure_xml_schemas => sub {
            my ( $this, $schemas ) = @_;

            for my $file ( @{ $this->xml_schema_files } ) {
                my $path = file($file)->absolute( $this->xml_schemas_dir );
                -f $path && -r $path
                    or die "Schema file '$path' doesnot exist";
                $schemas->importDefinitions($path);
            }
        };

        if ( $p->use_hal_links ) {
            with 'Akar::Trox::App::XMLSchemas::HALLinksHooks';
        }
    }

    method new_request => sub {
        my ( $this, $env ) = @_;

        return $this->request_class->new(
            env               => $env,
            exception_factory => $this->fetch('exception_factory')->get,
            (   $use_xml_schemas
                ? ( xml_schemas => $this->fetch('xml_schemas')->get )
                : ()
            ),
        );
    };

    after BUILD => sub {
        my $this = shift;
        container $this => sub {
            service exception_factory => (
                block => sub {
                    my $s                 = shift;
                    my $exception_factory = $s->class->new( $s->params );
                    $s->parent->configure_exception_factory(
                        $exception_factory);
                    return $exception_factory;
                },
                lifecycle    => 'Singleton',
                class        => $p->exception_factory_class,
                dependencies => {
                    (   $use_xml_schemas
                        ? ( xml_schemas => 'xml_schemas' )
                        : ()
                    )
                }
            );
        };
    };
    method configure_exception_factory => sub { };

    around handle_response => sub {
        my $orig = shift;
        my ( $this, $res, $req ) = @_;

        # normal interface
        return $orig->(@_) if not( ref $res && ref $res eq 'CODE' );

        # delayed interface, handle_response is propagated inside
        return sub {
            my $respond = shift();
            $res->(
                sub {
                    my $res = shift;
                    $respond->( $this->$orig( $res, $req ) );
                }
            );
        };
    };

    # 2013-05-31 danielr
    # I have to keep reference to the root container
    # otherwise it is released and all services
    # other than in and below the OX contai disaappear
    around build_app => sub {
        my $orig = shift;
        my $this = shift;
        my $app  = $this->$orig(@_);
        my $root = $this->get_root_container;
        return sub {
            $root if 0;    # I need only to close the $root reference in code
            return $app->(@_);
        };
    };
};

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

