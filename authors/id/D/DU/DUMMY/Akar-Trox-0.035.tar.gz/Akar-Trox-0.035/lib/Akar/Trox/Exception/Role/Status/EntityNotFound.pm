package Akar::Trox::Exception::Role::Status::EntityNotFound;
{
  $Akar::Trox::Exception::Role::Status::EntityNotFound::VERSION = '0.035';
}
use Moose::Role;

# to be used in application also, when it has no customized exception

with 'HTTP::Throwable::Role::Status::NotFound';

no Moose::Role; 1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
