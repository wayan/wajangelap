package Akar::Trox::Exception::Role::PresetBody;
{
  $Akar::Trox::Exception::Role::PresetBody::VERSION = '0.035';
}
use Moose::Role;

# the body and body_headers can be preset at construction 
# time

# the request can decide whether the body is constructed
# as JSON or XML or text

has preset_body => ( is => 'rw', clearer => 'clear_preset_body');

has preset_body_headers => (is => 'rw', isa => 'ArrayRef', clearer => 'clear_preset_body_headers');

requires 'text_body';

sub body { my $this = shift; return $this->preset_body || $this->text_body }

sub body_headers {
    my ( $this, $body ) = @_;

    return $this->preset_body_headers
        || [
        'Content-Type'   => 'text/plain',
        'Content-Length' => length $body,
        ];
}

sub as_string { $_[0]->body }

sub clear_presets {
    my $this = shift;
    $this->clear_preset_body;
    $this->clear_preset_body_headers;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 



