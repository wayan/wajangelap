package Akar::Trox::Request::XMLData;
{
  $Akar::Trox::Request::XMLData::VERSION = '0.035';
}
use Moose::Role;

use Try::Tiny;
use XML::Compile::Util qw(pack_type);
use XML::LibXML;

# serialization and deserialization of XML data by schema
has xml_parser => (
    is => 'ro',
    default => sub { XML::LibXML->new },
);

has xml_schemas => (
    is       => 'rw',
    required => 1,
);

sub xml_content_types { return 'text/xml' }

around default_content_types => sub {
    my $orig = shift;
    my ($this) = @_;
    return ( $orig->(@_), $this->xml_content_types );
};

sub accepts_xml {
    my $this = shift;

    my $accept = $this->header('accept') or return 1;
    return grep { $_ eq '*/*' || /xml/ } split /,/, $accept;
}

around get_data => sub {
    my $orig = shift;
    my $this = shift;

    my $content_type = $this->content_type;
    $content_type && $content_type =~ /xml/ or return $this->$orig(@_);

    my %args = @_;

    my $doc = eval { $this->xml_parser->parse_string( $this->content ); }
        or $this->throw( MalformedXML => {} );

    my $elem_got = pack_type(
        $doc->documentElement->namespaceURI,
        $doc->documentElement->localname
    );
    my $elem_expected = $args{xml_element} || $elem_got;
    $elem_got eq $elem_expected
        or $this->throw(
        XMLElementMismatch => {
            message =>
                "Different root element, got $elem_got, expected $elem_expected",
        }
        );

    # no reader means our mistake
    my $reader = eval { $this->xml_schemas->reader($elem_got) }
        or
        $this->throw( NoXMLReader => { message => 'No schema for element' } );

    my $ret = eval { $reader->($doc); }
        or $this->throw(
        XMLReaderFailed => { message => 'XML does not conform to schema' } );
    return $ret;
};

around deserialize_from => sub {
    my $orig = shift;
    my $this = shift;
    my $content_type = shift;
    grep { $content_type eq $_ } $this->xml_content_types
        or return $this->$orig($content_type, @_);

    my ( $content, %args) = @_;
    my $doc = eval { $this->xml_parser->parse_string( $this->content ); }
        or $this->throw( MalformedXML => {} );

    my $elem_got = pack_type(
        $doc->documentElement->namespaceURI,
        $doc->documentElement->localname
    );
    my $elem_expected = $args{xml_element} || $elem_got;
    $elem_got eq $elem_expected
        or $this->throw(
        XMLElementMismatch => {
            message =>
                "Different root element, got $elem_got, expected $elem_expected",
        }
        );

    # no reader means our mistake
    my $reader = eval { $this->xml_schemas->reader($elem_got) }
        or
        $this->throw( NoXMLReader => { message => 'No schema for element' } );

    my $entity = eval { $reader->($doc); }
        or $this->throw(
        XMLReaderFailed => { message => 'XML does not conform to schema' } );
    return $entity;
};

around serialize_into => sub {
    my $orig         = shift;
    my $this         = shift;
    my $content_type = shift;
    grep { $content_type eq $_ } $this->xml_content_types
        or return $orig->( $this, $content_type, @_ );

    # to serialize to XML we need to have xml_element

    my ( $serialized_ref, $entity, %args ) = @_;
    my $element = $args{xml_element} or return 0;

    my $writer = eval { $this->xml_schemas->writer($element); }
        or $this->throw( NoXMLWriter => {} );

    my $doc = XML::LibXML::Document->new;
    my $elem = eval { $writer->( $doc, $entity ) }
        or $this->throw( XMLWriterFailed => {} );
    $doc->setDocumentElement($elem);

    $$serialized_ref = $doc->toString( $this->pretty_print ? 1 : 0 );
    return 1;
};

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
