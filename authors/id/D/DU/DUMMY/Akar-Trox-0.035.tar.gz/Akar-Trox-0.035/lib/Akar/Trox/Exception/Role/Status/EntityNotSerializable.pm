package Akar::Trox::Exception::Role::Status::EntityNotSerializable;
{
  $Akar::Trox::Exception::Role::Status::EntityNotSerializable::VERSION = '0.035';
}
use Moose::Role;

with 'HTTP::Throwable::Role::Status::NotAcceptable';

no Moose::Role; 1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
