package Akar::Trox::Exception::Role::DefaultXMLElement;
{
  $Akar::Trox::Exception::Role::DefaultXMLElement::VERSION = '0.035';
}
use Moose::Role;

use XML::Compile::Util qw(pack_type);

# default xml element 
sub default_xml_element {
    return pack_type( 'http://davosro.cz/trox', 'exception' );
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 


