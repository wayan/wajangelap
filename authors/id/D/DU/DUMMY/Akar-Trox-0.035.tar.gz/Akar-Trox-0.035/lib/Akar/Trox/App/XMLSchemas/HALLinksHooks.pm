package Akar::Trox::App::XMLSchemas::HALLinksHooks;
{
  $Akar::Trox::App::XMLSchemas::HALLinksHooks::VERSION = '0.035';
}
use Moose::Role;

use namespace::autoclean;
use Try::Tiny;

# adds hooks to xmls_schema (via modification of configure_xml_schemas)
# which turn HAL format of hypertext links
#
# _links => {
#   self => {
#       href=>"http://that.is.me"
#   },
#   other => {
#       href=>"http://that.is.someone.else"
#   },
# }
#
# into format suitable for to XML conversion
#
# link => [
#   { rel => 'self', href=>"http://that.is.me"},
#   { rel => 'other', href=>"http://that.is.someone.else"},
# ]

my $is_hash = sub { return ref $_[0] && ref $_[0] eq 'HASH'; };

# from hal hash to link array - this is before writer hook 
# we write xml from hal
my $hal_to_ary = sub {
    my ( $doc, $data, $elem ) = @_;

    $is_hash->($data) && $is_hash->($data->{_links}) or return;

    my $links = delete $data->{_links};
    $data->{link}
        = [ map { { rel => $_, %{ $links->{$_} } }; } keys %$links ];
};

# from link array to hal format  - this is after reader hook
# we read xml, want hal but after xml is read we are given array
my $ary_to_hal = sub {
    my ( $elem, $data, $path ) = @_;    # reader hook

    $is_hash->($data) && $data->{link} or return;

    my $links = $data->{link};
    $data->{link}
        = { map { my %v = %$_; ( delete $v{rel} => \%v ); } @$links };
};

after configure_xml_schemas => sub {
    my ( $this, $schemas ) = @_;

    $schemas->addHook(
        {   before => sub {
                return $_[0] if @_ == 2;    # 2 args => reader hook

                $hal_to_ary->(@_);
                return $_[1];               # modified data
                }
        }
    );

    # reader hook which converts
    # [ {rel="self", url=$url1}, ... ] into
    # { self=>$url1, ...} into
    $schemas->addHook(
        {   after => sub {
                return $_[1] if @_ == 4;    # 4 args => writer hook
                $ary_to_hal->(@_);
                return $_[1];    # data
                }
        }
    );
};

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
