package Akar::Trox::Exception::Role::Status::TooManyRequests;
{
  $Akar::Trox::Exception::Role::Status::TooManyRequests::VERSION = '0.035';
}
use Moose::Role;

# There is no HTTP::Throwable::Role::Status::UnprocessableEntity (why?)
with 'HTTP::Throwable',
    'HTTP::Throwable::Role::BoringText';

# there is no HTTP::Throwable::Role::Status::TooManyRequests
sub default_status_code {429}
sub default_reason      {'Too many requests'}
sub code                { return 'InvalidFields'; }

no Moose::Role; 1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
