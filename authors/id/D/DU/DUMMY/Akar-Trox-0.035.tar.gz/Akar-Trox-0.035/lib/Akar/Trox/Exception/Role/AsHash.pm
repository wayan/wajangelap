package Akar::Trox::Exception::Role::AsHash;
{
  $Akar::Trox::Exception::Role::AsHash::VERSION = '0.035';
}
use Moose::Role;

use namespace::autoclean;

#requires 'code', 'status_code', 'reason', 'message';

# quick and dirty solution working for all current exceptions
# other classes have to use around
sub as_hash {
    my $this = shift;

    my %ret = (
        code => $this->code,
        map { ( $_ => $this->$_ ); }
            grep {$_} map { $_->reader || $_->accessor } $this->meta->get_all_attributes
    );

    # deleting "technical" attributes
    delete @ret{
        qw(previous_exception xml_element previous_exception
            preset_body_headers
            additional_headers preset_body)
    };
    return \%ret;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

