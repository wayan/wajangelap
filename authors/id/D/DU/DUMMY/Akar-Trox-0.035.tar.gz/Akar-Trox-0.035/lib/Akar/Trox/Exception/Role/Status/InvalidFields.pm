package Akar::Trox::Exception::Role::Status::InvalidFields;
{
  $Akar::Trox::Exception::Role::Status::InvalidFields::VERSION = '0.035';
}
use Moose::Role;

# There is no HTTP::Throwable::Role::Status::UnprocessableEntity (why?)
with 'HTTP::Throwable',
    'HTTP::Throwable::Role::BoringText';

sub default_status_code { 422 }
sub default_reason      { 'Unprocessable Entity' }
sub code { return 'InvalidFields'; }

has invalid_fields => (
    is       => 'ro',
    isa      => 'HashRef',
    required => 1,
);

no Moose::Role; 1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
