package Akar::Trox::Request::Serialize;
{
  $Akar::Trox::Request::Serialize::VERSION = '0.035';
}
use Moose::Role;




1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:



