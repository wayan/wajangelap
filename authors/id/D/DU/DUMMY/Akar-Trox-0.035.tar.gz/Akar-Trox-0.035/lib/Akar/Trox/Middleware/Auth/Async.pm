package Akar::Trox::Middleware::Auth::Async;
{
  $Akar::Trox::Middleware::Auth::Async::VERSION = '0.035';
}
use Moose::Role;

use Plack::Util;

# asynchronous authentication

# is set then authentication and the operation are performed
# simultaneously and if the request is not authenticated
# the possible return value is discarded
has parallel_get => ( is => 'rw', isa => 'Bool', default => 1 );

has app => (is => 'rw', isa => 'CodeRef', required => 1);

requires 'authenticate';

sub unauthorized {
    return [ 401, [ 'Content-Type' => 'text/plain' ], ['Unauthorized'] ];
}

sub wrapper {
    my ( $class, @args ) = @_;
    return sub { my $app = shift; $class->wrap( $app, @args ); };
}

sub wrap {
    my $class = shift;
    my $app   = shift;

    return $class->new( app => $app, @_ )->to_app;
}

sub to_app {
    my $this = shift;
    my $app  = $this->app;
    return sub {
        my $env = shift;
        my $parallel = $env->{REQUEST_METHOD} eq 'GET' && $this->parallel_get;

        return sub {
            my $respond = shift;
            my ( $authorized, $res );

            my $code = sub {
                $res = shift();
                $respond->($res) if $authorized;
            };
            my $call_app = sub {
                my $app_res = $app->($env);
                return ref $app_res eq 'ARRAY'
                    ? $code->($app_res)    # direct
                                           # delayed
                    : $app_res->($code);
            };
            $this->authenticate(
                $env,
                sub {
                    $authorized = shift;
                    return $respond->( $this->unauthorized ) if !$authorized;
                    return $respond->($res)                  if $res;
                    $call_app->()                            if !$parallel;
                }
            );
            $call_app->() if $parallel;
            }
    };
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
