package Akar::BreadBoard::LazyLoader::Placeholder;
{
  $Akar::BreadBoard::LazyLoader::Placeholder::VERSION = '1.981';
}
use Moose;

# the "placeholder" - the container holding "place" for the container built

extends 'Bread::Board::Container';

has builder => (
    is       => 'ro',
    required => 1,
    handles => {
        build_container => 'build_container',
    }
);

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
