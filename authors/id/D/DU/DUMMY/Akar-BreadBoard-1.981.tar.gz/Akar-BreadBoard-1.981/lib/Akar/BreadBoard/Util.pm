package Akar::BreadBoard::Util;
{
  $Akar::BreadBoard::Util::VERSION = '1.981';
}
use strict;
use warnings;

# BreadBoard utilities 
# they don't use Akar::BreadBoard classes, 
# so they can be used from them (Akar::BreadBoard::Service::Config)
#
# If you are not sure whether to use Akar::BreadBoard or Akar::BreadBoard::Util
# use Akar::BreadBoard

use Moose ();
use Moose::Exporter;
use Moose::Util;
use Scalar::Util qw(blessed);

Moose::Exporter->setup_import_methods(
    with_meta => [],
    as_is     => [

        # traversing
        'find_services',
        'resolve_services',
        'get_path_of',
    ],
);

# returns services (hash { PATH => SERVICE} )
# where condition holds true
sub find_services(&@) {
    return _find_services(@_);
}

sub _find_services {
    my ( $condition, $root ) = @_;

    my ( $f, %ret );
    $f = sub {
        my ( $container, $path ) = @_;
        for my $name ( $container->get_service_list ) {
            my $spath = $path ? "$path/$name" : $name;
            local $_ = my $service = $container->get_service($name);
            if ( $condition->( $spath => $service ) ) {
                $ret{$spath} = $service;
            }
        }
        for my $name ( $container->get_sub_container_list ) {
            $f->(
                $container->get_sub_container($name),
                $path ? "$path/$name" : $name,
            );
        }
    };

    $f->($root);

    # returns hashref
    return \%ret;
}

sub resolve_services(&@) {
    my $services = _find_services(@_);
    return { map { ( $_ => scalar $services->{$_}->get ); } keys %$services };
}

# returns the path of container or service
sub get_path_of {
    my $subject      = shift;
    my $include_root = shift // 1;    # the path includes the name of the root

    my @names;
    while($subject){
        unshift @names, $subject->name;
        $subject = $subject->parent;
    }
    $include_root or shift @names; # removing the root
    return join '/', @names;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
