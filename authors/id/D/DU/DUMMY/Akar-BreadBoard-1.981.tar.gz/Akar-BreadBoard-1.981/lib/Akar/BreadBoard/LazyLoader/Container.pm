package Akar::BreadBoard::LazyLoader::Container;
{
  $Akar::BreadBoard::LazyLoader::Container::VERSION = '1.981';
}
use Moose;

extends 'BreadBoard::Container';


