package Akar::BreadBoard::Builder;
{
  $Akar::BreadBoard::Builder::VERSION = '1.981';
}
use Moose;
use utf8;
use namespace::clean '-except' => [qw(import meta)];

# Akar::BreadBoard::Builder also works as an exporter
# inherited subclasses can import rs
# which is shortcut for Something::IOC->root->resolve(service => @ARGS)
use Sub::Exporter -setup => { exports => [ rs => \'_rs_generator', ] };

use Module::Find qw(useall);
use List::MoreUtils qw(uniq);
use Bread::Board ();
use Carp;
use Akar::BreadBoard::Container;

# I make the rs function available for subclasses (Durian::IOC)
# who wants to export other functions also
sub _rs_generator {
    my ( $class, $name ) = @_;
    my $used = 0;
    return sub {
        die << "NEXT_OCCURENCE" if $used++;
Function '$name' is shortcut only and can be used only once per file (use $class).
If you need access to more services you have to use:

use $class;

my \$root = $class->root;
my \$service1 = \$root->resolve(service => PATH1);
my \$service2 = \$root->resolve(service => PATH2);

NEXT_OCCURENCE
        return $class->root->resolve( service => @_ );
    };
}

# this is the crucial property
has root => (
    is         => 'ro',
    lazy_build => 1,
    handles => [ 'resolve' ]
);

# root can be called also on class
around root => sub {
    my $orig = shift;
    my $this = shift;
    return $orig->( blessed $this? $this : $this->new, @_ );
};

# builds a root container from module structure
has root_name => ( is => 'ro', default => 'Root', );

has default_class => (
    is      => 'ro',
    default => 'Akar::BreadBoard::Container',
);

# the roles to be applied to a class in hierarchy
has roles_for => (
    is      => 'ro',
    isa     => 'HashRef',
    default => sub { return {} },
);

# the class for a node in hierarchy
has class_for => (
    is      => 'ro',
    isa     => 'HashRef',
    traits  => ['Hash'],
    default => sub { return {} },
    handles => { get_class => 'get', add_class => 'set', }
);


around add_class => sub {
    my $orig = shift;

    my ( $this, $key, $class ) = @_;
    if ( $class->meta->isa('Moose::Meta::Role') ) {

        # class where to apply
        # new, simplified style - role Durian::IOC::Root::Rate
        # applied to Root/Rate
        my $apply_to = $key;
        if (0) {

            # old style - role Tupai::IOC::Root::Webdesign::Blaf
            # applied to /Root/Webdesign
            ($apply_to) = $this->_split_key($key)
                or die "Can't make role $class as root\n ";
        }
        push @{ $this->roles_for->{$apply_to} }, $class;
    }
    else {
        my $conflict = $this->get_class($key);
        croak "Class conflict for $key, classes "
            . $conflict . " and "
            . $class . "\n "
            if $conflict;

        return $orig->(@_);
    }
};

sub _split_key {
    my ( $this, $key ) = @_;

    return $key =~ m{(?:(.+)/)?(.*)};
}

sub set_root_class {
    my ( $this, $class ) = @_;

    $this->add_class( $this->root_name, $class );
}

# this is preferred method
sub load_namespaces {
    my ($this, $prefix) = @_;

    for my $class ( sort { $a cmp $b } uniq useall($prefix) ) {

        # first part is replaced by root
        ( my $key = $class ) =~ s/^$prefix\:\:[^\:]*/$this->root_name/e;
        $this->add_class( join( '/', split /::/, $key ) => $class );
    }
}

sub load_classes {
    my ( $this, $prefix ) = @_;

    for my $class ( uniq useall($prefix) ) {
        ( my $key = $class ) =~ s/^$prefix\:\://;
        $this->add_class(
            join( '/', $this->root_name, split /::/, $key ) => $class );
    }
}

sub _build_container {
    my ( $this, $key, $container_for ) = @_;

    return $container_for->{$key} if $container_for->{$key};

    my $meta; # meta must be declared here not inside the id
    my $class = $this->get_class($key) || $this->default_class;
    if ( my $roles = $this->roles_for->{$key} ) {
        $meta = Moose::Meta::Class->create_anon_class(
            superclasses => [$class],
            roles        => $roles,
        );
        $class = $meta->name;
    }

    my ( $parent_key, $name ) = $this->_split_key($key);
    my $container = $container_for->{$key} = $class->new( name => $name );
    if ($parent_key ){
        my $parent = $this->_build_container($parent_key, $container_for);
        croak sprintf
            "Conflict: container %s already contains sub_container %s",
            $parent->name, $container->name
            if $parent->has_sub_container( $container->name );
        $parent->add_sub_container( $container );
    }
    return $container;
}

sub _build_root {
    my $this = shift;

    my %container_for;
    for my $key (
        $this->root_name,
        keys %{ $this->class_for },
        keys %{ $this->roles_for }
        )
    {
        $this->_build_container( $key, \%container_for );
    }

    # finalize is called
    for my $key ( reverse sort keys %container_for ){
        my $container = $container_for{$key};
        $container->finalize if $container->can('finalize');
    }

    return $container_for{$this->root_name};
}

# dumps the nodes (only the implicitly loaded containers) w
# with info from which class and roles the node consists of 
sub _dump_classes {
    my $this = shift;

    my %dumped;
    for my $key (
        $this->root_name,
        keys %{ $this->class_for },
        keys %{ $this->roles_for }
        )
    {
        $this->_dump_node( $key, \%dumped );
    }

    return join "\n", @dumped{ sort keys %dumped };
}

sub _dump_node {
    my ( $this, $key, $dumped ) = @_;

    return if $dumped->{$key};

    my ( $parent_key, $name ) = $this->_split_key($key);
    $this->_dump_node($parent_key, $dumped) if $parent_key;

    my @roles = map {@$_} grep {$_} $this->roles_for->{$key};

    $dumped->{$key} = 
    ('  ' x ($key =~ tr/\//\//))
        . $name . ' - '. 
       ($this->get_class($key) || $this->default_class . ' (default)'). 
        (@roles? ' with '. join(', ', @roles) : '');
}


__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
