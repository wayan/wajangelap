package Akar::BreadBoard::Service::Config;
{
  $Akar::BreadBoard::Service::Config::VERSION = '1.981';
}
use Moose;
use utf8;

use namespace::autoclean;

use Akar::BreadBoard::Util qw(get_path_of);

=head1 NAME

Akar::BreadBoard::ConfigService - A very simple service (for Bread::Board) loading its value from configuration

=head1 SYNOPSIS

use Akar::BreadBoard;

my $root = container Durian => as {
    container Rate => as {
        # loads from 
        config_service 'flush_after';
    }
};

=head1 DESCRIPTION

Akar::BreadBoard::ConfigService is a simple service which when resolved, 
loads its value from configuration object.

The configuration object is resolved via C<config> dependency of the service.
This dependency by default links to /config service. 

The configuration object is asked for the value for key given by path attribute
of the service

=cut 

with 'Bread::Board::Service::WithDependencies';

has path => (
    is => 'ro',
    lazy_build => 1,
);

has required => (
    is       => 'ro',
    required => 1,
    default  => 1,
);

has default => (
    is => 'ro', 
    predicate => 'has_default',
);

sub BUILD {
    my $this = shift;

    # adds the 'config' dependency
    $this->add_dependency( config => '/config' )
        if !$this->has_dependency('config');
}

sub _build_path {
    my $this = shift;

    # 0 ... without the root name from path
    # the parent container can set the config_path
    my $parent = $this->parent;
    return $parent->can('config_path')
        ? join( '/', grep {$_} $parent->config_path , $this->name )
        : get_path_of( $this, 0 );
}

# returns 1 if the service is missing (has neither value nor default)
sub is_missing {
    my $this = shift;

    return not( $this->has_default
        || $this->get_dependency('config')->get->has_config_for( $this->path )
    );
}

sub get {
    my $this = shift;
   
    my $config = $this->params->{config};
    if ($this->has_default){
        my $v;
        return $v if $config->has_config_for($this->path, \$v);  

        my $default = $this->default;
        return ref($default) eq 'CODE'? $default->($this): $default;
    }
    else {
        return $this->required? $config->require_config_for($this->path): $config->get_config_for($this->path);
    }
}

__PACKAGE__->meta->make_immutable;

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:



