package Akar::BreadBoard::Container;
{
  $Akar::BreadBoard::Container::VERSION = '1.981';
}
use Moose;
use namespace::autoclean;

extends 'Bread::Board::Container';

use Bread::Board;

# array of coderefs to be called when the structure is ready
has _on_finalize => (is => 'ro', isa => 'ArrayRef', default=>sub {[]} );

sub on_finalize {
    my $this = shift;

    push @{$this->_on_finalize}, @_;
}

sub BUILD {
    my ( $this, @args ) = @_;

    container $this => as {
        $this->build_content(@args);
    };
}

# it is just a hook called when builder completes the whole root
sub finalize {
    my $this = shift;

    container $this => as {

        # by splice I remove the codes from the object
        # they may be circular references to this
        for my $code ( splice @{ $this->_on_finalize } ) {
            $this->$code();
        }
    };
}

sub build_content { }

__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

