package Akar::Config::ConfigLoader;
{
  $Akar::Config::ConfigLoader::VERSION = '1.981';
}
use Moose;

# ultra simple configuration loader
# loads files (YAML) merges loaded hashes together

# each loaded file can have prefix, which is prepended before 
# configuration keys
use YAML;
use Path::Class;
use Carp;
use Hash::Merge qw(merge);

{

    package Akar::Config::ConfigLoader::File;
{
  $Akar::Config::ConfigLoader::File::VERSION = '1.981';
}
    use Moose;

    has content => ( is => 'ro', isa => 'HashRef', lazy_build => 1 );
    has prefix => ( is => 'ro' );
    has path => ( is => 'ro', required => 1 );

    # file content
    sub _build_content {
        my $this = shift;
        my $path = $this->path;

        -f $path or die "No file $path exists\n";
        return YAML::LoadFile("$path");
    }

    sub has_value_for {
        my ( $this, $path, $value_ref ) = @_;

        if ( my $prefix = $this->prefix ) {

            # can't be here
            $path =~ s/^$prefix(?:\/|$)// or return undef;
        }
        my $value = $this->content;
        for my $part ( grep {$_} split m{/}, $path ){
            ref $value && ref $value eq 'HASH' && exists $value->{$part}
                or return 0;
            $value = $value->{$part};
        }
        $$value_ref = $value if $value_ref;
        return 1;
    }

    __PACKAGE__->meta->make_immutable;
}

has config_files => (
    is         => 'rw',
    isa        => 'ArrayRef',
    auto_deref => 1,
    lazy       => 1,
    default    => sub { return [] },
);

sub add_config_file {
    my $this = shift;
    push @{ $this->config_files },
        Akar::Config::ConfigLoader::File->new( path => @_ );
}

# returns 1 if the config value exists
sub has_config_for {
    my ($this, $path, $value_ref) = @_;

    my @values = map {
        my $v;
        $_->has_value_for( $path, \$v ) ? ($v) : ();
        } $this->config_files;

    if ( $value_ref && @values ) {
        # computed only if we care about the config value
        # (when the reference is supplied)
        $$value_ref = $this->_merge_values(@values);
    }
    return scalar @values;
}

sub _merge_values {
    my $this = shift;

    return @_ == 1
        ? $_[0]
        # the merge from Hash::Merge can merge even scalar
        # and by default left value has precedence over rigt
        : merge(@_);
}

# returns config for a path
sub get_config_for {
    my ( $this, $path ) = @_;

    my $v;
    return $this->has_config_for( $path, \$v ) ? $v : undef;
}

sub require_config_for {
    my ($this, $path) = @_;

    my (@files, @values);
    for my $f ( $this->config_files ){
        my $v;
        my $has_value = $f->has_value_for($path, \$v);
        if ($has_value){
            push @values, $v;
        }
        elsif (defined $has_value){
            push @files, $f;
        }
    }
    return $this->_merge_values(@values) if @values;

    # no value => sensible die
    if (@files){    
        my %path_for;
        for my $f (@files){
            my $prefix = $f->prefix;
            my $key = $path;
            $key =~ s/^$prefix\/?// if $prefix;
            push @{$path_for{$key}}, $f->path;
        }
        croak join ',',
            map {
                "No value for key $_ found in config file(s): ". join(', ', @{$path_for{$_}});
            } keys %path_for;
    }
    else {
        croak "There is no config file where $path key could be found\n ";
    }
}

__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
