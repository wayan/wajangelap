package Akar::BreadBoard::Service::Collector;
{
  $Akar::BreadBoard::Service::Collector::VERSION = '1.981';
}
use Moose::Role;

has collected_container => (
    is      => 'rw',
    lazy    => 1,
    default => sub {
        shift()->parent;
    }
);

has __dependencies_added => ( is => 'rw' );

# before the dependencies are resolved for the first time
# the dependencies from container are added
before resolve_dependencies => sub {
    my $this = shift;

    return if $this->__dependencies_added;
    $this->__dependencies_added(1);
    $this->_populate_dependencies;
};

sub _populate_dependencies {
    my $this = shift;

    my $container = $this->collected_container;
    $container = $this->fetch($container) if !blessed($container);

    for my $name ( $container->get_service_list ) {
        my $service = $container->get_service($name);
        next if $service == $this;

        $this->add_dependency( $service->name,
            Bread::Board::Dependency->new( service => $service ) );
    }
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
