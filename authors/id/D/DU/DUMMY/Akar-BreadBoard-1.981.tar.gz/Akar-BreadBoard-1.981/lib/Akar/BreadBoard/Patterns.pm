package Akar::BreadBoard::Patterns;
{
  $Akar::BreadBoard::Patterns::VERSION = '1.981';
}
use strict;
use warnings;

# ABSTRACT: typical patterns (group of services) for IOC containers

use MooseX::Params::Validate;
use Akar::BreadBoard;

use Exporter 'import';

our @EXPORT_OK = qw(database_services webservices_services);

sub database_services {
    # 2013-05-20 I add a new service storage_new
    # which returns the new storage everytime I
    # resolve it
    my @storage_args = (
        class        => 'DBIx::Class::Storage::DBI',
        dependencies => [qw(connect_info env)],
        block        => sub {
            my $s   = shift;
            my $p   = $s->params;
            my $env = $p->{env};
            @ENV{ keys %$env } = values %$env;
            my $storage = $s->class->new();
            $storage->connect_info( $p->{connect_info} );
            return $storage;
        },
    );

    service storage => ( @storage_args, lifecycle => 'Singleton', );
    service storage_new => @storage_args;
    service dbh         => (
        block => sub {
            my $s = shift;
            return $s->params->{storage}->dbh;
        },
        dependencies => [qw(storage)],
    );
    service dbh_new => (
        block => sub {
            my $s = shift;
            return $s->params->{storage_new}->dbh;
        },
        dependencies => [qw(storage_new)],
    );

    service env => {};
    config_service 'dsn';
    config_service 'username';
    config_service 'password';

    container Attr => as {
        service RaiseError => 1;
        service AutoCommit => 1;
    };

    service attr => (
        block => sub {
            my $s         = shift;
            my $container = $s->fetch('Attr');
            my %attr = 
                map { ( $_ => $container->get_service($_)->get ) }
                    $container->get_service_list;   
            return \%attr;
        }
    );

    # on_connect_do returns subroutine
    service on_connect_do => sub { };

    # this service is connected from configuration
    service connect_info => (
        block => sub {
            my $s      = shift;
            my $params = $s->params;
            return [
                $params->{dsn},
                $params->{username},
                $params->{password},
                $params->{attr},
                { on_connect_do => $params->{on_connect_do}, }
            ];
        },
        dependencies => [qw(dsn username password on_connect_do attr)],
    );

}

# role with commonly used services in  WebServices container (OCP, CSR, ...)
#
# mostly for basic_auth
sub webservices_services {

    # basic authorization
    service basic_auth_middleware => (
        block => sub {
            my $s             = shift;
            my $authenticator = $s->param('authenticator');
            return sub {
                my $app = shift;
                $s->class->wrap( $app, authenticator => $authenticator );
            };
        },
        dependencies => ['authenticator'],
        class        => 'Plack::Middleware::Auth::Basic',
    );

    # basic auth authenticator
    service authenticator => (
        block => sub {
            my $s     = shift;
            my $users = $s->param('users');
            return sub {
                my ( $login, $password ) = @_;
                return $users->{$login}
                    && $users->{$login}{password} eq $password;
            };
        },
        dependencies => ['users'],
    );

    # normalizes the hash into form
    # $user => {
    #   password => $password,
    #   roles => [ ... ],
    # }
    #
    my $normalize_basic_auth_users = sub {
        my ($users) = @_;

        return {
            map {
                my $login = $_;
                my $info  = $users->{$login};
                if ( !ref $info ) {
                    $info = { password => $info };
                }
                $info->{password} or die "No password for user $login\n ";

                my $roles = $info->{roles} ||= [];
                if ( !ref $roles ) {
                    $info->{roles} = [ grep {$_} split /[,\s+]/, $roles ];
                }
                ( $login => $info );
            } keys %$users
        };
    };

    # checked users
    my $users_service = config_service 'users';
    service users => (
        block => sub {

            # normalizing users hash
            return $normalize_basic_auth_users->( $users_service->get );
        },
        lifecycle => 'Singleton',
    );
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 



