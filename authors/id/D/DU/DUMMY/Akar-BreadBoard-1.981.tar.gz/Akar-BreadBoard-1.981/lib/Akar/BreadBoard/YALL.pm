package Akar::BreadBoard::YALL;
{
  $Akar::BreadBoard::YALL::VERSION = '1.981';
}
use Moose;

# DON'T USE THIS MODULE, USE Bread::Board::LazyLoader INSTEAD

# ABSTRACT: Yet another lazy loader 
extends 'Bread::Board::LazyLoader';

# just different name for build
sub build_container {
    my $this = shift;
    return $this->build(@_);
}

__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
