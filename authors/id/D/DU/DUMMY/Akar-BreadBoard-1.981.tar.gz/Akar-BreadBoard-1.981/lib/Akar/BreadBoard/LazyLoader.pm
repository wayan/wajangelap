package Akar::BreadBoard::LazyLoader;
{
  $Akar::BreadBoard::LazyLoader::VERSION = '1.981';
}
use MooseX::Role::Parameterized;

use Sub::Exporter qw(build_exporter);

# interface to LazyLoader
parameter namespace => ( is => 'ro', required => 1);

role {
    my $p = shift;

    with 'Akar::BreadBoard::LazyLoader::Builder';

    method extra_roles => sub {
        return 'Akar::BreadBoard::LazyLoader::Role::BuildContent';
    };

    before build_root => sub {
        my $this = shift;
        $this->load_namespaces( $p->namespace );
    };

    my @exports = ( rs => \'_rs_generator' );

    # import also exports the method legacy_ioc_root
    # (to be used TEMPORARILY only in Durian) which is statically
    # kept root
    # this is the root used from inside the modules
    # deprecated and to be removed
    my $legacy_ioc_root;
    push @exports, legacy_ioc_root => sub {
        my ( $class, $name ) = @_;
        $legacy_ioc_root ||= $class->root;
        return sub {$legacy_ioc_root};
    };

    # Akar::BreadBoard::LazyLoader also works as an exporter
    # inherited subclasses can import rs
    # which is shortcut for Something::IOC->root->resolve(service => @ARGS)
    method import => build_exporter( { exports => \@exports } );

    # I make the rs function available for subclasses (Durian::IOC)
    # who wants to export other functions also
    method _rs_generator => sub {
        my ( $class, $name ) = @_;
        my $used = 0;
        return sub {
            die << "NEXT_OCCURENCE" if $used++;
Function '$name' is shortcut only and can be used only once per file (use $class).
If you need access to more services you have to use:

use $class;

my \$root = $class->root;
my \$service1 = \$root->resolve(service => PATH1);
my \$service2 = \$root->resolve(service => PATH2);

NEXT_OCCURENCE
            return $class->root->resolve( service => @_ );
        };
    };
};

=head1 NAME

Akar::BreadBoard::LazyLoader - loads the hierarchy of Bread::Board containers lazily by module names

=head1 SYNOPSIS

    use Akar::BreadBoard::LazyLoader;

    my $builder =  Akar::BreadBoard::LazyLoader->new;
    $builder->load_namespaces('MyIOC');
    my $root = $builder->root;

    $root->resolve(service => 'Database/schema');
  

=cut

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
