package Akar::BreadBoard::Service::BuildClass;
{
  $Akar::BreadBoard::Service::BuildClass::VERSION = '1.981';
}
use Moose::Role;

# role for service with even the class lazy
use strict;

# the argument passed instead of class
has _class_initializer => (is => 'rw');

has _class_built =>
    ( is => 'ro', required => 1, lazy => 1, builder => '_build_class' );

# class method is overwritten via new attribute
sub class { shift()->_class_built->name }

sub _build_class {
    my $this = shift;

    my $init = $this->_class_initializer;
    if (blessed $init &&  $init->can('get') ) {

        # service or dependency
        $init->parent($this) if $init->can('parent') && !$init->parent;
        return $init->get;
    }
    elsif ( ref $init eq 'CODE' ) {
        return $this->$init();
    }
    elsif ( ref $init eq 'HASH' ) {
        my $builder_class = delete $init->{builder_class}
            || 'Akar::BreadBoard::Service::BuildClass::Builder';
        return $builder_class->new(
            service => $this,
            %$init,
        )->build;
    }
}

{

    package Akar::BreadBoard::Service::BuildClass::Builder;
{
  $Akar::BreadBoard::Service::BuildClass::Builder::VERSION = '1.981';
}
    use Moose;

    use Bread::Board::Types;

    # base class
    has base => ( is => 'ro', default => 'Moose::Object', );

    has roles => (
        is      => 'ro',
        isa     => 'ArrayRef',
        default => sub { [] },
    );

    has service => ( is => 'ro', required => 1 );

    # another list of dependencies
    # this dependencies are turned into methods creating the dependent object
    has dep_methods => (
        is       => 'ro',
        required => 1,
        default  => sub { {} },
        isa      => 'Bread::Board::Service::Dependencies',
        coerce   => 1,
        trigger  => sub {
            my $self = shift;
            $_->parent( $self->service )
                foreach values %{ $self->dep_methods };
        },
    );

    sub build {
        my $this = shift;

        my %methods = map {
            my $method = $_;
            my $dep    = $this->dep_methods->{$method};
            (   $method => sub {
                    shift;
                    return $dep->get(@_);
                }
            );
        } keys %{ $this->dep_methods };

        my $roles = $this->roles;
        return Moose::Meta::Class->create_anon_class(
            ( @$roles ? ( roles => $this->roles ) : () ),
            superclasses => [ $this->base ],
            methods      => \%methods,
        );
    }

    __PACKAGE__->meta->make_immutable;
}


1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
