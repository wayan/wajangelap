package Akar::BreadBoard::LazyLoader::Role::BuildContent;
{
  $Akar::BreadBoard::LazyLoader::Role::BuildContent::VERSION = '1.981';
}
use Moose::Role;

use Bread::Board;

sub BUILD {}

# on BUILD built_content is called with $this set as current container
requires 'build_content';

after BUILD => sub {
    my $this = shift;
    container $this => sub {
        $this->build_content;
    };
};

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
