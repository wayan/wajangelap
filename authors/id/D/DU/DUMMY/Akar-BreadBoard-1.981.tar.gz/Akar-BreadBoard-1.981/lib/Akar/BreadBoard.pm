package Akar::BreadBoard;
{
  $Akar::BreadBoard::VERSION = '1.981';
}
use strict;
use warnings;

# ABSTRACT: Bread::Board (dependency injection framework) customizations

use Moose ();
use Moose::Exporter;
use Moose::Util;
use Scalar::Util qw(blessed);

use Akar::BreadBoard::Service::Config;

use Bread::Board;
use Akar::BreadBoard::Util;
use Scope::Guard qw(scope_guard);

Moose::Exporter->setup_import_methods(
    with_meta => [],
    also      => ['Bread::Board', 'Akar::BreadBoard::Util'],
    as_is     => [
        qw(collector params_service config_service is_config_service
            replace_by_literal anon_service anon setter_service
            on_container current_container without_container
            replace_service
        ),
    ],
);

sub UNUSED_service($@) {
    my $name = shift;
    return bb_service($name, @_) if @_ == 1;

    my %args  = @_;

    # if there is an class and the class is a reference
    # then the class is build lazily
    return  $args{class} && ref $args{class} ?
        _lazy_class_service( $name, %args): bb_service($name, %args);

}

sub collector {
    my $service = shift();

    # if only name not service is supplied, then simple service returning
    # the hash of parameters is constructed
    if ( !blessed($service) ) {
        my $name = $service;
        $service = service $name =>
            ( block => sub { return { %{ shift()->params } }; } );
    }

    Moose::Util::apply_all_roles( $service,
        'Akar::BreadBoard::Service::Collector' );
    $service->collected_container( shift() ) if @_;
    return $service;
}

# returns only parameters
sub params_service {
    my ( $name, $dependencies ) = @_;

    return service $name => (
        block => sub {
            my %params = %{ shift()->params };
            return \%params;
        },
        dependencies => $dependencies,
    );
}

sub config_service {
    my ( $name, @args ) = @_;

    return service(
        $name,
        service_class => 'Akar::BreadBoard::Service::Config',
        @args
    );
}

sub is_config_service {
    my $service = shift;
    return $service->isa('Akar::BreadBoard::Service::Config');
}

sub replace_by_literal {
    my ( $service, $value ) = @_;

    return $service->parent->add_service(
        Bread::Board::Literal->new(
            name  => $service->name,
            value => $value,
        )
    );
}

# anonymous service to be used in dependencies, for example
my $service_no = 0;

sub anon_service {
    my $name = anon();
    return Bread::Board::Literal->new( name => $name, value => @_ )
        if @_ == 1;

    my %attr          = @_;
    my $service_class = delete $attr{service_class}
        || (
        $attr{block}
        ? 'Bread::Board::BlockInjection'
        : 'Bread::Board::ConstructorInjection'
        );
    return $service_class->new( name => $name, %attr );
}

# returns anonymous name, which is skipped in collectors
sub anon {
    return 'anonymous_' . ( ++$service_no );
}

# first arg is either path or service, second is dependencies hashref
# all these dependencies are applied as setters
sub setter_service {
    my ( $service_path, $deps, %attr ) = @_;

    $deps ||= {};
    my $name = delete $attr{name} || anon();
    return service(
        $name,
        block => sub {
            my $p   = shift->params();
            my $val = delete $p->{__THIS__};
            $val->$_( $p->{$_} ) for keys %$p;
            return $val;
        },
        %attr,
        dependencies => {
            __THIS__ => $service_path,
            %$deps,
        }
    );
}

sub _lazy_class_service {
    my ( $name, %args ) = @_;

    # we build the class
    my $lifecycle = delete $args{lifecycle};
    my $init      = delete $args{class};
    $args{class} = 'FakeClass';
    my $s = bb_service( $name, %args );
    Moose::Util::apply_all_roles( $s,
        'Akar::BreadBoard::Service::BuildClass' );
    $s->_class_initializer($init);
    $s->lifecycle($lifecycle) if $lifecycle;
    return $s;
}

# working with current container
sub current_container {
    return $Bread::Board::CC;
}

# runs the block without container set
sub without_container(&) {
    local $Bread::Board::CC = undef;
    return shift()->();
}

# runs code on existing container without inserting it anywhere
sub on_container {
    my ( $container, $code ) = @_;

    # resolving container
    if ( !ref $container ) {
        my $path = $container;
        my $cc   = current_container()
            or die
            "on_container called with path ($path), when no current container set\n ";
        $container = $cc->fetch($path) or die "No container $path exist\n ";
    }

    $container->isa('Bread::Board::Container')
        or die "Argument to on_container is not container or path\n ";
    local $Bread::Board::CC = $container;
    return $code->($container);
}

# replace_service([C=>path], ....);
# replace_service(path, ...);
# replace_service(service, ...);
#
# The difference between 
# replace_service($c->fetch($path), ...)
# and replace_service([$c, $path], ...) is if the path leads to alias
# the fetch returned the aliased_from service not the alias
sub _fetch_service {
    my ($start, $path) = @_;
   
    $path =~ m{(.+)/(.*)} 
        or $path =~ m{(/?)(.*)};

    my ($ppath, $name) = ($1, $2);
    my $c = $ppath ne ''? $start->fetch($ppath): $start;
    my $s = $c && $c->get_service($name)
        or die "Can't find service $path\n";
    return $s;
}

sub replace_service {
    my ($service, @args) = @_;

    if (!ref $service){
        my $cc = current_container()
            or die "replace_service called with path ($service), when no current container set\n ";
        $service = _fetch_service($cc, $service);
    } 
    elsif ( ref $service eq 'ARRAY' ) {
        # TO DO more controls
        $service = _fetch_service(@$service);
    }

    $service->does('Bread::Board::Service')
        or die "Arg passed to replace_service is not service or path to service\n ";
    
    # the orig_service can be referenced
    if ( @args > 1 ) {
        my %params = @args;
        if ( my $orig_ref = delete $params{orig} ) {
            $$orig_ref = $service;  
            @args = %params;
        }
    }

    return on_container $service->parent => sub {
        return service $service->name => @args;
    };
}


# check whether we can use current_container
{   
    my $cc;
    my $c = container 'Z' => as {
        $cc = current_container();
    };

    $cc && $cc == $c
        or die "The interface of Bread::Board changed, current_container doesnot work";
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
