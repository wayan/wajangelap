package Akar::BreadBoard::LazyLoader::Builder;
{
  $Akar::BreadBoard::LazyLoader::Builder::VERSION = '1.981';
}
use Moose::Role;

use Module::Find;
use Moose::Util;
use Class::Load;
use Bread::Board::Container;

use Akar::BreadBoard::LazyLoader::Placeholder;

has name => ( is => 'ro', default => 'Root' );

# builders for sub_containers
has sub_builders => (
    is      => 'ro',
    isa     => 'HashRef',
    default => sub { {} },
);

# classes from which the container is composed (both roles and true classes)
has classes => ( is => 'ro', isa => 'ArrayRef', default => sub { [] } );

# the root is an attribute it is build only once
has root => (
    is         => 'ro',
    init_arg   => undef,
    lazy_build => 1,
    builder    => 'build_root',
    handles    => [qw(resolve fetch)],
);

around root => sub {
    my $orig = shift;
    my $this = blessed($_[0])? shift(): shift()->new;
    return $this->$orig(@_);
};

sub build_root {
    my $this = shift;
    return $this->build_container;
}

# the default container class
sub default_base_class {
    return 'Bread::Board::Container';
}

sub sub_builder_class {
    my $this = shift;
    return blessed $this;
}

# roles to be placed to container
sub extra_roles { 
    return 'Akar::BreadBoard::LazyLoader::Role::BuildContent';
}

sub empty_extra_roles {
    return;
}

sub load_namespaces {
    my ( $this, $prefix ) = @_;

    for my $module ( Module::Find::findallmod($prefix) ) {
        $this->_add_class( $prefix => $module );
    }
}

sub _add_class {
    my ( $this, $prefix, $module ) = @_;

    # with $prefix MyApp::IOC
    # the class MyApp::IOC::Root belongs to $this 
    # while MyApp::IOC::Root::Database belongs to Database builder
    if ( my ( $sub_prefix, $sub_name )
        = $module =~ /^($prefix\:\:.+?)::([^:]+)/ )
    {
        $this->get_sub_builder($sub_name)->_add_class( $sub_prefix, $module );
    }
    else {
        push @{ $this->classes }, $module;
    }
}

sub get_sub_builder {
    my ( $this, $sub_name ) = @_;

    return $this->sub_builders->{$sub_name}
        ||= $this->sub_builder_class->new(
        name              => $sub_name,
        sub_builder_class => $this->sub_builder_class
        );
}

sub new_sub_builder {
    my ( $this, $sub_name ) = @_;
    return $this->sub_builder_class->new(
        name              => $sub_name,
        sub_builder_class => $this->sub_builder_class,
    );
}

# returns the container
sub build_container {
    my $this = shift;

    my ( @classes, @roles );

    my @modules = @{$this->classes};
    for my $module ( @modules ) {
        Class::Load::load_class($module);
        my $meta = Moose::Util::find_meta($module)
            or die "Module '$module' is neither Moose class nor role";
        if ( $meta->isa('Moose::Meta::Class') ) {
            push @classes, $module;
        }
        elsif ( $meta->isa('Moose::Meta::Role') ) {
            push @roles, $module;
        }
        else {
            die "Module '$module' is weird";
        }
    }
    @classes < 2
        or die sprintf
        "There is more than one class for a container (%s). There may be only one class, other must be roles",
        join( ', ', map {"'$_'"} @classes );

    my $meta = Moose::Meta::Class->create_anon_class(
        superclasses => [ shift @classes || $this->default_base_class ],
        roles => [
            @roles,
            'Akar::BreadBoard::LazyLoader::WithPlaceholders',
            ( @modules ? $this->extra_roles : $this->empty_extra_roles ),
        ],
        cache => 1,
    );
    my $container = $meta->new_object(
        {   name         => $this->name,
            sub_builders => $this->sub_builders,
        }
    );
    for my $name ( keys %{ $this->sub_builders } ) {
        $container->add_sub_container(
            Akar::BreadBoard::LazyLoader::Placeholder->new(
                name    => $name,
                builder => $this->sub_builders->{$name},
            )
        );
    }
    return $container;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
