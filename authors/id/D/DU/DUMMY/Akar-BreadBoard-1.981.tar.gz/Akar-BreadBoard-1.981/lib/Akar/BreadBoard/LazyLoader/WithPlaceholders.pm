package Akar::BreadBoard::LazyLoader::WithPlaceholders;
{
  $Akar::BreadBoard::LazyLoader::WithPlaceholders::VERSION = '1.981';
}
use Moose::Role;

# if the container is placeholder inflate it

around get_sub_container => sub {
    my ($orig, $this, $name) = @_;

    my $sub_container = $this->$orig($name);
    if ( $sub_container &&  $sub_container->can('build_container') ) {
        $sub_container = $sub_container->build_container;
        $this->add_sub_container($sub_container);
    }
    return $sub_container;
};

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
