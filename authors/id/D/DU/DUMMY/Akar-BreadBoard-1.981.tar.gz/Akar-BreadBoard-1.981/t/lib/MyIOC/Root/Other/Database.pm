package MyIOC::Root::Other::Database;
use Moose::Role;

use Bread::Board;

sub build_content {
    service dbh => 'other_dbh';
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 


