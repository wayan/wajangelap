package Akar::Plack::Sprinter::CLI;
{
  $Akar::Plack::Sprinter::CLI::VERSION = '1.993';
}
use Moose::Role;

use namespace::autoclean;

use Akar::CLI;

# ABSTRACT: command line interface for plack runner
sub build_cli {
    my $this = shift;

    #    require Server::Starter;
    #use Server::Starter qw(restart_server start_server);
    my $cli = Akar::CLI->new(
        { description => 'Start/stop/restart the webserver' } );
    $cli->add_action(
        'start - starts the server',
        sub {
            $this->start();
        }
    );
    $cli->add_action(
        'restart - (gracefully) restarts the server',
        sub {
            $this->graceful_restart();
        }
    );
    $cli->add_action( 'stop - stops the webserver', sub { $this->stop(); } );

    $cli->add_action(
        'status - displays basic status',
        sub {
            $this->do_status();
            return;
        }
    );
    return $cli;
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
