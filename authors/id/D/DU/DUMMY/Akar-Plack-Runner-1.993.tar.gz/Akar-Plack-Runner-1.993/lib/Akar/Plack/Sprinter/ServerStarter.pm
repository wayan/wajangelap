package Akar::Plack::Sprinter::ServerStarter;
{
  $Akar::Plack::Sprinter::ServerStarter::VERSION = '1.993';
}
use Moose::Role;

use namespace::autoclean;

use Server::Starter qw(start_server);

# array for server starter (how to start_self)
has start_self => (
    is         => 'ro',
    lazy_build => 1,
);

sub _build_start_self {
    return [ $0, 'start' ];
}

sub inside_server_starter {
    return $ENV{SERVER_STARTER_PORT};
}

around run_program => sub {
    my ($orig, $this, $app)  = @_;

    return $this->$orig($app) if $this->inside_server_starter;

    start_server(  port => [ $this->get_ports ], exec => $this->start_self  );
};

around start => sub {
    my ($orig, $this, @args) = @_;

    if ( $this->inside_server_starter ) {
        # no checks inside server starter
        $this->run_program;
    }
    else {
        $this->$orig(@args);
    }
};

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 


