package Akar::Plack::Runner::PreloadApp;
{
  $Akar::Plack::Runner::PreloadApp::VERSION = '1.993';
}
use Moose;
use namespace::autoclean;

use Daemon::Control;
use Server::Starter;

extends 'Akar::Plack::Runner';

# runs starman plack server with --preload-app via Server::Starter and
# Daemon::Control

has server_starter_interval => (is => 'ro', isa => 'Int', default => 5 );

# Daemon::Control object
has daemon_control => ( is => 'rw', lazy_build => 1,);

has _start_check_delay => (is => 'rw', default => 2);

# unlikely to be changed
has _daemon_control_class => (
    is         => 'ro',
    lazy_build => 1,
);

my $dc_class = do {

    package Akar::Plack::Runner::PreloadApp::DaemonControl;
{
  $Akar::Plack::Runner::PreloadApp::DaemonControl::VERSION = '1.993';
}
    use base qw(Daemon::Control);

    # disable pretty_print
    sub pretty_print { }

    __PACKAGE__;
};

sub _build__daemon_control_class { return $dc_class; }


# weird - If 
before wait_until_started => sub {  
    my $this = shift;
    sleep($this->_start_check_delay);
};

sub _do_start {
    my $this = shift;

    $this->daemon_control->do_start;
}

sub _do_gracefull_restart {
    my $this = shift;

    # this is quite weird, but since Server::Starter waits interval seconds
    # before it creates status_file we can wait for it 
    $this->_wait_until(
    sub {
        -f $this->status_file;
    }, $this->server_starter_interval + 2
    )
    or die "No status file appeared\n ";

    Server::Starter::restart_server(
        interval    => $this->server_starter_interval,
        pid_file    => $this->pid_file,
        status_file => $this->status_file,
    );
}

sub _build_daemon_control {
    my $this = shift;

    return $this->_daemon_control_class->new(
        {   name        => $this->name,
            pid_file    => $this->pid_file,
            stdout_file => $this->error_log,
            stderr_file => $this->error_log,
            program     => sub {
                Server::Starter::start_server(
                    port        => [ $this->get_all_ports ],
                    status_file => $this->status_file,
                    interval    => $this->server_starter_interval,

                    # pid_file is not passed, it is handled by Daemon::Control
                    exec => [
                        'starman',
                        '--preload-app',
                        '--access-log' => $this->access_log,
                        (   $this->workers
                            ? ( '--workers' => $this->workers )
                            : ()
                        ),
                        $this->psgi_app_wrapped
                    ]
                );
                }
        }
    );
}

__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
