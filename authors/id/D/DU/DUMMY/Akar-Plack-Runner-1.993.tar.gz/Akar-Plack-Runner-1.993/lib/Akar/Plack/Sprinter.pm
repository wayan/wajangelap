package Akar::Plack::Sprinter;
{
  $Akar::Plack::Sprinter::VERSION = '1.993';
}
use Moose;
use Starman::Server;
use Path::Class;

use Akar::Base;
use Plack::Builder;
use Plack::Util;
use JSON qw(from_json to_json);
use LWP::UserAgent;
use IPC::System::Simple qw(capture);
use Plack::Middleware::AccessLog;
use DateTime;

# ABSTRACT: simplified version of Akar::Plack::Runner

has name => ( is => 'ro', required => 1 );

has error_log => ( is => 'ro', required => 1, lazy_build => 1 );

has access_log => ( is => 'ro', required => 1, lazy_build => 1 );

has data_root => (
    is       => 'ro',
    lazy_build => 1,
);

has pid_file => ( is => 'ro', required => 1, lazy_build => 1 );

has log_dir => ( is => 'ro', required => 1, lazy_build => 1 );

has daemon_control_class => ( is => 'ro', lazy_build => 1 );

has daemon_control => (
    is         => 'ro',
    lazy_build => 1,
    handles    => { }
);

has port => ( is => 'ro', isa => 'Int|ArrayRef[Int]', required => 1 );

# psgi_app is a file or a coderef
has psgi_app => ( is => 'ro', );

has psgi_app_builder => (
    is  => 'ro',
    isa => 'CodeRef',
);

has max_stop_timeout => ( is => 'rw', default => 60 );

has max_start_timeout => ( is => 'rw', default => 20 );

# how many lines from error log to display when error
has error_log_tail_lines => ( is => 'rw', default => 10, );

has status_path => ( is => 'ro', lazy_build => 1 );

has server_class => ( is => 'ro', lazy_build => 1 );

# how many workers starman has
has workers => ( is => 'ro', isa => 'Int', predicate => 'has_workers' );

sub _build_server_class {
    require Plack::Handler::Starman;
    return 'Plack::Handler::Starman';
}

sub _build_pid_file {
    my $this = shift;
    return dir( $this->data_root )->file( $this->name . '.pid' );
}

# returns the pid from pid_file if the process is running
# (the Daemon::Control returns true/false)
sub pid_running {
    my $this = shift;
    
    my $dc = $this->daemon_control;
    return $dc->pid_running && $dc->pid;
}

sub get_ports {
    my $this = shift;
    my $port = $this->port;
    return ref $port ? @$port : $port;
}

sub _build_access_log {
    dir( shift()->log_dir() )->file('access_log');
}

sub _build_error_log {
    dir( shift()->log_dir() )->file('error_log');
}

sub _build_log_dir {
    my $dir = dir( shift()->data_root() )->subdir('logs');
    # logs dir is created automatically
    $dir->mkpath if ! -d $dir;
    return $dir;
}

my $dc_class = do {

    package Akar::Plack::Runner::Sprinter::DaemonControl;
{
  $Akar::Plack::Runner::Sprinter::DaemonControl::VERSION = '1.993';
}
    use base qw(Daemon::Control);

    # disable pretty_print
    sub pretty_print { }

    __PACKAGE__;
};

sub _build_daemon_control_class { return $dc_class; }

sub _build_data_root {
    my $this = shift;
    my $dir  = Akar::Base->app_data( $this->name );

    # dir is created automatically
    $dir->mkpath if !-d $dir;
    return $dir;
}

sub run_plack_server {
    my ( $this, $app ) = @_;

    $this->server_class->new( $this->plack_server_options )->run($app);
}

sub plack_server_options {
    my $this = shift;

    return (
        listen => [ map {":$_"} $this->get_ports ],
        ( $this->has_workers ? ( workers => $this->workers ) : () )
    );
}

sub _build_daemon_control {
    my $this = shift;

    my $name = $this->name;
    return $this->daemon_control_class->new(
        {   name        => $this->name,
            pid_file    => $this->pid_file,
            stdout_file => $this->error_log,
            stderr_file => $this->error_log,
            program     => sub {
                $this->run_program;
            },
        }
    );
}

# what is run inside daemon control
sub run_program {
    my $this = shift;

    my $app  = $this->complete_psgi_app;
    $this->run_plack_server($app);
}

# returns the final (wrapped by status and middleware)
# psgi app which is lazily loaded
sub complete_psgi_app {
    my $this = shift;

    die "Can't supply both psgi_app and psgi_app_builder\n "
        if $this->psgi_app && $this->psgi_app_builder;
    die "Neither psgi_app nor psgi_app_builder supplied\n "
        if !( $this->psgi_app || $this->psgi_app_builder );

    my $builder = $this->psgi_app_builder;
    if ( !$builder ) {
        my $app = $this->psgi_app;
        if ( ref $app ) {
            $builder = sub {$app};
        }
        else {
            -f $app or die "PSGI app $app does not exist\n ";
            $builder = sub { Plack::Util::load_psgi($app); };
        }
    }

    my $access_log_mw = sub {
        my $app = shift;
        open my $logfh, ">>", $this->access_log
            or die "open(" . $this->access_log . "): $!";
        $logfh->autoflush(1);
        Plack::Middleware::AccessLog->wrap(
            $app,
            logger => sub {
                $logfh->print(@_);
            }
        );
    };

    # status middleware
    my ( $loaded, $app, $error );
    my $path = $this->status_path;
    return sub {
        if ( !$loaded ) {
            $loaded = time();
            $app    = eval { $access_log_mw->( $builder->() ) };
            $error  = $@;
            if ( !$error ) {
                if ( !$app ) {
                    $error = "Psgi app returns undef";
                }
                elsif ( ref $app ne 'CODE' ) {
                    $error = "Psgi app returns not coderef, but $app";
                }
            }
        }

        my $env = shift;
        if ( $env->{PATH_INFO} eq $path && $env->{REQUEST_METHOD} eq 'GET' ) {

            # status URL
            return [
                200,
                [ 'Content-Type' => 'application/json' ],
                [   to_json(
                        {   loaded => $loaded,
                            pid    => $$,
                            (   $error
                                ? ( status => 'ERROR',
                                    error  => $error
                                    )
                                : ( status => 'OK' )
                            ),
                        }
                    )
                ]
            ];
        }

        return $error
            ? [ 500, [], ["PSGI app was loaded with error"] ]
            : $app->($env);
    };
}

sub start {
    my $this = shift;

    if ( my $pid = $this->pid_running ) {
        die sprintf "%s is already running, pid %d, pidfile %s\n",
            $this->name, $pid, $this->pid_file;
    }
    $this->daemon_control->do_start;
    $this->wait_for_start;
}

sub stop {
    my $this = shift;

    if ( !$this->pid_running ){
        warn sprintf "%s is not running\n", $this->name;
        return;
    }

    $this->daemon_control->do_stop;
    $this->wait_for_stop;
}

sub wait_for_stop {
    my $this = shift;

    my $started = time();
    my $timeout = $this->max_stop_timeout;
    while ( $this->pid_running ) {
        time() <= $started + $timeout
            or die sprintf "Even after %d seconds %s did not stop\n",
            $timeout, $this->name;
        sleep 1;
    }
}

sub graceful_restart {
    my $this = shift;

    if ( my $pid = $this->pid_running ) {

        # HUP ping the starman
        kill 'HUP' => $pid;
        $this->wait_for_start(1);
    }
    else {
        warn sprintf "%s is not running\n", $this->name;
        $this->start;
    }
}

# returns commented n lines from tail of error log
sub tail_error_log {
    my $this      = shift;
    my $error_log = $this->error_log;
    my $n         = $this->error_log_tail_lines;
    my $content   = capture( 'tail', '-n', $n, $this->error_log );
    return
        "last $n lines from error log$error_log:\n------   LOG START -------------\n$content\n----------- END OF LOG ---------------";
}

sub wait_for_start {
    my ( $this, $restart ) = @_;

    my $timeout = $this->max_start_timeout;
    my $started = time();
CHECK: while (1) {
        my $too_long = time() - $started > $timeout;

        if ( !$this->pid_running ){

           # the daemon failed (usually when someone is listening at the port)
            die "The daemon is not running, may be the port is occupied,\n"
                . $this->tail_error_log;
        }
        my $res = $this->fetch_status_url;

        # test for connection refused
        if (   $res->code == 500
            && $res->header('client-warning') =~ /internal/i )
        {
            if ($too_long) {
                warn
                    "Even after $timeout seconds the connection to is still refused\n";
                $this->stop;
                die sprintf "The start of %s failed\n", $this->name;
            }
        }
        else {
            my $data = $res->code == 200
                && eval { from_json( $res->decoded_content ) };
            if ( !$data ) {
                warn sprintf
                    "I got an invalid response from a status url: %s\n%s\nI try to stop the daemon\n",
                    $res->as_string,
                    $this->tail_error_log;
                $this->stop;
                die sprintf "The start of %s failed\n", $this->name;
            }
            elsif ( $data->{status} ne 'OK' ) {
                warn
                    "Some problem with psgi app: $data->{error}\nI try to stop the daemon\n";
                $this->stop;
                die sprintf "The start of %s failed\n", $this->name;
            }
            elsif ( $started > $data->{loaded} ) {
                if ($too_long) {
                    die sprintf
                        "Restart of %s failed: I still got the response from the old invocation\n",
                        $this->name;
                }
            }
            else {
                # The OK case
                last CHECK;
            }
        }

        die sprintf "Start of %s timeouted without certain reason"
            if $too_long;
        sleep(1);
    }
}

sub fetch_status_url {
    my $this = shift;

    my $ua  = LWP::UserAgent->new(timeout => 30);
    my $url = $this->status_url;
    my $res = $ua->get($url);
    return $res;
}

sub status_url {
    my $this = shift;
    return 'http://localhost:' . ( $this->get_ports )[0] . $this->status_path;
}

# the path from which I get the status
# must be constant
sub _build_status_path {
    my $this = shift;
    return '/' . join( '-', split /::/, __PACKAGE__ ) . '-status';
}

# displays status (and configuration)
sub do_status {
    my $this = shift;

    my $pid = $this->pid_running;
    my $message
        = join "\n",
        "Server "
        . $this->name . ' '
        . ( $pid ? "running, pid $pid" : "not running" ),
        '------------------------------------',
        'port        : ' . (join ' ', $this->get_ports),
        'psgi        : ' . ($this->psgi_app || 'CODE'),
        'access_log  : ' . $this->access_log,
        'error_log   : ' . $this->error_log,
        'pid_file    : ' . $this->pid_file,
        '';
    print $message;
}

__PACKAGE__->meta->make_immutable;
1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
