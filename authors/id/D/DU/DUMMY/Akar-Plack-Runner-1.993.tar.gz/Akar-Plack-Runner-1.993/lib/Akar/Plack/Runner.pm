package Akar::Plack::Runner;
{
  $Akar::Plack::Runner::VERSION = '1.993';
}
use Moose;
use namespace::autoclean;

# ABSTRACT: start/stop/restart of webserver (starman + psgi) with checks

# very simple plackup (starman) wrapper handling just name of logs, ...
use File::Slurp qw(slurp write_file);
use Akar::Base;
use FileHandle;
use Akar::CLI;
use Path::Class;
use Akar::Types::PathClass qw(file_type dir_type);
use Plack::Util ();
use JSON;
# used to detect whether 
use LWP::UserAgent;
use Data::Dump qw(pp);

# base name of the application

# all directories are derived from the name
has name => ( is => 'ro', required => 1 );

has port => (is => 'ro', required => 1);

# runner can be run on more than one port 
# (to be used sparingly, only when we need to merge some existing services)
has other_ports => (
    is      => 'ro',
    isa     => 'ArrayRef',
    default => sub { return [] },
);

# how many workers starman has
has workers => ( is => 'ro', isa => 'Int' );

has data_root => (
    is         => 'ro',
    lazy_build => 1,
    isa        => dir_type( mkpath => 1 ),
    coerce     => 1
);

# psgi_app is a file
has psgi_app => (
    is         => 'ro',
    lazy_build => 1,
    isa        => file_type( must_exists => 1 ),
    coerce     => 1
);

has log_dir => (
    is         => 'rw',
    lazy_build => 1,
    isa        => dir_type( mkpath => 1 ),
    coerce     => 1
);

has access_log => (
    is         => 'rw',
    lazy_build => 1,
    isa        => file_type( dir_exists => 1 ),
    coerce     => 1
);

has error_log => (
    is         => 'rw',
    lazy_build => 1,
    isa        => file_type( dir_exists => 1 ),
    coerce     => 1
);

has pid_file => (
    is         => 'rw',
    lazy_build => 1,
    isa        => file_type( dir_exists => 1 ),
    coerce     => 1
);

has status_file => ( is => 'rw', lazy_build => 1 );

has max_stop_timeout => (is => 'rw', default => 60);

has max_start_timeout => (is => 'rw', default => 20);

# preloads app and runs starman via start server
has preload_app => ( is => 'rw', isa => 'Bool', default => 0 );

# wraps psgi so we can check whether service is running 
has psgi_wrapped => (
    is => 'ro',
    isa => 'Bool', 
);

# 2013-05-10 danielr, this is quite a hack
# for Durian when I need more than one port
# and I don't want to touch Durian and add
# new config parameters
around BUILDARGS => sub {
    my $orig  = shift;
    my $args  = $orig->(@_);
    my $ports = $args->{port};
    if ( ref $ports && ref $ports eq ref [] ) {
        my ( $port, @other_ports ) = @$ports;
        @$args{qw(port other_ports)} = ( $port, \@other_ports );
    }

    return $args;
};

sub _build_data_root {
    my $this = shift;
    return Akar::Base->app_data( $this->name );
}

sub _build_psgi_app {
    my $this = shift;
    
    return Akar::Base->app_config( $this->name . '.psgi');
}

# builders
sub _build_log_dir {
    my $this = shift;

    return $this->data_root->subdir('logs');
}

sub _build_error_log {
    my $this = shift;
    return $this->log_dir->file('error_log');
}

sub _build_access_log {
    my $this = shift;
    return $this->log_dir->file('access_log');
}

sub _build_pid_file {
    my $this = shift;

    $this->data_root->file($this->name. '.pid');
}

sub _build_status_file {
    my $this = shift;

    $this->log_dir->file($this->name. '.status');
}

sub build_cli {
    my $this = shift;

#    require Server::Starter;
    #use Server::Starter qw(restart_server start_server);
    my $cli = Akar::CLI->new();
    $cli->add_action(
        'start - starts the server',
        sub {
            $this->do_start();
        }
    );
    $cli->add_action(
        'restart - restarts the server',
        sub {
            $this->do_restart();
        }
    );
    $cli->add_action(
        'stop - stops the webserver',
        sub { $this->do_stop(); }
    );

    $cli->add_action(
        'status - displays basic status',
        sub {
            $this->do_status();
            return;
        }
    );

    my $error_log = $this->error_log;
    return $cli;
}

sub do_start {
    my $this = shift;

    die $this->name . ' already running' if $this->get_pid;

    $this->write_psgi_app_wrapped;
    my $psgi_app = $this->psgi_app_wrapped;
    $this->check_psgi_app($psgi_app);
    
    my $loaded = time();
    $this->_do_start();
    $this->wait_until_started($loaded);
}

sub get_all_ports {
    my $this = shift;
    return ( $this->port, @{ $this->other_ports } );
}

sub _do_start {
    my $this = shift;

    my @args = (
        ( map { ("--listen" => ":$_"); } $this->get_all_ports ), 
        '--daemonize',
        '--access-log' => $this->access_log,
        '--error-log'  => $this->error_log,
        '--pid'        => $this->pid_file,
        ( $this->workers ? ( '--workers' => $this->workers ) : () ),
        $this->psgi_app_wrapped,
    );

    my $cmd = join( ' ', 'starman', @args );
    system("$cmd") == 0 or die "Running starman failed\n";
}

sub start_command {}

# displays status (and configuration)
sub do_status {
    my $this = shift;

    my $pid = $this->get_pid;
    my $message
        = join "\n",
        "Server "
        . $this->name . ' '
        . ( $pid ? "running, pid $pid" : "not running" ),
        '------------------------------------',
        'port        : ' . (join ' ', $this->get_all_ports),
        'psgi_file   : ' . $this->psgi_app,
        'access_log  : ' . $this->access_log,
        'error_log   : ' . $this->error_log,
        'pid_file    : ' . $this->pid_file,
        '';
    print $message;
}

sub do_restart {
    my $this = shift;

    $this->do_gracefull_restart;
}

sub do_stop {
    my $this = shift;

    my $pid = $this->get_pid();
    if (!$pid){
        warn "No pid of running process\n";
        return;
    }

    kill 'TERM', $pid or die "Killing start_server failed\n";
    $this->wait_until_stopped($pid);
}

sub wait_until_stopped {
    my ( $this, $pid ) = @_;

    # we wait til there is no live pid 
    $this->_wait_until(
        sub {
            my $p = $this->get_pid;
            return not($p && $p == $pid);
        },
        $this->max_stop_timeout,
    ) and return;

    die "Even after "
        . $this->max_stop_timeout
        . " seconds webserver doesnot stopped, you should check the stop manually\n";
}

# returns server starter pid
sub get_pid {
    my $this = shift;
    -f $this->pid_file or return;
    my ($line) = slurp $this->pid_file or return;
    my ($pid) = $line =~ /^(\d+)/ or return;

    # no process exists
    kill 0, $pid or return;
    return $pid;
}

# tries to load the psgi_app in independent process
# forks itself 
# child loads the psgi application and sends the status to parent in JSON
sub check_psgi_app {
    my ($this, $psgi_app) = @_;

    $psgi_app ||= $this->psgi_app;

    my $json = JSON->new;
    my $pid = open( my $fh, '-|' );
    if ($pid) {

        # parent reads the JSON status from child
        my $data = $json->decode( scalar slurp $fh );
        die "Loading psgi (" . $this->psgi_app . ") failed: " . $data->{error}
            if !$data->{ok};
        return 1;
    }
    elsif ( !defined $pid ) {
        die "Checking psgi: Fork failed: $!\n";
    }
    else {

        # child process
        # I will keep the descriptor to parent and close STDOUT and STDERR
        open( $fh, '>&1' ) or die "Can't dup STDOUT";
        open( STDOUT, '>', '/dev/null' ) or die "Can't close STDOUT";
        open( STDERR, '>&1' ) or die "Can't dup STDERR";

        eval { $this->load_psgi_app($psgi_app); };
        my $err = $@;
        print $fh $json->encode( { ok => !$err, error => $err // "$err" } );
        exit(0);
    }
}

sub load_psgi_app {
    my ($this, $psgi_app) = @_;

    $psgi_app ||= $this->psgi_app;
    my $app = Plack::Util::load_psgi( $psgi_app );
    ref $app && ref $app eq 'CODE'
        or die "psgi application is not a coderef\n ";
    return $app;
}

sub do_hard_restart {
    my $this = shift;

    $this->check_psgi_app();
    $this->do_stop if $this->get_pid;
    $this->do_start;
}

sub do_gracefull_restart {
    my $this = shift;

    $this->check_psgi_app();
    my $pid = $this->get_pid;
    if (!$pid){
        $this->do_start;
        return;
    }

    # real graceful restart
    my $loaded = time();

    $this->_do_gracefull_restart;

    $this->wait_until_started($loaded);
}

sub _do_gracefull_restart {
    my $this = shift;
    kill HUP => $this->get_pid;
}

# waits until condition returns true
# returns false if timeout occured
sub _wait_until {
    my ( $this, $condition, $max_timeout ) = @_;

    my $started = time();
    my @int = ( 1, 1 );
    my $ret;
    while ( not( $ret = $condition->() )
        && time() - $started <= $max_timeout )
    {
        push @int, $int[0] + $int[1];
        sleep shift @int;
    }
    return $ret;
}

sub runner_status_url {
    my $this = shift;
    return 'http://localhost:'. $this->port. $this->runner_status_path;
}

# must be constant
sub runner_status_path {
    my $this = shift;
    return '/'. join('-', split /::/, __PACKAGE__). '-status';
}


sub fetch_runner_url {
    my $this = shift;

    my $ua = LWP::UserAgent->new;
    my $url = $this->runner_status_url;
    my $res = $ua->get($url);
    return $res;
}

sub wait_until_started {
    my ($this, $min_loaded) = @_;

    my ( $res, $data, $loaded );
    my $json = JSON->new;
    $this->_wait_until(
        sub {
            $res = $this->fetch_runner_url or return;
            $res->code == 200 or return;

            $data = eval { $json->decode( $res->decoded_content ) }
                or return 0;    # we won't check further
            $loaded = $data->{loaded} or return 0;
            
            # we found it
            my $ok = !defined $min_loaded || $min_loaded <= $loaded;
            return $ok;
        },
        $this->max_start_timeout
    ) and return;

    die "Even after blah the script doesnot started\n";
}

# application wrapped which provides the "server_status" like URL
has psgi_app_wrapped => (
    is         => 'rw',
    lazy_build => 1,
    isa        => file_type( dir_exists => 1 ),
    coerce     => 1
);

sub _build_psgi_app_wrapped {
    my $this = shift;

    return $this->data_root->file($this->name. '-wrapped.psgi');
}

sub write_psgi_app_wrapped {
    my $this = shift;

    write_file($this->psgi_app_wrapped, $this->psgi_app_wrapped_content);
}

# write the psgi_app file wrapped
sub psgi_app_wrapped_content {
    my $this = shift;

    my $the_in = pp(
        psgi_app           => $this->psgi_app . '',
        runner_status_path => $this->runner_status_path . '',
    );

    return join "\n", <<'END_PSGI_HEADER',
use strict;
use warnings;
use Plack::Util ();
use JSON;
END_PSGI_HEADER

        "my %IN = $the_in;\n",

        <<'END_PSGI',
my $loaded = time();
my $json   = JSON->new;
my $app = Plack::Util::load_psgi($IN{psgi_app});
ref $app && ref $app eq 'CODE' or die "$IN{psgi_app} doesnot return coderef\n ";

sub {
    my $env = shift;
    $env->{PATH_INFO} eq $IN{runner_status_path}
            && $env->{REQUEST_METHOD} eq 'GET'
            or return $app->($env);

        return [ 200, [], [ $json->encode( { loaded => $loaded, pid => $$ } ) ] ];
    };
END_PSGI
    ;
}

__PACKAGE__->meta->make_immutable;

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
