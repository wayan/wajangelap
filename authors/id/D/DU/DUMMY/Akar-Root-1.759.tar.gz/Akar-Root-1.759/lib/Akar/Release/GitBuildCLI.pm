package Akar::Release::GitBuildCLI;
{
  $Akar::Release::GitBuildCLI::VERSION = '1.759';
}
use strict;
use warnings;

use Akar::Release::GitBuild;
use Akar::CLI;
use Cwd qw/abs_path/;

# command line interface for Akar::Release::GitBuild
sub build_cli{
    my $this    = shift;
    my $subject = shift || 'Akar::Release::GitBuild';

    my $cli = Akar::CLI->new;
    $cli->add_option('!config|c=s - config in *.yml file');
    $cli->add_action(
        'build - builds the archive',
        sub { $this->build_cli_archive($subject, @_) }
    );
    return $cli;
}

sub build_cli_archive {
    my $this        = shift;
    my $subject     = shift;
    my $script_call = shift;

    my $config_file = $script_call->value_of('config');
    my $config      = YAML::LoadFile($config_file);

    # required for relative path 
    $config->{__config_filename} = abs_path($config_file);

    my $build = $subject->new($config);
    $build->pack();
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 



