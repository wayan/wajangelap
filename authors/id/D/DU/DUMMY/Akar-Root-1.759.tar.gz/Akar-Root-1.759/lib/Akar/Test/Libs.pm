package Akar::Test::Libs;
{
  $Akar::Test::Libs::VERSION = '1.759';
}
use strict;
use warnings;

use File::Spec;
use File::Basename qw(dirname);
use Cwd qw(realpath);

# uses all lib dirs from the script up to lib directory in the build

# if called from test script t/level1/level2/t01.t
# it is equivalent to 
# use qw(t/level1/level2/lib t/level1/lib t/lib ./lib)

use FindBin qw($Bin);
require lib;

# to be used from test scripts only
my $max_levels = 5;

sub import {
    shift();

    my %params = @_;

    my @dirs;
    #my $dir = dirname((caller)[1]); # caller's dir
    my $dir = $Bin; # script dir

    # go maximum 5 levels or until I find t lib
    my $module_dir;
    for my $level ( 1 .. $max_levels ) {
        push @dirs, realpath("$dir/lib") if -d "$dir/lib";
        if (-d "$dir/t"){
            # show stopper
            $module_dir = $dir;
            last;
        }
        $dir = File::Spec->rel2abs('..', $dir);
    }
    # we can add also dirs from other modules 
    if ($module_dir ){
        push @dirs, grep { -d $_ } map { "$module_dir/$_/lib"; }
            map { ref $_ ? @$_ : $_ } grep {$_} $params{modules};
    }
    lib->import(@dirs);
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
