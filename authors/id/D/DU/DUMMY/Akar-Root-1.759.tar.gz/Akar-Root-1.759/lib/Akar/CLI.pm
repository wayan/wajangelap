package Akar::CLI;
{
  $Akar::CLI::VERSION = '1.759';
}
use strict;
use warnings;

use base qw(Akar::Class::Accessor);

use Carp qw(carp croak);
use List::MoreUtils qw(first_value uniq indexes);
use Class::ISA;
use Getopt::Long qw(GetOptions);
use Scalar::Util qw(blessed);
use File::Basename qw(basename);
use Pod::Usage qw(pod2usage);
use Pod::Text;
use IO::Scalar;
use Scalar::Util qw(weaken);

use Akar::CLI::_Option;
use Akar::CLI::_OptionGroup;
use Akar::CLI::_Action;
use Akar::CLI::_Arg;
use Akar::List::Utils qw(pop_options grep_values);
use Akar::Class::Utils qw(require_package);
use Interpolation 'E' => 'eval';
# for script_call
use Class::Prototyped;

use Akar::CLI::Exceptions qw(
    throw_duplicit_option
    throw_help
    throw_invalid_optspec
    throw_invalid_actionspec
    throw_invalid_groupspec
    throw_invalid_argspec
    throw_invalid_options
    throw_more_rep_args
    throw_no_actions 
    throw_no_option
    throw_required_option_missing
);

# local constants
my $OPTION_CLASS       = 'Akar::CLI::_Option';
my $OPTION_GROUP_CLASS = 'Akar::CLI::_OptionGroup';
my $ACTION_CLASS       = 'Akar::CLI::_Action';
my $ARG_CLASS          = 'Akar::CLI::_Arg';

######################################################################
# Building script - adding options, groups, ....
######################################################################

__PACKAGE__->mk_accessors(qw(script_name title description));

# one list of options, option groups, arguments, ...
__PACKAGE__->mk_ro_accessors(qw(optionlikes optionlike_index));

# the name of default action
__PACKAGE__->mk_accessors(qw(default_action));

__PACKAGE__->mk_accessors(qw(has_bare_actions));

# action handler - called for every action
__PACKAGE__->mk_accessors(qw(on_action));

# run handler - called once
__PACKAGE__->mk_accessors(qw(on_run));

# list of requirements (option1 requires option2 or option3 ...)
__PACKAGE__->mk_ro_accessors(qw(requirements));


sub new {
    my ( $package, $fields ) = @_;

    $fields ||= {};
    my $cli = $package->SUPER::new(
        {   'optionlikes'      => [],
            'optionlike_index' => {},
            'script_name'      => basename($0),
            'requirements'     => [],
            %{$fields},
        }
    );

    # 2008-04-02 danielr
    # the circular references which prevents the cleanup of cli objects
    # are perhaps generally inevitable, but I can prevent them here at least.
    my $cli_weak = $cli;
    weaken($cli_weak);
    $cli->add_option(
        'help - Help',
        {   'on_parse' => sub { throw_help($cli_weak); }
        }
    );
    return $cli;
}

# returns the list of the options, option_groups, actions, arguments
sub optionlikes { return @{ shift()->_optionlikes_accessor } }

sub options {
    return grep { $_->isa($OPTION_CLASS) } shift()->optionlikes;
}

sub option_groups {
    return grep { $_->isa($OPTION_GROUP_CLASS) } shift()->optionlikes;
}

sub args {
    return grep { $_->isa($ARG_CLASS) } shift()->optionlikes;
}

sub actions {
    return grep { $_->isa($ACTION_CLASS) } shift()->optionlikes;
}

sub has_bare_actions {
    my ($this) = @_;

    my $has_ba = $this->_has_bare_actions_accessor;
    return defined $has_ba ? $has_ba : $this->actions && !$this->args;
}

sub get_optionlike {
    my ( $this, $name_or_option ) = @_;

    return $this->optionlike_index->{"$name_or_option"};
}

sub get_option {
    my ( $this, $name_or_option ) = @_;

    my $option = $this->get_optionlike($name_or_option);
    $option && $option->isa($OPTION_CLASS)
        or throw_no_option( $this, 'option' => "$name_or_option" );
    return $option;
}

sub get_option_group {
    my ( $this, $name_or_option ) = @_;

    my $option_group = $this->get_optionlike($name_or_option);
    $option_group && $option_group->isa($OPTION_GROUP_CLASS)
        or throw_no_option( $this, 'option' => "$name_or_option" );
    return $option_group;
}

sub get_action {
    my ( $this, $name_or_option ) = @_;

    my $action = $this->get_optionlike($name_or_option);
    $action && $action->isa($ACTION_CLASS)
        or throw_no_option( $this, 'option' => "$name_or_option" );
    return $action;
}

# parses '!from|f=s{Date}% - Date of beggining' to 
# {
#   'name' => from,
#   'is_mandatory' => 1,
#   'arg_name' => Date,
#   'title' => 'Date of of beginning'
# }
sub parse_optspec {
    my ( $package, $ext_optspec ) = @_;

    my ($is_mandatory, $the_names, $name,     $opt_modifiers,
        $optionality,  $type,      $arg_name, $storage_type,
        $title,        $description
        )
        = $ext_optspec =~ m{
        \A 
        (!)?                                # mandatory flag
        (
            (\w+[\w-]*)                     # option name
            (?: \| (?: \w[\w-]* | \? ))*    # alternatives
        )
        (?:
            ([!+])                          # parameter-less option
            | ([:=])                        # optionability
              (\w+(?:::\w+)*)               # type - actually Perl package
              (?:{(.*?)})?                  # argument name (optional)
              (\%|\@)?                      # storage type (@ %)
            | 
        )
        # documentation
        (?:
            \s+(?:-\s+)?
            (.+?)                           # title up to empty line
            (?:\s*\n)?                      # stripping spaces and line from title
            (?:
                \s*^(?:\s+)^\s*             # this is the empty line
                (.*?)                       # description
                \s* 
            )?
            |
                                            # or no doc at all
        )
        \z 
    }smx
        or throw_invalid_optspec( $package, 'optspec' => $ext_optspec );

    # Type is either sif Getopt::Long or package or existing type
    # optspec for get opt long
    my $type_package;
    my $getopt_type;
    if ($type) {
        if ( $type =~ /^.$/ ) {

            # ordinary Getopt::Long type
            $getopt_type = $type;
        }
        else {

            # special types
            $type_package =
                  $type =~ /::/
                ? $type
                : 'Akar::CLI::_OptionType::' . $type;
            require_package($type_package);
            $getopt_type = 's';
            $arg_name ||= $type_package->arg_name;
        }
    }
    my $optspec = $the_names
        . (
          $opt_modifiers ? $opt_modifiers
        : $type ? $optionality . $getopt_type . ( $storage_type || '' )
        : ''
        );

    return {
        grep_values { defined($_) }
            'type_package' => $type_package,
        'name'             => $name,
        'is_mandatory'     => $is_mandatory,
        'title'            => $title,
        'arg_name'         => $arg_name,
        'description'      => $description,
        'is_documented'    => ( $title || $description ? 1 : 0 ),
        'variants' => [ split /\|/, $the_names ],
        'optspec'  => $optspec,
    };
}

sub parse_groupspec {
    my ( $package, $ext_groupspec ) = @_;

    my ( $is_mandatory, $name, $title, $description ) = $ext_groupspec =~ m{
        \A 
        (!)?                            # mandatory flag
        (\w+[\w-]*)                     # option name

        # documentation
        (?:
            \s+(?:-\s+)?
            (.+?)                           # title up to empty line
            (?:\s*\n)?                      # stripping spaces and line from title
            (?:
                \s*^(?:\s+)^\s*             # this is the empty line
                (.*?)                       # description
                \s* 
            )?
            |
                                            # or no doc at all
        )
        \z 
    }smx
        or throw_invalid_groupspec( $package, 'groupspec' => $ext_groupspec );

    return {
        grep_values { defined($_) }
        'name'          => $name,
        'is_mandatory'  => $is_mandatory,
        'title'         => $title,
        'description'   => $description,
        'is_documented' => ( $title || $description ? 1 : 0 ),
    };
}

sub parse_actionspec {
    my ( $package, $ext_actionspec ) = @_;

    my ( $the_names, $name, $title, $description ) = $ext_actionspec =~ m{
        \A 
        (
            (\w+[\w-]*)                     # option name
            (?: \| (?: \w[\w-]* | \? ))*    # alternatives
        )
        # documentation
        (?:
            \s+(?:-\s+)?
            (.+?)                           # title up to empty line
            (?:\s*\n)?                      # stripping spaces and line from title
            (?:
                \s*^(?:\s+)^\s*             # this is the empty line
                (.*?)                       # description
                \s* 
            )?
            |
                                            # or no doc at all
        )
        \z 
    }smx
        or throw_invalid_actionspec( $package, 'actionspec' => $ext_actionspec );

    return {
        'name'          => $name,
        'title'         => $title,
        'description'   => $description,
        'is_documented' => ( $title || $description ? 1 : 0 ),
        'variants' => [ split /\|/, $the_names ],
        'optspec'  => $the_names,
    };
}

# parses '!file - modified files' to 
# {
#   'name' => 'file',
#   'is_mandatory' => 1,
#   'title' => 'modified files'
# }
sub parse_argspec {
    my ( $package, $argspec ) = @_;

    my ( $is_mandatory, $name, $is_repetitive, $title, $description )
        = $argspec =~ m{
        \A 
        (!)?                                # mandatory flag
        (\w+[\w-]*)                         # argument name
        (\.\.\.)?                           # repetititive argument
        # documentation
        (?:
            \s+(?:-\s+)?
            (.+?)                           # title up to empty line
            (?:\s*\n)?                      # stripping spaces and line from title
            (?:
                \s*^(?:\s+)^\s*             # this is the empty line
                (.*?)                       # description
                \s* 
            )?
            |
                                            # or no doc at all
        )
        \z 
    }smx
        or throw_invalid_argspec( $package, 'argspec' => $argspec );

    return {
        'name'          => $name,
        'is_repetitive' => $is_repetitive,
        'is_mandatory'  => $is_mandatory,
        'title'         => $title,
        'description'   => $description,
        'is_documented' => ( $title || $description ? 1 : 0 ),
    };
}

sub add_option {
    my $this = shift;

    # if the first arg is the blessed object it is the option object
    #my ($possible_object) = @_;
    #return $this->_add_option($possible_object)
    #    if ref($possible_object) && blessed($possible_object);

    # if the last arg is unblessed hash it is the options
    my $fields = pop_options( \@_ )           || {};

    # first parameter is the optspec
    my %params = @_ ? %{ $this->parse_optspec( shift(@_) ) } : ();

    # first argument if present is optspec
    return $this->_add_optionlike(
        $OPTION_CLASS->new(
            $this,
            {   'is_documented' => 1,
                %{$fields},
                %params,
            }
        )
    );
}

# creates list of optionlike names
sub _optionlike_list {
    my ( $this, @optionlikes ) = @_;

    my %exists;
    return map {
        my $name = ref($_) ? $_->name : $_;
        throw_no_option( $this, 'option' => $name )
            if !$this->optionlike_index->{$name};

        die "Duplicit option $name "
            if $exists{$name}++;

        $name;
    } @optionlikes;
}

sub default_action {
    my ($this) = @_;

    return $this->_default_action_accessor
        || ( $this->actions )[0]->name;
}

sub set_default_action {
    my ( $this, $default_action ) = @_;

    my ($action) = $this->get_optionlike($default_action)
        or die "No action $default_action\n ";
    $action->isa($ACTION_CLASS)
        or die "$default_action is not action\n ";
    $this->_default_action_mutator( $action->name );
}

# adds new script action
sub add_action {
    my $this = shift;

    # last arg may be options hash
    my $fields = pop_options( \@_ ) || {};

    my $actionspec = shift();

    # if there is next argument and it is code it is on_run sub
    my %params;
    if ( @_ && UNIVERSAL::isa( $_[0], 'CODE' ) ) {
        $params{'on_run'} = shift(@_);
    }

    my $action = $ACTION_CLASS->new(
        $this,
        {   %{ $this->parse_actionspec($actionspec) },
            %params,
            %{$fields},
        }
    );

    return $this->_add_optionlike($action);
}

sub _add_optionlike {
    my ( $this, $optionlike ) = @_;

    my $name = $optionlike->name;
    throw_duplicit_option( $this, 'option' => $name )
        if $this->optionlike_index->{$name};

    push @{ $this->_optionlikes_accessor }, $optionlike;
    $this->optionlike_index->{$name} = $optionlike;
    return $optionlike;
}

my $group_no = 0;

sub add_option_group {
    my $this = shift;

    # last arg may be options hash
    my $fields = pop_options( \@_ ) || {};

    # first argument if not reference is group spec
    my %params =
        ( @_ && !ref( $_[0] ) )
        ? %{ $this->parse_groupspec( shift() ) }
        : ( 'name' => "_group $E{ ++$group_no }" );

    # next argument if array is option list
    my $options_ref = delete($fields->{'options'})
        || ( @_ && UNIVERSAL::isa( $_[0], 'ARRAY' ) 
                ? shift(@_): []
            );

    my $option_group = $OPTION_GROUP_CLASS->new(
        $this,
        {   'is_documented' => 0,
            %params,
            'options' => [ $this->_optionlike_list( @{$options_ref} ) ],
            %{$fields},
        }
    );

    return $this->_add_optionlike( $option_group);
}


sub add_arg {
    my $this = shift;

    # if the last arg is unblessed hash it is the options
    my $fields = pop_options( \@_ )           || {};

    # first arg is the optspec
    my %params = @_ ? %{ $this->parse_argspec( shift(@_) ) } : ();

    return $this->_add_optionlike(
        $ARG_CLASS->new(
            $this,
            {   'is_documented' => 1,
                %params,
                %{$fields},
            }
        )
    );
}

######################################################################
# Running script 
######################################################################

sub run {
    my ( $this, @args ) = @_;

    no warnings 'redefine';
    no strict   'refs';

    my $script_call; 
    eval {
        $script_call = $this->parse_args(@args);
        $this->check_options($script_call);
    };

    my $e;
    if ( $e = Akar::CLI::Exception::Help->caught() ) {
        $this->print_help();
        return 1;
    }
    elsif ( $e = Exception::Class->caught ) {
        die $e;
    }

    if (my $on_run_sub = $this->on_run){
        # no actions
        $on_run_sub->($script_call);
    }
    elsif ( my @actions = $this->actions ) {
        for my $action_name ( $script_call->actions(1) ){
            my $action = $this->get_action($action_name);

            my $action_handler = $action->on_run || $this->on_action
                or die "No handler for action $E{ $action->name }\n ";
            $action_handler->($script_call, $action_name);
        }
    }
    else {
        # no actions
        throw_no_actions($this);
    }
}

sub check_requirement {
    my ( $this, $script_call, $requiring, @required ) = @_;

    return
        if defined($requiring) && !defined $script_call->value_of($requiring);

    grep { defined $script_call->value_of($_) } @required
        or die(
        (   defined($requiring)
            ? "Option $requiring: "
            : "Script " . $this->script_name
        )
        . " missing one of required options $E{ join ', ', @required}\n "
        );
}

sub check_options {
    my ($this, $script_call) = @_;

    # mandatory options, groups, ...
    for my $option ( grep { $_->is_mandatory } $this->optionlikes  ){
        defined $script_call->value_of($option->name)
            or throw_required_option_missing($this, 'option' => $option->name);
    }

    # requirements 
    for my $requirement ( @{ $this->requirements } ) {
        $this->check_requirement( $script_call, @{$requirement});
    }

    return;
}

######################################################################
# Documentation, help
######################################################################

sub print_help {
    my ($this) = @_;

    my $script_doc    = $this->compose_script_doc();
    my $script_doc_fh = IO::Scalar->new( \$script_doc );

    my $pod_parser = Pod::Text->new;
    $pod_parser->parse_from_filehandle( $script_doc_fh, \*STDERR );
    return (1);
}

# returns script documentation in POD
sub compose_script_doc {
    my ($this) = @_;

    # already displayed options
    my %displayed;

    # options in groups
    my @doc_groups;
    for my $group ( grep { $_->is_documented } $this->option_groups ) {
        push @doc_groups, $group;
        for my $option ( $group, $group->options ) {
            $displayed{ $option->name } = 1;
        }
    }

    my @doc_actions;
    for my $action (
        grep { $_->is_action && $_->is_documented && !$displayed{ $_->name } }
        $this->options
        )
    {
        push @doc_actions, $action;
        $displayed{ $action->name } = 1;
    }

    my @doc_options;
    for my $option ( grep { $_->is_documented && !$displayed{ $_->name } }
        $this->options )
    {
        push @doc_options, $option;
        $displayed{ $option->name } = 1;
    }

    # synopsis is indented (POD verbatim section)
    my $synopsis = $this->script_synopsis;
    $synopsis =~ s/^/    /mg;

    my @paras = (
        '=head1 NAME',
        join( ' - ', grep {$_} $this->script_name, $this->title),
        '=head1 SYNOPSIS',
        $synopsis,
        (   $this->description
            ? ( '=head1 DESCRIPTION', $this->description )
            : ()
        ),
        '=head1 OPTIONS'
    );
    if (@doc_actions) {
        push @paras, '=head2 Actions', '=over 4',
            ( map { $_->compose_doc } @doc_actions ), '=back';
    }
    if (@doc_groups) {
        push @paras, map { $_->compose_doc } @doc_groups;
    }
    if (@doc_options) {
        if ( @doc_groups || @doc_actions ) {
            push @paras, '=head2 Other options';
        }
        push @paras, '=over 4', ( map { $_->compose_doc } @doc_options ),
            '=back';
    }
    if ( my @args = $this->args ) {
        push @paras, '=head2 Arguments', '=over 4',
            ( map { $_->compose_doc } @args ), '=back';
    }
    return join "\n\n", @paras;
}

# return script synopsis
sub script_synopsis {
    my ($this) = @_;

    # action goes first
    my ( @synopsis, @action_synopsis );
    for my $option ( $this->options ) {
        if ( $option->is_action ) {
            push @action_synopsis, $option->synopsis;
        }
        else {
            if ( $option->synopsis ) {
                push @synopsis, join( ' | ', $option->synopsis );
            }
        }
    }

    # actions goes first
    if (@action_synopsis) {
        unshift @synopsis, join( ' | ', @action_synopsis );
    }

    # parameters last
    if ( my @args = $this->args ) {
        push @synopsis, join ' ', map { $_->synopsis } @args;
    }

    return join "\n", $this->script_name, map {"  $_"} @synopsis;
}

#######################################################################


sub script_optspecs {
    my ( $this, $options_ref, $actions_ref ) = @_;

    my @optspecs;
    for my $option ( grep { $_->optspec } $this->options ) {

        my $on_parse = $option->on_parse;
        if ( $option->is_action ) {

            # action which is not bare
            $on_parse = sub {
                $options_ref->{ $option->name } = 1;
                push @{$actions_ref}, $option->name;
            };
        }
        elsif ( $option->type_package ) {
            $on_parse = sub {
                my ( $name, $value ) = @_;
                $options_ref->{ $option->name }
                    = $option->type_package->parse($value);
            };
        }

        push @optspecs, grep {$_} $option->optspec, $on_parse;
    }

    # actions
    if ( $this->has_bare_actions ) {
        # mapping variant => action
        my %variants = map {
            my $action = $_;
            map { ( $_ => $action->name ); } $action->variants;
        } $this->actions;

        # mapping prefix => [ action, action, action ]
        my %action_lookup;
        while ( my ( $variant, $action ) = each %variants ) {
            my @prefixes = map { substr( $variant, 0, $_ ) }
                    1 .. length($variant); 
            for my $prefix (@prefixes){
                push @{ $action_lookup{$prefix} }, $action;
            }
        }

        # if prefix equals complete variant it is preferred
        @action_lookup{ keys %variants } = map { [$_] } values %variants;

        push @optspecs, '<>' => sub {
            my ($arg) = @_;

            my $found = $action_lookup{$arg};
            croak "No action $arg,"
                . " available actions are: $E{ join ', ', $this->actions} \n"
                if !$found;
            croak "Action $arg is ambiguous ($E{ join ', ', @{$found}} )\n"
                if @{$found} > 1;

            my $action = $found->[0];
            $options_ref->{$action} = 1;
            push @{$actions_ref}, $action;
        };
    }

    return @optspecs;
}

# parse the arguments and returns the script_call object 
# (options, actions, args together)
sub parse_args {
    my ( $this, @args ) = @_;

    my @current_actions;
    my %current_options;
    my @optspecs
        = $this->script_optspecs( \%current_options, \@current_actions );

    # subs are sligthly modified
    # if there's an error it is stored and parsing is immediately finished
    # "standard way" via die in $SIG{__WARN__} doesn't work because
    # warn will textify any structural exception
    my $parsing_error;
    for my $sub ( grep { UNIVERSAL::isa( $_, 'CODE' ) } @optspecs ) {
        my $orig_sub = $sub;
        $sub = sub {
            eval { $orig_sub->(@_); };
            die '!FINISH'
                if $parsing_error = $@;    # this will stop parsing
        };
    }

    # options
    local @ARGV = @args;
    my $go = GetOptions( \%current_options, @optspecs );
    croak $parsing_error if $parsing_error;
    throw_invalid_options( $this ) if !$go;

    # groups
    my %current_option_groups = map {
        my $group = $_;
        my %group_value = map {
            my $name = $_->name;
            exists $current_options{$name}?
                ($name => $current_options{$name})
                : ();
        } $group->options;

        %group_value?
            ( $group => \%group_value): ();
    } $this->option_groups;

    my @args_left = @ARGV;
    my $arg_values_ref = $this->map_args(@args_left);

    # the names are different, value_of is everything together
    my %value_of
        = ( %current_options, %current_option_groups, %{$arg_values_ref}, );
    my %has_optionlike = map { ( $_->name => 1 ); } $this->optionlikes;
    return Class::Prototyped->new(
            # this should be used
            'value_of' => sub {
                my (undef, $name_or_obj) = @_;

                $has_optionlike{$name_or_obj}
                or die "Nothing with name $name_or_obj exists\n ";

                return $value_of{"$name_or_obj"};
            },
            'actions' => sub {
                my ( undef, $use_default_action ) = @_;
                return @current_actions
                    || !$use_default_action
                    ? @current_actions
                    : ( $this->default_action );
                },
            # this probably shouldn't
            'cli'        => sub { return $this },
            'options'    => sub { return \%current_options },
            'args'       => sub { return @args_left },
            'arg_values' => sub { return $arg_values_ref },
            'option_groups' => sub { return \%current_option_groups },
            'optionlikes'  => sub {
                return \%value_of;
            },
            'default_action' => sub {
                return $this->default_action;
            }
    );
}

sub map_args {
    my ( $this, @arg_values ) = @_;

    my @args = $this->args or return {};

    # very simple repetitive arguments parsing
    # there may be only one repetitive argument
    # usually the last one
    throw_multiple_rep_args($this)
        if 2 < grep { $_->is_repetitive } @args;

    my $value_idx = 0;
    my %arg_values;
    for my $arg (@args) {
        if ( $arg->is_repetitive ) {
            my @values;
            if ( @arg_values >= @args ) {

                # there is more args
                @values
                    = @arg_values[ $value_idx .. $value_idx + @ARGV - @args ];
                $value_idx += @arg_values - @args + 1;
            }
            $arg_values{ $arg->name } = \@values;
        }
        else {
            $arg_values{ $arg->name } = $arg_values[$value_idx];
            $value_idx++;
        }
    }

    return \%arg_values;
}

#------------------------------------------------------------------------------
#   option list (used in requirements, groups, ...)
#------------------------------------------------------------------------------

# constraints
sub _requires_any {
    my ( $this, $requiring, @required ) = @_;

    push @{ $this->requirements }, [ $this->_optionlike_list( $requiring, @required ) ];
}

sub _requires_all {
    my ( $this, $requiring, @required ) = @_;

    for my $required (@required) {
        $this->_requires_any( $requiring, $required );
    }
}

sub requires_any {
    my ( $this, @required ) = @_;

    push @{ $this->requirements }, [ undef, $this->_optionlike_list( @required ) ];
}

sub requires_all {
    my ( $this, @required ) = @_;

    for my $required (@required) {
        $this->requires_any( $required );
    }
}


1;

__END__

=head1 NAME

Akar::CLI - simple command line interface

=head1 SYNOPSIS

    use Akar::CLI;

    my $cli = Akar::CLI->new;
    $cli->set_title('Advanced queueing manager');

    # option added as Getopt::Long specifier with variants
    $cli->add_option('from|f=s');

    # option can be documented 
    $cli->add_option('to|to=s - the last day of the period');

    # even the option argument can be named
    $cli->add_option('middle|m=s{DAY} - the middle day of the period');

    # option can be groupped
    $cli->add_option_group('period', [qw(from to)]);

    # actions can be run without -
    $cli->add_action('show|s - shows all actions in supplied period');

    # what to do when action is called can be specified directly
    ....
    my $aq_package = ...
    $cli->add_action(
        'list|l - lists all messages in queue',
        sub {
            my ($script_call, $action) = @_;
            $aq_package->create_controller->list_messages();
        }
    );


    # options can be made mandatory globally (for the script)
    $cli->add_action('!username=s - name of the user who changed the records');

    # or for other action 
    $cli->add_action('userid=i - user changing the records');

    my $act_show = $cli->add_action('show|s - shows all actions in supplied period');

    # all options must be supplied
    $act_show->requires_all(qw(period username));
    
    # some option must be supplied 
    $act_show->requires_any(qw(username userid));

    # script can have arguments also
    $cli->add_arg('source_file - the input image file');
    
    # arguments (only one) can be made repetitive
    $cli->add_arg('file... - one or more files');

    # myscript.pl 
    
    #!/usr/bin/perl
    MyScript->run(@ARGV);

    # running script
    perl myscript.pl --help
    perl myscript.pl list --all
    perl myscript.pl show 


=head1 DESCRIPTION

Akar::CLI is the successor of Akar::Script (and Akar::Trait::Scriptmodule)
The main differences (advantages) are

=over 4

=item *

The documentation can be a part of the option specifier.

=item *

Command line help is generated from the option specifiers (and documentation)
not from POD. It means up-to-date help - even undocumented options
can be seen and guessed.

=item *

It is much simpler and cleaner than Akar::Trait::Scriptmodule.
The interface is a simple object, it is not mixed with the package,
which means shorter method names - no namespace clashes, 
scope (package(s) exist forever).

=item *

Some option checks (mandatory options, options required by other options)
can be added in a very simple way.

=item *

Options can be groupped and the group value used as whole.
This is usefull for "inherited" command line interfaces. 
The groups are rendered as sections in generated script documentation (help).

=item *

Script can have arguments also. 

=back

=head1 ATTRIBUTES

An attribute can be obtained via I<ATTRIBUTE> method and set via set_I<ATTRIBUTE> method

    my $title = $cli->title;
    $cli->set_title('Rating of all incoming calls'); 

Some attribute(s) may be even set in constructor 

    my $cli = Akar::CLI->new(
        {   'title'  => 'Rating of all incoming calls',
            'descr'  => 'This neat and sophisticated script, blah ...',
            'on_run' => sub {
                }
        }
    );

=over 4

=item title 

The title of the script used in documentation.

=item description

Script description;

=item on_run 

Handler for whole script. More in HANDLERS.

=item on_action 

Handler for one action. More in HANDLERS.

=item has_bare_actions

Determines whether actions are supplied with (has_bare_actions = 0)
or without (has_bare_actions = 1) leading hyphen.

    Durian-Call-Rate rerate -from 2008-03-11 -to 2008-03-12
    # versus
    Durian-Call-Rate -rerate -from 2008-03-11 -to 2008-03-12

With has_bare_actions = 0 we can have both actions and arguments.
If has_bare_actions is not set it considered 1 if script has actions
and no arguments, 0 otherwise.

=head1 METHODS 

=head2 Constructor

    my $cli = Akar::CLI->new(\%fields);

=head2 Options, actions, option groups and arguments

=over 4

=item add_option

Adds a new command line option for the scriptmodule.
Returns the option object created.

    $cli->add_option($option_specifier);

    $cli->add_option("!ifile|if=s{File} - Input file\n\n".
    "Input file from which the image data are read, ".
    "it can be simple text file or MS Excel (.xls) with one sheet."  );

$option_specifier is an option specifier as defined in 
L<GetOpt::Long>, with a few enhancements:

=over 4

=item *

Text in braces C<{}> after option argument specifier 
is considered as the name of the option argument and used in documentation.

=item *

Text after space (or after C<' - '>) is considered the option title 
and used in generated (POD) documentation.

=item *

Text after first blank line is considered the option description 
and used in generated (POD) documentation.

=item *

If the specifier is preceded by C<!> then the option is considered mandatory. 

=back

=item add_action

Adds a new command line action for the scriptmodule.

    $cli->add_action($action_specifier, \&action_handler)

$action_specifier has the same meaning as $option_specifier, 
except that there is no option argument. 

$action_handler is a reference to subroutine to be called when action
is supplied from command line.

=item add_arg

Adds a new command line argument for the scriptmodule.

    $cli->add_arg($arg_specifier)

arg_specifier is similar to option_specifier but there are no variants
(file|f) nor arguments (file|f=s). 

  $cli->add_arg('source_image - file to be manipulated with');
  $cli->add_arg('file... - file(s) to be processed');

If the name of the arguments ends with C<...>, the argument is repetitive.
The value of such argument is then the array of command line arguments.
There may be only one repetitive argument.

=item add_option_group

Adds a new option group for the scriptmodule.

    $cli->add_option_group($group_specifier, \@options_or_names );

The group_specifier is similar to option_specifier 
except that there are no variants nor option arguments. The second argument
is a list of option objects (returned by add_option method) or  
option names.

    $cli->add_option_group( 'period - The searched period',
        [qw(from to)] );
    # or even
    $cli->add_option_group(
        'period - The searched period',
        [   $cli->add_option(
                'from=s - the beginning of the period'),
            $cli->add_option('end=s  - the end of the period'),
        ]
    );

=back

=head2 Checks

Any option can be make mandatory by prepending the specifier by ! (exclamation
mark).

Additional requirements can be added via

    $cli->requires_any($option1, $option2, ...);
    $cli->requires_all($option1, $option2, ...);

    $option1->requires_any($option2, $option3, ...);
    $option1->requires_all($option2, $option3, ...);

=head2 Running the script

=over 4

=item run

    $cli->run(@ARGV);

Parses the command line options, checks them and runs appropriate handler.
It is approximately:

    sub run {
        my $this = shift;
        
        my $script_call = $this->parse_args(@_);
        $this->check_options($script_call);
        my $handler = ....
        $handler->($script_call, [$action]);
    }

=back

=head1 HANDLERS

There are two handlers on script, both being an anonymous subroutine:

=over 4

=item on_run

If set it is run once after arguments are parsed and options checked. 
In this case no other handler is implicitly called.
The handler is called like

    $handler->($script_call);

=item on_action

If set (and there are some actions defined) it is run for each action on a
command line:

    for my $action_name ($script_call->actions){
        $action_handler->($script_call, $action_name);
    }

=back

There can also be an on_run handler on any action. If supplied it is preferred
from on_action handler. It is also called.

    $action->on_run->($script_call, $action_name);

=head1 SCRIPT CALL

Any handler is given a script call context as its first argument.
The context has a few functions to extract the values of current call
options:

=over 4

=item value_of

    my $value = $script_call->value_of($optionlike);

Basic function used to get the value of option, option_group, action (0, 1),
argument. The argument of value_of is the name of option, ... or the option,
... object itself.

=item actions

    my @action = $script_call->actions($use_default_action);

Returns the list of names of actions supplied. If no action(s) are supplied
on command line and $use_default_action is set returns list with
default action.

=item args

    my @args = $script_call->args;

Returns script call arguments.

=item default_action

Returns the name of the default action.

=item cli

Returns the command line object itself (don't know why should it be needed).

=back

=head1 AUTHOR

=cut

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

