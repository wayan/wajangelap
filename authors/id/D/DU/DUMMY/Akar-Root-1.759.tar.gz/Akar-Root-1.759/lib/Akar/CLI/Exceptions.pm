package Akar::CLI::Exceptions;
{
  $Akar::CLI::Exceptions::VERSION = '1.759';
}
use strict;
use warnings;

use base qw(Exporter);

use Carp qw(carp croak);
use Exception::Class;

{

    # base class - every exception must know the script
    use Exception::Class 'Akar::CLI::Exception' =>
        { 'fields' => [qw(cli script)], };

    package Akar::CLI::Exception;
{
  $Akar::CLI::Exception::VERSION = '1.759';
}

    # the cli must be supplied as first parameter
    sub new {
        my ( $package, $cli, %fields ) = @_;

        return $package->SUPER::new(
            'cli'    => $cli,
            'script' => $cli->script_name,
            %fields
        );
    }
}


# defines new exception class with properly set full_message method
# it is a syntactic sugar just to avoid repetition of the name class 
# in full_message definition
sub define_script_exception {
    my ( $class, $definition ) = @_;

    $definition->{'isa'} ||= qw(Akar::CLI::Exception);

    Exception::Class->import( $class, $definition );
    if ( my $full_message = $definition->{'full_message'} ) {

        # subroutine
        my $full_message_sub =
            UNIVERSAL::isa( $full_message, 'CODE' )
            ? $full_message
            : do {
            my @fields;
            $full_message
                =~ s/\$(?:{(\w+)}|(\w+))/push @fields, $1 || $2; '%s'/esg;
            sub {
                my ($this) = @_;
                return sprintf $full_message . "\n", map { $this->$_ } @fields;
            };
            };

        # text
        no strict 'refs';
        *{ $class . '::full_message' } = $full_message_sub;
    }
}

define_script_exception 'Akar::CLI::Exception::Help' =>
    { 'alias' => 'throw_help' };

# No option with given name
define_script_exception 'Akar::CLI::Exception::NoOption' => {
    'fields'       => [qw(option)],
    'alias'        => 'throw_no_option',
    'full_message' => 'Script $script has no option --$option',
};

# Parsing errors
define_script_exception
    'Akar::CLI::Exception::InvalidOptspec' => {
    'fields'       => [qw(optspec)],
    'alias'        => 'throw_invalid_optspec',
    'full_message' => 'Invalid option specifier: $optspec',
    };

define_script_exception
    'Akar::CLI::Exception::InvalidActionspec' => {
    'fields'       => [qw(actionspec)],
    'alias'        => 'throw_invalid_actionspec',
    'full_message' => 'Invalid action specifier: $actspec',
    };

define_script_exception
    'Akar::CLI::Exception::InvalidArgspec' => {
    'fields'       => [qw(argspec)],
    'alias'        => 'throw_invalid_argspec',
    'full_message' => 'Invalid argument specifier: $argspec',
    };

define_script_exception
    'Akar::CLI::Exception::InvalidGroupspec' => {
    'fields'       => [qw(groupspec)],
    'alias'        => 'throw_invalid_groupspec',
    'full_message' => 'Invalid option group specifier: $groupspec',
    };

# end of parsing errors

define_script_exception 'Akar::CLI::Exception::NoActions' => {
    'alias'        => 'throw_no_actions',
    'full_message' =>
        'Script $script has neither action nor run_script_body method',
};

define_script_exception 'Akar::CLI::Exception::InvalidOptions' => {
    'alias'        => 'throw_invalid_options',
    'full_message' => 'Invalid options passed from command line',
};

# There may only one repetitive argument
define_script_exception 'Akar::CLI::Exception::MoreRepArgs' => {
    'isa'          => 'Akar::CLI::Exception',
    'alias'        => 'throw_more_rep_args',
    'full_message' => 'Script $script has more than one repetitive arguments',
};

define_script_exception 'Akar::CLI::Exception::DuplicitOption' => {
    'alias'        => 'throw_duplicit_option',
    'fields'       => [qw(option)],
    'full_message' => 'Script $script already has option $option',
};

define_script_exception 'Akar::CLI::Exception::RequiredOptionMissing' => {
    'alias'        => 'throw_required_option_missing',
    'fields'       => [qw(option)],
    'full_message' => 'Required option $option is missing',
};


#all throw_XYZ routines are exported on demand
{
    no strict 'refs';
    our @EXPORT_OK = grep { /^throw_/ && __PACKAGE__->can($_) }
        keys %{ __PACKAGE__ . '::' };
    push @EXPORT_OK, qw(define_script_exception);
}

1;

__END__

=head1 NAME

Akar::CLI::Exceptions - exceptions for cli

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
