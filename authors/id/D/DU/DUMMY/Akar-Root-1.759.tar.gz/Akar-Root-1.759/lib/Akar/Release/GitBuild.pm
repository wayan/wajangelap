package Akar::Release::GitBuild;
{
  $Akar::Release::GitBuild::VERSION = '1.759';
}
use strict;
use warnings;

use base qw(Class::Accessor::Grouped);

use File::Temp qw(tempdir);
use File::Spec;
use File::Basename qw(dirname basename);
use Data::Dump qw(pp);
use FileHandle;
use Cwd;
use File::Path;
use YAML;
use Class::C3;
use DateTime;
use Akar::CLI;
use List::MoreUtils qw(uniq);

use Akar::Base;

__PACKAGE__->mk_group_accessors(
    'simple', 'module_name', 'version', 'code',
    [ '_source_info', 'source_info' ],
    [ '_sources',     'sources' ],
    'services', 'post_install',
    '__config_filename'
);

=begin INPUT_STRUCT

{

 module_name => 'Durian',
 version => 'SK_razdva',
 sources => [
         {   
             name => 'Akar',
             repo => 'git@github.com:DAVOCZ/Akar.git',
             'tree_ish' => 'master',
             path => [
                 'perl/Core'
             ],
             install => [qw{perl/Core} ],
         },
         {
             name => 'Durian',
             repo => 'ssh://cvs@irsay.in.gtsgroup.cz/~cvs/git/Durian',
             'tree_ish' => '_migration',
             path => [
                 qw{perl/Core perl/site/gtssk}
             ],
             install => [qw{perl/Core perl/site/gtssk} ],
         },
     ],

}

=end INPUT_STRUCT

=begin INPUT_YAML

---
module_name: Durian
version: SK_razdva
services:
  - bin/*-Manager
  - bin/Durian-Umum-Transport-Processor
  - bin/Durian-Umum-Apache
sources:
  - install:
      - perl/Core
    name: Akar
    path:
      - perl/Core
    repo: git@github.com:DAVOCZ/Akar.git
    tree_ish: master
  - install:
      - perl/Core
      - perl/site/gtssk
    name: Durian
    path:
      - perl/Core
      - perl/site/gtssk
    repo: ssh://cvs@irsay.in.gtsgroup.cz/~cvs/git/Durian
    tree_ish: _migration
# nepovinny parametr - shell nebo perl scripty, ktere se spusti po
# instalaci (pred spustenim sluzeb)
post_install:
   - check_configuration.pl
   - mydir/create_some_directory.sh

=end INPUT_YAML

=cut

sub sources { return @{ shift()->_sources } }

sub source_info {
    my $this = shift;

    my $mi = $this->_source_info;
    return @_ ? $mi->{ shift() } : $mi;
}

sub new {
    my $class      = shift;
    my $fields_ref = shift;

    $fields_ref->{module_name} or die "Module name is missing\n ";
    $fields_ref->{version} or die "Versio is missing\n ";

    my $sources = delete $fields_ref->{sources} || [];
    my $release = bless {
        sources     => [],
        source_info => {},
        %$fields_ref
    } => $class;
    $release->_add_sources($sources);
    return $release;
}

sub _add_sources {
    my ( $this, $sources_ref ) = @_;

    for my $source_info ( @$sources_ref){
        my $name = $source_info->{name};
        $this->_source_info->{$name} = $source_info;
        push @{ $this->_sources }, $name;
    }
}

sub _call_system {
    my ( $this, $cmd, $label ) = @_;

    $label ||= "Calling '$cmd'";
    system($cmd) == 0 or die "$label failed: $!\n";
}

sub check_env {
    die "Can't install into global application hierarchy, PERL5LIB not set?\n"
        if Akar::Base->is_global;
}

# installs the modules
sub install_self {
    my $this = shift;

    $this->check_env();
    $this->_do_dir('_install_self');
}

sub _install_self {
    my $this = shift;

    $this->_unpack_self;

    warn "Running preinstalation\n";
    $this->preinstall();

    warn "Uninstalling previous\n";
    $this->uninstall();

    $this->install_sources();

    warn "Writing release_info " . $this->release_info_file . "\n";
    $this->write_release_info();
    warn "Running postinstallation\n";
    $this->postinstall();

    warn "Starting services....\n";
    $this->start_services;
    $this->create_start_stop_script();

    $this->log_installation();
}

sub install_sources {
    my $this = shift;
    for my $source ( $this->sources ) {
        my $source_info = $this->_source_info->{$source};
        for my $install ( @{ $source_info->{install} } ) {
            my $dir = $source  . '/' . $install;
            warn "installing $dir\n";
            $this->_call_system("Akar-Module-Install $dir");
        }
    }
}

sub log_installation {
    my $this = shift;

    # logging the installation
    my $logfile = $this->logfile;
    mkpath( dirname $logfile) if !-d dirname($logfile);
    my $fh = FileHandle->new(">>$logfile");
    my $now = DateTime->now( time_zone => 'local' );
    $fh->print(
        "$now: Installed "
            . $this->module_name
            . " version "
            . $this->version . "\n",
        pp( {%$this} ),
        "\n",
        '-' x 80,
        "\n\n",
    );
}

# deletes the previously installed modules
sub uninstall {
    my $this = shift;

    my $release_info = $this->read_release_info;

    for my $source ( @{ $release_info->{sources} } ) {
        my $info = $release_info->{source_info}{$source};
        for my $module ( @{ $info->{modules} } ) {
            $this->_uninstall_module($module);
        }
    }
    warn "Deleting " . $this->release_info_file . "\n";
    unlink $this->release_info_file;
}

# improvised deleting files from packlist
sub _uninstall_module {
    my ( $this, $module_name ) = @_;

    my $packlist = File::Spec->catfile(
        Akar::Base->perl5lib, 'auto',
        split( /::/, $module_name ), '.packlist'
    );
    -f $packlist or return;

    my $fh = FileHandle->new($packlist)
        or die "Can't open $packlist for reading: $!\n ";
    while ( my $file = $fh->getline ) {
        chomp($file);
        next if $file =~ /^#/;
        -f $file or next;
        warn "Deleting $file\n";
        unlink $file;
    }
    warn "Deleting $packlist\n";
    unlink $packlist;
}

sub release_info_file {
    my $this = shift;

    return File::Spec->catfile( Akar::Base->perl5lib, 'auto',
        split( /::/, $this->module_name ),
        'release.yml' );
}

sub write_release_info {
    my $this = shift;

    my $release_info_file = $this->release_info_file;
    -d dirname($release_info_file)
        or File::Path::mkpath( dirname($release_info_file) );

    YAML::DumpFile( $release_info_file, {%$this} );
}

sub read_release_info {
    my $this = shift;

    return -f $this->release_info_file
        ? YAML::LoadFile( $this->release_info_file )
        : {};
}

sub _unpack_self {
    my $this = shift;

    warn "Unpacking modules\n";
    my $fh_unpack = FileHandle->new("| tar xzf - ");

    # no warning 'once'
    # prevents warning
    # Name "main::DATA" used only once: possible typo
    # issued by Akar-Release-GitBuild having no __END__
    no warnings 'once';
    while ( my $line = <main::DATA> ) {
        $fh_unpack->print($line);
    }
}

sub preinstall { 
    my $this = shift;

    $this->stop_services;
}

sub postinstall { 
    my $this = shift;

    return unless defined($this->post_install);

    for my $script ( @{$this->post_install} ) {
        warn "* running post install script '$script'\n";    
        $this->_call_system("chmod u+x './_post_install/$script'");
        $this->_call_system("./_post_install/$script");
    }
}

sub dist_file {
    my $this = shift;
    return join( '-', $this->module_name, $this->version, 'install' ) . '.pl';
}

sub pack {
    my $this = shift;

    my $tempdir   = $this->_do_dir('export_sources');
    my $dist_file = $this->dist_file;
    warn "Building $dist_file\n";
    my $fh = FileHandle->new( '>' . $dist_file ) or die $!;
    $fh->print(
        join "\n",
        'use ' . ( ref($this) || $this ) . ';',

        #$this->code || '',
        '',
        'my $release = ' . $this->dump_self() . ';',
        '$release->run_build(@ARGV);',
        '__END__',
        ''
    );
    $fh->close;

    $this->_call_system( "(cd $tempdir; tar czf - . ) >> $dist_file",
        'Building dist file' );
}

sub dump_self {
    my $this = shift;

    my %args = %$this;
    delete $args{source_info};
    $args{sources} = [ @{ $this->source_info }{ $this->sources } ];

    my $class = ref($this) || $this;
    return "$class->new(" . pp( \%args ) . ')';
}

# exports sources into current dir
sub export_sources {
    my ($this) = @_;

    # the modules are exported into temp directory
    for my $source ( $this->sources ) {
        my $info = $this->_source_info->{$source};

        my $repo     = $info->{repo};
        my $tree_ish = $info->{tree_ish};
        my @paths    = @{ $info->{path} };

        warn "Exporting $source $repo\n";
        if ( $repo =~ /^git/ ) {

            # we have to clone first
            my $cloned = $this->_do_dir(
                sub {
                    my $command
                        = join( ' ', 'git', 'clone', '--bare', $repo, '.' );
                    warn "Cloning $command\n";
                    $this->_call_system($command, 'Git cloning')
                }
            );
            $repo = $cloned;
        }
        my $command = join( ' ',
            'git',      'archive',      '--format', 'tar',
            '--prefix', "$source/", '--remote', $repo,
            $tree_ish,  @paths,         '|',        'tar',
            '-xf -' );
        warn "Using $command\n";
        $this->_call_system($command, 'git archive export');

        # looking 
        for my $install ( @{ $info->{install} } ) {
            my $build_PL = "$source/$install/Build.PL";
            -f $build_PL or die "No file $build_PL exist\n ";

            push @{$info->{modules}}, $this->_find_module_name( $build_PL );
        }

    }

    if ( defined( $this->post_install ) ) {
        mkdir('_post_install');
        my $curr_dir = Cwd::cwd();
        $this->_do_dir(sub {
            my $this = shift;

            for my $script ( @{$this->post_install} ) {
                if ( -r "$script" ) {
                    warn "Copying '$script' into package...\n";
                    $this->_call_system("cp --parents '$script' '$curr_dir/_post_install'");
                }
                else {
                    die "Can't read '$script' specified in post_install section";
                }
            }
        }, dirname($this->__config_filename));
    }
}

sub _do_dir {
    my $this    = shift;
    my $method  = shift;
    my $tempdir = shift || File::Temp::tempdir( UNLINK => 1 );

    my $olddir = Cwd::cwd();
    chdir($tempdir);
    $this->$method();
    chdir($olddir);
    return $tempdir;
}

sub _find_module_name {
    my ( $this, $build_pl ) = @_;

    # trying to find "real" module name from Build.PL
    # unfortunately sometimes the name from the structure
    # is not same as the name in Build.PL
    # apps/Durian/Charge-base contains Durian::Charge
    my $fh = FileHandle->new($build_pl)
        or die "Can't open $build_pl for read: $!\n ";
    my $text = join '', $fh->getlines;
    my ($module_name) = $text =~ /['"]?module_name['"]?\s*=>\s*['"](.*?)['"]/s
        or die "Can't find module name from $build_pl\n ";
    return $module_name;
}

# logs the installation
sub log_install {}

sub logfile {
    my $this = shift;

    return Akar::Base->app_data(
        join( '/', join( '-', split /::/, __PACKAGE__ ), 'install.log' ) );
}

# the script inside the built *.pl
sub run_build {
    my $this = shift;
    $this->build_cli->run(@_);
}

sub start_services {
    my $this = shift;
    for my $daemon ( $this->expand_services ) {
        warn "* Starting service '$daemon'...\n";
        if ( -r "$daemon" ) {
            $this->_call_system("$daemon start") ;
        } else {
            warn "'$daemon' was not found'\n";
        }
    }
}

sub restart_services {
    my $this = shift;
    for my $daemon ( $this->expand_services ) {
        warn "* Restarting service '$daemon'...\n";
        if ( -r "$daemon" ) {
            $this->_call_system("$daemon restart") ;
        } else {
            warn "'$daemon' was not found'\n";
        }
    }
}

sub stop_services {
    my $this = shift;
    for my $daemon ( reverse $this->expand_services ) {
        warn "* Stoppping service '$daemon'...\n";
        if ( -r "$daemon" ) {
            $this->_call_system("$daemon stop") ;
        } else {
            warn "'$daemon' was not found'\n";
        }
    }
}



# command line interface for *.pl
sub build_cli {
    my $this = shift;

    my $cli = Akar::CLI->new;
    $cli->add_action(
        'install - installs the archive',
        sub {
            $this->install_self;
        }
    );
    $cli->add_action(
        'unpack - unpacks the archive',
        sub {
            my $dir = join( '-', $this->module_name, $this->version );
            mkdir($dir);
            warn "Unpacking into $dir\n";
            $this->_do_dir( '_unpack_self', $dir );
        }
    );
    $cli->add_action(
        'restart - restart the services',
        sub { $this->restart_services; }
    );
    $cli->add_action(
        'stop - stops the services',
        sub { $this->stop_services; }
    );
    $cli->add_action(
        'start - starts the services',
        sub { $this->start_services; }
    );
    return $cli;
}

sub expand_services {
    my ($this) = @_;

    my @daemons;
    for my $mask (
        @{  $this->services || [];
        }
        )
    {
        push @daemons, glob( Akar::Base->app_home($mask) );
    }
    return uniq @daemons;
}

sub create_start_stop_script {
    my $this = shift;

    my @services = $this->expand_services;
    my $services_string = pp(\@services);
    my $command = Akar::Base->app_bin('Manage-Services');
    my $fh = FileHandle->new( '>' . $command ) or die $!;
    my $content = qq{#!/usr/bin/env perl

# This script was created at } . scalar(localtime) . qq{ 
# during installation release pack '$0' 
# DO NOT MODIFY THIS FILE MANUALLY

package My::Durian::Services;
use strict;
use Akar::Base;
use Akar::CLI;
use base qw/Class::Accessor/;

my \$services = $services_string;
};
    $content .= <<'_EOF';

__PACKAGE__->mk_accessors(qw/cli/);

sub build_cli {
    my $this = shift;

    my $cli = Akar::CLI->new();

    $cli->add_action("helphelp - print help", 
        sub { $this->cli->print_help(); } );

    for my $action (qw/stop start restart/) {
        $cli->add_action( "$action - $action Durian Services",
            sub { $this->_do_action($action); } );
    }
    $this->cli($cli);
}

sub _do_action {
    my $this = shift;
    my ($action) = @_;

    for my $service ( ($action eq 'stop' ? ( @$services ) : ( reverse @$services) ) ) {
        if ( -r $service ) {
            warn "Performing $action: $service\n";
            system ($service . " " . $action);
        } else {
            warn "'$service' not found\n";
        }
    }

}
1;

package main;

my $script = My::Durian::Services->new();
$script->build_cli->run(@ARGV);

_EOF
    $fh->print($content);
    $fh->close;
    system("chmod u+x $command");
    warn "Created script '$command' script for start|stop|restart Durian Services\n";

}

1;

__END__




=head1 NAME 

Akar-Release-Build - create release package for perl application

=head1 SYNOPSYS

    Akar-Release-GitBuild --config release-katka.yml

=head1 OPTIONS

=over 3

=item --config=<file>

    Configuration file in YAML format. See CONFIG FILE section

=back

=head1 DESCRIPTION

Akar-Release-GitBuild creates single-file deploy package. The package is
created according to configuration file from I<git> resources. The deployment
requires a valid I<Akar> perl environment and contains the following steps:

=over 3

=item * stopping all services specified in YML file

=item * deleting old perl modules from previous deployment

=item * installation of perl packages using I<Akar-Module-Install>

=item * running post install scripts specified in the config (optional)

=item * starting services in reverse order

=item * script Manage-Services is created 

=back

The script I<Manage-Services> is created in app/bin directory. 
It can be used for stopping, starting and restarting services.

=head1 CONFIG FILE

Simple example of YAML configuration file:

    ---
    module_name: Durian-SK
    version: 20111216-git-emilie
    services:
      - bin/*-Manager
      - bin/Durian-Umum-Transport-Processor
      - bin/Durian-Umum-Apache
    post_install:
      - deploy_postinstall/create_configuration.pl
      - release-katerina/add_enumerator.pl
    sources:
      - install:
          - perl/Core
        name: Akar
        path:
          - perl/Core
        repo: git@github.com:DAVOCZ/Akar.git
        tree_ish: master
      - install:
          - perl/Core
          - perl/site/gtssk
        name: Durian
        path:
          - perl/Core
          - perl/site/gtssk
        repo: ssh://cvs@irsay.in.gtsgroup.cz/~cvs/git/Durian
        tree_ish: release-sk-emilie


=head2 Parameters

=over 3

=item module_name

Identification - it is the first part of the final deploy package name


=item version

The second part of the final package name. Usually a release name prefixed
with YYYYMMDD for easy sorting in a directory.

=item restart

A list of services (daemons) which should be stopped before installation
of the deploy package. Services are stopped in the order and started in
reverse order after installation. The file name can containt unix wildcards.

=item post_install

A list of scripts (perl, shell,...) which will be run ater installation
of perl modules and before I<services> are started. The scripts are run
in defined order. Script must have sheebang on the first line for proper
interpretation, ex.


    #!/usr/bin/env perl
    use strict;
    use Akar::Base;

    opendir( my $dh, Akar::Base->app_config ) || die;
    while ( readdir $dh ) {
        print "Test: $_\n";
    }
    closedir $dh;


The location is B<relative> to I<config file>. For example the config YML
file is located in directory C</home/user/git/Durian/perl/deploy/site/gtssk/release.yml>
and the I<post_install> section contains:


   post_install:
      - demo/install_config.pl


the absolute path is
    

    /home/user/git/Durian/perl/deploy/site/gtssk/demo/install_config.pl


Scripts are packed with perl modules and they are run during deployment from
temporary directory. 


=item sources

This section declare a list of git sources for exporting and installing.

=over 3


=item install

A list of directories with Build.PL file inside. The installation
is provided via Akar-Module-Install for each item.

=item name

A name of the source

=item repo

Git repository URI

=item tree_ish

Git SHA commit identification, name of a tag or branch name. Referenced
commit will be exported.

=item path

Subdirectory or subdirectories in the repository - listed directories will
be packed into deploy package only.

=back

=back

=cut

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96:
