package Akar::CLI::_Option;
{
  $Akar::CLI::_Option::VERSION = '1.759';
}
use strict;
use warnings;

use base qw(Akar::CLI::_Optionlike);

use Carp qw(carp croak);
use overload
    'fallback' => 1,
    '""'       => sub { return shift()->name };

# Getopt::Long option specifier
__PACKAGE__->mk_ro_accessors(qw(optspec));

# Getopt::Long option specifier
__PACKAGE__->mk_ro_accessors(qw(variants));

# option argument
__PACKAGE__->mk_accessors(qw(arg_name));

# processing properties and checks
__PACKAGE__->mk_accessors(qw(on_parse));

__PACKAGE__->mk_accessors(qw(on_check));

# package parsing the option
__PACKAGE__->mk_accessors(qw(type_package));

sub is_group  { return 0 }

sub is_action { return 0 }

sub variants { 
    return @{shift()->_variants_accessor } 
}

# returns the text displayed in warning or die messages
sub the_option {
    my ($this) = @_;

    my @variants = map { "--$_" } $this->variants;
    my $the_option = 'Option '. shift(@variants);
    if (@variants){

        # more alternatives
        $the_option .= ' ('. join(', ', @variants). ')';
    }
    return $the_option;
}

sub compose_doc {
    my ($this) = @_;

    return (
        ( map { "=item $_"; } $this->synopsis ),
        ( grep {$_} $this->title, $this->description )
    );
}

# compose the documentation of the option from optspec and arg_name
# 'optspec' => 'file|f=s', 'arg_name' => 'FILE' yields
# ('--file FILE', '--f FILE') 
sub synopsis {
    my ($this) = @_;
    
    my @synopsis = map { $this->_synopsis($_); } $this->variants;
    return wantarray? @synopsis: $synopsis[0];
}

sub _synopsis {
    my ( $this, $variant ) = @_;

    my $optspec = $this->optspec;

    # negated option
    return ( "--$variant", "--no$variant" ) if $optspec =~ /\!/;

    # option with arg
    if ( $optspec =~ /[=:]/ ) {

        # argument
        my $arg_part = $this->arg_name
            || ( $optspec =~ /\%$/ ? 'KEY=VALUE' : 'ARG' );
        if ( $optspec =~ /:/ ) {
            $arg_part = "[$arg_part]";
        }

        my $line = "--$variant $arg_part";
        return $optspec =~ /\@/ ? "$line $line ..." : $line;
    }

    # no arg
    return '--' . $variant;
}

1;

__END__

=head1 NAME

Akar::CLI::_Option - Enhanced Getopt::Long option specifier

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
