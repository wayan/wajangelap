package Akar::CLI::_Optionlike;
{
  $Akar::CLI::_Optionlike::VERSION = '1.759';
}
use strict;
use warnings;

# passing CLI to subordinated objects
use base qw(Akar::Class::Accessor);

use Carp qw(carp croak);
use Scalar::Util qw(weaken);

# the name the option (action, argument, ...) is referred to
__PACKAGE__->mk_ro_accessors(qw(name));

__PACKAGE__->mk_ro_accessors(qw(_cli));

# option (action, arg, ...) documentation
__PACKAGE__->mk_accessors(qw(is_documented title description));

# must be supplied?
__PACKAGE__->mk_accessors(qw(is_mandatory));


sub new {
    my ( $class, $cli, $fields ) = @_;

    # reference must be weak to prevent circular references
    # cli -> option -> cli
    weaken($cli);
    return $class->SUPER::new(
        {   %{ $fields || {} },
            '_cli' => sub { return $cli; }
        }
    );
}

sub cli { return shift()->_cli->() }

# constraints
sub requires_any {
    my $this = shift;

    $this->cli->_requires_any($this, @_);
}

sub requires_all {
    my $this = shift;

    $this->cli->_requires_all($this, @_);
}

sub requires {
    croak "There's no method requires, use requires_any or requires_all\n ";
}

1;

__END__

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 

=head1 NAME

Akar::CLI::_Optionlike - an object belonging to command line interface (option,
action, arg, ...)

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
