package Akar::Module::Install;
{
  $Akar::Module::Install::VERSION = '1.759';
}
use strict;

use base qw(Class::Accessor::Grouped);

use File::Basename qw(dirname basename);
use File::Temp qw(tempdir);
use File::Spec;
use File::chdir;
use FileHandle;
use File::Spec::Functions qw(catfile);
use File::Path qw(rmtree);
use File::Find;
use Module::Build;
use Scalar::Util qw(refaddr blessed);
use Class::Prototyped;

use Carp qw(croak);
use List::MoreUtils qw(uniq insert_after first_index);

use Akar::Base;
use Akar::CLI;
use File::Slurp qw(slurp);
use ExtUtils::Packlist;
use YAML;

__PACKAGE__->load_config;

__PACKAGE__->mk_group_accessors('inherited', 'cvs_rev', 'cvs_main_rev');

#------------------------------------------------------------------------------  
# Command line interface
#------------------------------------------------------------------------------  
sub run {
    shift()->build_cli->run(@_);
}

sub build_cli {
    my $this = shift;

    my $cli = Akar::CLI->new(
        {   'title'       => 'Akar module installer',
            'description' => <<"END_DESCR",
Akar-Module-Install is a simplified while enhanced module installer.
It:

- tries to remove everything from the previous module installation
- doesn't process man pages and HTML pages, since nobody uses them
    
END_DESCR
        }
    );
    $cli->add_option(<<"END_CVS_REVISION");
cvs_rev=s{cvs_revision} - checkout will use -rev cvs_revision parameters
END_CVS_REVISION

    $cli->add_option(<<"END_CVS_MAIN");
cvs_main - checkout will use main trunk 
END_CVS_MAIN

    $cli->add_arg(<<"END_MODULE_OR_FILE");
module_or_file... - List of files or modules to install. Modules are checked
out, bundles (Bundle::*) are expanded.
END_MODULE_OR_FILE

    $cli->set_on_run(
        sub {
            my $script_call = shift();

            my $options_ref = $script_call->options;

            my $installer = $this->new( $options_ref);
            my @builds = $installer->expand_builds(
                @{ $script_call->value_of('module_or_file') },
            );
            $installer->install_builds( @builds);
        }
    );

    return $cli;
}

#------------------------------------------------------------------------------  

# works like new and clone together
sub new {
    my $proto      = shift;
    my $fields_ref = shift || {};

    my $class = ref $proto || $proto;
    return bless( { ref $proto ? %$proto : (), %$fields_ref } => $class );
}

#------------------------------------------------------------------------------  
#   CVS 
#------------------------------------------------------------------------------  

sub checkout_dir {
    my ($this) = @_;

    $this->{'_checkout_dir'} ||= do {
        my $templ = join( '-', split /::/, __PACKAGE__ ) . 'XXXX';
        tempdir( $templ, 'TMPDIR' => 1, 'CLEANUP' => 1 );
    };
}

# package can be subtree Cow::Request::*
# returns the build directory (directories)
sub checkout_module {
    my ( $this, $module ) = @_;

    local $CWD = $this->checkout_dir;

    if ($module =~ s/::\*?$//){
        # subtree
        my $checkout_subtree = $this->checkout_module($module);
        # looking for Build.PL
        my @build_pls;
        File::Find::find sub {
            push @build_pls, $File::Find::name if -f $_ && $_ eq 'Build.PL';
        }, $checkout_subtree;
        return map { dirname $_ } @build_pls;
    }
    my $cvs_module = join '/', 'apps', split /::/, $module;

    # there may be cvs_rev supplied
    my @cmd = (
        'cvs', '-Q',
        'checkout',
        (   $this->cvs_rev
                && !$this->cvs_main_rev ? ( '-r', $this->cvs_rev ) : ()
        ),
        $cvs_module
    );
    warn join(' ', 'Doing:', @cmd), "\n";
    system(@cmd) == 0
        or die "Checking out $cvs_module failed\n ";

    return $this->checkout_dir . '/' . $cvs_module;
}

#------------------------------------------------------------------------------  
#   Bundles
#------------------------------------------------------------------------------  

sub extract_bundle_modules {
    my ( $this, $bundle_build ) = @_;

    my $module = $bundle_build->module_name;
    my $source  = File::Spec->rel2abs(
        join( '/', 'lib', split( /::/, $module ) ) . '.pm',
        $bundle_build->build_dir );
    -f ($source) or die "No bundle module ($module) exists\n ";

    my @contents
        = grep { /^=head1 CONTENTS/ ... /^=/ and !/^=/ } slurp($source);

    # versions are ignored, first word from each line is returned
    return map {/^(\S+)/} @contents;
}

#------------------------------------------------------------------------------  
#   Loading builds Build
#------------------------------------------------------------------------------  

# looking upwards for the directory containing Build.PL
sub find_build_dir {
    my ( $this, $file ) = @_;

    my $dir = File::Spec->rel2abs( -d ($file) ? $file : dirname($file) );
    while ( dirname($dir) ne $dir ) {
        return $dir if -e File::Spec->catfile( $dir, 'Build.PL' );

        $dir = dirname($dir);
    }
    croak "Build.PL not found\n ";
}

# loads build either from package or file
sub expand_builds {
    my $this = shift;

    return map {
        my $build_dir =
              ( m{/} || -e $_ ) ? $this->find_build_dir($_)
            : ( /::/ || /^(\w+)$/ ) ? $this->checkout_module($_)
            : undef
            or die "Don't know whether $_ is a file or directory\n ";
        my $build = $this->load_build( $build_dir . '/Build.PL' );
        (   $build,
            $build->module_name =~ /^Bundle::/
            ? $this->expand_builds( $this->extract_bundle_modules($build) )
            : ()
        );
    } @_;
}

# retrieves the Module::Build (Akar::Module::Build) object from Build.PL
sub load_build {
    my ( $this, $build_pl ) = @_;

    my $build_dir = dirname($build_pl);
    local $CWD = $build_dir;

    # I redefine create_build_script so that no script is created
    # but the Module::Build object is remembered
    # I don't want any script to be created
    my $build;
    local *Module::Build::create_build_script = sub { $build = shift(); };

    # 2007-08-14 danielr I have to pass install path
    # "via command line", because ->install_path($hash)
    # doesn't work with newest Module::Build
    my $install_path = Akar::Base->install_path;
    local @ARGV = (
        'akar_home=' . Akar::Base->akar_home,
        (   !Akar::Base->is_global
            ? ( map { ( '--install_path', $_ . '=' . $install_path->{$_} ); }
                    keys %{$install_path}
                )
            : ()
        )
    );
    my $basename = basename($build_pl);
    do $basename;
    die $@                                                   if $@;
    croak "No Module::Build object created in ./Build.PL\n " if !$build;

    # adds singletons into

    add_method( $build, 'build_dir' => sub { return $build_dir } );

    my $orig_dispatch;
    add_method(
        $build,
        'dispatch' => sub {
            local $CWD = $_[0]->build_dir;
            return $orig_dispatch->(@_);
        },
        \$orig_dispatch
    );
    add_method(
        $build,
        'ACTION_build',
        # docs is skipped
        sub {
            my $self = shift;
            $self->depends_on('code');
        }
    );

    my $orig_install;
    add_method(
        $build,
        'ACTION_install',
        sub {
            my ($build) = @_;
            my $old_packlist = $this->packlist_for($build);
            my $retval = $orig_install->(@_);
            my $new_packlist = $this->packlist_for($build);
            $this->remove_uninstalled_files($old_packlist, $new_packlist);
            # performing the realclean
            warn "Cleaning the blib, ...\n";
            $build->dispatch('realclean');
            return $retval;
        },
        \$orig_install);
        
    return $build;
}

sub install_builds {
    my $this = shift;

    for my $build (@_){
        $build->dispatch('install');
    }
}

sub packlist_for {
    my ( $this, $build ) = @_;

    my $archdir = $build->install_destination('arch');
    my @ext     = split /::/, $build->module_name;
    my $path    = File::Spec->catdir( $archdir, 'auto', @ext, '.packlist' );
    return if !-f $path;

    my $pl = ExtUtils::Packlist->new;
    $pl->read($path);
    return $pl;
}

sub remove_uninstalled_files {
    my ( $this, $old_packlist, $new_packlist ) = @_;

    return if !$old_packlist || !$new_packlist;

    my @files_to_delete
        = grep { !exists $new_packlist->{$_} } keys %{$old_packlist};
    for my $to_delete (@files_to_delete) {
        warn "deleting $to_delete\n";
        unlink $to_delete;
    }
}

# -------------------------------------------------------------------------------
#   "Utilities"
# -------------------------------------------------------------------------------

# loads YAML into classdata - should be put into self package
sub load_config {
    my $class = shift;

    my $config_file
        = Akar::Base->app_config( join( '-', split /::/, $class ) . '.yml' );
    -r $config_file
        or return;
    my $cfg = YAML::LoadFile($config_file);
    UNIVERSAL::isa($cfg, 'HASH')
        or die "Invalid configuration file $cfg - HASHREF expected\n ";
    for my $param (keys %$cfg){
        $class->set_inherited($param => $cfg->{$param});
    }
}

# adds singleton method to the object
sub add_method {
    my ( $obj, $method, $subref, $orig_method_ref ) = @_;

    my $suffix = '::_singleton' . refaddr($obj);
    my $class  = ref $obj;
    if ( $class !~ /$suffix$/ ) {
        my $inherited = $class . $suffix;
        no strict 'refs';
        @{ $inherited . '::ISA' } = ($class);
        bless $obj, $inherited;
        $class = $inherited;
    }
    $$orig_method_ref = $class->can($method) if $orig_method_ref;
    no strict 'refs';
    *{ $class . '::' . $method } = $subref;
}

1;

__END__

sub _get_build {
    my($this, $arg) = @_;
    
    # build passed
    return $arg if blessed($arg);

    my $fields = ref($arg)? $arg: {'package' => $arg};

    return $this->retrieve_build($fields);
}

sub run {
    my ( $package, @args ) = @_;

    # root should not install into local directories
    # because the files cannot be later reinstalled
    # by ordinary user
    croak "ERROR: Root may not install into local directory ('"
        . Akar::Base->akar_home . "')"
        if $> == 0 && !Akar::Base->is_global;


    # @package_or_files is organized
    # (
    #   {'package' => $name },
    #   {'file'    => $name },
    # ....
    # )
    my ( @actions, @package_or_files, %opt );
    local @ARGV = @args;
    my $should_list;
    my $getopt_code = GetOptions(
        \%opt,

        # help is solved immediately
        'help|h' => sub {
            pod2usage(
                {   '-input'   => __FILE__,
                    '-verbose' => 2,
                    '-exitval' => 0,
                }
            );
        },
        '<>' => sub {
            my ($arg) = @_;
            push @package_or_files, { $package->_guess_type($arg) => $arg };
        },
        'file=s@'    => sub { push @package_or_files, {@_}; },
        'package=s@' => sub { push @package_or_files, {@_}; },

        # options
        $package->installer_optspecs,

        # actions are collected into @actions
        (   map {
                ( $_ => sub { push @actions, shift() } )
                } $package->installer_actspecs
        ),

        'list' => \$should_list,

        # action can be specified as option also
        'action=s@' => sub {
            my ( $opt, $action ) = @_;
            push @actions, split /\s*,\s*/, $action;
        },
    );
    if ( !$getopt_code ) {
        pod2usage(
            {   '-input'   => __FILE__,
                '-msg'     => 'Invalid options',
                '-exitval' => 2,
            }
        );
    }

    # creates installer from the options
    my $installer = $package->new(
        {   map {
                my $accessor = $_;
                my $value    = $opt{$accessor};

                # normalizing inhouse prefixes (this is the list of prefixes)
                # which can be divided by commas
                if ( $accessor eq 'inhouse_prefixes' ) {
                    $value
                        = [ grep {$_} map { split /\s*,\s*/, $_ } @$value ];
                }
                ( $accessor => $value );
                } grep { defined( $opt{$_} ) } $package->installer_accessors
        }
    );

    my @builds
        = $installer->complete_builds( map { $installer->_get_build($_) }
            @package_or_files );

    if ($installer->create_build_script){
        # nothing is made, the script was already created 
    }
    elsif ($should_list) {
        $installer->list_builds(@builds);
    }
    elsif (@actions) {
        $installer->run_actions( \@actions, @builds );
    }
    else {
        $installer->run_actions( ['install'], @builds );
    }
}

__END__

# options directly passed to installer
sub installer_optspecs {
    return qw(
        source_root|cvs_dir=s
        with_prereqs!
        recursive!
        check_versions!
        recovers_from_errors!
        cvs_rev=s
        uses_checkout|checkout|co!
        clean_after!
        silent!
        inhouse_prefixes|ihp=s@
        create_build_script|cb
    );
}

sub installer_accessors {
    my ($package) = @_;
    return map {/(\w+)/} $package->installer_optspecs;
}

# action specifiers
sub installer_actspecs {
    return qw(install test);
}

sub new {
    my ( $package, $fields ) = @_;

    $fields ||= {};
    return $package->SUPER::new(
        {   'check_versions' => 0,
            'with_prereqs'   => 0,
            'recursive'      => 0,
            'clean_after'    => 1,
            'uses_checkout'  => 1,
            %$fields,
        }
    );
}


# command line processing
sub run {
    my ( $package, @args ) = @_;

    # root should not install into local directories
    # because the files cannot be later reinstalled
    # by ordinary user
    croak "ERROR: Root may not install into local directory ('"
        . Akar::Base->akar_home . "')"
        if $> == 0 && !Akar::Base->is_global;

    # old "legacy" code
    my $legacy_opt_re = qw{^--?leg(a(cy?)?)?$};
    if ( grep {/$legacy_opt_re/} @args ) {
        require Akar::Module::Install::Legacy;
        return Akar::Module::Install::Legacy->run( grep { !/$legacy_opt_re/ }
                @args );
    }

    # @package_or_files is organized
    # (
    #   {'package' => $name },
    #   {'file'    => $name },
    # ....
    # )
    my ( @actions, @package_or_files, %opt );
    local @ARGV = @args;
    my $should_list;
    my $getopt_code = GetOptions(
        \%opt,

        # help is solved immediately
        'help|h' => sub {
            pod2usage(
                {   '-input'   => __FILE__,
                    '-verbose' => 2,
                    '-exitval' => 0,
                }
            );
        },
        '<>' => sub {
            my ($arg) = @_;
            push @package_or_files, { $package->_guess_type($arg) => $arg };
        },
        'file=s@'    => sub { push @package_or_files, {@_}; },
        'package=s@' => sub { push @package_or_files, {@_}; },

        # options
        $package->installer_optspecs,

        # actions are collected into @actions
        (   map {
                ( $_ => sub { push @actions, shift() } )
                } $package->installer_actspecs
        ),

        'list' => \$should_list,

        # action can be specified as option also
        'action=s@' => sub {
            my ( $opt, $action ) = @_;
            push @actions, split /\s*,\s*/, $action;
        },
    );
    if ( !$getopt_code ) {
        pod2usage(
            {   '-input'   => __FILE__,
                '-msg'     => 'Invalid options',
                '-exitval' => 2,
            }
        );
    }

    # creates installer from the options
    my $installer = $package->new(
        {   map {
                my $accessor = $_;
                my $value    = $opt{$accessor};

                # normalizing inhouse prefixes (this is the list of prefixes)
                # which can be divided by commas
                if ( $accessor eq 'inhouse_prefixes' ) {
                    $value
                        = [ grep {$_} map { split /\s*,\s*/, $_ } @$value ];
                }
                ( $accessor => $value );
                } grep { defined( $opt{$_} ) } $package->installer_accessors
        }
    );

    my @builds
        = $installer->complete_builds( map { $installer->_get_build($_) }
            @package_or_files );

    if ($installer->create_build_script){
        # nothing is made, the script was already created 
    }
    elsif ($should_list) {
        $installer->list_builds(@builds);
    }
    elsif (@actions) {
        $installer->run_actions( \@actions, @builds );
    }
    else {
        $installer->run_actions( ['install'], @builds );
    }
}

# 2007-09-20 shortcut used from Akar::Setup
sub install {
    my ( $this, @builds ) = @_;
    return $this->run_actions( ['install'], @builds );
}

use Data::Dumper;

# smart retrieve, handles error
sub _get_build {
    my($this, $arg) = @_;
    
    # build passed
    return $arg if blessed($arg);

    # only arg supplied it is a package
    return Akar::Module::Install::CPANBuild->new($arg) 
        if !ref($arg) 
        && !$this->is_inhouse_package($arg); 
    
    my $fields = ref($arg)? $arg: {'package' => $arg};

    return $this->retrieve_build($fields) if ! $this->recovers_from_errors;

    # with recovery from errors
    my $build = eval {
        $this->retrieve_build($fields);
    };
    return $build if !$@;

    # error
    warn 'Error retrieving build for '. join(' ', %$fields). ":\n$@\n";
    return;
}

sub extract_bundle_packages {
    my ( $this, $bundle_build ) = @_;

    my $package = $bundle_build->module_name;
    my $source  = File::Spec->rel2abs(
        join( '/', 'lib', split( /::/, $package ) ) . '.pm',
        $bundle_build->build_dir );
    -f ($source) or die "No bundle package ($package) exists\n ";

    my $fh = FileHandle->new($source);
    my @contents
        = grep { /^=head1 CONTENTS/ ... /^=/ and !/^=/ } $fh->getlines;

    # versions are ignored, first word from each line is returned
    return map {/^(\S+)/} @contents;
}

# makes the closure by Bundles and prerequisities
sub complete_builds {
    my ($this, @builds) = @_;

    return $this->_complete_builds({}, @builds);
}

sub _complete_builds {
    my ($this, $is_installed_ref, @builds) = @_;

    @$is_installed_ref{ map { $_->module_name } @builds } = (1) x @builds;

CLOSURE: 
    {
        my $added = 0;
        @builds = map {
            my $build       = $_;
            my $module_name = $build->module_name;
            my @prereqs     =
                  $this->with_prereqs
                ? $this->_expand_prereqs( $is_installed_ref, $build )
                : ();
            my @bundled =
                  $module_name =~ /^Bundle::/
                ? $this->_expand_bundle( $is_installed_ref, $build )
                : ();

            $added ||= @prereqs || @bundled;
            ( @prereqs, $build, @bundled );
        } @builds;

        redo CLOSURE if $added;
    }

    return @builds;
}

sub _expand_bundle {
    my ( $this, $is_installed_ref, $bundle_build ) = @_;

    my @builds;

PACKAGE:
    for my $package ( $this->extract_bundle_packages($bundle_build) ) {
        next PACKAGE if $is_installed_ref->{$package};

        $is_installed_ref->{$package} = 1;

        my $build = $this->_get_build($package)
        or next PACKAGE;
        push @builds,
            $this->recursive
            ? $this->_complete_builds( $is_installed_ref, $build )
            : $build;
    }

    return @builds;
}

    
sub _expand_prereqs {
    my ( $this, $is_installed_ref, $build ) = @_;

    my @builds;

    PACKAGE:
    for my $package ( keys %{ $build->requires } ) {
        next PACKAGE if $is_installed_ref->{$package};

        if ( $this->check_versions ) {
            my $spec = $build->requires->{$package};
            my $status = $build->check_installed_status( $package, $spec );
            next PACKAGE if $status->{'ok'};
        }

        $is_installed_ref->{$package} = 1;

        my $build = $this->_get_build($package)
            or next PACKAGE;
        push @builds,
            $this->recursive
            ? $this->_complete_builds( $is_installed_ref, $build )
            : $build;
    }

    return @builds;
}

# runs $bundle->dispatch($actions) for many bundles and many actions
sub run_actions {
    my ( $this, $actions_ref, @builds ) = @_;

    for my $build (@builds) {
        for my $action (@$actions_ref) {
            if ( $build->is_inhouse ) {
                warn '*' x 20,
                    ucfirst($action) . 'ing ' . $build->module_name, ' ',
                    '*' x 20, "\n", 'from ', $build->build_dir, "\n";

                if ( $this->recovers_from_errors ) {
                    eval { $build->dispatch($action); };
                    warn "ERROR: $@\n" if $@;
                }
                else {
                    $build->dispatch($action);
                }
            }
            else {
                warn '*' x 20, ' Skipping ' . $build->module_name, ' (CPAN) ',
                    '*' x 20, "\n";
            }
        }
    }
}

# show prerequisities
sub list_builds {
    my ( $this, @builds ) = @_;

    for my $build (@builds) {
        my $package = $build->module_name;
        warn $build->is_inhouse ? 'in house' : 'cpan ', ' : ', $package, "\n";
    }
}

sub find_package_build_dir {
    my ( $this, $package ) = @_;

    return $this->checkout_package($package) if $this->uses_checkout;
}

# return 1 if module should be installed from source_root
# 0 otherwise (installed from CPAN, for example)
sub is_inhouse_package {
    my ( $this, $package ) = @_;

    my @prefixes = ( qw(Akar Durian Manggis Supp CSR BModel OC Moai),
        @{ $this->inhouse_prefixes || [] } );
    my $re = '^(Bundle::)?(' . join( '|', @prefixes ) . ')::';
    return $package =~ /$re/;
}

# retrieves the Module::Build (Akar::Module::Build) object from Build.PL
# in working directory
sub retrieve_build {
    my ( $this, $opt_ref ) = @_;

    my ( $dir, $package, $file ) = @$opt_ref{qw(dir package file)};
    my $build_dir =
          $dir ? $dir : $package ? $this->find_package_build_dir($package)
        : $file ? $this->find_file_build_dir($file)
        : die "Don't know where to find build_dir";
    local $CWD = $build_dir;

    # I redefine create_build_script
    # so no script is created instead of the Module::Build object
    # is remembered
    # I don't want any script to be created
    my $build;
    my $orig_create_build_script = Module::Build->can('create_build_script');
    local *Module::Build::create_build_script = sub {
        $build = shift();    # setting build
        if ( $this->create_build_script ) {
            $build->$orig_create_build_script;
        }
        return;
    };

    # 2007-08-14 danielr I have to pass install path
    # "via command line", because ->install_path($hash)
    # doesn't work with newest Module::Build

    my $install_path = Akar::Base->install_path;
    local @ARGV = (
        'akar_home=' . Akar::Base->akar_home,
        (   !Akar::Base->is_global
            ? ( map { ( '--install_path', $_ . '=' . $install_path->{$_} ); }
                    keys %{$install_path}
                )
            : ()
        )
    );
    do './Build.PL';
    die $@                                                   if $@;
    croak "No Module::Build object created in ./Build.PL\n " if !$build;

    _wrap_method( $build, 'build_dir' => sub { return $build_dir } );

    _wrap_method(
        $build,
        'dispatch' => sub {
            my $orig_method = pop(@_);

            my ( $this, @args ) = @_;
            local $CWD = $this->build_dir;
            return $this->$orig_method(@args);
        }
    );

    _wrap_method( $build, 'is_inhouse' => sub { return 1 } );
    return $build;
}

# I should wrap_method from Akar::Class::Utils but these may not be installed yet
sub _wrap_method {
    my ( $obj_or_package, $method, $subref ) = @_;

    my $package;
    if ( ref($obj_or_package) ) {
        my $orig_package = ref($obj_or_package);
        $package = '_Singletons_for::obj' . refaddr($obj_or_package);

        # when called on object for the first time, the object is reblessed
        if ( $package ne $orig_package ) {
            no strict 'refs';
            *{ $package . '::ISA' } = [$orig_package];
            bless( $obj_or_package => $package );
        }
    }
    else {

        # called on package
        $package = $obj_or_package;
    }

    no strict 'refs';
    my $orig_method = $obj_or_package->can($method);
    *{ $package . '::' . $method } = sub {

        # the orig method is passed as last parameter
        return $subref->( @_, $orig_method );
    };
}

# Module may work even without Pod::Usage
sub pod2usage {
    require Pod::Usage;
    Pod::Usage::pod2usage(@_);
}

{

    package Akar::Module::Install::CPANBuild;

    # fake CPAN build
    sub new {
        my ( $package, $module_name ) = @_;

        return bless \$module_name => $package;
    }

    sub module_name { return ${ $_[0] }; }

    sub requires { return {} }

    sub build_dir { return undef }

    sub is_inhouse { return 0 }
}

sub checkout_dir {
    my ($this) = @_;

    my $checkout_dir = $this->_checkout_dir_accessor;
    if ( !$checkout_dir ) {
        my $checkout_dir_templ = __PACKAGE__;
        $checkout_dir_templ =~ s/::/-/g;
        $checkout_dir_templ .= '-XXXX';
        $checkout_dir
            = tempdir( $checkout_dir_templ, 'TMPDIR' => 1, 'CLEANUP' => 1 );
        $this->_checkout_dir_accessor($checkout_dir);
    }
    return $checkout_dir;
}

sub checkout_package {
    my ( $this, $package ) = @_;

    local $CWD = $this->checkout_dir;

    my $cvs_module = $package;
    $cvs_module =~ s{::}{/}g;
    $cvs_module = "apps/$cvs_module";

    # there may be cvs_rev supplied
    my @cmd = (
        'cvs', 'checkout', ( $this->cvs_rev ? ( '-r', $this->cvs_rev ) : () ),
        $cvs_module
    );
    system(@cmd) == 0
        or die "Checking out $cvs_module failed\n ";

    return $this->checkout_dir . '/' . $cvs_module;
}

# guess whether argument is a package or file
sub _guess_type {
    my ( $this, $package_or_file ) = @_;

    return 'file'    if -e $package_or_file;
    return 'file'    if $package_or_file =~ m{/};
    return 'package' if $package_or_file =~ /::/;
    return 'package'
        if $package_or_file =~ /^(\w+)$/;    # one word packages (Manggis)

    croak "Don't know what $package_or_file is\n ";
}

1;

__END__

=head1 NAME

Akar::Module::Install - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78: 
~


# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96:
