package Akar::List::Utils;
{
  $Akar::List::Utils::VERSION = '1.759';
}
use strict;
use warnings;

use base qw(Exporter);

# very miscellaneous utilitites - nothing exported on demand
our @EXPORT_OK
    = qw(grep_values map_values single_map first_defined pop_options hash_slice
        grep_keys map_keys);

use Carp qw(carp croak);
use Scalar::Util qw(blessed);

sub grep_values(&@) {
    my $sub = shift;

    my @ret;
    while ( my ( $k, $v ) = splice( @_, 0, 2 ) ) {
        push @ret, $k => $v if grep { $sub->($k) } $v;
    }
    return @ret;
}

sub map_values (&@) {
    my $sub = shift;

    my @ret;
    while ( my ( $k, $v ) = splice( @_, 0, 2 ) ) {
        push @ret, ( $k => $_ ) for map { $sub->($k) } $v ;
    }
    return @ret;
}

sub grep_keys(&@) {
    my $sub = shift;

    my @ret;
    while ( my ( $k, $v ) = splice( @_, 0, 2 ) ) {
        push @ret, $k => $v if grep { $sub->($v) } $k;
    }
    return @ret;
}

sub map_keys (&@) {
    my $sub = shift;

    my @ret;
    while ( my ( $k, $v ) = splice( @_, 0, 2 ) ) {
        push @ret, ( $_ => $v ) for map { $sub->($v) } $k ;
    }
    return @ret;
}


sub single_map(&$) {
    my ( $sub, $value ) = @_;

    local $_ = $value;
    my ($ret) = &$sub($value);

    return $ret;
}

sub first_defined {
    for my $val (@_) {
        return $val if defined($val);
    }
    return;
}

sub pop_options {
    my ($ary) = @_;

    return if !@$ary;

    my $last_arg = $ary->[-1];
    return pop(@$ary)
        if ref($last_arg)
        && !blessed($last_arg)
        && UNIVERSAL::isa( $last_arg, 'HASH' );

    return;
}

# returns list
sub hash_slice {
    my $hash = shift();

    my @slice = map { ( $_ => $hash->{$_} ) } grep { exists $hash->{$_} } @_;
    return wantarray ? @slice : {@slice};
}

1;

__END__

=head1 NAME

Akar::List::Utils - miscellaneous list utilities

=head1 Functions

All following functions are imported on demand.

=over 4

=item grep_values 

  grep_values {BLOCK} KEY1=>VALUE1, KEY2=>VALUE2, ...

Works similarly to grep, returns list of those KEY => VALUE pairs,
where BLOCK yields true value for VALUE. The VALUE is passed to block
in C<$_>.

=item map_values 

  map_values {BLOCK} KEY1=>VALUE1, KEY2=>VALUE2, ...

  my @x = map_values { 2 * $_ } 'a' => 10, 'b' => 20; 
  # gives 'a', 20, 'b', 20

Works similarly to map, for each KEY => VALUE pair maps the value by block.
The VALUE is passed to block in C<$_>.

=item grep_keys 

  grep_keys {BLOCK} KEY1=>VALUE1, KEY2=>VALUE2, ...

Works similarly to grep, returns list of those KEY => VALUE pairs,
where BLOCK yields true value for KEY. The KEY is passed to block
in C<$_>.

=item single_map

=item first_defined 

    first_defined val1, val2, ...

Returns first defined value from the list.

=item my $opt_ref = pop_options(\@_);

If the last parameter of passed array is unblessed hash it is popped and returned
(option argument of functions). 

=item hash_slice

    hash_slice(\%hash, \@keys)

=back


=cut

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96: 
