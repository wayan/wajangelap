package Akar::Trait::Class::Data;
{
  $Akar::Trait::Class::Data::VERSION = '1.759';
}
use strict;
use warnings;


use Class::Trait qw(base);

use Carp qw(carp croak);
use Class::ISA;
use Akar::Class::Utils qw(make_named_sub);
use Akar::List::Utils qw(pop_options);

sub mk_classdata {
    # mapping property - package
    my %class_data;

    # last parameter may be options
    my $options_ref = pop_options(\@_) || {};
    my ( $package_declared, $property ) = @_;

    # when data are not available for the package 
    # they are cloned from the SUPER package value
    my $auto_clone_sub = $options_ref->{'auto_clone_sub'};

    my $accessor = sub {
        @_ == 1
            or croak
            "$package_declared->$property() can't be called with parameters, "
            . "use $package_declared->set_$property instead\n ";

        my ($this) = @_;
        my $package_called = ref($this) || $this;

        # value set directly for the package
        return $class_data{$package_called}
            if exists $class_data{$package_called};

        # looking for value inherited
    SUPER_PACKAGE:
        for my $super_package ( Class::ISA::super_path($package_called) ) {
            next SUPER_PACKAGE if !exists $class_data{$super_package};

            my $super_value = $class_data{$super_package};
            return $auto_clone_sub
                ? ( $class_data{$package_called}
                    = $auto_clone_sub->($package_called, $super_value, $super_package ) )
                : $super_value;
        }

        return $class_data{$package_called} =
$auto_clone_sub->($package_called)
            if $auto_clone_sub;

        # nothing found
        return;
    };

    # returns the package (caller or super_class) which set the package
    my $author = sub {
        my ($this) = @_;

        my $package_called = ref($this) || $this;
        return $package_called
            if exists $class_data{$package_called};

        # looking for value inherited
    SUPER_PACKAGE:
        for my $super_package ( Class::ISA::super_path($package_called) ) {
            return $super_package
                if exists $class_data{$super_package};
        }

        # nothing found
        return;
    };

    my $mutator = sub {
        my ( $this, $new_value ) = @_;

        my $package_called = ref($this) || $this;
        $class_data{$package_called} = $new_value;
        return;
    };

    my $cleaner = sub {
        my ($this) = @_;

        my $package_called = ref($this) || $this;
        delete $class_data{$package_called};
        return;
    };

    # methods PROPERTY, set_PROPERTY, reset_PROPERTY
    # can be redefined, so they are set only when they don't exist
    # in the target package
    my $set_method = sub {
        my ($method, $code, $preserve) = @_;
        no strict 'refs';

        my $qname = join '::', $package_declared, $method;
        if (!$preserve || !*{ $qname }{'CODE'}){
            # I use make_named_sub so the $code look like being defined in
            # target package (which can be trait)
            make_named_sub($qname => $code);
            #*{ $qname } = $code;
        }
    };

    $set_method->( $property, $accessor, 1 );
    $set_method->( '_' . $property . '_accessor', $accessor );
    $set_method->( 'set_' . $property, $mutator, 1 );
    $set_method->( '_' . $property . '_mutator', $mutator );
    $set_method->( 'reset_' . $property, $cleaner, 1 );
    $set_method->( '_' . $property . '_cleaner', $cleaner );
    $set_method->( $property . '_author', $author, 1 );
}

sub mk_autocloned_classdata {
    my ( $this, $property, $auto_clone_sub ) = @_;

    $this->mk_classdata( $property, { 'auto_clone_sub' => $auto_clone_sub } );
}

1;

__END__

=head1 NAME

Akar::Trait::Class::Data - inheritable class data

=head1 SYNOPSIS

    {
    package MyPkg1;
    use Class::Trait qw(Akar::Trait::Class::Data);

    __PACKAGE__->mk_classdata('duration');
    }

    {
    package MyPkg2;
    use base qw(MyPkg1);

    __PACKAGE__->mk_classdata('length');
    }

    warn MyPkg1->duration; # undef
    MyPkg1->set_duration(102);
    warn MyPkg1->duration; # 102
    warn MyPkg2->duration; # 102
    warn MyPkg2->duration_author; # MyPkg1
    MyPkg2->set_duration(33);
    warn MyPkg2->duration;  # 33
    warn MyPkg2->duration_author; # MyPkg2
    MyPkg2->reset_duration; 
    warn MyPkg2->duration; # 102 again
    warn MyPkg2->duration_author; # MyPkg1 again

=head1 DESCRIPTION

Implements inheritable class data as Class::Data::Inheritable does.

=head1 IMPORTS

The trait imports the only method C<mk_classdata>.

  PACKAGE->mk_classdata(PROPERTY);

It create in callers package followin methods

=over 4

=item CLASS->PROPERTY()

Returns property value, set by class or super class.  Accessor only. 

=item CLASS->set_PROPERTY(NEW_VALUE)

Sets new value for property. Mutator only.

=item CLASS->reset_PROPERTY()

Resets the value for property just for the caller's class. 
If the property has value in super class, it becomes visible again. 

=item CLASS->PROPERTY_author

Returns the package which set the property.

=item CLASS->_PROPERTY_accessor()

Synonym for PROPERTY.

=item CLASS->_PROPERTY_mutator(NEW_VALUE)

Synonym for set_PROPERTY.

=item CLASS->_PROPERTY_cleaner()

Synonym for reset_PROPERTY.

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz>

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
