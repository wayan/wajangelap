package Akar::UTest::Class::Utils;
{
  $Akar::UTest::Class::Utils::VERSION = '1.759';
}
use strict;
use warnings;


use base qw(Test::Class);

# Test::More imports: 
#   ok use_ok require_ok is isnt like unlike is_deeply
#   cmp_ok skip todo todo_skip pass fail eq_array
#   eq_hash eq_set $TODO plan can_ok isa_ok diag BAIL_OUT
use Test::More;

# Test::Exception imports:
#   dies_ok lives_ok throws_ok lives_and
use Test::Exception;

use Akar::Class::Utils qw(lexical_cleaner);

use Carp qw(carp croak);

sub tested_module { return 'Akar::Class::Utils' }

sub test_lexical_cleaner: Test(6) {
   my ($this) = @_;

    my  $x = 10;
    {
        my $lc = lexical_cleaner(sub { $x = shift()}, $x);
        $x = 30;
    }
    is($x, 10, 'the x returns to previous value');

    throws_ok {
        my $lc = lexical_cleaner( sub { $x = shift() }, $x );
        $x = 30;
        die "Dieing\n";
        }
        qr(Dieing), '$@ is unchanged by cleaner';
    is($x, 10, 'the x returns to previous value even when block dies');

    throws_ok {
        my $lc = lexical_cleaner(sub { $x = shift(); eval {1}}, $x);
        $x = 30;
        die "Dieing\n";
    } qr(Dieing), '$@ is unchanged by eval in cleaner';
    is($x, 10, 'the x returns to previous value even when block dies');

    throws_ok {
        # using form allowed by prototype
        my $lc = lexical_cleaner { $x = shift(); die "Lexical die"}, $x;
        $x = 30;
        die "Dieing\n";
    } qr(Dieing), '$@ is unchanged by die in cleaner';
}


1;

__END__

=head1 NAME

Akar::Test::Class::Utils - Testing class for Akar::Class::Utils

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
