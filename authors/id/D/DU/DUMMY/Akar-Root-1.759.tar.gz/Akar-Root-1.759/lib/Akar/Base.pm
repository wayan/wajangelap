package Akar::Base;
{
  $Akar::Base::VERSION = '1.759';
}
use strict;
use warnings;

=head1 NAME

Akar::Base - determining paths in the application hierarchy 

=head1 SYNOPSIS

    use Akar::Base;

    my $log = Akar::Base->app_data('log/Anoa-Salwin-Integration/SOAP-extra.log');

=head1 DESCRIPTION

Akar::Base deals with paths in application hierarchy. It knows the application root,
path to binaries, ...  it can construct the absolute paths to different part
of the application tree. 

=head1 METHODS

=over 4

=item app_home(RELATIVE_PATH?)

Return the root of application hierarchy.
When a parameter is supplied then it is considered as path relative to the root 
and absolute path is returned.

=item app_config(RELATIVE_PATH?)

Return the path to directory in application hierarchy, where configuration files are stored.
When a parameter is supplied then it is considered as path relative to this directory 
and absolute path is returned.

=item app_data(RELATIVE_PATH?)

Return the path to directory in application hierarchy for variable data (logs, ...) .
When a parameter is supplied then it is considered as path relative to this directory 
and absolute path is returned.

=item app_bin(RELATIVE_PATH?)

Return the path to directory in application hierarchy, where the binaries are stored.
When a parameter is supplied then it is considered as path relative to this directory 
and absolute path is returned.

=item perl5lib

Returns the root of perl modules for the application hierarchy.

=item main_profile

Returns the path to the application main profile (F<$APP_CONFIG/profile.pm>)

=item subprofile_dir

Returns the directory where the subprofiles are stored (F<$APP_CONFIG/profile.d>).

=item subprofile(PACKAGE)

    my $subprofile = $this->subprofile('Anoa::Salwin::Integration');

    # returns  .../etc/Anoa-Salwin-Integration.pm

=back

=cut

BEGIN {
    require Akar::Base::Config;
}


use File::Spec;

sub app_home {
    my ( $this, @subdirs ) = @_;

    return $this->akar_home if !@subdirs;

    return File::Spec->rel2abs( File::Spec->catfile(@subdirs),
        $this->akar_home );
}

sub app_data {
    my ( $this, @subdirs ) = @_;

    return $this->app_home( File::Spec->catfile('var', @subdirs) );
}

sub app_config {
    my ( $this, @subdirs ) = @_;
    return $this->app_home( File::Spec->catfile('etc', @subdirs) );
}

sub app_bin {
    my ( $this, @subdirs ) = @_;

    return $this->app_home( File::Spec->catfile('bin', @subdirs) );
}

# returns the root of Perl modules
sub perl5lib {
    my ($this) = @_;

    # if installed globally there is no Perl root
    return if $this->is_global;
    return $this->app_home('lib/perl');
}

sub install_path {
    my ($this) = @_;

    return {
        'lib'    => $this->perl5lib,
        'arch'   => $this->perl5lib,
        'script' => $this->app_bin,
        'bin'    => $this->app_bin,
        'libdoc' => $this->app_home('man/man3'),
        'bindoc' => $this->app_home('man/man1'),
    };
}

sub install_path_as_build_params {
    my ($this) = @_;

    my $install_path = $this->install_path;
    return map { ( '--install_path', $_ . '=' . $$install_path{$_} ) }
        keys %{$install_path};
}

sub main_profile {
    my ($this) = @_;
    return $this->app_config('profile.pm');
}

sub subprofile_dir {
    my ($this) = @_;
    return $this->app_config('profile.d');
}

# subprofile for the package
sub subprofile {
    my ( $this, $package ) = @_;

    return File::Spec->catfile( $this->subprofile_dir,
        join( '-', split( /::/, $package ) ) . '.pm' );
}

sub require_main_profile {
    my ($this) = @_;

    my $profile = $this->main_profile;
    if ( -e ($profile) ) {
        eval { require($profile) };
        die $@ if $@;
    }
}

sub require_subprofiles {
    my ($this) = @_;

    for my $subprofile ( sort { $a cmp $b }
        glob( File::Spec->catfile( $this->subprofile_dir, '/*.pm' ) ) )
    {
        eval { require($subprofile) };
        warn "subprofile $subprofile failed:\n$@\n " if $@;
    }
}

sub map_global_path {
    my ($this, $subpath) = @_;

    return "/usr/bin/$subpath"
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
