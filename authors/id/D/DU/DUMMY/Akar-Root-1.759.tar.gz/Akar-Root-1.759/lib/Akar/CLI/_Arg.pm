package Akar::CLI::_Arg;
{
  $Akar::CLI::_Arg::VERSION = '1.759';
}
use strict;
use warnings;

# positional script parameter
use base qw(Akar::CLI::_Optionlike);

use Carp qw(carp croak);
use List::MoreUtils qw(first_index);

__PACKAGE__->mk_ro_accessors(
    'is_repetitive', # 1 if there may be more arguments
    'position',      # returns the position of parameter (starting with 1)
);

sub compose_doc {
    my ($this) = @_;

    return (
        ( map { "=item $_"; } $this->synopsis ),
        ( grep {$_} $this->title, $this->description )
    );
}

sub synopsis {
    my ($this) = @_;

    return $this->name . ( $this->is_repetitive ? ' ...' : '' );
}

1;

__END__

=head1 NAME

Akar::CLI::_Arg - Command line argument

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
