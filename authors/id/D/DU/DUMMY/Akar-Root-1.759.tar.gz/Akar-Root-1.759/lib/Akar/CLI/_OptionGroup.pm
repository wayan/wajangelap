package Akar::CLI::_OptionGroup;
{
  $Akar::CLI::_OptionGroup::VERSION = '1.759';
}
use strict;
use warnings;

use base qw(Akar::CLI::_Optionlike);

use Carp qw(carp croak);
use overload
    'fallback' => 1,
    '""'       => sub { return shift()->name };

# checks
__PACKAGE__->mk_accessors(qw(is_mandatory));

# the list of options (option names)
__PACKAGE__->mk_ro_accessors(qw(options));

# is exclusive - just one option may be supplied
__PACKAGE__->mk_accessors(qw(is_exclusive));

sub options {
    my ($this) = @_;
    return map { $this->cli->get_optionlike($_) } @{ $this->_options_accessor };
}

# adds new option
sub add_options {
    my ( $this, @options ) = @_;

    @{ $this->_options_accessor }
        = $this->cli->_optionlike_list( @{ $this->_options_accessor },
        @options );
}

sub compose_doc {
    my ($this) = @_;

    return (
        ( $this->title       ? ( '=head2 ' . $this->title ) : () ),
        ( $this->description ? $this->description           : () ),
        '=over 4',
        ( map { $_->compose_doc; } $this->options ),
        '=back',
    );
}

sub the_option {
    my ($this) = @_;

    return 'One of the options '
        . join( ', ', map { $_->the_option } $this->options );
}

1;

__END__

=head1 NAME

Akar::CLI::_OptionGroup - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
