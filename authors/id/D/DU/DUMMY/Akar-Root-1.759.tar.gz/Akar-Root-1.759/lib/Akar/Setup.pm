package Akar::Setup;
{
  $Akar::Setup::VERSION = '1.759';
}
use strict;

use base qw(Class::Accessor);

use Getopt::Long qw(GetOptions);
use File::Path qw(mkpath rmtree);
use File::Spec;
use File::chdir;
use File::Temp qw(tempdir);
use File::Basename qw(basename dirname);
use FileHandle;
use Module::Build;
use FileHandle;
use File::Slurp qw(write_file);


sub help_text {
    my ($this, @message) = @_;

    join("\n", @message, <<__HELP__);
$0 --akar_home=DIR 

Setups the akar directory hierarchy and installs the very basic Akar modules 
(Akar::Base, Akar::Install::Module)

  --akar_home   the root of application hierarchy  

__HELP__
}

sub run {
    (my $package, local @ARGV) = @_;

    my %options;
    GetOptions(\%options, qw(help|h akar_home=s is_global modules_root=s))
      or die $package->help_text('Invalid options');

    # help
    if ($options{'help'}) {
        print $package->help_text;
        exit(0);
    }

    # options check and absolute
    my $root = $options{'akar_home'}
        or die "No --akar_home option supplied\n ";

    -d ($root) or die "$root is not a directory\n ";
    $root = File::Spec->rel2abs($root);

    $package->make_dirs($root, \%options);
    $package->make_base_config($root, \%options);
}

sub make_dirs {
    my ($this, $root, $options_ref) = @_;

    local $CWD = $root;

    # global setup has neither bin nor lib/perl
    for my $subdir (
        qw(bin etc lib var),
        qw(lib/perl lib/perl/Akar),
        qw(lib/man/man1 lib/man/man3),
        qw(www lib/mason)
        )
    {
        warn "  creates $subdir\n";
        mkpath($subdir);
        -d ($subdir) or die "Couldn't create directory $subdir\n ";
    }
}

sub make_base_config {
    my ($this, $root) = @_;

    my $base_config = 'lib/perl/Akar/Base/Config.pm';
    my $abs_path = File::Spec->rel2abs('lib/perl/Akar/Base/Config.pm', $root);   
    mkpath(dirname $abs_path);
    warn "  creates $base_config\n";
    write_file($abs_path, <<"END_CONFIG");
package Akar::Base;
use strict;

# this file  is automatically generated
# do not modify it or your changes will be lost

sub is_global { return 0 }

sub akar_home { return '$root'; }

1;
__END__

=head1 NAME

Akar::Base::Config - application root for Akar::Base

=head1 DESCRIPTION

Module Akar::Base::Config is automatically generated when installed
and introduces some methods to Akar::Base class. In current installation
they look like:

  sub akar_home { return '/opt/novera/app'; }

  sub is_global { return 0 }

=over 4

=item akar_home

=item is_global

Has no meaning now.

=back

=head1 AUTHOR

Roman Daniel <roman.daniel\@davosro.cz>

END_CONFIG
}

1;
    
# vim: expandtab shiftwidth=4 tabstop=4 softtabstop=0
