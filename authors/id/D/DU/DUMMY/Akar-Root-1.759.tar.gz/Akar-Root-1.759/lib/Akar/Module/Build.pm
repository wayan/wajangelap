package Akar::Module::Build;
{
  $Akar::Module::Build::VERSION = '1.759';
}
use strict;
use warnings;

# Module::Build enhancements

use base qw(Module::Build);

use Carp qw(croak carp);
use File::Spec;
use File::Copy qw(copy);
use File::Path qw(mkpath);
use File::Glob qw(bsd_glob);
use File::Temp;
use File::Basename qw(basename dirname);
use FileHandle;
use File::chdir;
use Data::Dumper;

use Akar::Base;

# 2011-10-09 danielr
# missing prerequisities are fatal

my $check_failed_field = '_akar_prereq_check_failed';

sub new {
    my $class = shift;
    my $build = $class->SUPER::new(@_);
    $build->add_build_element('app');
    return $build;
}

sub check_prereq {
    my $this = shift;
    my $ok   = $this->SUPER::check_prereq(@_);

    if ( !$ok ) {

        # record for later use in build;
        $this->{properties}{_akar_prereq_failed} = 1;
    }
    return $ok;
}

# scriptmodules is a read only property
sub scriptmodules { return shift->{'properties'}{'scriptmodules'} }

sub main_module_name { return shift->{'properties'}{'main_module_name'} }

sub configures { return shift->{'properties'}{'configures'} }

# as is file_contents (files created automatically without being present in directory)
sub file_contents {
    my ($this) = @_;

    return map {
        UNIVERSAL::isa( $_, 'ARRAY' )
            ? Akar::Module::Build::FileContent->new(
            {   'path'    => $_->[0],
                'content' => $_->[1],
            }
            )
            : $_
    } @{ $this->{'properties'}{'file_contents'} || [] };
}


sub process_app_files {
    my ($this) = @_;

    my $files = $this->find_app_files;
    while ( my ( $file, $dest ) = each %$files ) {
        $this->copy_if_modified(
            'from' => $file,
            'to'   => File::Spec->catfile( $this->blib, $dest )
        );
    }
}

sub find_app_files {
    my ($this) = @_;

    my %app_files = (

        # files in app_directory
        # SQL files
        # tests to  be installed
        (   map { ( $_ => $this->app_target_path($_) ) }
                $this->_find_files_under('app'),
            $this->_find_files_under('sql'),
            $this->_find_files_under('test'),
            $this->_find_files_under('utils'),
            $this->_find_files_under('mason'),
            $this->_find_files_under('www'),
        ),

        # adding files that exist only "virtually"
        (   map {
                my $file_content = $_;
                my $abs_path     = $this->write_file_content($file_content);
                ( $abs_path => $this->app_target_path( $file_content->path )
                );
                } grep { $_->path =~ m{^(app|sql|test|utils)/} }
                $this->file_contents
        ),
    );

    return \%app_files;
}

# scriptmodules handling is moved into find_script_files
sub find_script_files {
    my ($this) = @_;

    my %files         = %{ $this->SUPER::find_script_files };
    my @scriptmodules = @{ $this->scriptmodules || [] };

    # scriptmodule scripts created on the fly
    for my $scriptmodule (@scriptmodules) {
        my $file_content = Akar::Module::Build::ScriptModule->new(
            ref $scriptmodule
            ? $scriptmodule
            : { 'module' => $scriptmodule } );
        my $path = $this->write_file_content($file_content);

        $files{$path} = $path;
    }

    # script files created on fly
    for my $file_content ( grep { $_->path =~ m{^bin/} }
        $this->file_contents )
    {
        my $abs_path = $this->write_file_content($file_content);
        $files{$abs_path} = $abs_path;
    }
    return \%files;
}

sub ACTION_install {
    my ($this) = @_;

    die "Akar::Module::Build: prerequisities check failed, can't continue.\n"
        if $this->{properties}{_akar_prereq_failed};

    $this->depends_on('install_inherited');
    $this->depends_on('install_postinstall');
    $this->depends_on('install_configuration');
}

sub ACTION_install_inherited {
    my ($this) = @_;

    $this->SUPER::ACTION_install;
}
    
sub install_map {
    my ($this) = @_;

    my %install_map = (
        %{ $this->SUPER::install_map },

        # app is installed into app
        File::Spec->catfile( $this->blib, 'app' ) => Akar::Base->app_home,
    );
    return \%install_map;
}

sub ACTION_install_postinstall {
    my ($this) = @_;

    -f './postinstall.pl' or return;

    warn "Running post installation\n";
    my @command = (
        'perl', ( Akar::Base->perl5lib ? '-I' . Akar::Base->perl5lib: () ),
        './postinstall.pl'
    );
    system(@command) == 0
        or die "Post installation failed\n ";
}

sub ACTION_install_configuration {
    my ($this) = @_;

    return if !$this->configures;

    while ( my ( $package, $value ) = each %{ $this->configures } ) {
        eval qq{require $package};
        croak $@ if $@;

        $package->modify_config( 'installation of ' . $this->module_name,
            $value );
    }
}

sub ACTION_test {
    my ($this) = @_;

    require Test::Harness;

    # Passing Akar environment to tests scripts run via Test::Harness,
    my @harness_switches
        = ( 
            # 2007-07-13 danielr
            # pridani adresare s moduly zaridi Module::Build
            # naopak adresar tu nesmi byt, protoze pak se 
            # v @INC testovaciho skriptu dostane PRED blib/lib
            # a cele testovani je k nicemu, protoze se testuje
            # ne instalovana, ale nainstalovana verze
            # '-I' . Akar::Base->perl5lib, 
	);
    local $Test::Harness::switches = join ' ',
        grep { defined($_) } $Test::Harness::switches, @harness_switches;

    $this->SUPER::ACTION_test;
}

# taken from Module::Build generated MANIFEST.SKIP
{
    my $skip = <<'END_SKIP';
# Avoid version control files.
\bRCS\b
\bCVS\b
,v$
\B\.svn\b

# Avoid Makemaker generated and utility files.
\bMakefile$
\bblib
\bMakeMaker-\d
\bpm_to_blib$
\bblibdirs$
^MANIFEST\.SKIP$

# Avoid Module::Build generated and utility files.
\bBuild$
\b_build

# Avoid temp and backup files.
~$
\.old$
\.bak$
\#$
\b\.#

# 2008-05-12 danielr
# Avoid swap files
\.swp$
END_SKIP

    my $skip_re = join '|', grep { !/^#/ && /\S/ } split /\n/, $skip;

    sub app_should_skip {
        my ( $this, $filename ) = @_;

        return $filename =~ /$skip_re/;
    }
}


# temporary directory used to create files on the fly
sub tempdir {
    my ($this) = @_;

    return $this->{'properties'}{'akar_tempdir'}
        ||= File::Temp::tempdir( 'CLEANUP' => 1 );
}

sub write_file_content {
    my ( $this, $file_content ) = @_;

    my $abs_path = File::Spec->catfile( $this->tempdir, $file_content->path );
    # warn "Writing $abs_path\n";
    if ( !-d ( dirname($abs_path) ) ) {
        mkpath( dirname($abs_path) );
    }
    my $fh = FileHandle->new( '>' . $abs_path )
        or die "Can't open '$abs_path' for write: $!\n ";
    $fh->print( $file_content->content );
    return $abs_path;
}

# find ordinary files under a directory
sub _find_files_under {
    my ( $this, $dir ) = @_;

    return if !-d($dir);

    my @files;
    File::Find::find(
        {   'wanted' => sub {
                if ( -f ($_) && !$this->app_should_skip($_) ) {
                    push @files, $_;
                }
            },
            'no_chdir' => 1
        },
        $dir,
    );
    return @files;
}

sub app_target_path {
    my ($this, $source) = @_;

    return $source if $source =~ m{^app/};

    # if main_module_name is set it is used to construct the path
    # for example SQL can be in Durian::Call::Rate::SQL
    # but it is installed into app/sql/Durian-Call-Rate/

    my $module_subdir = $this->main_module_name || $this->module_name;
    $module_subdir =~ s/::/-/g;

    # SQL file 
    if ($source =~ m{^(sql/)(.*)} ){
        return "app/lib/$1$module_subdir/$2";
    }

    # test and utils file
    if ($source =~ m{^((?:test|utils)/)(.*)} ){
        return "app/$1$module_subdir/$2";
    }

    # 2008-05-15 added www files installation
    if ($source =~ m{^(?:www|mason)/}){
        return "app/lib/$source";
    }

    croak "No target path known for '$source'\n ";
}

{

    # file installed but created on fly
    package Akar::Module::Build::FileContent;
{
  $Akar::Module::Build::FileContent::VERSION = '1.759';
}
    use base qw(Class::Accessor);

    __PACKAGE__->mk_accessors(qw(path content));
}

{

    # scriptmodule
    package Akar::Module::Build::ScriptModule;
{
  $Akar::Module::Build::ScriptModule::VERSION = '1.759';
}
    use base qw(Class::Accessor);

    __PACKAGE__->mk_accessors(qw(module method script args));

    sub new {
        my ( $class, $fields_ref ) = @_;

        my $module = $fields_ref->{'module'};
        $fields_ref->{'method'} ||= 'run';
        $fields_ref->{'script'} ||= join('-', split /::/, $module);
        return $class->SUPER::new($fields_ref);
    }

    sub path {
        my ($this) = @_;

        return 'bin/' . $this->script;
    }

    sub content {
        my ($this) = @_;

        my $module   = $this->module;
        my $method   = $this->method;
        my $perl5lib = Akar::Base->perl5lib;
        my $the_args = join ', ',
            ( map { Data::Dumper->new( [$_] )->Terse(1)->Dump; }
                @{ $this->args || [] } ), '@ARGV';
        return <<"END_SCRIPT";
#!/usr/bin/env perl
use strict;
use lib qw($perl5lib);

use $module;

$module->$method($the_args);
END_SCRIPT
    }

    # create script, set the permissions
    sub create_script {
        my ( $this, $script_path ) = @_;

        my $fh = FileHandle->new(">$script_path")
            or die "Can't open $script_path for write: $!\n";
        $fh->print( $this->content );
        $fh->close;

        # 2007-09-25 danielr copied from Module::Build
        my $mb = Module::Build->new(
            'module_name'  => 'NoModule',
            'dist_version' => '0.1',
        );
        $mb->fix_shebang_line($script_path);
        $mb->make_executable($script_path);
        return;
    }
}

1;

__END__

=head1 NAME

Akar::Module::Build - Module::Build enhancements

=head1 SYNOPSIS

Use Akar::Module::Build in your Build.PL as you would use Module::Build

    use strict;
    use Akar::Module::Build;

    Akar::Module::Build->new(
        'module_name' => 'Akar::Apache::Private',
        'requires'    => {
            'Apache'          => 0,
            'Class::Accessor' => 0,
        },
        'scriptmodules' => [qw(Akar::Apache::Private::Manager)]
    )->create_build_script;

=head1 DESCRIPTION

Akar::Module::Build is a subclass of Module::Build so it shares its behaviour
with several enhancements.

=head1 Scriptmodules

Akar::Modules::Build can automatically create scripts according to listed scriptmodules

    use strict;
    use Akar::Module::Build;

    Akar::Module::Build->new(
        'module_name'   => 'Akar::Config',
        'requires'      => {},
        'scriptmodules' => ['Akar::Config::Manager']
    )->create_build_script;

=head1 Application files

Module::Build takes care of Perl modules and scripts only (and some doc ...). 
With Akar::Module::Build all files under app directory are copied under application home
directory.  This feature was designed especially for library files (XSLT templates, Mason components) 
coming with a module.

CVS and similar (look into Akar::Module::Build for exact information) files are not copied.

=head1 Files created on the fly

Akar::Module::Build can via C<file_contents> property also install files 
which don't exist under build directory.

The value of C<file_contents> property is a reference to the array of arrays:

  [

    [ FILE_PATH1, FILE_CONTENT1 ],
    [ FILE_PATH2, FILE_CONTENT2 ],

  ],

It is usefull for short files whose content or name can be generated 
automatically. 

This feature is currently used only for application ofiles or script files 
(path must start with C<app/> or C<bin/>).

    use strict;
    use Akar::Module::Build;

    my $module_name = 'MyWeird::Module';

    # many configs created (no sense)
    my @file_contents = map {
        my $path
            = 'app/etc/' . join( '-', split /::/, $module_name ) . $_ . '.pm';

        my $content = join "\n", 'use Akar::Config;',
            "Akar::Config->set_param('MyWeird/Module/Param$_' => '$_');", '';
        [ $path => $content ];
    } 1 .. 3;

    Akar::Module::Build->new(
        'module_name' => $module,
        'requires'    => {
            'Apache'          => 0,
            'Class::Accessor' => 0,
        },
        'file_contents' => \@file_contents,
    )->create_build_script;

=head1 Post installation script

If C<postinstall.pl> is found in the top-level directory of the module distribution then it is run
at the end of action install with paths properly set.

In postinstallation script you can create run-time directories, add modules to SOAP server or
perform other useful activity. 

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz>

=cut


# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=96:

