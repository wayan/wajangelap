package Akar::UTest::CLI;
{
  $Akar::UTest::CLI::VERSION = '1.759';
}
use strict;
use warnings;


use base qw(Test::Class);

# Test::More imports: 
#   ok use_ok require_ok is isnt like unlike is_deeply
#   cmp_ok skip todo todo_skip pass fail eq_array
#   eq_hash eq_set $TODO plan can_ok isa_ok diag BAIL_OUT
use Test::More;

# Test::Exception imports:
#   dies_ok lives_ok throws_ok lives_and
use Test::Exception;

use Akar::CLI;
use Carp qw(carp croak);

sub tested_module { return 'Akar::CLI' }

sub sample_cli {
    my ($this) = @_;

    my $cli = Akar::CLI->new;
    $cli->add_option('from=s{Date} - Start of period');
    $cli->add_option('to=s{Date} - End of period');
    $cli->add_option_group( 'period', [qw(from to)] );
    $cli->add_action('list|vypis - lists the objects');
    $cli->add_action('show|ukaz - displays the objects');

    # empty action
    $cli->set_on_action( sub { my ( $script_call, $action ) = @_ } );
    return $cli;
}

sub test_parse: Test(2) {
    my ($this) = @_;

    my $cli = $this->sample_cli;
    throws_ok {
        $cli->add_option('from - Beginning of new era');
        }
        'Akar::CLI::Exception::DuplicitOption';
    throws_ok {
        $cli->add_option('from=$ - invalid option');
    } 'Akar::CLI::Exception::InvalidOptspec';
}

sub test_cli : Test(4) {
    my ($this) = @_;

    my $cli = Akar::CLI->new;
    isa_ok( $cli, 'Akar::CLI' );

    my $opt = $cli->add_option(<<"END_OPTION");
from=s{Date} - Start of period
END_OPTION
    is( $opt->name,    'from' );
    is( $opt->optspec, 'from=s' );
    is( $opt->title,    'Start of period' );
}

sub test_requirements: Test(7) {
    my ($this) = @_;

    {
        my $cli = $this->sample_cli;
        lives_ok { $cli->run; } 'without requirements script passes';
        $cli->requires_any('from');
        dies_ok  { $cli->run; } 'with requirements does not pass';
        lives_ok { $cli->run(qw(-from 2007-11-01)); }
            'when required is given, script passes';
    }
    {   
        # from requires to
        my $cli = $this->sample_cli;
        $cli->get_option('from')->requires_any('to');
        lives_ok { $cli->run } 'without from, everything is OK';
        lives_ok { $cli->run(qw(-to 2007-11-01)) } 'without from, with to, everything is OK';
        dies_ok { $cli->run(qw(-from 2007-11-01)) } 'with from and without to script fails';
        lives_ok { $cli->run(qw(-from 2007-11-01 -to 2008-11-01)) } 'with from and to, script passes';
    }
}

sub test_handlers: Test(3){
    my ($this) = @_;

    my $cli = $this->sample_cli;
    my @actions;

    my $action_called = '';
    $cli->set_on_action(
        sub {
            my ( $script_call, $action ) = @_;
            $action_called .= $action;
        }
    );
    $cli->run(qw(list show));

    is($action_called, 'listshow', 'Action handler is called twice');

    my $script_called = '';
    $action_called    = '';
    $cli->set_on_run(
        sub {
            my ($script_call) = @_;
            $script_called .= 'called';
        }
    );
    $cli->run(qw(list show));
    is($script_called, 'called', 'Run handler is called once');
    is($action_called, '', 'Action handler is not called');
}

sub test_scriptcall : Test(5) {
    my ($this) = @_;

    my $cli = $this->sample_cli;
    {
        my $script_call = $cli->parse_args(qw(-from 2007-12-02));
        is( $script_call->value_of('from'), '2007-12-02' );
        is_deeply(
            $script_call->value_of('period'),
            { 'from' => '2007-12-02' },
            'period group contains from and to'
        );
    }
    {
        my $script_call = $cli->parse_args(qw(-from 2007-12-02 -to 2008-12-01));
        is_deeply(
            $script_call->value_of('period'),
            {   'from' => '2007-12-02',
                'to'   => '2008-12-01'
            },
            'period group contains from and to'
        );
    }
    {
        my $script_call = $cli->parse_args;
        ok(!defined $script_call->value_of('period'), 'When no option from a group is supplied, group is undef');
    }
    {
        my $script_call = $cli->parse_args(qw(-from 2007-12-02 list vypis));
        is_deeply( [ $script_call->actions ],
            [qw(list list)], 'action synonyms are reported as actions' );
    }
}

1;

__END__

=head1 NAME

Akar::UTest::CLI - Unit testing class for Akar::CLI

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
