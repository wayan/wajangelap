package Akar::Root;
{
  $Akar::Root::VERSION = '1.759';
}
use strict;
use warnings;

# ABSTRACT: The core utilitities and libraries to be installed into perl system libraries

1;
# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:

