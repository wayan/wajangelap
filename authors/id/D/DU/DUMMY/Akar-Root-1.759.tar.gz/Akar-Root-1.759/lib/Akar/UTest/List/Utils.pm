package Akar::UTest::List::Utils;
{
  $Akar::UTest::List::Utils::VERSION = '1.759';
}
use strict;
use warnings;


use base qw(Test::Class);

# Test::More imports: 
#   ok use_ok require_ok is isnt like unlike is_deeply
#   cmp_ok skip todo todo_skip pass fail eq_array
#   eq_hash eq_set $TODO plan can_ok isa_ok diag BAIL_OUT
use Test::More;

# Test::Exception imports:
#   dies_ok lives_ok throws_ok lives_and
use Test::Exception;

use Akar::List::Utils qw(grep_keys map_values grep_values);
use Carp qw(carp croak);

sub tested_module { return 'Akar::List::Utils' }

sub test_grep_keys : Test(1) {
    my ($this) = @_;

    is_deeply(
        {   grep_keys { length($_) > 3 }
                'jan' => 'Fretka',
            'jirka'   => 'Sirka',
            'ota'     => 'Skota',
            'pepa'    => 'Zdepa'
        },
        {   'jirka' => 'Sirka',
            'pepa'  => 'Zdepa'
        }
    );
}

sub test_map_values: Test(2) {
    my ($this) = @_;

    is_deeply(
        [ map_values { uc $_ } qw(abraka dabra simsala -bim hokus pokus) ],
        [ qw(abraka DABRA simsala -BIM hokus POKUS) ]
    );

    is_deeply(
        [ map_values { /^-/? (): $_ } qw(abraka dabra simsala -bim hokus pokus) ],
        [ qw(abraka dabra hokus pokus) ]
    );
}

1;

__END__

=head1 NAME

Akar::UTest::List::Utils - Unit testing class for Akar::List::Utils

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
