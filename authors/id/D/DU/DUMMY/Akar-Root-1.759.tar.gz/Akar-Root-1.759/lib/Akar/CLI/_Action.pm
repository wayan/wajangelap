package Akar::CLI::_Action;
{
  $Akar::CLI::_Action::VERSION = '1.759';
}
use strict;
use warnings;

use base qw(Akar::CLI::_Option);

use Carp qw(carp croak);

__PACKAGE__->mk_accessors(qw(on_run));

sub _synopsis {
    my ( $this, $variant ) = @_;

    return $this->cli->has_bare_actions
        ? $variant
        : $this->SUPER::_synopsis($variant);
}

sub is_action { return 1 }

sub is_required { return 0 }

sub the_option {
    my ($this) = @_;

    my @variants = map { $this->cli->has_bare_actions ? $_ : "-$_" }
        $this->variants;
    my $the_option = 'Action ' . shift(@variants);
    if (@variants) {

        # more alternatives
        $the_option .= ' (' . join( ', ', @variants ) . ')';
    }
    return $the_option;
}

1;

__END__

=head1 NAME

Akar::CLI::_Action - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
